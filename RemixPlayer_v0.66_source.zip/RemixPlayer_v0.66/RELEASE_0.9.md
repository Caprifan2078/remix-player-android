# Remix Player 0.9.0 — autonomous rendering and reliability

## Changes
- New model-free mode for all 30 procedural genre templates: original stereo PCM stays intact, generated percussion, harmony-informed bass and transitions are added. No ONNX needed in this mode. A compatible installed/cached model enables the existing advanced mode, with instrument replacement. Model-free outputs labeled `Mix`. No claim of professional arrangement or stem separation in fallback mode.
- Two-pass bounded-memory RMS mastering for generated genre WAVs: target -15 dBFS RMS, sample peak ceiling -1 dBFS, gain capped at 2x, silence preserved. Not LUFS/true-peak mastering; cannot repair clipping already present in the input or intermediate signal.
- Batch rendering of any subset of 40 effects, or all 40; single decoding of original, size estimates and atomic batch rollback on rendering errors/cancellation. Output still WAV, user can export separately to FLAC/MP3. Lyrics retimed for each effect. Available under Studio.
- Switching a version of the current composition replaces the current queue item instead of rebuilding the whole queue. Uses Media3 replaceMediaItem, seek, prepare. Preserve queue order and play/pause intent; Android behavior needs QA.
- Saved stem mixes have 1.0 tempo ratio. Playback button pauses while buffering and prepares idle player for retry. Import deduplication uses a hash set instead of repeated linear scans. Genre progress updates the label rather than recreating the view every percent.

## Acceptance gates
- Host tests: see `tests/RESULT.txt` and `tests/MP3_RESULT.txt` from this version. Model-free tests use synthetic PCM; distinct outputs do not prove subjective genre quality. Model-free rendering tested without ONNX, not Android decoder integration.
- Android SDK, Gradle and emulator unavailable in this runtime. APK not compiled. Workflow present but not executed; no new repository created. No actual model inference or device tests performed. No Rust changes: no on-device performance profiling available.
- Before release: compile/lint, run Android smoke, test queue replacement during buffering/playing/paused/shuffle, validate live stem audio, import real model and licensed songs, measure CPU/RAM/thermal, verify new batch cancel and disk failure, assess audible results and lyrics. Current progress checklist stays 22/24 prototype implementation, not release readiness.
