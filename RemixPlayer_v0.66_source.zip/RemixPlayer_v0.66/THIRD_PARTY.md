# Зависимости и распространение

В архиве только собственный код интеграции; веса моделей, сторонний код, музыка и бинарные библиотеки не включены. В сборке используются внешние зависимости. До распространения APK необходимо собрать полный список транзитивных зависимостей, их лицензии, уведомления и условия распространения.
- LAME 3.100: https://lame.sourceforge.io/ (LGPL, точные условия в COPYING и исходном архиве). Скрипт скачивает исходный архив с фиксированным SHA256, компилирует отдельную заменяемую JNI-библиотеку. При распространении предоставить соответствующий исходный код LAME и JNI, тексты лицензий и возможность пересобрать/заменить библиотеку; не ограничивать реверс-инжиниринг для отладки изменений LGPL-компонента. APK пока не распространяется.
- Vosk API: https://github.com/alphacep/vosk-api (Apache-2.0), модели: https://alphacephei.com/vosk/models — лицензия зависит от конкретных весов. Пользователь импортирует ZIP модели сам.
- ML Kit: https://developers.google.com/ml-kit/language/translation/android — условия Google ML Kit; модели скачиваются по явному разрешению, не перепаковываются.
- ONNX Runtime: https://github.com/microsoft/onnxruntime (MIT); Demucs: https://github.com/facebookresearch/demucs (MIT, отдельно проверить лицензию конкретных весов).
- Media3 / AndroidX: https://developer.android.com/media/media3 (Apache-2.0).

- Jamendo API: https://developer.jamendo.com/v3.0/tracks — пользовательский Client ID, учитывать условия API и лицензию трека, не предлагать загрузку при audiodownload_allowed=false. Музыка не включена в проект.

## Каталог 0.15
HT-Demucs: https://huggingface.co/StemSplitio/htdemucs-onnx , ревизия d54ed9eb60e258ea82131c6ee14578628816456a, заявлена MIT. Vosk small: https://alphacephei.com/vosk/models , выбранные ru/en-us/es/pt/ja заявлены Apache-2.0. Веса не распространяются в исходном ZIP. Фактическое скачивание и проверка лицензий файлов до выпуска APK остаются открытыми.

## Каталог 0.36
AST GTZAN: https://huggingface.co/onnx-community/ast-finetuned-gtzan-ONNX/commit/7f313d5ef95bdd541b857c5385702194703b8185 — по метаданным издателя BSD-3-Clause, базовая модель ramsri818/ast-finetuned-gtzan. Используется model_int8.onnx, SHA-256 f7322d9c9a0d40e01bb4fc2feb303864bbfb93b0264e654e2a37f413b86a31bf. Веса не включены, лицензия всей цепочки требует окончательной проверки перед распространением. TorchAudio используется только для независимого теста на ПК, не включается в приложение.

## MERT — опциональный пользовательский импорт (v0.37)
Кандидат: https://huggingface.co/huyleit/mert-v1-95m-music-emotion-int8 . Карточка указывает Apache-2.0, но необходимо отдельно подтвердить права на базовые веса и производную модель. Веса не распространяются, не включены в каталог автоматической загрузки.

## v0.39
Whisper.cpp: https://github.com/ggml-org/whisper.cpp (MIT; фиксированный тег v1.7.6, сборка из исходников); ggml-tiny.bin: https://huggingface.co/ggerganov/whisper.cpp/blob/main/ggml-tiny.bin (MIT по карточке, SHA-256 be07e048e1e599ad46341c8d2a135645097a538221678b7acdd1b1919c6e1b21). Веса и сторонний исходный код не включены. При выпуске APK приложить лицензии и уведомления Whisper/ggml и всех транзитивных компонентов. PhraseWeights — собственные веса, обученные на собственных искусственных нотных шаблонах; NumPy требуется только для повторного обучения, не на Android.

## v0.57
HT-Demucs 6s FP16: https://huggingface.co/StemSplitio/htdemucs-6s-onnx/commit/49df9b6989cf2150840ea65b0bef77a2e471b678 . По карточке MIT, размер 136428532 байт, SHA-256 7ce55792e2231c93fbf92de95f5fd5b3a5e6c89f7db690dfd693e8f1dce56869. Веса не включены; фактическая проверка и лицензии до выпуска APK. GenrePhraseWeights — собственные веса на синтетических шаблонах, NumPy только для обучения.

## v0.62
Whisper multilingual base/small — MIT по карточке издателя: https://huggingface.co/ggerganov/whisper.cpp/blob/main/ggml-base.bin и https://huggingface.co/ggerganov/whisper.cpp/blob/main/ggml-small.bin. Проверка размера и SHA-256 в WhisperModelSpec.kt. Веса не включены; реальный инференс не проверялся.
