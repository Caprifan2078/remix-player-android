# Acceptance 0.65
Run `bash tests/run-audio-safety65.sh`, `bash tests/run-effects65.sh`, and `bash tests/run-core.sh` (full suite); `bash tests/run-mp3-host.sh`; `bash tests/run-library50.sh`; `bash tests/run-batch-history.sh`; `bash tests/run-whisper63.sh`; `bash tests/run-syntax-audit.sh`; `python3 tests/test-native-audit.py`; `python3 tests/test-release-gates.py`.
Android build and real device/model acceptance remain open.
