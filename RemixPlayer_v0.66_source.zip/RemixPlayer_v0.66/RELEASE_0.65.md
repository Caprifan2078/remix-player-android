# 0.65 — audio safety QA
- Sanitize nonfinite PCM before stateful DSP and EQ processing. Previously, invalid samples could escape bypass and poison subsequent filter state. Valid normalized PCM is unchanged by the new input guard.
- Added two regression tests, included in run-core.sh, and standalone audio-safety and effects test scripts.
- Fresh host tests: MP3 4 bitrates (LAME JNI, independent FFmpeg decode); FLAC 6 bit-exact round trips; all 41 effect profiles including original; EQ response/stereo/cancellation; library paging, grouped search, grouping, metadata; queue and playlist order; Whisper timestamp/merge logic; synthetic native packaging gates; Kotlin syntax.
- These are JVM/Linux tests using synthetic inputs, not Android UI or real neural model tests. The complete host suite was terminated by the execution timeout. Android preflight was blocked by missing Gradle, SDK, NDK and adb. GitHub source archive was not found; no APK or Android smoke evidence.
- See tests/qa65 for fresh logs. Existing historic acceptance files are not evidence of a fresh test run.
