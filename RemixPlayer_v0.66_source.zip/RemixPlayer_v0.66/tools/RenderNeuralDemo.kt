package app.remix.player
import java.io.File
fun main(args:Array<String>){require(args.size==1);NeuralInstrumental.render(File(args[0]),NeuralInstrumental.Settings(NeuralInstrumental.Style.DARK,140,9,true,8,39))}
