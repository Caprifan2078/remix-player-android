package app.remix.player
import java.io.File
fun main(args:Array<String>){require(args.size==1);val dir=File(args[0]).apply{mkdirs()};genrePhraseTests();for(i in listOf(1,6,11,16)){val style=GenreEngine.styles[i];val out=File(dir,style.name.replace(' ','_')+".wav");val frames=NeuralInstrumental.render(out,NeuralInstrumental.Settings(GenrePhrase.family(i),style.target,9,true,8,5703,genre=i));println("DEMO ${out.name}: $frames frames")}}
