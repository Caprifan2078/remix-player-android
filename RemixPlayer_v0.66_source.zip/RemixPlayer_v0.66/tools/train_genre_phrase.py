"""Reproducible small 30-class symbolic phrase model on original synthetic examples.
Rhythm derives from project GenreEngine profiles, not commercial recordings.
"""
import re
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/app/remix/player'
text=(src/'GenreEngine.kt').read_text()
rows=re.findall(r'Style\("([^"\n]+)",(\d+),intArrayOf\(([^)]*)\),intArrayOf\(([^)]*)\),intArrayOf\(([^)]*)\),([.\d]+)f',text)
assert len(rows)==30
rng=np.random.default_rng(5703)
X=[];Y=[];groups=[]
for genre,(name,bpm,kick,snare,hat,drive) in enumerate(rows):
    kick=set(map(int,kick.split(',')));snare=set(map(int,snare.split(',')));hat=set(map(int,hat.split(',')));drive=float(drive);bpm=int(bpm)
    # Three hand-authored procedural motif templates per style, with controlled variation.
    patterns=[]
    for variant in range(3):
        pattern=[]; last=1
        for slot in range(16):
            if slot==0: note=1
            elif slot in kick: note=[1,3,5,7][(genre+slot//2+variant)%4] if slot%4!=0 or drive>.45 else [1,5,3,7][(slot//4+variant)%4]
            elif slot in snare: note=[0,3,5,0][(genre+variant+slot//4)%4]
            elif slot in hat and (drive>.45 or (slot+genre+variant)%3==0): note=[0,5,3,7,0,1,8][(slot+genre*2+variant)%7]
            else: note=0 if bpm<160 or slot%3 else last
            pattern.append(note);last=note
        patterns.append(pattern)
    for example in range(160):
        minor=int(rng.integers(2)); prev=0; pat=patterns[example%3]
        for slot,t in enumerate(pat):
            if rng.random()<.12: t=int(rng.choice([0,1,3,5,7,8]))
            x=np.zeros(56,np.float32);x[genre]=1;x[30]=minor;x[31+slot]=1;x[47+prev]=1
            X.append(x);Y.append(t);groups.append(example%8==0);prev=t
X=np.array(X);Y=np.array(Y);test=np.flatnonzero(groups);train=np.flatnonzero(np.logical_not(groups))
w1=rng.normal(0,.12,(56,32)).astype(np.float32);b1=np.zeros(32,np.float32);w2=rng.normal(0,.12,(32,9)).astype(np.float32);b2=np.zeros(9,np.float32)
def pred(x):
 h=np.tanh(x@w1+b1);z=h@w2+b2;z-=z.max(axis=1,keepdims=True);q=np.exp(z);return h,q/q.sum(axis=1,keepdims=True)
def loss():return -np.log(pred(X[test])[1][np.arange(len(test)),Y[test]]+1e-10).mean()
initial=loss()
for i in range(2400):
 j=rng.choice(train,192,replace=False);x=X[j];h,q=pred(x);q[np.arange(len(j)),Y[j]]-=1;q/=len(j);dh=(q@w2.T)*(1-h*h);w2-=.075*h.T@q;b2-=.075*q.sum(axis=0);w1-=.075*x.T@dh;b1-=.075*dh.sum(axis=0)
final=loss();assert final<initial*.8
# Split weight initialization into small arrays to avoid JVM method size growth.
def arr(name,x):return '    val '+name+' = floatArrayOf(\n'+',\n'.join('        '+','.join(f'{v:.8f}f' for v in x.ravel()[i:i+12]) for i in range(0,x.size,12))+'\n    )\n'
(src/'GenrePhraseWeights.kt').write_text('package app.remix.player\n\n/** Generated on synthetic patterns by tools/train_genre_phrase.py. */\ninternal object GenrePhraseWeights {\n'+arr('w1',w1)+arr('b1',b1)+arr('w2',w2)+arr('b2',b2)+'}\n')
print(f'30 genre profiles; {len(Y)} synthetic tokens; holdout {len(test)}; cross entropy {initial:.4f} -> {final:.4f}; not an audio quality metric')
