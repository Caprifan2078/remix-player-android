# Приёмка v0.64

Все пункты ACCEPTANCE_0.63.md остаются открытыми до Android-проверки.

1. `python3 tests/test-release-gates.py` и `python3 tests/test-native-audit.py`.
2. Создать отдельный private GitHub repo. Вариант ZIP: поместить исходный архив и соответствующий workflow из поставки в корень и `.github/workflows/remix-build.yml`. Вариант исходников: распаковать содержимое папки проекта в корень нового репозитория, включая `.github/workflows/android.yml`.
3. Запустить Actions. Артефакт UNVERIFIED — промежуточный; кандидат только после host, lint, native и smoke API 29/35. Проверить настоящий ARM64 телефон, модели и звучание отдельно.
4. Локально `bash scripts/build-local.sh --device` при наличии требуемой среды и тестового устройства (mixer smoke записывает синтетические тестовые данные в debug-приложение; использовать только отдельный тестовый экземпляр).
