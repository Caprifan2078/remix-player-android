# Remix Player v0.20.0 — live overlap, adjustable genre rendering and tempo precision

Base: v0.19 (the newest available working archive; v0.18 was the last version presented in this conversation). No previous feature was intentionally removed. The preceding v0.19 changes are documented separately in RELEASE_0.19.md, with their own test evidence.

## Implemented in v0.20
- Experimental live crossfade, opt-in, 1/2/3/5/8 s: secondary ExoPlayer preloads next local URI without taking audio focus, primary player retains MediaSession and queue. Bounded constant-sum gain curve and handoff at incoming position. Short tracks use shorter overlap. Disabled for A/B, repeat-one, non-original playback effects, non-flat EQ, non-unit pitch/speed, mixer, unknown durations and duplicate current/next media IDs. Pause, seeks, changed queue, excessive drift, buffering/error or timeout abort overlap; preview released. If overlap is enabled but unavailable, normal transition without overlap occurs. No gapless or sample-accurate guarantee; audible discontinuity at handoff is possible. Runtime is not tested on Android.
- Genre studio: six immutable per-job gain controls (new drums/transitions, new bass, new lead, original instruments/mix, vocals, original drums), range 0–200%; five mix profiles. Vocal and old drum adjustments require separated stems; fallback mode only controls whole source and generated elements. Preserved across launches. The original default blend remains at 100%. RMS mastering can change final overall level. Existing output is not modified. No trained generative model added.
- Tempo estimation: fractional interpolation of autocorrelation peak, bounded BPM, rejection of nonfinite/negative energy and unsupported envelope rates. Old code reproduces 123.7 BPM as 122.44898. New synthetic cases 123.7/137.3/174.2 within 0.8 BPM after allowing half/double interpretation; this is not proof of beat/downbeat or variable-tempo accuracy on real songs.
- Android instrumentation extends existing local WAV playback/seek/queue/A-B/background scenario with an enabled overlap and verification of incoming position. It is deliberately a gate, not claimed to have passed. Requires real Android build.

## v0.19 carried forward
Lossless FLAC compression (fixed predictors + Rice coding; host FFmpeg roundtrips), anti-aliased pitch resampling, correlation-aware stereo analysis, A/B loop, export of EQ as audio version, build-local preflight. See RELEASE_0.19.md for prior evidence and limitations.

## Verification
- Current JVM log: tests/RESULT.txt. Previous failing tempo test: tests/TEMPO_REGRESSION_BEFORE.txt. Current host MP3 log: tests/MP3_RESULT.txt. Synthetic ELF alignment audit: tests/NATIVE_AUDIT.txt.
- The overlap host test verifies gain curve, duration bounds, eligibility and drift/handoff math only. It does NOT run Media3 or test audible handoff.
- `scripts/build-local.sh` preflight stops at Missing tool: gradle; no SDK or adb available. services.gradle.org DNS resolution failed. No GitHub repository was created or CI executed. No APK generated. Android compilation/lint, instrumentation, ONNX/Vosk real inference, Android UI and battery/memory profiling remain unverified. No Rust conversion or licensed weight redistribution performed.

## Release gates still open
Build APK + test APK; inspect dependency licenses; check real APK 16 KiB alignment; run emulator on API 29 and 35; verify overlap with pause/seek/reorder/shuffle/repeat/BT/headphones/focus loss; check actual separation, lyrics and generation on licensed real songs; profile CPU/RAM and temperature; visual acceptance. Still no trained genre/mood classifier or semantic verse/chorus classifier, reliable singing transcription, or professional learned arrangement generator. Do not use source-function counts as release-readiness percentages.

Current run: 41 PASS lines, exit 0; MP3 host exit 0 (4 bitrates).
