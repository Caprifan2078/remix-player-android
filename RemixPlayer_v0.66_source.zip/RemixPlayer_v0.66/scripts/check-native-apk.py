#!/usr/bin/env python3
"""Audit ELF LOAD segment and uncompressed ZIP entry alignment, not device compatibility itself."""
import struct, sys, zipfile
PAGE=16384
ABI_MACHINE={"arm64-v8a":183,"x86_64":62}

def elf_errors(data, expected_machine=None):
    if len(data)<64 or data[:6]!=b'\x7fELF\x02\x01': return ['not little-endian ELF64']
    phoff=struct.unpack_from('<Q',data,32)[0]; entsize,count=struct.unpack_from('<HH',data,54)
    if entsize<56 or not count or phoff+entsize*count>len(data): return ['invalid program header table']
    errors=[];loads=0
    machine=struct.unpack_from('<H',data,18)[0]
    if expected_machine is not None and machine!=expected_machine: errors.append(f'ELF machine {machine}, expected {expected_machine}')
    for i in range(count):
        typ,flags,off,va,pa,fs,ms,align=struct.unpack_from('<IIQQQQQQ',data,phoff+i*entsize)
        if typ!=1: continue
        loads+=1
        if align<PAGE or align&(align-1) or (va-off)%PAGE: errors.append(f'LOAD[{i}] align={align:#x}, offset={off:#x}, vaddr={va:#x}')
    if not loads: errors.append('no LOAD segment')
    return errors

def audit(path):
    errors=[]; abis=set(); count=0; libraries=set()
    with open(path,'rb') as raw,zipfile.ZipFile(raw) as z:
        for info in z.infolist():
            if not info.filename.startswith('lib/') or not info.filename.endswith('.so'): continue
            count+=1; abi=info.filename.split('/')[1];abis.add(abi)
            key=(abi,info.filename.split('/')[-1])
            problems=elf_errors(z.read(info),ABI_MACHINE.get(abi))
            if key in libraries: problems.append('duplicate native library')
            libraries.add(key)
            if info.compress_type==zipfile.ZIP_STORED:
                raw.seek(info.header_offset); h=raw.read(30)
                if len(h)!=30 or h[:4]!=b'PK\x03\x04':problems.append('invalid ZIP local header')
                else:
                    name,extra=struct.unpack_from('<HH',h,26);offset=info.header_offset+30+name+extra
                    if offset%PAGE:problems.append(f'uncompressed ZIP offset {offset:#x} not 16 KiB aligned')
            print(('FAIL' if problems else 'PASS')+' '+info.filename+(' — '+'; '.join(problems) if problems else ''))
            errors.extend(problems)
    if abis!={'arm64-v8a','x86_64'}: errors.append(f'unexpected ABI set {abis}')
    for abi in ('arm64-v8a','x86_64'):
        for name in ('libremixmp3.so','libremixwhisper.so','libonnxruntime.so'):
            if (abi,name) not in libraries: errors.append(f'missing {abi}/{name}')
    if not count: errors.append('no native libraries')
    for error in errors: print('ERROR:',error)
    print(f'Native libraries: {count}, problems: {len(errors)}')
    return 1 if errors else 0

if __name__=='__main__':sys.exit(audit(sys.argv[1]))
