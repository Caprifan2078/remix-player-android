#!/usr/bin/env python3
"""Reject partial, skipped or failed Android instrumentation runs."""
import re, sys
from pathlib import Path

def verify(output, expected):
    # Runner reports -3 ignored, -4 assumption failure, -2 failure, -1 error.
    if expected <= 0 or re.search(r'FAILURES|INSTRUMENTATION_FAILED|INSTRUMENTATION_ABORTED|Process crashed|INSTRUMENTATION_STATUS_CODE:\s*-[1-4]\b', output, re.I):
        return False
    counts = re.findall(r'\bOK \((\d+) tests?\)', output)
    ends = re.findall(r'^INSTRUMENTATION_CODE:\s*(-?\d+)\s*$', output, re.M)
    return counts == [str(expected)] and ends == ['-1']

if __name__ == '__main__':
    ok = verify(Path(sys.argv[1]).read_text(errors='replace'), int(sys.argv[2]))
    print('PASS: all expected instrumentation tests completed' if ok else 'FAIL: incomplete, skipped or failed instrumentation run')
    sys.exit(0 if ok else 1)
