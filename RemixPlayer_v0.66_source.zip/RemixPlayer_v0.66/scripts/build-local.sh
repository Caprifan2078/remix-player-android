#!/usr/bin/env bash
# Run from an extracted source project on a Linux host with the Android toolchain installed.
set -euo pipefail
cd "$(dirname "$0")/.."
missing=0
for cmd in java gradle python3 curl sha256sum make git cmake; do
  if ! command -v "$cmd" >/dev/null; then echo "Missing tool: $cmd" >&2; missing=1; fi
done
sdk="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [[ -z "$sdk" || ! -f "$sdk/platforms/android-35/android.jar" ]]; then echo 'Android SDK 35 missing. Set ANDROID_HOME and install platform android-35.' >&2; missing=1; fi
ndk="${REMIX_NDK_HOME:-$sdk/ndk/28.2.13676358}"
if [[ ! -d "$ndk/toolchains/llvm/prebuilt/linux-x86_64/bin" ]]; then echo 'Android NDK 28.2.13676358 missing.' >&2; missing=1; fi
if [[ "${1:-}" == --device ]] && ! command -v adb >/dev/null; then echo 'Missing tool: adb' >&2; missing=1; fi
if (( missing )); then exit 2; fi
export ANDROID_HOME="$sdk" REMIX_NDK_HOME="$ndk"
if ! gradle --version | grep -q '^Gradle 8\.9$'; then echo 'Use Gradle 8.9.' >&2; exit 2; fi
python3 tests/test-native-audit.py
python3 tests/test-release-gates.py
bash scripts/build-mp3-android.sh
bash scripts/build-whisper-android.sh
gradle --no-daemon :app:assembleDebug :app:assembleDebugAndroidTest --stacktrace
apk=app/build/outputs/apk/debug/app-debug.apk
[[ -s "$apk" ]]
python3 scripts/check-native-apk.py "$apk"
printf 'APK: %s\n' "$apk"
gradle --no-daemon :app:lintDebug --stacktrace
if [[ "${1:-}" == --device ]]; then
  command -v adb >/dev/null || { echo 'adb missing' >&2; exit 2; }
  bash tests/android-smoke.sh "$apk"
  bash tests/android-playback.sh app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk
  bash tests/android-mixer-smoke.sh
fi
