#!/usr/bin/env bash
# Linux x86_64 host, Android NDK r28c. Source is fetched and verified; no opaque binaries.
set -euo pipefail
cd "$(dirname "$0")/.."; root="$PWD"
ndk="${REMIX_NDK_HOME:-${ANDROID_HOME:?}/ndk/28.2.13676358}"
tool="$ndk/toolchains/llvm/prebuilt/linux-x86_64/bin"
work=$(mktemp -d);trap 'rm -rf "$work"' EXIT
curl --fail --location --retry 3 -o "$work/lame.tar.gz" https://download.videolan.org/pub/contrib/lame/lame-3.100.tar.gz
printf '%s  %s\n' ddfe36cab873794038ae2c1210557ad34857a4b6bdc515785d1da9e175b1da1e "$work/lame.tar.gz" | sha256sum -c -
for abi in arm64-v8a x86_64; do
  case "$abi" in arm64-v8a) host=aarch64-linux-android;; x86_64) host=x86_64-linux-android;; esac
  mkdir -p "$work/$abi"; tar xzf "$work/lame.tar.gz" -C "$work/$abi" --strip-components=1
  cd "$work/$abi"
  CC="$tool/${host}26-clang" AR="$tool/llvm-ar" RANLIB="$tool/llvm-ranlib" CFLAGS='-O2 -fPIC -Wno-error=implicit-function-declaration' ./configure --host="$host" --disable-shared --enable-static --disable-frontend --disable-decoder --disable-gtktest --disable-nasm
  make -C libmp3lame -j2
  mkdir -p "$root/app/src/main/jniLibs/$abi"
  "$tool/${host}26-clang" -O2 -shared -fPIC -Wl,-z,max-page-size=16384 "$root/native/mp3.c" libmp3lame/.libs/libmp3lame.a -lm -o "$root/app/src/main/jniLibs/$abi/libremixmp3.so"
done
