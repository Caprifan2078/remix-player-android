#!/usr/bin/env bash
# Optional native Whisper backend. Uses source from a fixed upstream release.
set -euo pipefail
cd "$(dirname "$0")/.."; root="$PWD"
ndk="${REMIX_NDK_HOME:-${ANDROID_HOME:?}/ndk/28.2.13676358}"
work=$(mktemp -d);trap 'rm -rf "$work"' EXIT
git clone --depth 1 --branch v1.7.6 https://github.com/ggml-org/whisper.cpp.git "$work/source"
git -C "$work/source" rev-parse HEAD
for abi in arm64-v8a x86_64; do
  cmake -S "$root/native/whisper" -B "$work/$abi" -DCMAKE_BUILD_TYPE=Release -DCMAKE_TOOLCHAIN_FILE="$ndk/build/cmake/android.toolchain.cmake" -DANDROID_ABI="$abi" -DANDROID_PLATFORM=android-26 -DANDROID_STL=c++_static -DWHISPER_SOURCE="$work/source"
  cmake --build "$work/$abi" --target remixwhisper --parallel 2
  mkdir -p "$root/app/src/main/jniLibs/$abi"
  cp "$work/$abi/libremixwhisper.so" "$root/app/src/main/jniLibs/$abi/"
done
