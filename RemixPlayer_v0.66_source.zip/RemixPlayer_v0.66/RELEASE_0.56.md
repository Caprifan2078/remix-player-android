# v0.56 — musical synthesis and release handoff

* Nine separate additive timbres for three styles and three pitched parts. Harmonic selection depends on note frequency; interpolated shared tables replace per-sample sine evaluation in pitched oscillators. The original note model is unchanged.
* Stereo pad voicing via opposite side contributions; mono sum preserved. Silence for unknown chords and previous articulation preserved.
* Targeted JVM test `bash tests/run-neural56.sh` passed, including the preceding articulation regression. The new test verifies harmonic spectra, high-frequency alias rejection, exact mute and stereo pad. No listening-based quality judgement has been performed. Same seed now produces different PCM compared with v0.55; existing exported audio is not changed.
* Android build remains blocked: Gradle, Android SDK, NDK and adb not installed; DNS failed for Gradle and Google download endpoints. No APK or Android/model acceptance claim.

## Release sequence agreed with the user
1. Complete remaining functionality and improve the neural generation and singing-ASR quality. Do not add scope for its own sake.
2. Developer technical acceptance: build the APK, execute instrumentation tests, test real weights and authorized audio, compare output quality, exercise UI, performance and reliability. Fix blocking defects and rerun.
3. Only after technical acceptance hand the APK to the user for practical testing on their own device. No claim that this source ZIP is an installable application.
4. Fix feedback and perform final release acceptance. No requirement for Rust unless measured performance indicates need.

The earlier v0.55 full host result is retained as `tests/CORE_0.55_FULL.txt`; it is not evidence of a v0.56 pass. See actual new logs for current results.

Final checks: full host regression exit 0 (99 PASS lines); syntax 169 files, no parse errors.
