#include <jni.h>
#include <whisper.h>
#include <string>
#include <vector>
#include <algorithm>
#include <cstdint>
#include <cctype>
// Group byte-level tokens into whitespace-separated words without splitting UTF-8.
// A word boundary inside a token or inconsistent token/segment text causes phrase fallback.
static bool space(unsigned char c){return c==' '||c=='\t'||c=='\r'||c=='\n';}
static std::string normalized(const std::string& s){std::string out;bool pending=false;for(unsigned char c:s){if(space(c)){pending=!out.empty();continue;}if(pending){out+=' ';pending=false;}out+=static_cast<char>(c);}return out;}
static std::string word_starts(whisper_context* ctx,int segment,const std::string& text,int64_t lo,int64_t hi){
    std::string combined;std::vector<int64_t> starts;bool inside=false;
    for(int j=0;j<whisper_full_n_tokens(ctx,segment);++j){
        auto token=whisper_full_get_token_data(ctx,segment,j);if(token.id>=whisper_token_eot(ctx))continue;
        const char* raw=whisper_full_get_token_text(ctx,segment,j);if(!raw)return "";std::string part(raw);combined+=part;int new_words=0;
        for(unsigned char c:part){if(space(c)){inside=false;continue;}if(!inside){inside=true;++new_words;if(new_words>1||token.t0<lo||token.t0>=hi||(!starts.empty()&&starts.back()>=token.t0))return "";starts.push_back(token.t0);}}
    }
    if(starts.size()<2||starts.size()>200||normalized(combined)!=normalized(text))return "";
    std::string out;for(auto t:starts){if(!out.empty())out+=',';out+=std::to_string(t);}return out;
}
extern "C" JNIEXPORT jlong JNICALL Java_app_remix_player_WhisperLocal_open(JNIEnv* e,jobject,jstring path){
    if(!path)return 0; const char* p=e->GetStringUTFChars(path,nullptr);if(!p)return 0;
    auto cp=whisper_context_default_params();cp.use_gpu=false;
    auto* ctx=whisper_init_from_file_with_params(p,cp);e->ReleaseStringUTFChars(path,p);return reinterpret_cast<jlong>(ctx);
}
extern "C" JNIEXPORT void JNICALL Java_app_remix_player_WhisperLocal_close(JNIEnv*,jobject,jlong h){if(h)whisper_free(reinterpret_cast<whisper_context*>(h));}
extern "C" JNIEXPORT jbyteArray JNICALL Java_app_remix_player_WhisperLocal_recognize(JNIEnv* e,jobject,jlong h,jfloatArray pcm,jstring language,jint threads){
    auto* ctx=reinterpret_cast<whisper_context*>(h);if(!ctx||!pcm||!language)return nullptr;
    const auto n=e->GetArrayLength(pcm);if(n<1||n>480000)return nullptr;
    std::vector<float> data(n);e->GetFloatArrayRegion(pcm,0,n,data.data());if(e->ExceptionCheck())return nullptr;
    const char* lang=e->GetStringUTFChars(language,nullptr);if(!lang)return nullptr;
    auto p=whisper_full_default_params(WHISPER_SAMPLING_GREEDY);p.n_threads=std::clamp(int(threads),1,4);p.language=lang;p.translate=false;p.no_context=true;p.print_progress=false;p.print_realtime=false;p.print_timestamps=false;p.print_special=false;p.token_timestamps=true;
    int rc=whisper_full(ctx,p,data.data(),n);e->ReleaseStringUTFChars(language,lang);if(rc!=0)return nullptr;
    std::string result;for(int i=0;i<whisper_full_n_segments(ctx);++i){std::string text=whisper_full_get_segment_text(ctx,i);for(auto& c:text)if(c=='\t'||c=='\n'||c=='\r')c=' ';auto lo=whisper_full_get_segment_t0(ctx,i),hi=whisper_full_get_segment_t1(ctx,i);auto words=word_starts(ctx,i,text,lo,hi);result+=std::to_string(lo)+"\t"+std::to_string(hi)+"\t"+text+(words.empty()?"":"\t"+words)+"\n";if(result.size()>1048576)return nullptr;}
    auto out=e->NewByteArray(static_cast<jsize>(result.size()));if(out)e->SetByteArrayRegion(out,0,static_cast<jsize>(result.size()),reinterpret_cast<const jbyte*>(result.data()));return out;
}
