/* Original JNI bridge. LAME is a separate, replaceable native dependency. */
#include <jni.h>
#include <stdint.h>
#include <stdlib.h>
typedef struct lame_global_struct *lame_t;
extern lame_t lame_init(void);
extern int lame_set_in_samplerate(lame_t,int), lame_set_num_channels(lame_t,int), lame_set_brate(lame_t,int), lame_set_quality(lame_t,int), lame_set_bWriteVbrTag(lame_t,int), lame_init_params(lame_t), lame_close(lame_t);
extern int lame_encode_buffer_interleaved(lame_t,short*,int,unsigned char*,int), lame_encode_flush(lame_t,unsigned char*,int);
JNIEXPORT jlong JNICALL Java_app_remix_player_Mp3Export_open(JNIEnv*e,jobject o,jint bitrate){(void)e;(void)o;lame_t l=lame_init();if(!l)return 0;if(lame_set_in_samplerate(l,44100)<0||lame_set_num_channels(l,2)<0||lame_set_brate(l,bitrate)<0||lame_set_quality(l,2)<0||lame_set_bWriteVbrTag(l,0)<0||lame_init_params(l)<0){lame_close(l);return 0;}return (jlong)(intptr_t)l;}
JNIEXPORT jint JNICALL Java_app_remix_player_Mp3Export_encodeBlock(JNIEnv*e,jobject o,jlong h,jshortArray a,jint frames,jbyteArray out){(void)o;if(!h||frames<0||frames>8192||(*e)->GetArrayLength(e,a)<frames*2||(*e)->GetArrayLength(e,out)<18000)return -1;short pcm[16384];unsigned char data[18000];(*e)->GetShortArrayRegion(e,a,0,frames*2,pcm);if((*e)->ExceptionCheck(e))return -1;int n=lame_encode_buffer_interleaved((lame_t)(intptr_t)h,pcm,frames,data,sizeof(data));if(n>0)(*e)->SetByteArrayRegion(e,out,0,n,(jbyte*)data);return n;}
JNIEXPORT jint JNICALL Java_app_remix_player_Mp3Export_finish(JNIEnv*e,jobject o,jlong h,jbyteArray out){(void)o;if(!h||(*e)->GetArrayLength(e,out)<18000)return -1;unsigned char data[18000];int n=lame_encode_flush((lame_t)(intptr_t)h,data,sizeof(data));if(n>0)(*e)->SetByteArrayRegion(e,out,0,n,(jbyte*)data);return n;}
JNIEXPORT void JNICALL Java_app_remix_player_Mp3Export_close(JNIEnv*e,jobject o,jlong h){(void)e;(void)o;if(h)lame_close((lame_t)(intptr_t)h);}
