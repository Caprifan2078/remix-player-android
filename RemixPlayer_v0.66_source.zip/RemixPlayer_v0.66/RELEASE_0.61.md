# v0.61 — recovered checkpoint
Based on the delivered v0.60 ZIP. Recovered the repeated-section defect fix only. The matching fallback now includes every non-overlapping occurrence of its selected reference pattern rather than only the best pair. This is audio feature matching, not semantic chorus classification.

Evidence: `tests/REPEAT_0.61_BEFORE.txt` fails on three repeats; `tests/REPEAT_0.61_AFTER.txt` passes both previous regression group and new three-repeat case. Reproduce with `bash tests/run-repeat61.sh`. Full JVM suite not rerun; old reports apply to previous versions. No APK or Android test. Earlier interrupted Whisper changes were not recovered and are not included. No other functional changes.
