package app.remix.player
import kotlin.math.*

/** Estimates tempo from a 100 Hz energy envelope; deliberately reports weak estimates as unknown. */
object Tempo {
    data class Result(val bpm: Double, val confidence: Double)
    fun estimate(energy: List<Double>, hz: Int=100): Result? {
        if(hz !in 50..200||energy.size<hz*8||energy.size>hz*900||energy.any{!it.isFinite()||it<0||it>10})return null
        val flux=DoubleArray(energy.size){i->if(i<1)0.0 else max(0.0,ln1p(energy[i]*100)-ln1p(energy[i-1]*100))}
        val mean=flux.average();val signal=DoubleArray(flux.size){flux[it]-mean}
        val power=signal.sumOf{it*it};if(power<1e-8)return null
        fun correlation(lag:Int):Double {var a=0.0;var b=0.0;var c=0.0;for(i in lag until signal.size){val x=signal[i];val y=signal[i-lag];a+=x*y;b+=x*x;c+=y*y};return if(b*c>0)a/sqrt(b*c)else 0.0}
        val low=(hz*60.0/190).roundToInt();val high=(hz*60.0/65).roundToInt();var best=low;var score=Double.NEGATIVE_INFINITY
        for(lag in low..high){val corr=correlation(lag);val bpm=hz*60.0/lag;val prior=1.0-.06*abs(ln(bpm/120));val value=corr*prior;if(value>score){score=value;best=lag}}
        val confidence=correlation(best);if(confidence<.12)return null
        // Refine the correlation peak between integer envelope samples.
        val left=correlation(best-1);val right=correlation(best+1);val curvature=left-2*confidence+right
        val delta=if(curvature< -1e-9)(.5*(left-right)/curvature).coerceIn(-.5,.5)else 0.0
        return Result((hz*60.0/(best+delta)).coerceIn(65.0,190.0),confidence.coerceIn(0.0,1.0))
    }
}
