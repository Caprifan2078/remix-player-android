package app.remix.player

import android.content.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.*
import android.view.*
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.*
import com.google.common.util.concurrent.ListenableFuture
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

private data class Track(val uri: String, val title: String, val artist: String, var group: String, var lyrics: String="", var favorite: Boolean=false, val tempoRatio:Double?=null, val album:String="",val folder:String="")
@UnstableApi
class MainActivity : ComponentActivity() {
    private val bg=Color.rgb(12,14,20); private val surface=Color.rgb(29,33,45); private val accent=Color.rgb(192,176,255); private val muted=Color.rgb(174,181,200)
    private val tracks=mutableListOf<Track>(); private var libraryIndex=LibraryIndex(tracks,Track::uri,Track::group); private var searchIndex:LibrarySearch<Track>?=null; private fun reindex(){libraryIndex=LibraryIndex(tracks,Track::uri,Track::group);searchIndex=null};private fun searchMatches()=(searchIndex?:LibrarySearch(tracks,Track::uri,Track::group){listOf(it.title,it.artist,it.album,it.folder)}.also{searchIndex=it}).find(query); private val io=Executors.newSingleThreadExecutor(); private val handler=Handler(Looper.getMainLooper())
    private var controller: MediaController?=null; private lateinit var future: ListenableFuture<MediaController>
    private val navButtons=linkedMapOf<String,Button>(); private lateinit var root: LinearLayout; private lateinit var body: LinearLayout; private lateinit var bar: LinearLayout; private lateinit var mainScroll:ScrollView;private var renderedScreen=""; private lateinit var now: TextView; private lateinit var play: Button; private lateinit var seek: SeekBar; private lateinit var time: TextView
    private var lyricsBusy=false; private var translationBusy=false; private var scanBusy=false; private var shownSongs=100; private var visibleTranslation=listOf<String>(); private var translationViews=listOf<TextView>(); private var analysisBusy=false; private val tempos=mutableMapOf<String,Tempo.Result>(); private var screen="Музыка"; private var query=""; private var onlyFavorites=false; private var addingTo: String?=null; private var lyricTarget: String?=null; private var lyricRevision: String?=null; private var dragging=false; private var activeLyrics=listOf<Lyric>(); private var lyricViews=listOf<TextView>(); private var lastLine=-2; private var lastWord=-2; private var wordLines=listOf<WordLyrics.Line>(); private var lyricScroll: ScrollView?=null
    private val playlists=linkedMapOf<String,MutableSet<String>>();private var selectedPlaylist:String?=null;private var sortMode=0;private var categoryMode=0;private var category:String?=null;private var randomVersions=false
    private fun loadPlaylists(){runCatching{val json=JSONObject(getSharedPreferences("library",MODE_PRIVATE).getString("playlists","{}")?:"{}");val keys=json.keys();while(keys.hasNext()){val name=keys.next();if(name.isBlank()||name.length>80)continue;val a=json.optJSONArray(name)?:continue;playlists[name]=LibraryRecovery.playlist(a.length(),{i->a.get(i) as? String?:error("Некорректная запись")},{id->libraryIndex.get(id)?.group}).toMutableSet()}}}
    private fun savePlaylists(){val json=JSONObject();playlists.forEach{(name,ids)->json.put(name,JSONArray(ids.toList()))};getSharedPreferences("library",MODE_PRIVATE).edit().putString("playlists",json.toString()).apply()}
    private fun visibleSongs(matches:Map<String,LibrarySearch.Match<Track>> = searchMatches())=tracks.filter{it.uri==it.group&&(!onlyFavorites||it.favorite)&&(selectedPlaylist==null||playlists[selectedPlaylist]?.contains(it.uri)==true)&&(category==null||categoryValue(it)==category)&&(it.uri in matches)}.let{songs->when(sortMode){1->songs.sortedBy{it.title.lowercase()};2->songs.sortedWith(compareBy({it.artist.lowercase()},{it.title.lowercase()}));else->selectedPlaylist?.let{playlists[it]}?.let{PlaylistOrder.apply(songs,it,Track::uri)}?:songs}}
    private fun newPlaylist(track:Track?=null){val field=EditText(this).apply{hint="Название плейлиста";setSingleLine()};android.app.AlertDialog.Builder(this).setTitle("Новый плейлист").setView(field).setNegativeButton("Отмена",null).setPositiveButton("Создать"){_,_->val name=field.text.toString().trim();if(name.isBlank()||name.length>80||playlists.containsKey(name)){toast("Название пустое или уже используется")}else{playlists[name]=mutableSetOf<String>().apply{if(track!=null)add(track.group)};savePlaylists();render()}}.show()}
    private fun choosePlaylist(t:Track){val names=playlists.keys.toList();android.app.AlertDialog.Builder(this).setTitle("Плейлисты · ${t.title}").setItems((names.map{if(playlists[it]?.contains(t.group)==true)"✓ $it" else it}+"＋ Создать").toTypedArray()){_,i->if(i==names.size)newPlaylist(t)else{val ids=playlists.getValue(names[i]);if(!ids.add(t.group))ids.remove(t.group);savePlaylists();render()}}.show()}
    private fun playlistFilter(){val names=playlists.keys.toList();android.app.AlertDialog.Builder(this).setTitle("Библиотека").setItems((listOf("Все песни")+names+"＋ Новый плейлист").toTypedArray()){_,i->when{ i==0->{selectedPlaylist=null;shownSongs=100;render()};i==names.size+1->newPlaylist();else->{selectedPlaylist=names[i-1];sortMode=0;shownSongs=100;render()}}}.setNeutralButton("Управление"){_,_->val name=selectedPlaylist;if(name==null)toast("Сначала выберите плейлист")else android.app.AlertDialog.Builder(this).setTitle(name).setItems(arrayOf("Переименовать","Удалить плейлист")){_,choice->if(choice==0)renamePlaylist(name)else android.app.AlertDialog.Builder(this).setMessage("Удалить плейлист «$name»? Песни останутся.").setNegativeButton("Отмена",null).setPositiveButton("Удалить"){_,_->playlists.remove(name);if(selectedPlaylist==name)selectedPlaylist=null;savePlaylists();render()}.show()}.show()}.show()}
    private fun renamePlaylist(old:String){
        val field=EditText(this).apply{setSingleLine();setText(old);selectAll()}
        android.app.AlertDialog.Builder(this).setTitle("Переименовать плейлист").setView(field).setNegativeButton("Отмена",null).setPositiveButton("Сохранить"){_,_->
            val name=field.text.toString().trim();if(name==old)return@setPositiveButton
            if(name.isBlank()||name.length>80||name in playlists||old !in playlists){toast("Название пустое, занято или плейлист изменился");return@setPositiveButton}
            val renamed=playlists.entries.map{(key,ids)->(if(key==old)name else key) to ids};playlists.clear();renamed.forEach{(key,ids)->playlists[key]=ids};if(selectedPlaylist==old)selectedPlaylist=name;savePlaylists();render()
        }.show()
    }
    private val reports=ReportCache<String,MusicAnalysis.Report>(12)
    private var lastMixerActive=false;private var previewButton:Button?=null;private var previewFrame=0L;private var previewSource:String?=null;private var previewLabel:TextView?=null;private var previewSeek:SeekBar?=null;private var previewDragging=false
    private fun stopPreview(){if(MixerSession.active){previewFrame=MixerSession.position();MixerSession.stop(this)} }
    private fun readMixerGains(source:String,count:Int):FloatArray=runCatching{val a=JSONArray(getSharedPreferences("mixer_gains",MODE_PRIVATE).getString(source,"[]"));require(a.length()==count);FloatArray(count){a.getDouble(it).toFloat().also{v->require(v.isFinite()&&v in 0f..1f)}}}.getOrElse{FloatArray(count){1f}}
    private fun persistMixerGains(g:FloatArray){previewSource?.let{getSharedPreferences("mixer_gains",MODE_PRIVATE).edit().putString(it,JSONArray(g.map{v->v.toDouble()}).toString()).apply()}}
    private fun updatePreview(g:FloatArray){if(MixerSession.request?.source==previewSource)MixerSession.update(g);persistMixerGains(g)}
    private var globalWorkRow:LinearLayout?=null;private var globalWorkText:TextView?=null;private var studioStatusView:TextView?=null;private val stemBusy get()=workGate.current()!=null; private var stemStatus=""; private var workTicket:WorkGate.Ticket?=null; private var lastWorkBusy=false
    companion object { private val workGate=WorkGate() }
    private fun workJournal()=getSharedPreferences("work_journal",MODE_PRIVATE)
    private fun cancelWork(){workTicket?.let{workGate.cancel(it);stemStatus="Отмена…"}}
    private fun showInterruptedWork(){if(stemBusy)return;val prefs=workJournal();val title=runCatching{prefs.getString("title",null)}.getOrNull()?:return;val id=prefs.getString("id",null);android.app.AlertDialog.Builder(this).setTitle("Предыдущая операция прервана").setMessage("$title\nОперация не подтверждена как завершённая. Проверьте библиотеку и файл назначения перед повтором. Автоматический повтор отключён. Пакет эффектов можно продолжить в Студии или Настройках.").setPositiveButton("Понятно"){_,_->if(!stemBusy&&prefs.getString("id",null)==id)prefs.edit().clear().apply()}.show()}
    private val stemIo=Executors.newSingleThreadExecutor()
    private val stemGains=mutableMapOf<String,FloatArray>()
    private val modelPicker=registerForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null&&!stemBusy) stemWork("Проверка модели…",{StemEngine.install(this,uri);Unit}){toast("Модель установлена")}
    }
    private fun <T> stemWork(status:String,work:()->T,discard:(T)->Unit={},success:(T)->Unit){
        if(stemBusy){toast("Другая операция ещё выполняется");return}
        val journal=workJournal();val ticket=workGate.begin(status){t->journal.edit().putString("id",t.id).putString("title",t.title).commit()}
        if(ticket==null){toast("Не удалось начать обработку: проверьте свободное место");return}
        workTicket=ticket;stopPreview();stemStatus=status;render()
        stemIo.submit{
            val result=if(workGate.enter(ticket))try{runCatching{work()}}finally{workGate.leave(ticket)} else Result.failure(java.util.concurrent.CancellationException("Отменено"))
            runOnUiThread{
                var confirmed=false
                try{
                    if(!isDestroyed&&!isFinishing&&!ticket.cancelled){result.onSuccess{success(it)}.onFailure{toast(it.message?:"Ошибка обработки")};confirmed=true}
                    else {result.onSuccess{value->runCatching{discard(value)}};if(!isDestroyed&&!isFinishing){toast("Обработка отменена. Проверьте файл назначения перед повтором.")}}
                }catch(e:Exception){if(!isDestroyed)toast(e.message?:"Не удалось сохранить результат")}
                finally{
                    workGate.finish(ticket){if(confirmed&&journal.getString("id",null)==ticket.id)journal.edit().clear().commit()}
                    workTicket=null;stemStatus="";if(!isDestroyed&&!isFinishing)render()
                }
            }
        }
    }
    private val picker=registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val target=addingTo; addingTo=null
        if(uris.isEmpty()) return@registerForActivityResult
        val existing=tracks.map{it.uri}.toSet(); val pending=uris.distinct().filter{it.toString() !in existing}
        if(pending.isEmpty()){toast("Файлы уже в библиотеке");return@registerForActivityResult}
        toast("Импорт: ${pending.size} файлов")
        io.execute {
            val result=pending.mapNotNull { uri -> runCatching {
                contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val name=contentResolver.query(uri,arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),null,null,null)?.use{if(it.moveToFirst())it.getString(0) else null}?:"Аудио"
                val retriever=MediaMetadataRetriever(); var title=name.substringBeforeLast('.'); var artist="Неизвестный исполнитель";var album=""
                try { retriever.setDataSource(this,uri); title=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?:title; artist=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)?:artist;album=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM).orEmpty() } catch(_:Exception) {} finally { runCatching{retriever.release()} }
                Track(uri.toString(),title,artist,target?:uri.toString(),album=album,folder=uri.lastPathSegment?.substringBeforeLast('/', "").orEmpty())
            }.getOrNull() }
            runOnUiThread { if(isDestroyed)return@runOnUiThread; val known=tracks.map{it.uri}.toHashSet();var added=0;result.forEach{if(known.add(it.uri)){it.group=GroupEdit.importRoot(target,it.uri){id->libraryIndex.get(id)?.group};tracks.add(it);added++}}; save(); render(); toast("Импортировано: $added/${pending.size}") }
        }
    }
    private var exportSource:String?=null
    private var mp3Bitrate=256
    private val exportPicker=registerForActivityResult(ActivityResultContracts.CreateDocument("audio/wav")){dest->handleExport(dest,"wav")}
    private val flacPicker=registerForActivityResult(ActivityResultContracts.CreateDocument("audio/flac")){dest->handleExport(dest,"flac")}
    private val mp3Picker=registerForActivityResult(ActivityResultContracts.CreateDocument("audio/mpeg")){dest->handleExport(dest,"mp3")}
    private fun handleExport(dest:Uri?,format:String){val source=exportSource;exportSource=null;if(dest==null||source==null)return;if(stemBusy){runCatching{contentResolver.delete(dest,null,null)};toast("Другая обработка уже запущена");return};val bitrate=mp3Bitrate
        stemWork("Подготовка экспорта ${format.uppercase()}…",{
            val raw=java.io.File.createTempFile("export-raw-",".pcm",cacheDir);var wav:java.io.File?=null;var encoded:java.io.File?=null
            try{val input=Uri.parse(source);updateWork("Подготовка WAV…");val w=java.io.File.createTempFile("export-wav-",".wav",cacheDir);wav=w
                val canonical=if(input.authority=="app.remix.player.files"&&input.pathSegments.firstOrNull()=="mixes"&&input.lastPathSegment?.endsWith(".wav",true)==true)runCatching{contentResolver.openInputStream(input)!!.buffered().use{r->w.outputStream().buffered().use{out->AudioFileCore.copyCanonical(r,out)}}}.getOrNull()else null
                check(!Thread.currentThread().isInterrupted);val frames=canonical?:StemEngine.decode(this,input,raw).also{w.outputStream().buffered().use{out->AudioFileCore.write(raw,out)}};raw.delete();val result=if(format=="wav")w else java.io.File.createTempFile("export-encoded-",".$format",cacheDir).also{f->encoded=f;updateWork("Кодирование ${format.uppercase()}…");w.inputStream().buffered().use{r->f.outputStream().buffered().use{out->if(format=="flac")FlacExport.encode(r,out)else Mp3Export.encode(r,out,bitrate)}}};require(result.length()>0&&frames>0);contentResolver.openOutputStream(dest,"w")?.use{out->result.inputStream().buffered().use{AudioFileCore.copy(it,out)}}?:error("Файл недоступен")
            }catch(e:Throwable){runCatching{contentResolver.delete(dest,null,null)};throw e}finally{raw.delete();wav?.delete();encoded?.delete()}
        }){toast("${format.uppercase()} экспортирован")}
    }
    private fun exportName(t:Track)=t.title.map{if(it.isLetterOrDigit()||it in " -_.·")it else '_'}.joinToString("").take(120).ifBlank{"Audio"}
    private fun exportMp3(t:Track){if(!Mp3Export.available){toast("MP3-кодировщик не включён в эту сборку");return};if(stemBusy)return;val rates=listOf(128,192,256,320);android.app.AlertDialog.Builder(this).setTitle("Качество MP3").setItems(rates.map{"$it кбит/с"}.toTypedArray()){_,i->mp3Bitrate=rates[i];exportSource=t.uri;mp3Picker.launch(exportName(t)+".mp3")}.show()}
    private fun exportWav(t:Track,flac:Boolean=false){if(stemBusy)return;exportSource=t.uri;if(flac)flacPicker.launch(exportName(t)+".flac")else exportPicker.launch(exportName(t)+".wav")}
    private fun clipDialog(t:Track){if(stemBusy)return;val panel=column();panel.addView(label("Создаёт отдельный WAV, не меняет исходник. Начало, конец и затухание — в секундах. До 15 минут.",14,muted));fun field(h:String,v:String)=EditText(this).apply{hint=h;setSingleLine();inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL;setText(v);panel.addView(this)}
        val a=field("Начало","0");val b=field("Конец",((controller?.duration?:0L).coerceIn(0,900000)/1000.0).toString());val f=field("Затухание с обеих сторон","0.2");val dialog=android.app.AlertDialog.Builder(this).setTitle("Вырезать фрагмент").setView(panel).setNegativeButton("Отмена",null).setPositiveButton("Создать",null).create();dialog.setOnShowListener{dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener{runCatching{fun ms(e:EditText):Long {val n=e.text.toString().replace(',','.').toDouble();require(n.isFinite()&&n in 0.0..900.0);return (n*1000).toLong()}
            val start=ms(a);val end=ms(b);val fade=ms(f);require(end>start&&fade<=10000);dialog.dismiss();stemWork("Создание фрагмента…",{val raw=java.io.File.createTempFile("clip-raw-",".pcm",cacheDir);val out=java.io.File.createTempFile("clip-",".wav",java.io.File(filesDir,"mixes").apply{mkdirs()});try{val frames=StemEngine.decode(this,Uri.parse(t.uri),raw);val clip=AudioFileCore.clipFromMs(start,end,fade,frames);out.outputStream().buffered().use{AudioFileCore.write(raw,it,clip){n->updateWork("Фрагмент: $n%")}};out}catch(e:Throwable){out.delete();throw e}finally{raw.delete()}},discard={file->file.delete()}){file->val uri=androidx.core.content.FileProvider.getUriForFile(this,"app.remix.player.files",file).toString();val v=Track(uri,t.title+" · фрагмент",t.artist,uri);tracks.add(v);save();toast("Фрагмент добавлен в библиотеку")}}.onFailure{toast(it.message?:"Неверный интервал")}}};dialog.show()}
    private val speechPicker=registerForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null&&!stemBusy)stemWork("Установка речевой модели…",{LocalTranscription.install(this,uri)}){toast("Модель установлена")}}
    private val scanPermission=registerForActivityResult(ActivityResultContracts.RequestPermission()){granted->if(granted)scanMusic()else toast("Доступ не разрешён. Можно импортировать файлы вручную.")}
    private fun requestScan(){val permission=if(Build.VERSION.SDK_INT>=33)android.Manifest.permission.READ_MEDIA_AUDIO else android.Manifest.permission.READ_EXTERNAL_STORAGE;if(checkSelfPermission(permission)==android.content.pm.PackageManager.PERMISSION_GRANTED)scanMusic()else scanPermission.launch(permission)}
    private fun scanMusic(){if(scanBusy)return;scanBusy=true;toast("Поиск музыки на устройстве…");io.execute{val found=runCatching{val result=mutableListOf<Track>();val base=android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;val cols=arrayOf("_id","title","artist","_display_name","album",if(Build.VERSION.SDK_INT>=29)"relative_path" else "_data");contentResolver.query(base,cols,"is_music != 0",null,"title ASC")?.use{c->while(c.moveToNext()&&result.size<30000){val uri=ContentUris.withAppendedId(base,c.getLong(0)).toString();result.add(Track(uri,c.getString(1)?:c.getString(3)?:"Аудио",c.getString(2)?:"Неизвестный исполнитель",uri,album=c.getString(4).orEmpty(),folder=c.getString(5).orEmpty().let{if(Build.VERSION.SDK_INT>=29)it else it.substringBeforeLast('/', "")}))}};result};runOnUiThread{if(!isDestroyed){scanBusy=false;found.onSuccess{list->val known=tracks.map{it.uri}.toHashSet();val byUri=list.associateBy{it.uri};for(i in tracks.indices){val old=tracks[i];val found=byUri[old.uri]?:continue;tracks[i]=old.copy(album=old.album.ifBlank{found.album},folder=old.folder.ifBlank{found.folder})};val added=list.filter{known.add(it.uri)};tracks.addAll(added);save();toast("Добавлено: ${added.size}. Импортированные файлы сохранены.")}.onFailure{toast("Не удалось прочитать медиатеку")};render()}}}}
    private fun rawLyrics(t:Track)=t.lyrics.ifBlank{if(t.tempoRatio!=null)tracks.find{it.uri==t.group}?.lyrics?.let{TimeStretch.lyrics(it,t.tempoRatio)}.orEmpty()else ""}
    private fun translationKey(t:Track,raw:String):String=java.security.MessageDigest.getInstance("SHA-256").digest((t.uri+"\u0000"+raw).toByteArray()).joinToString(""){"%02x".format(it.toInt() and 255)}
    private fun translated(t:Track,raw:String):List<String> = runCatching{val a=JSONArray(getSharedPreferences("translations",MODE_PRIVATE).getString(translationKey(t,raw),"[]"));(0 until a.length()).map{a.getString(it)}}.getOrDefault(emptyList())
    private fun chooseTranslation(t:Track,raw:String){if(translationBusy)return;val codes=LyricTranslation.languages.keys.toList();val names=LyricTranslation.languages.values.toTypedArray();android.app.AlertDialog.Builder(this).setTitle("Язык оригинала").setItems(names){_,i->android.app.AlertDialog.Builder(this).setTitle("Перевести на…").setItems(names){_,j->if(i==j)toast("Выберите разные языки")else android.app.AlertDialog.Builder(this).setTitle("Локальный перевод").setMessage("Текст обрабатывается на устройстве. При необходимости можно скачать языковые модели по Wi-Fi (около 30 МБ на модель).") .setNegativeButton("Отмена",null).setNeutralButton("Только офлайн"){_,_->translateLyrics(t,raw,codes[i],codes[j],false)}.setPositiveButton("Разрешить загрузку"){_,_->translateLyrics(t,raw,codes[i],codes[j],true)}.show()}.show()}.show()}
    private fun translateLyrics(t:Track,raw:String,source:String,target:String,download:Boolean){translationBusy=true;render();io.execute{val result=runCatching{LyricTranslation.translate(Lrc.parse(raw).map{WordLyrics.parse(it).text},source,target,download)};runOnUiThread{if(!isDestroyed){translationBusy=false;result.onSuccess{lines->getSharedPreferences("translations",MODE_PRIVATE).edit().putString(translationKey(t,raw),JSONArray(lines).toString()).apply();toast("Перевод сохранён")}.onFailure{toast("Перевод не выполнен: ${it.message}")};render()}}}}
    private fun recognizeLyrics(t:Track){if(stemBusy)return;val original=if(t.tempoRatio!=null)tracks.find{it.uri==t.group}?:t else t;val originalBefore=original.lyrics;val targetBefore=t.lyrics;val stem=getSharedPreferences("stem_cache",MODE_PRIVATE).getString(original.uri,null)?.let{StemEngine.load(this,it)};android.app.AlertDialog.Builder(this).setTitle("Экспериментальное распознавание").setMessage("Речевая модель Vosk может ошибаться на пении. Новый черновик заменит текущий текст, если он не изменился во время обработки. "+(if(stem!=null)"Будет использована выделенная дорожка вокала." else "Будет использован исходный микс. Для лучшего результата сначала разделите инструменты.")).setNegativeButton("Отмена",null).setPositiveButton("Распознать"){_,_->stemWork("Распознавание текста…",{LocalTranscription.transcribe(this,Uri.parse(original.uri),stem){msg->runOnUiThread{if(!isDestroyed){stemStatus=msg;if(screen=="Текст")render()}}}}){raw->if(tracks.contains(original)&&original.lyrics==originalBefore){original.lyrics=raw;if(t!==original&&tracks.contains(t)&&t.lyrics==targetBefore&&t.group==original.uri&&t.tempoRatio!=null)t.lyrics=TimeStretch.lyrics(raw,t.tempoRatio!!);save();toast("Черновик текста сохранён. Проверьте слова.")}else toast("Исходный текст или песня изменились. Черновик не сохранён.")}}.show()}
    private fun editLyrics(t:Track){val original=rawLyrics(t);val field=EditText(this).apply{setText(original);minLines=6;gravity=Gravity.TOP;inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE};android.app.AlertDialog.Builder(this).setTitle("Редактировать LRC").setView(field).setNegativeButton("Отмена",null).setPositiveButton("Сохранить"){_,_->val raw=field.text.toString();if(raw.length<=500000){val target=libraryIndex.get(t.uri);if(target==null||rawLyrics(target)!=original)toast("Текст уже изменился")else{target.lyrics=raw;save();render()}}else toast("Текст слишком большой")}.show()}
    private fun lyricRevision(t:Track)=LyricDocument.revision(t.group,t.tempoRatio,rawLyrics(t))
    private val lyricPicker=registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val target=lyricTarget; val revision=lyricRevision; lyricTarget=null; lyricRevision=null
        if(uri==null||target==null||revision==null)return@registerForActivityResult
        io.execute {
            val result=runCatching { contentResolver.openInputStream(uri)?.use{stream->val bytes=java.io.ByteArrayOutputStream();val buffer=ByteArray(8192);while(true){val n=stream.read(buffer);if(n<0)break;require(bytes.size()+n<=LyricDocument.MAX_BYTES){"Файл слишком большой"};bytes.write(buffer,0,n)};LyricDocument.decode(bytes.toByteArray())}?:error("Не удалось открыть файл") }
            runOnUiThread { if(!isDestroyed)result.onSuccess{raw->val t=libraryIndex.get(target);if(t==null||lyricRevision(t)!=revision)toast("Текст или версия изменились; импорт отменён")else{t.lyrics=raw;save();render();toast(if(Lrc.parse(raw).isEmpty())"Обычный текст импортирован" else "Синхронный текст импортирован")}}.onFailure{toast(it.message?:"Не удалось прочитать текст")} }
        }
    }
    private fun shiftLyricsDialog(t:Track,raw:String){
        val panel=column();panel.addView(label("Плюс — текст появляется позже, минус — раньше. Метки слов и строк не переписываются.",14,muted))
        val info=label("",16,accent,true);panel.addView(info);var delta=0L
        fun refresh(){info.text="Сдвиг: ${if(delta>0)"+" else ""}$delta мс · общий offset: ${Lrc.offset(raw)+delta} мс"};refresh()
        val controls=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};for(step in listOf(-1000L,-100L,100L,1000L)){controls.addView(btn("${if(step>0)"+" else ""}$step"){delta=(delta+step).coerceIn(-60000,60000);refresh()},LinearLayout.LayoutParams(0,-2,1f))};panel.addView(controls)
        panel.addView(btn("Приблизить общий сдвиг к нулю"){delta=(-Lrc.offset(raw)).coerceIn(-60000,60000);refresh()})
        val revision=lyricRevision(t);val dialog=android.app.AlertDialog.Builder(this).setTitle("Синхронизация караоке").setView(panel).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",null).create()
        dialog.setOnShowListener{dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener{runCatching{val target=libraryIndex.get(t.uri)?:error("Песня удалена");require(lyricRevision(target)==revision){"Текст или версия изменились"};if(delta!=0L){target.lyrics=LyricDocument.shift(raw,delta);save()};dialog.dismiss();render()}.onFailure{toast(it.message?:"Не удалось изменить сдвиг")}}};dialog.show()
    }
    override fun onCreate(state: Bundle?) {
        super.onCreate(state);state?.let{saved->exportSource=saved.getString("exportSource");mp3Bitrate=saved.getInt("mp3Bitrate",256).takeIf{it in listOf(128,192,256,320)}?:256;addingTo=saved.getString("addingTo");lyricTarget=saved.getString("lyricTarget");lyricRevision=saved.getString("lyricRevision");screen=(saved.getString("screen")?:"Музыка").takeIf{it in listOf("Музыка","Версии","Студия","Текст","Загрузки","Плеер","Микшер","Жанры","Настройки","Очередь","История","Эквалайзер")}?:"Музыка";query=saved.getString("query").orEmpty();shownSongs=saved.getInt("shownSongs",100).coerceIn(100,60000);onlyFavorites=saved.getBoolean("onlyFavorites");selectedPlaylist=saved.getString("selectedPlaylist");sortMode=saved.getInt("sortMode",0).coerceIn(0,2);categoryMode=saved.getInt("categoryMode",0).coerceIn(0,3);category=saved.getString("category").takeIf{categoryMode!=0}}; window.statusBarColor=bg; window.navigationBarColor=bg; load();reindex();loadPlaylists();if(selectedPlaylist !in playlists.keys)selectedPlaylist=null;loadCustomPresets();loadGenreMix();randomVersions=getSharedPreferences("play_options",MODE_PRIVATE).getBoolean("random_versions",false)
        onBackPressedDispatcher.addCallback(this,object:androidx.activity.OnBackPressedCallback(true){override fun handleOnBackPressed(){if(screen!="Музыка"){screen="Музыка";render()}else{isEnabled=false;onBackPressedDispatcher.onBackPressed();isEnabled=true}}});root=column();root.setBackgroundColor(bg);root.setPadding(dp(16),dp(8),dp(16),dp(10));setContentView(root)
        if(Build.VERSION.SDK_INT>=35){root.setOnApplyWindowInsetsListener { v,insets ->
            val b=insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout() or WindowInsets.Type.ime())
            v.setPadding(dp(16)+b.left,dp(8)+b.top,dp(16)+b.right,dp(10)+b.bottom);insets
        };root.requestApplyInsets()}
        val header=row();header.addView(label("REMIX",26,accent,true),weight());header.addView(btn("Настройки"){screen="Настройки";render()});header.addView(btn("＋ Импорт"){addingTo=null;picker.launch(arrayOf("audio/*"))});root.addView(header)
        val nav=row();listOf("Музыка","Версии","Студия","Текст","Загрузки").forEach{ name->val button=btn(name){screen=name;render()};button.textSize=12f;button.minHeight=dp(48);button.minimumHeight=dp(48);navButtons[name]=button;nav.addView(button,weight()) };
        val content=ScrollView(this);mainScroll=content;content.isFillViewport=true;content.isVerticalScrollBarEnabled=false;body=column();content.addView(body);root.addView(content,LinearLayout.LayoutParams(-1,0,1f))
        val workRow=row();globalWorkRow=workRow;val workText=label("",13,accent);globalWorkText=workText;workText.maxLines=2;workRow.addView(workText,weight());workRow.addView(btn("Отмена"){cancelWork()});workRow.visibility=View.GONE;root.addView(workRow)
        bar=column();bar.background=rounded(surface,20);bar.setPadding(dp(12),dp(9),dp(12),dp(8));root.addView(bar)
        now=label("Выберите композицию",16,Color.WHITE,true);bar.addView(now);now.contentDescription="Открыть экран воспроизведения";now.setOnClickListener{screen=if(MixerSession.active)"Микшер" else "Плеер";render()}
        seek=SeekBar(this);seek.max=1000;seek.contentDescription="Позиция воспроизведения";bar.addView(seek)
        seek.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
            override fun onStartTrackingTouch(s:SeekBar){dragging=true;seekTarget=currentSeekTarget()}
            override fun onStopTrackingTouch(s:SeekBar){val target=seekTarget;seekTarget=null;dragging=false;applySeek(target,s.progress)}
            override fun onProgressChanged(s:SeekBar,p:Int,user:Boolean){if(user&&!dragging)applySeek(currentSeekTarget(),p)}
        })
        time=label("0:00 / 0:00",12,muted);bar.addView(time)
        val controls=row();controls.addView(btn("⇄"){controller?.let{it.shuffleModeEnabled=!it.shuffleModeEnabled;toast(if(it.shuffleModeEnabled)"Случайный порядок" else "По порядку")}},weight());controls.addView(btn("|◀"){stopPreview();controller?.seekToPrevious()},weight());play=btn("▶"){if(MixerSession.active){stopPreview();render();return@btn};controller?.let{if(it.playWhenReady&&it.playbackState!=Player.STATE_ENDED&&it.playerError==null)it.pause()else {if(it.mediaItemCount==0)tracks.firstOrNull{t->t.uri==t.group}?.let{t->start(pickVersion(t))}else {if(it.playbackState==Player.STATE_ENDED)it.seekTo(0);if(it.playbackState==Player.STATE_IDLE)it.prepare();it.play()}}}};controls.addView(play,weight());controls.addView(btn("▶|"){stopPreview();controller?.seekToNext()},weight());controls.addView(btn("↻"){controller?.let{it.repeatMode=(it.repeatMode+1)%3;toast(listOf("Повтор выключен","Повтор трека","Повтор очереди")[it.repeatMode])}},weight());bar.addView(controls);root.addView(nav)
        future=MediaController.Builder(this,SessionToken(this,ComponentName(this,PlaybackService::class.java))).buildAsync();future.addListener({if(!isDestroyed){runCatching{future.get()}.onSuccess{controller=it;it.addListener(object:Player.Listener{override fun onMediaItemTransition(mediaItem:MediaItem?,reason:Int){playbackEpoch++;if(screen!="Музыка")refreshPlayerScreen()};override fun onTimelineChanged(timeline:Timeline,reason:Int){if(screen=="Очередь")refreshPlayerScreen()};override fun onIsPlayingChanged(isPlaying:Boolean){if(isPlaying&&MixerSession.active){stopPreview();refreshPlayerScreen()}};override fun onPlayerError(error:PlaybackException){toast("Ошибка воспроизведения: ${error.errorCodeName}")}});if(it.mediaItemCount==0&&!MixerSession.active){restoreQueue(it)};render()}.onFailure{toast("Не удалось подключить плеер")}}},mainExecutorCompat())
        if(intent.getBooleanExtra("open_mixer",false)||MixerSession.active)screen="Микшер";stemStatus=workGate.current()?.title.orEmpty();lastWorkBusy=stemBusy;render();showInterruptedWork()
    }
    private fun restoreQueue(p:MediaController){
        val b=getSharedPreferences("playback_bookmark",MODE_PRIVATE);val shuffle=b.getBoolean("shuffle",false);val repeat=b.getInt("repeat",0).coerceIn(0,2)
        val saved=b.getString("queue",null)
        if(saved!=null){val snapshot=runCatching{require(saved.length<=3*1024*1024);val a=JSONArray(saved);require(a.length()<=QueueSnapshot.LIMIT);QueueSnapshot.Saved((0 until a.length()).map{a.getString(it)},b.getInt("index",-1),b.getLong("position",0),b.getLong("duration",0),shuffle,repeat)}.getOrNull()
            val restored=snapshot?.let{QueueSnapshot.restore(it){id->libraryIndex.get(id)}}
            if(restored!=null){p.setMediaItems(restored.items.map(::item),restored.index,restored.position);p.prepare();p.pause()}
        }else libraryIndex.get(b.getString("id",null))?.let{t->start(t,PlaybackBookmark.position(b.getLong("position",0),b.getLong("duration",0)),false)}
        p.shuffleModeEnabled=shuffle;p.repeatMode=repeat
    }
    private fun playbackOptionsDialog(){val panel=column();val remain=PlaybackTiming.remaining(android.os.SystemClock.elapsedRealtime(),PlaybackOptions.sleepDeadline);panel.addView(label(if(remain>0)"Таймер: ${fmt(remain)}" else "Таймер выключен",16,Color.WHITE,true));val times=listOf(15,30,45,60,90,120);panel.addView(btn("Установить таймер…"){android.app.AlertDialog.Builder(this).setTitle("Остановить через").setItems(times.map{"$it мин"}.toTypedArray()){_,i->PlaybackOptions.sleepDeadline=PlaybackTiming.deadline(android.os.SystemClock.elapsedRealtime(),times[i]);toast("Таймер: ${times[i]} мин")}.show()});panel.addView(btn("Выключить таймер"){PlaybackOptions.sleepDeadline=0;toast("Таймер выключен")});panel.addView(label("Плавное затухание в начале и конце песни. Без наложения треков; не crossfade. Действует только в обычном плеере.",14,muted));val fades=listOf(0L,1000L,2000L,3000L,5000L);panel.addView(btn("Переходы: ${PlaybackOptions.fadeMs/1000} с"){android.app.AlertDialog.Builder(this).setTitle("Длительность затухания").setItems(fades.map{if(it==0L)"Выключено" else "${it/1000} с"}.toTypedArray()){_,i->PlaybackOptions.fadeMs=fades[i];getSharedPreferences("play_options",MODE_PRIVATE).edit().putLong("fade_ms",fades[i]).apply();toast("Настройка сохранена")}.show()});panel.addView(label("Экспериментальное наложение двух песен. Только обычный звук без эффектов, EQ и A/B. При ошибке декодирования переход пропускается. Требует проверки на устройстве.",14,muted));val overlaps=listOf(0L,1000L,2000L,3000L,5000L,8000L);panel.addView(btn("Crossfade: ${PlaybackOptions.overlapMs/1000} с"){android.app.AlertDialog.Builder(this).setTitle("Наложение песен").setItems(overlaps.map{if(it==0L)"Выключено" else "${it/1000} с"}.toTypedArray()){_,i->PlaybackOptions.overlapMs=overlaps[i];getSharedPreferences("play_options",MODE_PRIVATE).edit().putLong("overlap_ms",overlaps[i]).apply();toast("Настройка сохранена")}.show()});android.app.AlertDialog.Builder(this).setTitle("Воспроизведение").setView(panel).setPositiveButton("Закрыть",null).show()}
    private fun mainExecutorCompat()=java.util.concurrent.Executor{handler.post(it)}
    private var seekTarget:PlayerUiSafety.Target?=null
    private var playbackEpoch=0L
    private fun currentSeekTarget():PlayerUiSafety.Target? {
        MixerSession.request?.let{return PlayerUiSafety.Target(true,it.source,it.token)}
        return controller?.currentMediaItem?.mediaId?.let{PlayerUiSafety.Target(false,it,playbackEpoch)}
    }
    private fun applySeek(target:PlayerUiSafety.Target?,progress:Int){
        val actual=currentSeekTarget()
        val r=MixerSession.request
        val duration=r?.frames?:controller?.duration?:0L
        val position=PlayerUiSafety.seekPosition(target,actual,duration,progress)?:return
        if(r!=null)runCatching{MixerSession.seek(this,position)}.onFailure{toast(it.message?:"Ошибка перемотки")}
        else controller?.seekTo(position)
    }
    private var uiStarted=false
    private var deferredPlayerRender=false
    private fun refreshPlayerScreen(){if(uiStarted)render() else deferredPlayerRender=true}
    private fun setTextChanged(view:TextView?,value:String){if(view!=null&&view.text.toString()!=value)view.text=value}
    private val ticker=object:Runnable{
        override fun run(){
            if(!uiStarted)return
            val p=controller
            val busyNow=stemBusy
            if(lastWorkBusy!=busyNow){lastWorkBusy=busyNow;if(workTicket==null){stemStatus=workGate.current()?.title.orEmpty();render();if(!busyNow)showInterruptedWork()}}
            val workVisibility=if(busyNow)View.VISIBLE else View.GONE
            globalWorkRow?.let{if(it.visibility!=workVisibility)it.visibility=workVisibility}
            if(busyNow)setTextChanged(globalWorkText,stemStatus)
            val active=MixerSession.active
            if(lastMixerActive!=active){
                if(!active){previewFrame=MixerSession.bookmark?.takeIf{it.source==previewSource}?.frame?:previewFrame;setTextChanged(previewButton,"▶ Слушать микс")}
                if(screen=="Текст"||screen=="Микшер")render()
            }
            lastMixerActive=active
            MixerSession.takeError()?.let{toast(it)}
            val pos=if(active)MixerSession.position()*1000/44100 else p?.currentPosition?.coerceAtLeast(0L)?:0L
            val dur=if(active)(MixerSession.request?.frames?:0)*1000/44100 else p?.duration?.coerceAtLeast(0L)?:0L
            val playing=active||p?.isPlaying==true
            val title=if(active)"Микшер · ${MixerSession.request?.title}" else (current()?.title?:"Выберите композицию")+(if(Presets.active!=Presets.all.first())" · ${Presets.active.name}" else "")
            setTextChanged(now,title);setTextChanged(play,if(playing)"Ⅱ" else "▶")
            val playDescription=if(active)"Остановить микшер" else if(playing)"Пауза" else "Воспроизвести"
            if(play.contentDescription!=playDescription)play.contentDescription=playDescription
            if(!dragging){val progress=UiRefresh.progress(pos,dur);if(seek.progress!=progress)seek.progress=progress}
            setTextChanged(time,"${fmt(pos)} / ${fmt(dur)}")
            if(screen=="Текст")highlight(pos)
            if(screen=="Микшер"){
                val f=if(active)MixerSession.position()else previewFrame
                setTextChanged(previewLabel,"Микшер · ${fmt(f*1000/44100)}")
                if(!previewDragging)previewSeek?.let{val v=(f/441).toInt().coerceIn(0,it.max);if(it.progress!=v)it.progress=v}
            }
            if(uiStarted)handler.postDelayed(this,UiRefresh.delayMs(playing,screen=="Текст",busyNow))
        }
    }
    private fun current()=libraryIndex.get(controller?.currentMediaItem?.mediaId)
    private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
    private fun column()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
    private fun row()=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
    private fun weight()=LinearLayout.LayoutParams(0,-2,1f)
    private fun rounded(c:Int,r:Int)=GradientDrawable().apply{setColor(c);cornerRadius=dp(r).toFloat()}
    private fun label(s:String,size:Int=16,c:Int=Color.WHITE,b:Boolean=false)=TextView(this).apply{text=s;textSize=size.toFloat();setTextColor(c);if(b)setTypeface(null,Typeface.BOLD);setPadding(dp(6),dp(8),dp(6),dp(8))}
    private fun btn(s:String,action:()->Unit)=Button(this).apply{text=s;isAllCaps=false;textSize=14f;minWidth=0;minimumWidth=0;minHeight=dp(44);minimumHeight=dp(44);setPadding(dp(8),dp(5),dp(8),dp(5));setTextColor(accent);background=android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(0x30FFFFFF),rounded(surface,12),rounded(Color.WHITE,12));setOnClickListener{action()}}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    private fun fmt(ms:Long)="${ms/60000}:${(ms/1000%60).toString().padStart(2,'0')}"
    private fun heading(s:String)=body.addView(label(s,24,Color.WHITE,true))
    private fun card(title:String,sub:String,action:()->Unit){val c=column();c.background=android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(0x25FFFFFF),rounded(surface,16),rounded(Color.WHITE,16));c.isFocusable=true;c.setPadding(dp(10),dp(4),dp(10),dp(4));c.addView(label(title,17,Color.WHITE,true));c.addView(label(sub,13,muted));c.setOnClickListener{action()};val lp=LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(7);body.addView(c,lp)}
    private val screenScroll=mutableMapOf<String,Int>()
    private fun render(){if(!::body.isInitialized)return;if(renderedScreen.isNotEmpty())screenScroll[renderedScreen]=mainScroll.scrollY;val oldY=screenScroll[screen]?:0;renderedScreen=screen;val selected=when(screen){"Жанры","Микшер"->"Студия";"Плеер","Очередь","Настройки","История","Эквалайзер"->"Музыка";else->screen};navButtons.forEach{(name,button)->button.isSelected=name==selected;button.setTextColor(if(button.isSelected)accent else muted);button.background=android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(0x33FFFFFF),rounded(if(button.isSelected)surface else bg,12),rounded(Color.WHITE,12));button.contentDescription=if(button.isSelected)"$name, текущий раздел" else name};studioStatusView=null;backupStatus=null;previewLabel=null;previewSeek=null;previewButton=null;body.removeAllViews();activeLyrics=emptyList();lyricViews=emptyList();lyricScroll=null;lastLine=-2;lastWord=-2;wordLines=emptyList();visibleTranslation=emptyList();translationViews=emptyList();when(screen){"Плеер"->nowPlaying();"Музыка"->library();"Версии"->versions();"Студия"->studio();"Текст"->lyrics();"Микшер"->mixer();"Загрузки"->downloads();"Жанры"->genres();"Настройки"->settingsScreen();"Очередь"->queueScreen();"История"->historyScreen();"Эквалайзер"->equalizerScreen()};val targetScreen=screen;mainScroll.post{if(screen==targetScreen)mainScroll.scrollTo(0,oldY)}}
    private var coverToken=0L
    private val coverCache=object:android.util.LruCache<String,android.graphics.Bitmap>(8*1024*1024){
        override fun sizeOf(key:String,value:android.graphics.Bitmap):Int=value.allocationByteCount
    }
    private val missingCovers=android.util.LruCache<String,Boolean>(64)
    private val coverIo=java.util.concurrent.ThreadPoolExecutor(1,1,0L,java.util.concurrent.TimeUnit.MILLISECONDS,
        java.util.concurrent.ArrayBlockingQueue<Runnable>(1),java.util.concurrent.ThreadPoolExecutor.DiscardOldestPolicy())
    private fun nowPlaying(){
        heading("Сейчас играет");val t=current()?:run{body.addView(label("Выберите композицию",16,muted));return}
        val image=ImageView(this).apply{scaleType=ImageView.ScaleType.FIT_CENTER;setBackgroundColor(surface);contentDescription="Обложка композиции";setImageResource(android.R.drawable.ic_media_play)}
        body.addView(image,LinearLayout.LayoutParams(-1,dp(if(resources.configuration.screenHeightDp<500)180 else 270)));val token=++coverToken
        val source=libraryIndex.get(t.group)?:t
        val cached=coverCache.get(source.uri)
        if(cached!=null)image.setImageBitmap(cached) else if(missingCovers.get(source.uri)==null)coverIo.execute{
            val bitmap=runCatching{val r=MediaMetadataRetriever();try{r.setDataSource(this,Uri.parse(source.uri));val bytes=r.embeddedPicture?:return@runCatching null;if(bytes.size>12*1024*1024)return@runCatching null;val bounds=android.graphics.BitmapFactory.Options().apply{inJustDecodeBounds=true};android.graphics.BitmapFactory.decodeByteArray(bytes,0,bytes.size,bounds);val sample=PlayerUiSafety.coverSample(bounds.outWidth,bounds.outHeight)?:return@runCatching null;android.graphics.BitmapFactory.decodeByteArray(bytes,0,bytes.size,android.graphics.BitmapFactory.Options().apply{inSampleSize=sample})}finally{runCatching{r.release()}}}.getOrNull()
            runOnUiThread{if(!isDestroyed){if(bitmap==null)missingCovers.put(source.uri,true) else {coverCache.put(source.uri,bitmap);if(screen=="Плеер"&&token==coverToken&&current()?.uri==t.uri)image.setImageBitmap(bitmap)}}}
        }
        body.addView(label(t.title,26,Color.WHITE,true));body.addView(label(t.artist,17,muted));val original=source
        val actions=row();actions.addView(btn(if(original.favorite)"♥ Избранное" else "♡ В избранное"){original.favorite=!original.favorite;save();render()},weight());actions.addView(btn("Версии · ${tracks.count{it.group==t.group}}"){screen="Версии";render()},weight());body.addView(actions)
        val tools=row();listOf("Текст","Микшер","Студия","Очередь").forEach{name->tools.addView(btn(name){screen=name;render()},weight())};body.addView(tools);body.addView(btn("Дополнительные действия…"){android.app.AlertDialog.Builder(this).setTitle("Плеер").setItems(arrayOf("Таймер сна и переходы","Повтор фрагмента A/B","Вырезать аудиофрагмент","Эквалайзер")){_,i->if(current()?.uri!=t.uri){toast("Композиция изменилась");return@setItems};when(i){0->playbackOptionsDialog();1->loopDialog();2->clipDialog(t);3->{screen="Эквалайзер";render()}}}.show()})
    }
    private var loopStart:Pair<String,Long>?=null
    private fun loopDialog(){val p=controller?:return;val id=p.currentMediaItem?.mediaId?:return;val duration=p.duration;if(duration<=0||MixerSession.active){toast("A/B доступен для обычного плеера после загрузки песни");return};val now=p.currentPosition.coerceIn(0,duration);val a=loopStart?.takeIf{it.first==id}?.second;val active=RepeatRegion.active?.takeIf{it.id==id};val options=arrayOf("Отметить A: ${fmt(now)}","Отметить B: ${fmt(now)}","Выключить повтор A/B");android.app.AlertDialog.Builder(this).setTitle(if(active!=null)"Повтор ${fmt(active.start)} — ${fmt(active.end)}" else "A/B · ${a?.let(::fmt)?:"A не задана"}").setItems(options){_,i->if(p.currentMediaItem?.mediaId!=id)return@setItems;when(i){0->{loopStart=id to now;RepeatRegion.active=null;toast("Точка A: ${fmt(now)}")};1->{val region=a?.let{LoopCore.create(id,it,now,duration)};if(region==null)toast("Сначала задайте A, затем B минимум на 0,5 с позже")else{RepeatRegion.active=region;p.seekTo(region.start);toast("Повтор включён")}};2->{RepeatRegion.active=null;loopStart=null;toast("Повтор выключен")}};render()}.show()}
    private fun library(){heading("Моя музыка");if(stemBusy){body.addView(label(stemStatus,13,accent));body.addView(btn("Отменить обработку"){cancelWork()})};body.addView(btn("Инструменты библиотеки…"){android.app.AlertDialog.Builder(this).setTitle("Инструменты библиотеки").setItems(arrayOf("AI-сортировка по жанрам","AI-сортировка по настроению","Найти версии по названию","Сравнить песни по звуку…")){_,i->if(!stemBusy)when(i){0->chooseGenreBatch();1->chooseMoodBatch();2->suggestVersions();3->fingerprintDialog()}}.show()});body.addView(btn(if(scanBusy)"Сканирование…" else "Найти музыку на телефоне"){requestScan()});val search=EditText(this).apply{hint="Песня, исполнитель, альбом или ремикс";setSingleLine();setText(query)};body.addView(search);val filter=btn(if(onlyFavorites)"♥ Избранное" else "Все композиции"){onlyFavorites=!onlyFavorites;shownSongs=100;render()};body.addView(filter);val tools=row();tools.addView(btn(selectedPlaylist?:"Плейлисты"){playlistFilter()},weight());tools.addView(btn(listOf(if(selectedPlaylist==null)"По добавлению" else "Порядок плейлиста","По названию","По исполнителю")[sortMode]){sortMode=(sortMode+1)%3;shownSongs=100;render()},weight());body.addView(tools);val extras=row();extras.addView(btn("История"){screen="История";render()},weight());extras.addView(btn("Эквалайзер"){screen="Эквалайзер";render()},weight());body.addView(extras);body.addView(btn(category?:listOf("Каталог: все песни","Каталог: альбомы","Каталог: папки","Каталог: исполнители")[categoryMode]){chooseCategory()});body.addView(btn(if(randomVersions)"Случайные версии: вкл" else "Случайные версии: выкл"){randomVersions=!randomVersions;getSharedPreferences("play_options",MODE_PRIVATE).edit().putBoolean("random_versions",randomVersions).apply();render()});val list=column();body.addView(btn("Добавить найденные песни в плейлист…"){bulkPlaylistDialog()});body.addView(btn("Добавить найденные песни в очередь…"){bulkQueueDialog()});body.addView(list)
        fun fill(){list.removeAllViews();val matches=searchMatches();val songs=visibleSongs(matches);val page=LibraryPage.window(songs.size,shownSongs);shownSongs=page.anchor.coerceAtLeast(100)
            fun navigate(end:Int){shownSongs=end;fill();list.post{mainScroll.smoothScrollTo(0,list.top)}}
            fun navigation():LinearLayout{
                val controls=row()
                page.previousEnd?.let{end->controls.addView(btn("←"){navigate(end)},weight())}
                val pages=(page.total-1)/LibraryPage.SIZE+1;val currentPage=page.start/LibraryPage.SIZE+1
                controls.addView(btn("$currentPage / $pages · ${page.total} песен"){
                    val field=EditText(this).apply{inputType=android.text.InputType.TYPE_CLASS_NUMBER;setSingleLine();setText(currentPage.toString());selectAll()}
                    android.app.AlertDialog.Builder(this).setTitle("Перейти на страницу (1–$pages)").setView(field).setNegativeButton("Отмена",null).setPositiveButton("Перейти"){_,_->val number=field.text.toString().toIntOrNull();if(number==null||number !in 1..pages)toast("Неверный номер страницы")else{val offset=(number-1)*LibraryPage.SIZE;navigate(offset+minOf(LibraryPage.SIZE,page.total-offset))}}.show()
                },weight())
                page.nextEnd?.let{end->controls.addView(btn("→"){navigate(end)},weight())}
                return controls
            }
            if(page.total>LibraryPage.SIZE)list.addView(navigation())
            if(songs.isEmpty()){list.addView(label(if(tracks.isEmpty())"Нет композиций. Нажмите «Импорт»." else "Нет совпадений с текущими фильтрами.",14,muted));if(tracks.isNotEmpty())list.addView(btn("Сбросить поиск и фильтры"){query="";onlyFavorites=false;selectedPlaylist=null;category=null;categoryMode=0;shownSongs=100;render()})};songs.subList(page.start,page.end).forEach{t->val r=row();val col=column();col.addView(label(t.title,17,Color.WHITE,true));col.addView(label("${t.artist} · ${libraryIndex.versions(t.uri).size} файл(ов)",12,muted));val found=matches[t.uri]?.takeIf{!it.originalMatches}?.versions.orEmpty();if(found.isNotEmpty())col.addView(label("Совпадения: "+found.take(3).joinToString(" · "){it.title}+(if(found.size>3)" · +${found.size-3}" else ""),12,accent));col.setOnClickListener{when(found.size){0->start(pickVersion(t));1->start(found.first());else->android.app.AlertDialog.Builder(this).setTitle("Найденные версии").setItems(found.map{it.title}.toTypedArray()){_,i->start(found[i])}.setNegativeButton("Отмена",null).show()}};r.background=rounded(surface,14);r.addView(col,weight());r.addView(btn(if(t.favorite)"♥" else "♡"){t.favorite=!t.favorite;save();fill()});r.addView(btn("⋮"){songMenu(t)});val lp=LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(6);list.addView(r,lp)};if(page.total>LibraryPage.SIZE)list.addView(navigation())}
        val pending=Runnable{if(search.isAttachedToWindow&&screen=="Музыка")fill()};search.addOnAttachStateChangeListener(object:View.OnAttachStateChangeListener{override fun onViewAttachedToWindow(v:View){};override fun onViewDetachedFromWindow(v:View){handler.removeCallbacks(pending)}});search.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){query=s.toString();shownSongs=100;handler.removeCallbacks(pending);handler.postDelayed(pending,180)};override fun afterTextChanged(s:Editable?){}});fill()
    }
    /** Snapshot the visible filtered list, not just the currently rendered page. */
    private fun bulkPlaylistDialog(){
        val ids=visibleSongs().map{it.uri};if(ids.isEmpty()){toast("Нет найденных песен");return}
        val names=playlists.keys.toList()
        fun appendTo(name:String,create:Boolean){
            if((create&&name in playlists)||(!create&&name !in playlists)){toast("Плейлист изменился");return}
            val live=ids.filter{libraryIndex.get(it)?.let{t->t.uri==t.group}==true}
            if(live.isEmpty()){toast("Песни больше недоступны");return}
            val old=playlists[name].orEmpty();val result=PlaylistOrder.append(old,live);val added=result.size-old.size
            playlists[name]=result.toCollection(linkedSetOf());savePlaylists();toast("Добавлено: $added");render()
        }
        android.app.AlertDialog.Builder(this).setTitle("Добавить ${ids.size} песен в плейлист").setItems((names+"＋ Новый плейлист").toTypedArray()){_,i->
            if(i==names.size){val field=EditText(this).apply{hint="Название плейлиста";setSingleLine()};android.app.AlertDialog.Builder(this).setTitle("Новый плейлист · ${ids.size} песен").setView(field).setNegativeButton("Отмена",null).setPositiveButton("Создать"){_,_->val name=field.text.toString().trim();if(name.isBlank()||name.length>80)toast("Недопустимое название")else appendTo(name,true)}.show()}
            else android.app.AlertDialog.Builder(this).setMessage("Добавить ${ids.size} песен в «${names[i]}»? Дубли будут пропущены.").setNegativeButton("Отмена",null).setPositiveButton("Добавить"){_,_->appendTo(names[i],false)}.show()
        }.setNegativeButton("Отмена",null).show()
    }
    private fun bulkQueueDialog(){
        val matches=searchMatches();val songs=visibleSongs(matches)
        if(songs.isEmpty()){toast("Нет найденных песен");return}
        val requested=songs.map{original->
            val found=matches[original.uri]?.takeIf{!it.originalMatches}?.versions.orEmpty()
            (if(found.isEmpty())pickVersion(original)else if(randomVersions)found.random()else found.first()).uri
        }
        val p=controller?:return toast("Плеер подключается")
        val initial=QueueEdit.appendBatch(queueIds(p),requested)
        if(initial.additions.isEmpty()){toast("Нет новых мест или версий в очереди");return}
        android.app.AlertDialog.Builder(this).setTitle("Добавить в конец очереди")
            .setMessage("Найдено: ${requested.size}. Можно добавить: ${initial.additions.size}. Повторы: ${initial.duplicates}. За пределом ${QueueSnapshot.LIMIT}: ${initial.overflow}. Текущая песня не изменится. При перемешивании порядок воспроизведения может отличаться.")
            .setNegativeButton("Отмена",null).setPositiveButton("Добавить"){_,_->
                val live=controller?:return@setPositiveButton
                val ids=initial.additions.filter{libraryIndex.get(it)!=null}
                val plan=QueueEdit.appendBatch(queueIds(live),ids)
                val items=plan.additions.mapNotNull{libraryIndex.get(it)}.map(::item)
                if(items.isEmpty()){toast("Очередь изменилась, ничего не добавлено");return@setPositiveButton}
                if(live.mediaItemCount==0){live.pause();live.setMediaItems(items);live.prepare()}
                else live.addMediaItems(live.mediaItemCount,items)
                toast("Добавлено в очередь: ${items.size}/${initial.additions.size}")
                if(screen=="Очередь")render()
            }.show()
    }
    private fun movePlaylistSong(t:Track){
        val name=selectedPlaylist?:return toast("Сначала выберите плейлист")
        val snapshot=playlists[name]?.toList()?:return toast("Плейлист недоступен")
        val id=t.group;val old=snapshot.indexOf(id);if(old<0)return toast("Песня не входит в плейлист")
        val field=EditText(this).apply{inputType=android.text.InputType.TYPE_CLASS_NUMBER;setSingleLine();setText((old+1).toString());selectAll()}
        android.app.AlertDialog.Builder(this).setTitle("Позиция в «$name» (1–${snapshot.size})").setView(field).setNegativeButton("Отмена",null).setPositiveButton("Переместить"){_,_->
            if(playlists[name]?.toList()!=snapshot){toast("Плейлист изменился, повторите действие");return@setPositiveButton}
            val position=field.text.toString().toIntOrNull();val result=position?.takeIf{it in 1..snapshot.size}?.let{PlaylistOrder.move(snapshot,id,it-1)}
            if(result==null){toast("Недопустимая позиция");return@setPositiveButton}
            playlists[name]=result.toCollection(linkedSetOf());sortMode=0;savePlaylists();render()
        }.show()
    }
    private fun fingerprintDialog(){
        if(stemBusy)return
        val source=current()?.let{libraryIndex.get(it.group)?:it}?:return toast("Сначала включите песню для сравнения")
        val options=visibleSongs().filter{it.uri!=source.uri}.take(100)
        if(options.isEmpty())return toast("Нет других песен в текущем фильтре")
        val chosen=BooleanArray(options.size)
        android.app.AlertDialog.Builder(this).setTitle("По звуку · ${source.title}").setMultiChoiceItems(options.map{"${it.title} · ${it.artist}"}.toTypedArray(),chosen){d,i,b->chosen[i]=b;if(b&&chosen.count{it}>12){chosen[i]=false;(d as android.app.AlertDialog).listView.setItemChecked(i,false);toast("До 12 песен за запуск")}}.setNegativeButton("Отмена",null).setPositiveButton("Сравнить"){_,_->
            val ids=options.filterIndexed{i,_->chosen[i]}.map{it.uri};if(ids.isEmpty())return@setPositiveButton
            stemWork("Сравнение по звуку…",{FingerprintScan.scan(this,source.uri,ids){updateWork(it)}}){result->
                val matches=result.matches.filter{libraryIndex.get(it.id)?.group==it.id}
                if(matches.isEmpty()){toast("Похожих фрагментов не найдено · недоступно: ${result.failed}");return@stemWork}
                val checks=BooleanArray(matches.size)
                val labels=matches.map{m->"${libraryIndex.get(m.id)?.title} · ${kotlin.math.round(m.match.score*100).toInt()}% сходства · ${"%.2f".format(m.match.speed)}×"}
                android.app.AlertDialog.Builder(this).setTitle("Возможные версии · проверьте вручную").setMultiChoiceItems(labels.toTypedArray(),checks){_,i,b->checks[i]=b}.setNegativeButton("Закрыть",null).setPositiveButton("Объединить выбранные"){_,_->
                    val target=libraryIndex.get(source.uri);if(target==null||target.group!=source.uri){toast("Оригинал уже изменился");return@setPositiveButton}
                    var count=0;matches.filterIndexed{i,_->checks[i]}.forEach{m->libraryIndex.get(m.id)?.let{if(mergeGroups(it,target))count++}};save();render();toast("Объединено: $count")
                }.show()
            }
        }.show()
    }
    private fun suggestVersions(){
        val roots=tracks.filter{it.uri==it.group}.map{GroupingCore.Song(it.uri,it.title,it.artist)}
        stemWork("Поиск похожих версий…",{GroupingCore.suggest(roots)}){suggestions->
            if(suggestions.isEmpty()){toast("Однозначные совпадения не найдены");return@stemWork}
            val shown=suggestions.take(200);val checked=BooleanArray(shown.size)
            val labels=shown.map{v->"${libraryIndex.get(v.version)?.title} → ${libraryIndex.get(v.original)?.title}"}.toTypedArray()
            android.app.AlertDialog.Builder(this).setTitle("Предложения объединения (${shown.size}/${suggestions.size})").setMultiChoiceItems(labels,checked){_,i,b->checked[i]=b}.setNegativeButton("Отмена",null).setPositiveButton("Объединить выбранные"){_,_->
                var count=0;shown.filterIndexed{i,_->checked[i]}.forEach{v->val source=libraryIndex.get(v.version);val target=libraryIndex.get(v.original);if(source!=null&&target!=null&&source.group==source.uri&&target.group==target.uri){if(mergeGroups(source,target))count++}}
                save();render();toast("Объединено групп: $count")
            }.show()
        }
    }
    /** A ratio relative to the old root cannot be assumed relative to another song. */
    private fun mergeGroups(old:Track,new:Track):Boolean{
        val source=libraryIndex.get(old.uri)?:return false;val target=libraryIndex.get(new.uri)?:return false
        if(source.uri==target.uri||source.group!=source.uri||target.group!=target.uri)return false
        if(MixerSession.request?.source==source.uri)stopPreview()
        for(i in tracks.indices){val t=tracks[i];if(t.group==source.uri){val lyrics=GroupLyrics.preserve(t.lyrics,source.lyrics,t.tempoRatio);tracks[i]=t.copy(group=target.uri,lyrics=lyrics,tempoRatio=null)}}
        target.favorite=target.favorite||source.favorite
        playlists.values.forEach{ids->val merged=PlaylistOrder.merge(ids,source.uri,target.uri);ids.clear();ids.addAll(merged)}
        versionPrefs.edit().remove(source.uri).apply();reindex();return true
    }
    private fun editTrackMetadata(t:Track){
        val live=libraryIndex.get(t.uri)?:return toast("Песня больше недоступна")
        fun fields(v:Track)=TrackMetadata.Fields(v.title,v.artist,v.album)
        val expected=fields(live);val panel=column()
        panel.addView(label("Меняются только сведения библиотеки. Аудиофайл, тексты, плейлисты и связи версий сохраняются. Уведомление обновится при следующем формировании очереди.",14,muted))
        fun field(name:String,value:String)=EditText(this).apply{hint=name;setSingleLine();setText(value);panel.addView(label(name,13,muted));panel.addView(this)}
        val title=field("Название",expected.title);val artist=field("Исполнитель",expected.artist);val album=field("Альбом",expected.album)
        val dialog=android.app.AlertDialog.Builder(this).setTitle("Редактировать сведения").setView(panel).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",null).create()
        dialog.setOnShowListener{dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener{
            val next=try{TrackMetadata.validated(title.text.toString(),artist.text.toString(),album.text.toString())}catch(e:IllegalArgumentException){toast(e.message?:"Некорректные сведения");return@setOnClickListener}
            if(!TrackMetadata.replace(tracks,t.uri,expected,next,Track::uri,::fields){v,f->v.copy(title=f.title,artist=f.artist,album=f.album)}){toast("Сведения уже изменились или песня удалена");dialog.dismiss();return@setOnClickListener}
            save();dialog.dismiss();render();toast("Сведения сохранены")
        }};dialog.show()
    }
    private fun songMenu(t:Track){android.app.AlertDialog.Builder(this).setTitle(t.title).setItems(arrayOf("Играть следующей…","Добавить в конец очереди…","Добавить файлы ремиксов","Объединить с другой песней","Удалить группу из библиотеки","Добавить / убрать из плейлиста","Позиция в выбранном плейлисте…","Редактировать сведения…")){_,i->when(i){0->chooseQueueVersion(t,true);1->chooseQueueVersion(t,false);2->{addingTo=t.uri;picker.launch(arrayOf("audio/*"))};3->{val options=tracks.filter{it.group==it.uri&&it.uri!=t.uri};if(options.isEmpty())toast("Нет другой композиции")else android.app.AlertDialog.Builder(this).setTitle("Выберите оригинал").setItems(options.map{it.title}.toTypedArray()){_,j->if(mergeGroups(t,options[j])){save();render()}else toast("Группа уже изменилась")}.show()};4->{android.app.AlertDialog.Builder(this).setMessage("Убрать группу из библиотеки? Файлы останутся на устройстве.").setNegativeButton("Отмена",null).setPositiveButton("Убрать"){_,_->if(libraryIndex.get(t.uri)?.group!=t.uri){toast("Группа уже изменилась");return@setPositiveButton};if(MixerSession.request?.source==t.uri)stopPreview();controller?.let{p->for(j in p.mediaItemCount-1 downTo 0)if(libraryIndex.get(p.getMediaItemAt(j).mediaId)?.group==t.uri)p.removeMediaItem(j)};tracks.removeAll{it.group==t.uri};playlists.values.forEach{it.remove(t.uri)};save();render()}.show()};5->choosePlaylist(t);6->movePlaylistSong(t);7->editTrackMetadata(t)}}.show()}
    private val versionPrefs by lazy { getSharedPreferences("preferred_versions",MODE_PRIVATE) }
    private fun preferred(original:Track):Track{val id=versionPrefs.getString(original.uri,null);return libraryIndex.preferred(original,id)}
    private fun choosePreferred(t:Track){if(libraryIndex.get(t.uri)?.group!=t.group){toast("Группа уже изменилась");return};versionPrefs.edit().putString(t.group,t.uri).apply();toast("Версия по умолчанию: ${t.title}");render()}
    private fun item(t:Track)=MediaItem.Builder().setMediaId(t.uri).setUri(Uri.parse(t.uri)).setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(Uri.parse(t.uri)).build()).setMediaMetadata(MediaMetadata.Builder().setTitle(t.title).setArtist(t.artist).build()).build()
    private fun start(t:Track,position:Long=0,autoplay:Boolean=true){
        stopPreview();val p=controller?:return toast("Плеер подключается")
        val matches=if(screen=="Музыка")searchMatches() else emptyMap();val originals=if(screen=="Музыка")visibleSongs(matches) else tracks.filter{it.uri==it.group}
        val source=if(originals.any{it.uri==t.group})originals else tracks.filter{it.uri==it.group}
        val queue=libraryIndex.queue(source,t,t.group,{versionPrefs.getString(it,null)},choose={original->val found=matches[original.uri]?.takeIf{!it.originalMatches}?.versions.orEmpty();if(found.isEmpty())pickVersion(original)else if(randomVersions)found.random()else found.first()})
        val i=queue.indexOfFirst{it.uri==t.uri};if(i<0)return
        p.setMediaItems(queue.map(::item),i,position.coerceAtLeast(0));p.prepare();if(autoplay)p.play()else p.pause()
    }
    private fun switchVersion(from:Track,to:Track){
        if(current()?.uri!=from.uri||libraryIndex.get(from.uri)?.group!=from.group||libraryIndex.get(to.uri)?.group!=to.group){toast("Песня или группа уже изменилась");render();return}
        if(from.uri==to.uri)return
        stopPreview();val pos=controller?.currentPosition?.coerceAtLeast(0L)?:0L
        val target=if(from.group==to.group)PlaybackBookmark.transfer(pos,if(from.uri==from.group)1.0 else from.tempoRatio,if(to.uri==to.group)1.0 else to.tempoRatio)else 0L
        val p=controller?:return
        if(from.group==to.group&&p.currentMediaItemIndex in 0 until p.mediaItemCount){
            val i=p.currentMediaItemIndex;val playing=p.playWhenReady
            p.replaceMediaItem(i,item(to));p.seekTo(i,target);p.prepare();p.playWhenReady=playing;render()
        }else start(to,target,p.playWhenReady)
    }
    private fun transitionDialog(){if(stemBusy){toast("Дождитесь завершения обработки");return};val p=controller?:return;val i=p.currentMediaItemIndex;if(i<0||i+1>=p.mediaItemCount){toast("В очереди нужна следующая композиция");return};val a=libraryIndex.get(p.getMediaItemAt(i).mediaId)?:return;val b=libraryIndex.get(p.getMediaItemAt(i+1).mediaId)?:return;val durations=listOf(1,3,5,8,10)
        android.app.AlertDialog.Builder(this).setTitle("Создать DJ-переход в файл WAV").setItems(durations.map{"$it с · ${a.title} → ${b.title}"}.toTypedArray()){_,j->val duration=durations[j];stemWork("Декодирование для DJ-перехода…",{val x=java.io.File.createTempFile("transition-a-",".pcm",cacheDir);val y=java.io.File.createTempFile("transition-b-",".pcm",cacheDir);val dir=java.io.File(filesDir,"mixes").apply{mkdirs()};val out=java.io.File.createTempFile("transition-",".wav",dir);try{StemEngine.decode(this,Uri.parse(a.uri),x);StemEngine.decode(this,Uri.parse(b.uri),y);TransitionMix.render(x,y,out,duration){n->updateWork("DJ-переход: $n%")};out}catch(e:Throwable){out.delete();throw e}finally{x.delete();y.delete()}},discard={file->file.delete()}){file->val uri=androidx.core.content.FileProvider.getUriForFile(this,"app.remix.player.files",file).toString();val t=Track(uri,a.title+" → "+b.title,"DJ Mix",uri);tracks.add(t);save();screen="Музыка";toast("DJ-переход сохранён отдельной композицией")}}.setNegativeButton("Отмена",null).show()
    }
    private fun queueIds(p:MediaController)=List(p.mediaItemCount){p.getMediaItemAt(it).mediaId}
    private fun chooseQueueVersion(t:Track,next:Boolean){
        val versions=libraryIndex.versions(t.group)
        if(versions.isEmpty())return toast("Песня больше не в библиотеке")
        if(versions.size==1){editQueue(versions.first(),next);return}
        android.app.AlertDialog.Builder(this).setTitle(if(next)"Играть следующей" else "В конец очереди").setItems(versions.map{it.title}.toTypedArray()){_,i->editQueue(versions[i],next)}.setNegativeButton("Отмена",null).show()
    }
    private fun editQueue(t:Track,next:Boolean){
        val p=controller?:return toast("Плеер подключается")
        val live=libraryIndex.get(t.uri)?:return toast("Версия больше не в библиотеке")
        if(next&&p.mediaItemCount>0&&p.repeatMode==Player.REPEAT_MODE_ONE)return toast("Выключите повтор одного трека для выбора следующей песни")
        when(val action=QueueEdit.plan(queueIds(p),p.currentMediaItemIndex,live.uri,next,p.shuffleModeEnabled)){
            is QueueEdit.Action.Insert->{p.addMediaItem(action.index,item(live));toast("Добавлено в очередь")}
            is QueueEdit.Action.Move->{p.moveMediaItem(action.from,action.to);toast("Версия будет следующей")}
            QueueEdit.Action.Refused.EMPTY->{p.pause();p.setMediaItem(item(live));p.prepare();toast("Добавлено в пустую очередь")}
            QueueEdit.Action.Refused.CURRENT->toast("Эта версия уже играет")
            QueueEdit.Action.Refused.PRESENT->toast("Эта версия уже в нужной позиции или в очереди")
            QueueEdit.Action.Refused.FULL->toast("Очередь заполнена: ${QueueSnapshot.LIMIT} песен")
            QueueEdit.Action.Refused.SHUFFLE->toast("Выключите случайный порядок для выбора следующей песни")
            QueueEdit.Action.Refused.INVALID->toast("Очередь изменилась, попробуйте снова")
        };if(screen=="Очередь")render()
    }
    private fun queueRowAction(p:MediaController,snapshot:List<String>,action:()->Unit){
        if(!QueueEdit.sameTimeline(snapshot,queueIds(p))){toast("Очередь изменилась");render();return};action()
    }
    private fun queueScreen(){
        heading("Очередь воспроизведения");val p=controller?:return
        body.addView(label("${p.mediaItemCount}/${QueueSnapshot.LIMIT} композиций · порядок и позиция сохраняются",14,muted));if(p.mediaItemCount>0)body.addView(btn("Очистить очередь"){android.app.AlertDialog.Builder(this).setMessage("Остановить воспроизведение и очистить очередь? Файлы останутся.").setNegativeButton("Отмена",null).setPositiveButton("Очистить"){_,_->stopPreview();p.pause();p.clearMediaItems();render()}.show()});if(stemBusy){studioStatusView=label(stemStatus,14,muted);body.addView(studioStatusView!!);body.addView(btn("Отменить обработку"){cancelWork()})}else body.addView(btn("Создать DJ-переход: текущая → следующая"){transitionDialog()})
        val snapshot=queueIds(p);for(i in snapshot.indices){val id=snapshot[i];val t=libraryIndex.get(id)?:continue
            val r=row();val col=column();col.addView(label((if(i==p.currentMediaItemIndex)"▶ " else "")+t.title,16,Color.WHITE,true));col.addView(label(t.artist,13,muted));col.setOnClickListener{queueRowAction(p,snapshot){stopPreview();p.seekToDefaultPosition(i);p.play()}};r.addView(col,weight())
            r.addView(btn("↑"){queueRowAction(p,snapshot){if(i>0){p.moveMediaItem(i,i-1);render()}}});r.addView(btn("↓"){queueRowAction(p,snapshot){if(i+1<p.mediaItemCount){p.moveMediaItem(i,i+1);render()}}});r.addView(btn("×"){queueRowAction(p,snapshot){p.removeMediaItem(i);render()}});body.addView(r)
        }
    }
    private fun restructureVersion(t:Track,promote:Boolean){
        if(stemBusy)return toast("Дождитесь завершения обработки")
        if(t.uri==t.group)return
        val message=if(promote)"Сделать эту версию оригиналом всей группы? Плейлисты и тексты сохранятся. Неподтверждённые соотношения темпа будут сброшены." else "Отделить эту версию в самостоятельную песню? Исходный файл и текст сохранятся. Плейлисты старой группы останутся без изменений."
        android.app.AlertDialog.Builder(this).setMessage(message).setNegativeButton("Отмена",null).setPositiveButton("Продолжить"){_,_->
            if(stemBusy){toast("Дождитесь завершения обработки");return@setPositiveButton}
            val entries=tracks.map{GroupEdit.Entry(it.uri,it.group,it.lyrics,it.tempoRatio,it.favorite)}
            val updated=(if(promote)GroupEdit.promote(entries,t.uri,t.group)else GroupEdit.detach(entries,t.uri,t.group))?:return@setPositiveButton toast("Группа уже изменилась")
            val byId=updated.associateBy{it.id}
            for(i in tracks.indices){val v=tracks[i];val next=byId.getValue(v.uri);if(v.group!=next.group||v.lyrics!=next.lyrics||v.tempoRatio!=next.ratio||v.favorite!=next.favorite)tracks[i]=v.copy(group=next.group,lyrics=next.lyrics,tempoRatio=next.ratio,favorite=next.favorite)}
            if(promote){playlists.values.forEach{ids->val merged=PlaylistOrder.merge(ids,t.group,t.uri);ids.clear();ids.addAll(merged)};versionPrefs.edit().remove(t.group).remove(t.uri).apply()}
            else if(versionPrefs.getString(t.group,null)==t.uri)versionPrefs.edit().remove(t.group).apply()
            save();render();toast(if(promote)"Оригинал изменён" else "Версия отделена")
        }.show()
    }
    private fun removeVersion(t:Track){
        if(t.uri==t.group)return
        android.app.AlertDialog.Builder(this).setMessage("Убрать эту версию из библиотеки? Исходный файл останется.").setNegativeButton("Отмена",null).setPositiveButton("Убрать"){_,_->
            if(libraryIndex.get(t.uri)?.group!=t.group){toast("Группа уже изменилась");return@setPositiveButton};val p=controller; if(p!=null){for(i in p.mediaItemCount-1 downTo 0)if(p.getMediaItemAt(i).mediaId==t.uri)p.removeMediaItem(i)}
            if(versionPrefs.getString(t.group,null)==t.uri)versionPrefs.edit().remove(t.group).apply()
            qualityPrefs.edit().remove(t.uri).apply();tracks.removeAll{it.uri==t.uri};save();render()
        }.show()
    }
    private val qualityPrefs by lazy{getSharedPreferences("remix_quality",MODE_PRIVATE)}
    private fun qualityJson(q:RemixQuality.Result)=JSONObject().put("seconds",q.seconds).put("peak",q.peak).put("rms",q.rms).put("clipped",q.clippedFraction).put("silence",q.internalSilenceSeconds).put("dc",q.dc).put("bpm",q.measuredBpm?:JSONObject.NULL).put("target",q.targetBpm?:JSONObject.NULL)
    private fun qualityFor(uri:String):RemixQuality.Result?=runCatching{val j=JSONObject(qualityPrefs.getString(uri,null)?:return null);RemixQuality.Result(j.getDouble("seconds"),j.getDouble("peak"),j.getDouble("rms"),j.getDouble("clipped"),j.getDouble("silence"),j.getDouble("dc"),j.optDouble("bpm",Double.NaN).takeIf{it.isFinite()},j.optInt("target",0).takeIf{it in 50..220})}.getOrNull()
    private fun compareQuality(t:Track){val ranked=libraryIndex.versions(t.group).mapNotNull{v->qualityFor(v.uri)?.let{v to it}}.sortedByDescending{it.second.score};if(ranked.isEmpty()){toast("Оценка доступна для новых жанровых ремиксов");return};val labels=ranked.map{(v,q)->"${q.score}/100 · ${v.title}\nТемп: ${q.measuredBpm?.toInt()?:"?"} / ${q.targetBpm?:"?"} BPM · пик ${"%.1f".format(20*kotlin.math.log10(q.peak.coerceAtLeast(.000001)))} дБFS\n"+(q.warnings().joinToString("; ").ifBlank{"Без обнаруженных технических проблем"})}.toTypedArray();android.app.AlertDialog.Builder(this).setTitle("Техническая оценка (не музыкальный вкус)").setItems(labels){_,i->val selected=ranked[i].first;val current=current();if(current!=null&&current.group==selected.group)switchVersion(current,selected)else start(selected)}.setNegativeButton("Закрыть",null).show()}
    private fun versions(){heading("Версии песни");val t=current();if(t==null){body.addView(label("Сначала включите композицию.",14,muted));return};body.addView(label(tracks.find{it.uri==t.group}?.title?:t.title,18,accent,true));tracks.filter{it.group==t.group}.forEach{v->card(v.title+(if(v.uri==t.group)" · оригинал" else ""),(if(v.uri==t.uri)"Сейчас играет" else "Локальный файл")+(if(v.uri==preferred(tracks.find{it.uri==t.group}?:t).uri)" · по умолчанию" else "")){switchVersion(t,v)}};run{body.addView(btn("Экспорт WAV в папку…"){exportWav(t)});body.addView(btn("Экспорт FLAC без потерь…"){exportWav(t,true)});body.addView(btn("Экспорт MP3…"){exportMp3(t)})};if(t.uri!=t.group){body.addView(btn("Отделить в самостоятельную песню…"){restructureVersion(t,false)});body.addView(btn("Сделать оригиналом группы…"){restructureVersion(t,true)});body.addView(btn("Убрать текущую версию"){removeVersion(t)})};body.addView(btn("Редактировать сведения текущей версии…"){editTrackMetadata(t)});body.addView(btn("Сравнить качество ремиксов"){compareQuality(t)});body.addView(btn("Случайная версия сейчас"){val options=libraryIndex.versions(t.group).filter{it.uri!=t.uri};if(options.isEmpty())toast("Других версий нет")else switchVersion(t,options.random())});body.addView(btn("Сделать текущую версию основной"){choosePreferred(t)});body.addView(btn("＋ Добавить свой ремикс"){addingTo=t.group;picker.launch(arrayOf("audio/*"))});body.addView(btn("Открыть студию эффектов"){screen="Студия";render()})}
    private val customPresets=mutableListOf<Preset>()
    private fun loadCustomPresets(){runCatching{val a=JSONArray(getSharedPreferences("custom_effects",MODE_PRIVATE).getString("items","[]"));for(i in 0 until minOf(a.length(),100)){runCatching{val o=a.getJSONObject(i);val v=o.getJSONArray("values");val p=CustomPresetCore.create(o.getString("name"),FloatArray(7){v.getDouble(it).toFloat()});if(customPresets.none{it.name.equals(p.name,true)}&&Presets.all.none{it.name.equals(p.name,true)})customPresets.add(p)}}}}
    private fun saveCustomPresets(){val a=JSONArray();customPresets.forEach{p->a.put(JSONObject().put("name",p.name).put("values",JSONArray(CustomPresetCore.values(p).map{it.toDouble()})))};getSharedPreferences("custom_effects",MODE_PRIVATE).edit().putString("items",a.toString()).apply()}
    private fun editCustomPreset(existing:Preset?=null){
        val source=current()?.uri?:return;val before=Presets.active;val v=CustomPresetCore.values(existing?:before);val panel=column();val name=EditText(this).apply{hint="Название пресета";setSingleLine();setText(existing?.name?:"")};panel.addView(name)
        val labels=listOf("Скорость ×","Высота тона ×","Бас","Реверберация","Стереопанорама","Искажение","Приглушение")
        val info=label("",13,muted);fun refresh(){info.text=if(CustomPresetCore.exportable(CustomPresetCore.create("Preview",v)))"Можно сохранить в аудиофайл" else "Эта комбинация доступна только при прослушивании"}
        for(i in labels.indices){val lo=CustomPresetCore.minimum[i];val hi=CustomPresetCore.maximum[i];val text=label("${labels[i]}: ${"%.2f".format(v[i])}",14);panel.addView(text);panel.addView(SeekBar(this).apply{this.max=100;progress=((v[i]-lo)/(hi-lo)*100).toInt().coerceIn(0,100);setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onStartTrackingTouch(s:SeekBar){};override fun onStopTrackingTouch(s:SeekBar){};override fun onProgressChanged(s:SeekBar,p:Int,user:Boolean){if(user){v[i]=(lo+(hi-lo)*p/100f).coerceIn(lo,hi);text.text="${labels[i]}: ${"%.2f".format(v[i])}";if(current()?.uri==source)applyPreset(CustomPresetCore.create("Предпрослушивание",v));refresh()}}})})};panel.addView(info);refresh()
        val scroll=ScrollView(this);scroll.addView(panel);var kept=false
        val dialog=android.app.AlertDialog.Builder(this).setTitle("Свой звуковой эффект").setView(scroll).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",null).setNeutralButton("Только применить",null).create()
        dialog.setOnDismissListener{if(!kept&&current()?.uri==source)applyPreset(before);render()};dialog.setOnShowListener{
            fun selectedName()=name.text.toString().trim().ifBlank{"Мой эффект"}
            dialog.getButton(android.app.AlertDialog.BUTTON_NEUTRAL).setOnClickListener{if(current()?.uri==source){applyPreset(CustomPresetCore.create("Мой эффект",v));kept=true};dialog.dismiss()}
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener{runCatching{val p=CustomPresetCore.create(selectedName(),v);require(Presets.all.none{it.name.equals(p.name,true)}&&customPresets.none{it!==existing&&it.name.equals(p.name,true)}){"Название уже используется"};require(existing!=null||customPresets.size<100){"Не более 100 своих пресетов"};if(existing!=null)customPresets.remove(existing);customPresets.add(p);saveCustomPresets();if(current()?.uri==source)applyPreset(p);kept=true;dialog.dismiss()}.onFailure{toast(it.message?:"Ошибка")}}
        };dialog.show()
    }
    private fun customPresetMenu(p:Preset){android.app.AlertDialog.Builder(this).setTitle(p.name).setItems(arrayOf("Применить","Редактировать","Удалить")){_,i->when(i){0->{applyPreset(p);render()};1->editCustomPreset(p);2->{customPresets.remove(p);saveCustomPresets();if(Presets.active==p)applyPreset(Presets.all.first());render()}}}.show()}
    private var backingSource:String?=null
    private val backingPicker=registerForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        val id=backingSource;backingSource=null
        if(uri!=null&&!stemBusy)libraryIndex.get(id)?.let{backingDialog(it,uri)}
    }
    private fun chooseBacking(t:Track){if(stemBusy)return;val source=libraryIndex.get(t.group)?:t;backingSource=source.uri;backingPicker.launch(arrayOf("audio/*"))}
    private fun backingDialog(source:Track,backing:Uri){
        val bundle=getSharedPreferences("stem_cache",MODE_PRIVATE).getString(source.uri,null)?.let{StemEngine.load(this,it)}
        val panel=column();panel.addView(label("Добавьте свой инструментал или аудио, созданное внешней нейросетью. Длина и текст оригинала сохраняются. Можно автоматически подогнать темп и приблизительно привязать долю. Тональность — отдельная опция; результат зависит от уверенности анализа.",14,muted))
        val vocals=CheckBox(this).apply{text="Использовать только выделенный вокал";setTextColor(Color.WHITE);isEnabled=bundle!=null;isChecked=bundle!=null};panel.addView(vocals)
        fun option(name:String,enabled:Boolean)=CheckBox(this).apply{text=name;setTextColor(Color.WHITE);isChecked=enabled;panel.addView(this)}
        val fitTempo=option("Подогнать BPM (с сохранением высоты тона)",true);val fitKey=option("Подогнать тональность (транспонирование)",false);val fitPhase=option("Приблизительно совместить доли",true)
        val offset=EditText(this).apply{hint="Смещение в мс (−60000…60000)";setText("0");inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED;setSingleLine()};panel.addView(offset)
        fun gain(title:String,initial:Int):SeekBar{val text=label("$title · $initial%",14,accent);panel.addView(text);return SeekBar(this).apply{max=200;progress=initial;setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onStartTrackingTouch(s:SeekBar){};override fun onStopTrackingTouch(s:SeekBar){};override fun onProgressChanged(s:SeekBar,p:Int,user:Boolean){text.text="$title · $p%"}});panel.addView(this)}}
        val originalGain=gain("Исходный звук",100);val backingGain=gain("Инструментал",65)
        val scroll=ScrollView(this);scroll.addView(panel);val dialog=android.app.AlertDialog.Builder(this).setTitle("Новая аранжировка из файла").setView(scroll).setNegativeButton("Отмена",null).setPositiveButton("Создать",null).create()
        dialog.setOnShowListener{dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener{runCatching{
            require(!stemBusy);val settings=AccompanimentMix.Settings(offset.text.toString().trim().toInt(),originalGain.progress/100f,backingGain.progress/100f);val useVocal=vocals.isChecked;val options=BackingFit.Options(fitTempo.isChecked,fitKey.isChecked,fitPhase.isChecked);val lyrics=rawLyrics(source);dialog.dismiss()
            stemWork("Сведение новой аранжировки…",{
                val tmp=java.io.File.createTempFile("backing-",".pcm",cacheDir);val base=java.io.File.createTempFile("backing-base-",".pcm",cacheDir);val out=java.io.File.createTempFile("arrangement-",".wav",java.io.File(filesDir,"mixes").apply{mkdirs()})
                val fitted=java.io.File.createTempFile("backing-fit-",".pcm",cacheDir)
                try{
                    val analyze=options.tempo||options.key||options.phase;val baseAnalysis=if(analyze&&!useVocal)RenderAnalysis()else null;val backAnalysis=if(analyze)RenderAnalysis()else null
                    val input=if(useVocal){java.io.File(requireNotNull(bundle).dir,"3.pcm")}else{StemEngine.decode(this,Uri.parse(source.uri),base,baseAnalysis?.let{a->{l:Short,r:Short->a.frame(l,r)}});base}
                    val originalReport=if(analyze&&useVocal)TrackAnalyzer.report(this,Uri.parse(source.uri))else baseAnalysis?.finish()
                    StemEngine.decode(this,backing,tmp,backAnalysis?.let{a->{l:Short,r:Short->a.frame(l,r)}})
                    val plan=BackingFit.plan(originalReport,backAnalysis?.finish(),options,settings.offsetMs)
                    val prepared=BackingFit.prepare(tmp,fitted,plan){updateWork("Подгонка инструментала: $it%")}
                    AccompanimentMix.render(input,prepared,out,settings.copy(offsetMs=plan.offsetMs)){updateWork("Сведение: $it%")};out to plan.notes
                }catch(e:Throwable){out.delete();throw e}finally{tmp.delete();base.delete();fitted.delete()}
            },discard={it.first.delete()}){result->val file=result.first;if(libraryIndex.get(source.uri)==null){file.delete()}else{val id=batchUri(file);val t=Track(id,source.title+" · новая аранжировка",source.artist,source.uri,lyrics,tempoRatio=1.0);tracks.add(t);if(saveLibrary(true)){screen="Версии";start(t);toast("Аранжировка сохранена");if(result.second.isNotEmpty())android.app.AlertDialog.Builder(this).setTitle("Подгонка инструментала").setMessage(result.second.joinToString("\n")).setPositiveButton("Готово",null).show()}else{tracks.remove(t);reindex();file.delete();toast("Не удалось сохранить библиотеку")}}}
        }.onFailure{toast(it.message?:"Проверьте смещение и настройки")}}};dialog.show()
    }
    private val moodPicker=registerForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null&&!stemBusy)stemWork("Импорт MERT…",{MoodModel.install(this,uri){updateWork(it)}}){toast("Модель настроения установлена")}}
    private fun moodImport(){if(stemBusy)return;android.app.AlertDialog.Builder(this).setTitle("Модель настроения MERT").setMessage("Поддерживается ONNX с входом audio_waveform [1,360000] и выходом valence_arousal [1,2]. Например, mert_emotion_int8.onnx. Импортируйте только доверенный файл; источник и лицензию проверьте самостоятельно. Модель не встроена; контрольная сумма издателя не подтверждена. Базовая MERT-v1-95M имеет лицензию CC BY-NC 4.0; не используйте её коммерчески без отдельного разрешения.").setNeutralButton("Источник"){_,_->runCatching{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(MoodModel.SOURCE)))}}.setNegativeButton("Отмена",null).setPositiveButton("Выбрать ONNX"){_,_->moodPicker.launch(arrayOf("*/*"))}.show()}
    private fun chooseMoodBatch(){
        if(stemBusy)return;if(!MoodModel.model(this).isFile){moodImport();return};val candidates=visibleSongs(searchMatches()).take(200);if(candidates.isEmpty())return toast("Нет песен в текущем фильтре");val selected=BooleanArray(candidates.size)
        android.app.AlertDialog.Builder(this).setTitle("Настроение · до 20 песен").setMultiChoiceItems(candidates.map{"${it.title} · ${it.artist}"}.toTypedArray(),selected){_,i,v->selected[i]=v}.setNegativeButton("Отмена",null).setNeutralButton("Первые 20"){_,_->runMoodBatch(candidates.take(20))}.setPositiveButton("Анализировать"){_,_->val chosen=candidates.filterIndexed{i,_->selected[i]};if(chosen.size in 1..20)runMoodBatch(chosen)else toast("Выберите 1–20 песен")}.show()
    }
    private fun runMoodBatch(songs:List<Track>){
        val titles=songs.associate{it.uri to it.title};stemWork("Сортировка по настроению…",{MoodModel.batch(this,songs.map{it.uri}){updateWork(it)}}){rows->
            val accepted=rows.filter{it.result?.label!=null};val details=rows.joinToString("\n"){r->"${titles[r.uri]} — ${r.result?.label?:r.error?.take(100)?:"неоднозначно"}"};val dialog=android.app.AlertDialog.Builder(this).setTitle("Настроение: ${accepted.size}/${rows.size}").setMessage("$details\n\nОценки MERT приблизительны. Неоднозначные результаты пропущены.").setNegativeButton("Закрыть",null)
            if(accepted.isNotEmpty())dialog.setPositiveButton("Создать / дополнить плейлисты"){_,_->var count=0;accepted.forEach{r->libraryIndex.get(r.uri)?.takeIf{it.group==it.uri}?.let{t->if(playlists.getOrPut("MERT · ${r.result!!.label}"){linkedSetOf()}.add(t.uri))count++}};save();render();toast("Добавлено: $count")};dialog.show()
        }
    }
    private fun classifyMood(source:Track){if(!MoodModel.model(this).isFile){moodImport();return};stemWork("Анализ настроения…",{MoodModel.classify(this,Uri.parse(source.uri)){updateWork(it)}}){r->val name=r.label;val d=android.app.AlertDialog.Builder(this).setTitle(name?:"Неоднозначное настроение").setMessage("Эмоциональная окраска: ${kotlin.math.round(r.valence*100).toInt()} / 100\nЭнергия: ${kotlin.math.round(r.arousal*100).toInt()} / 100\nАнализ до трёх 15-секундных фрагментов; короткие записи дополнены тишиной. При расхождении оценок настроение не назначается. Это оценка модели, не вероятность точности и не эмоции слушателя.").setNegativeButton("Закрыть",null);if(name!=null)d.setPositiveButton("Добавить в плейлист"){_,_->libraryIndex.get(source.uri)?.let{t->playlists.getOrPut("MERT · $name"){linkedSetOf()}.add(t.group);save();render();toast("Добавлено")}};d.show()}}
    private var subtitleSnapshot:String?=null
    private val subtitlePicker=registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")){dest->val text=subtitleSnapshot;subtitleSnapshot=null;if(dest!=null&&text!=null&&!stemBusy)stemWork("Экспорт текста…",{try{contentResolver.openOutputStream(dest,"w")?.use{it.write(text.toByteArray(Charsets.UTF_8))}?:error("Файл недоступен")}catch(e:Throwable){runCatching{contentResolver.delete(dest,null,null)};throw e}}){toast("Текст сохранён")}}
    private fun exportSubtitles(t:Track,raw:String){if(stemBusy)return;android.app.AlertDialog.Builder(this).setTitle("Экспорт синхронного текста").setItems(arrayOf("LRC · строки и слова","SRT · строки, длительность оценивается")){_,i->runCatching{subtitleSnapshot=if(i==0)raw else SubtitleExport.srt(raw);subtitlePicker.launch(exportName(t)+if(i==0)".lrc" else ".srt")}.onFailure{toast(it.message?:"Не удалось подготовить текст")}}.setNegativeButton("Отмена",null).show()}
    private val whisperPicker=registerForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null&&!stemBusy)stemWork("Установка Whisper…",{WhisperLocal.install(this,uri)}){id->toast("Whisper $id установлен");render()}}
    private fun whisperModelDialog(){
        if(stemBusy)return
        val active=WhisperLocal.installed(this)?.title?:"не установлена"
        val message="Сейчас: $active\n\nTiny — быстрее; Base и Small — крупнее, требуют больше ОЗУ и времени. Точность пения экспериментальная. Проверяются размер, SHA-256 и загрузка модели. Хранится одна модель.\n\nНативный движок: "+if(WhisperLocal.available)"доступен" else "не включён в сборку"
        android.app.AlertDialog.Builder(this).setTitle("Whisper · офлайн").setMessage(message).setNegativeButton("Закрыть",null).setNeutralButton("Источник"){_,_->android.app.AlertDialog.Builder(this).setTitle("Модели Whisper").setItems(WhisperModelSpec.models.map{it.title}.toTypedArray()){_,i->runCatching{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(WhisperModelSpec.models[i].source)))}}.show()}.setPositiveButton("Импорт / заменить"){_,_->if(WhisperLocal.available)whisperPicker.launch(arrayOf("*/*"))else toast("Нужна сборка с Whisper")}.show()
    }
    private fun recognizeWhisper(t:Track){if(stemBusy)return;if(!WhisperLocal.available||WhisperLocal.installed(this)==null){whisperModelDialog();return};val original=if(t.tempoRatio!=null)libraryIndex.get(t.group)?:t else t;val before=original.lyrics;val targetBefore=t.lyrics;val stem=getSharedPreferences("stem_cache",MODE_PRIVATE).getString(original.uri,null)?.let{StemEngine.load(this,it)};val codes=listOf("auto","ru","en","es","pt","ja");android.app.AlertDialog.Builder(this).setTitle("Whisper · язык вокала").setItems(arrayOf("Авто","Русский","Английский","Испанский","Португальский","Японский")){_,i->android.app.AlertDialog.Builder(this).setTitle("Распознать пение?").setMessage("Локальный черновик с приблизительными метками слов (при неполных данных — метками фраз). Возможны пропуски и вымышленные слова; проверьте текст. "+if(stem==null)"Используется исходный микс." else "Используется выделенный вокал.").setNegativeButton("Отмена",null).setPositiveButton("Распознать"){_,_->stemWork("Whisper…",{WhisperLocal.transcribe(this,Uri.parse(original.uri),stem,codes[i]){updateWork(it)}}){raw->if(tracks.contains(original)&&original.lyrics==before){original.lyrics=raw;if(t!==original&&tracks.contains(t)&&t.lyrics==targetBefore&&t.group==original.uri&&t.tempoRatio!=null)t.lyrics=TimeStretch.lyrics(raw,t.tempoRatio!!);save();toast("Черновик Whisper сохранён")}else toast("Текст или песня изменились; черновик не сохранён")}}.show()}.show()}
    private fun neuralStudio(){if(stemBusy)return;val source=current()?.let{libraryIndex.get(it.group)?:it};val bundle=source?.let{getSharedPreferences("stem_cache",MODE_PRIVATE).getString(it.uri,null)?.let{id->StemEngine.load(this,id)}};val panel=column();panel.addView(label("Нейросеть генерирует последовательность нот; синтезатор создаёт новый инструментал. Обучение на искусственных фразах. Не генерация записи уровня студии.",14,muted))
        fun field(name:String,value:String,signed:Boolean=false):EditText{panel.addView(label(name,14,muted));return EditText(this).apply{setText(value);setSingleLine();inputType=android.text.InputType.TYPE_CLASS_NUMBER or (if(signed)android.text.InputType.TYPE_NUMBER_FLAG_SIGNED else 0);panel.addView(this)}}
        val styles=Spinner(this).apply{adapter=android.widget.ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,NeuralInstrumental.Style.entries.map{it.title}+GenreEngine.styles.map{it.name})};panel.addView(styles)
        val bpm=field("Темп · 60–200 BPM","120");val roots=listOf("C","C♯","D","D♯","E","F","F♯","G","G♯","A","A♯","B");val key=Spinner(this).apply{adapter=android.widget.ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,roots)};panel.addView(label("Тональность",14,muted));panel.addView(key)
        val minor=CheckBox(this).apply{text="Минор";setTextColor(Color.WHITE);isChecked=true};panel.addView(minor);val bars=field("Такты · 1–64 (отдельный инструментал)","16");val seed=field("Seed · меняет мелодию",kotlin.random.Random.nextInt().toString(),true)
        val variation=field("Разнообразие мелодии · 0–100","50");val structured=CheckBox(this).apply{text="Повторяющиеся мотивы и динамика секций";setTextColor(Color.WHITE);isChecked=true};panel.addView(structured)
        val drumLevel=field("Ударные · 0–100%","100");val bassLevel=field("Бас · 0–100%","100");val chordLevel=field("Аккорды · 0–100%","100");val leadLevel=field("Мелодия · 0–100%","100")
        val mix=CheckBox(this).apply{text="Свести с текущей песней";setTextColor(Color.WHITE);isEnabled=source!=null};panel.addView(mix);val vocal=CheckBox(this).apply{text="Только выделенный вокал при сведении";setTextColor(Color.WHITE);isEnabled=bundle!=null;isChecked=bundle!=null};panel.addView(vocal);val auto=CheckBox(this).apply{text="При сведении следовать темпу и аккордам (неясные участки — только ударные)";setTextColor(Color.WHITE);isEnabled=source!=null;isChecked=true};panel.addView(auto)
        val scroll=ScrollView(this).apply{addView(panel)};val dialog=android.app.AlertDialog.Builder(this).setTitle("Генератор инструменталов").setView(scroll).setNegativeButton("Отмена",null).setPositiveButton("Создать",null).create();dialog.setOnShowListener{dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener{runCatching{
            val genre=(styles.selectedItemPosition-NeuralInstrumental.Style.entries.size).takeIf{it in GenreEngine.styles.indices};val family=genre?.let{GenrePhrase.family(it)}?:NeuralInstrumental.Style.entries[styles.selectedItemPosition];val settings=NeuralInstrumental.Settings(family,bpm.text.toString().toInt(),key.selectedItemPosition,minor.isChecked,bars.text.toString().toInt().also{require(it in 1..64)},seed.text.toString().toInt(),variation.text.toString().toInt(),structured.isChecked,NeuralInstrumental.Mix(drumLevel.text.toString().toInt(),bassLevel.text.toString().toInt(),chordLevel.text.toString().toInt(),leadLevel.text.toString().toInt()),genre=genre);val combine=mix.isChecked&&source!=null;val useVocal=vocal.isChecked&&bundle!=null;val fit=auto.isChecked;val lyrics=if(combine)rawLyrics(requireNotNull(source))else "";dialog.dismiss()
            stemWork("Генерация инструментала…",{
                val out=java.io.File.createTempFile("neural-",".wav",java.io.File(filesDir,"mixes").apply{mkdirs()});val temps=mutableListOf<java.io.File>();fun temp(s:String,e:String)=java.io.File.createTempFile(s,e,cacheDir).also{temps.add(it)}
                try{if(!combine)NeuralInstrumental.render(out,settings){updateWork("Синтез: $it%")}
                else{val original=requireNotNull(source);val raw=temp("neural-base-",".pcm");val analysis=if(fit&&!useVocal)RenderAnalysis()else null;val input=if(useVocal)java.io.File(requireNotNull(bundle).dir,"3.pcm")else{StemEngine.decode(this,Uri.parse(original.uri),raw,analysis?.let{a->{l:Short,r:Short->a.frame(l,r)}});raw};val report=if(fit&&useVocal)TrackAnalyzer.report(this,Uri.parse(original.uri),full=true)else analysis?.finish();val detected=report?.tempo?.takeIf{it.confidence>=.30&&it.bpm in 60.0..200.0};val k=report?.key?.split(' ');val root=if((report?.keyConfidence?:0.0)>=.06)roots.indexOf(k?.firstOrNull().orEmpty())else -1;val actual=settings.copy(bpm=detected?.bpm?.let{ kotlin.math.round(it).toInt() }?:settings.bpm,root=if(root>=0)root else settings.root,minor=if(root>=0)k?.getOrNull(1)=="minor" else settings.minor);val phase=if(detected!=null)(report?.phaseSeconds?.times(1000)?.toInt()?:0).coerceIn(0,2000)else 0;val duration=input.length()/4/44100.0;val exactBpm=detected?.bpm?:actual.bpm.toDouble();val windows=if(detected!=null)report?.tempoWindows.orEmpty() else emptyList();val count=NeuralInstrumental.barsForDuration(duration,exactBpm,phase,windows);val follow=if(fit)NeuralInstrumental.Follow(report?.chords.orEmpty(),exactBpm,phase,windows)else null;val wav=temp("neural-score-",".wav");val pcm=temp("neural-score-",".pcm");NeuralInstrumental.render(wav,actual.copy(bars=count),follow){updateWork("Синтез: $it%")};wav.inputStream().buffered().use{r->java.io.DataInputStream(r).readFully(ByteArray(44));pcm.outputStream().buffered().use{w->AudioFileCore.copy(r,w)}};AccompanimentMix.render(input,pcm,out,AccompanimentMix.Settings(phase,1f,.65f)){updateWork("Сведение: $it%")}}
                    out
                }catch(e:Throwable){out.delete();throw e}finally{temps.forEach{it.delete()}}
            },discard={it.delete()}){file->if(combine&&libraryIndex.get(source?.uri)==null){file.delete()}else{val id=batchUri(file);val t=Track(id,if(combine)requireNotNull(source).title+" · Neural ${settings.genre?.let{GenreEngine.styles[it].name}?:settings.style.title}" else "Neural ${settings.genre?.let{GenreEngine.styles[it].name}?:settings.style.title} · ${settings.seed}",if(combine)requireNotNull(source).artist else "Remix Studio",if(combine)requireNotNull(source).uri else id,lyrics,tempoRatio=if(combine)1.0 else null);tracks.add(t);if(saveLibrary(true)){screen=if(combine)"Версии" else "Музыка";start(t);toast("Инструментал сохранён")}else{tracks.remove(t);reindex();file.delete();toast("Не удалось сохранить библиотеку")}}}
        }.onFailure{toast(it.message?:"Проверьте настройки")}}};dialog.show()}
    private fun studio(){heading("Remix Studio");if(!stemBusy)recoveryButton();if(stemBusy){studioStatusView=label(stemStatus,16,accent);body.addView(studioStatusView!!);body.addView(ProgressBar(this));body.addView(btn("Отменить"){cancelWork()});return};body.addView(label("Создание музыки",15,muted,true));card("Нейросетевой инструментал","Создать новый музыкальный материал офлайн"){neuralStudio()};if(current()==null){body.addView(label("Выберите композицию для остальных инструментов.",14,muted));return};card("Жанровые ремиксы","30 шаблонов · новая аранжировка"){screen="Жанры";render()};card("Сведение с инструменталом","Вокал / оригинал · автоматическая подгонка BPM"){current()?.let{chooseBacking(it)}};card("AI Mixer","Разделить вокал и инструменты"){screen="Микшер";render()};body.addView(label("Эффекты",15,muted,true));body.addView(btn("Пакет эффектов…"){chooseEffectBatch()});body.addView(btn("Создать свой эффект…"){editCustomPreset()});customPresets.forEach{p->card(p.name,"Свой пресет · применить / изменить / удалить"){customPresetMenu(p)}};body.addView(label("Обработка в реальном времени · без копий файлов",14,muted));val t=current()!!;if(Presets.active!=Presets.all.first())body.addView(btn("Сохранить эффект как версию · ${Presets.active.name}"){saveEffect(t,Presets.active)});val result=tempos[t.uri];body.addView(btn(if(analysisBusy)"Анализируется…" else "Анализировать BPM"){if(!analysisBusy){analysisBusy=true;render();io.execute{val report=runCatching{TrackAnalyzer.report(this,Uri.parse(t.uri))}.getOrNull();val estimate=report?.tempo;runOnUiThread{if(!isDestroyed){analysisBusy=false;if(report!=null)reports[t.uri]=report;if(estimate!=null){tempos[t.uri]=estimate;toast("Темп определён")}else toast("Темп не удалось определить надёжно");render()}}}}});reports[t.uri]?.let{r->body.addView(label("Тональность: ${r.key?:"не определена"} · аккорды: ${r.chords.size} оценок · RMS ${"%.2f".format(r.rms)} · анализ ${r.duration.toInt()} с",14,muted))};if(result!=null){body.addView(label("Оценка темпа: ${result.bpm.toInt()} BPM · возможна ошибка ×2",14,accent));listOf(90,140,160).forEach{target->card("Адаптивный темп $target BPM","Изменение скорости с сохранением высоты тона"){val ratio=(target/result.bpm).toFloat().coerceIn(.5f,1.8f);applyPreset(Preset("Auto $target BPM",ratio));render()}}};Presets.all.forEach{p->card((if(p==Presets.active)"✓  " else "")+p.name,"Темп ${p.speed}× · тон ${p.pitch}×"){applyPreset(p);render()}}}
    private fun chooseEffectBatch(){
        val current=current()?:return;val original=libraryIndex.get(current.group)?:return
        val builtIn=Presets.all.drop(1);val presets=builtIn+customPresets.filter(CustomPresetCore::exportable);val selected=BooleanArray(presets.size)
        fun confirm(items:List<Preset>){if(items.isEmpty()){toast("Выберите эффекты");return};if(items.size>70){toast("Не более 70 версий за запуск");return}
            android.app.AlertDialog.Builder(this).setTitle("Создать ${items.size} версий?").setMessage("Оригинал декодируется один раз. Файлы WAV занимают примерно 10 МБ за минуту; замедленные версии больше. При отмене готовые версии сохраняются для ручного продолжения.").setNegativeButton("Отмена",null).setPositiveButton("Создать"){_,_->generateEffectBatch(original,items)}.show()
        }
        android.app.AlertDialog.Builder(this).setTitle("Эффекты для ${original.title}").setMultiChoiceItems(presets.map{it.name}.toTypedArray(),selected){_,i,checked->selected[i]=checked}.setNegativeButton("Отмена",null).setNeutralButton("Все 40"){_,_->confirm(builtIn)}.setPositiveButton("Далее"){_,_->confirm(presets.filterIndexed{i,_->selected[i]})}.show()
    }
    private data class PendingEffects(val id:String,val source:String,val presets:List<Preset>)
    private fun effectPrefs()=getSharedPreferences("effect_checkpoint",MODE_PRIVATE)
    private fun pendingEffects():PendingEffects? {
        val raw=effectPrefs().getString("plan",null)?:return null
        val o=JSONObject(raw);val id=o.getString("id");EffectCheckpoint.directory(java.io.File(filesDir,"mixes"),id)
        val items=o.getJSONArray("presets");require(items.length() in 1..70)
        return PendingEffects(id,o.getString("source"),List(items.length()){i->val p=items.getJSONObject(i);val v=p.getJSONArray("values");require(v.length()==7);CustomPresetCore.create(p.getString("name"),FloatArray(7){v.getDouble(it).toFloat()})})
    }
    private fun batchUri(file:java.io.File)=androidx.core.content.FileProvider.getUriForFile(this,"app.remix.player.files",file).toString()
    private fun recoveryButton(){if(effectPrefs().contains("plan"))body.addView(btn("Продолжить / отменить пакет эффектов…"){recoverEffects()});genreRecoveryButton()}
    private fun recoverEffects(){
        if(stemBusy)return
        val plan=runCatching{pendingEffects()}.getOrElse{toast("Не удалось прочитать план пакета. Файлы не удалены.");return}?:return
        val dir=EffectCheckpoint.directory(java.io.File(filesDir,"mixes"),plan.id)
        val parent=libraryIndex.get(plan.source)?.takeIf{it.group==it.uri}
        val existing=plan.presets.indices.count{java.io.File(dir,"version-$it.sha256").isFile}
        val dialog=android.app.AlertDialog.Builder(this).setTitle("Незавершённый пакет").setMessage("${parent?.title?:"Оригинал недоступен"} · $existing/${plan.presets.size} контрольных точек. Готовые файлы будут проверены, остальные рассчитаны заново.").setNegativeButton("Закрыть",null).setNeutralButton("Удалить пакет"){_,_->
            if(stemBusy)return@setNeutralButton
            val protected=protectedMixes();if(plan.presets.indices.any{"${dir.name}/version-$it.wav" in protected}){toast("Часть версий уже в библиотеке или очереди. Продолжите сохранение.");return@setNeutralButton}
            if((!dir.exists()||dir.deleteRecursively())&&effectPrefs().edit().remove("plan").commit()){toast("Пакет удалён");render()}else toast("Не удалось удалить пакет")
        }
        if(parent!=null)dialog.setPositiveButton("Продолжить"){_,_->runEffectBatch(parent,plan)}
        dialog.show()
    }
    private fun generateEffectBatch(original:Track,presets:List<Preset>){
        if(stemBusy)return
        if(effectPrefs().contains("plan")){recoverEffects();return}
        val plan=PendingEffects(java.util.UUID.randomUUID().toString(),original.uri,presets.toList())
        val items=JSONArray();presets.forEach{p->items.put(JSONObject().put("name",p.name).put("values",JSONArray(CustomPresetCore.values(p).map{it.toDouble()})))}
        if(!effectPrefs().edit().putString("plan",JSONObject().put("id",plan.id).put("source",plan.source).put("presets",items).toString()).commit()){toast("Не удалось сохранить план");return}
        runEffectBatch(original,plan)
    }
    private fun runEffectBatch(original:Track,plan:PendingEffects){
        if(stemBusy)return
        val dir=EffectCheckpoint.directory(java.io.File(filesDir,"mixes"),plan.id)
        val published=plan.presets.indices.map{java.io.File(dir,"version-$it.wav")}.all{it.isFile&&libraryIndex.get(batchUri(it))!=null}
        if(published){if(saveLibrary(true)&&runCatching{EffectCheckpoint.finish(dir);effectPrefs().edit().remove("plan").commit()}.getOrDefault(false)){toast("Пакет уже сохранён");render()}else toast("Не удалось подтвердить сохранение");return}
        if(plan.presets.indices.any{libraryIndex.get(batchUri(java.io.File(dir,"version-$it.wav")))!=null}){toast("Часть версий уже в библиотеке. Повторная запись заблокирована.");return}
        stemWork("Декодирование оригинала…",{
            val raw=java.io.File.createTempFile("effect-batch-",".pcm",cacheDir)
            try{StemEngine.decode(this,Uri.parse(original.uri),raw);EffectCheckpoint.render(raw,dir,plan.presets,{i,p,n->updateWork("${i+1}/${plan.presets.size} · ${p.name}: $n%")})}finally{raw.delete()}
        }){files->
            val parent=libraryIndex.get(original.uri)?.takeIf{it.group==it.uri}
            if(parent==null){toast("Оригинал удалён или перемещён. Пакет сохранён для проверки.")}
            else{val versions=files.map{(p,file)->val uri=batchUri(file);Track(uri,parent.title+" · "+p.name,parent.artist,parent.uri,TimeStretch.lyrics(parent.lyrics,p.speed.toDouble()),tempoRatio=p.speed.toDouble())}.filter{libraryIndex.get(it.uri)==null};tracks.addAll(versions)
                check(saveLibrary(true)){"Не удалось сохранить библиотеку. Повторите завершение пакета."};EffectCheckpoint.finish(dir);check(effectPrefs().edit().remove("plan").commit()){ "Не удалось подтвердить завершение пакета" };screen="Версии";if(current()?.group!=parent.uri)start(parent,0,false);toast("Сохранено версий: ${files.size}")}
        }
    }
    private fun saveEffect(t:Track,preset:Preset){
        if(stemBusy){toast("Дождитесь завершения обработки");return}
        val source=libraryIndex.get(t.group)?:return
        val inherited=t.uri==t.group||t.tempoRatio!=null
        val combined=if(inherited)((t.tempoRatio?:1.0)*preset.speed).takeIf{it in .4..1.8}else null
        val text=rawLyrics(t)
        if(!CustomPresetCore.exportable(preset)){toast("Некорректные настройки эффекта");return}
        stemWork("Создание версии ${preset.name}…",{
            val dir=java.io.File(filesDir,"mixes").apply{mkdirs()};val raw=java.io.File.createTempFile("effect-input-",".pcm",cacheDir);val out=java.io.File.createTempFile("effect-",".wav",dir)
            try{StemEngine.decode(this,Uri.parse(t.uri),raw);EffectRender.render(raw,out,preset){progress->runOnUiThread{if(!isDestroyed){stemStatus="${preset.name}: $progress%";studioStatusView?.text=stemStatus}}};out}catch(e:Throwable){out.delete();throw e}finally{raw.delete()}
        },discard={file->file.delete()}){file->if(libraryIndex.get(source.uri)==null){file.delete()}else{val uri=androidx.core.content.FileProvider.getUriForFile(this,"app.remix.player.files",file).toString();val v=Track(uri,t.title+" · "+preset.name,t.artist,source.uri,TimeStretch.lyrics(text,preset.speed.toDouble()),tempoRatio=combined);tracks.add(v);save();screen="Версии";start(v);toast("Ремикс сохранён")}}
    }
    private var stemZipSource:StemEngine.Bundle?=null
    private val stemZipPicker=registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")){dest->
        val bundle=stemZipSource;stemZipSource=null
        if(dest!=null&&bundle!=null&&!stemBusy)stemWork("Экспорт инструментов…",{
            try{contentResolver.openOutputStream(dest,"w")?.use{out->StemZip.export(bundle.dir,bundle.frames,bundle.count,out){n->updateWork("Экспорт дорожек: $n/${bundle.count}")}}?:error("Файл недоступен")}
            catch(e:Throwable){runCatching{contentResolver.delete(dest,null,null)};throw e}
        }){toast("Дорожки сохранены в ZIP")}
    }
    private fun mixer(){
        heading("Микшер дорожек");body.addView(btn("← Студия"){screen="Студия";render()})
        val t=libraryIndex.get(MixerSession.request?.source)?:current()?:libraryIndex.get(MixerSession.bookmark?.source)?:run{body.addView(label("Сначала включите композицию",14,muted));return}
        val source=libraryIndex.get(t.group)?:t
        body.addView(label(source.title,18,accent,true))
        if(stemBusy){studioStatusView=label(stemStatus,16,accent);body.addView(studioStatusView!!);body.addView(ProgressBar(this));body.addView(label("Обработка выполняется вне аудиопотока. Не закрывайте приложение.",13,muted));body.addView(btn("Отменить"){cancelWork()});return}
        val prefs=getSharedPreferences("stem_cache",MODE_PRIVATE)
        val bundle=prefs.getString(source.uri,null)?.let{StemEngine.load(this,it)}
        if(bundle==null){
            body.addView(label("Локальное нейросетевое разделение. Модель HT-Demucs ONNX устанавливается один раз из доверенного источника. Музыка не отправляется в сеть.",15,muted))
            body.addView(btn("Каталог · 4 или 6 дорожек"){showModelCatalog()});body.addView(btn(if(StemEngine.model(this).isFile)"Заменить модель ONNX" else "Импортировать модель ONNX"){modelPicker.launch(arrayOf("*/*"))})
            if(StemEngine.model(this).isFile)body.addView(btn(if(StemEngine.hasPending(this,Uri.parse(source.uri)))"Продолжить разделение" else "Разделить оригинал"){stemWork("Подготовка…",{StemEngine.separate(this,Uri.parse(source.uri)){progress->runOnUiThread{if(!isDestroyed){stemStatus=progress;if(screen=="Микшер")render()}}}}){b->prefs.edit().putString(source.uri,b.dir.name).apply();toast("Готово: ${b.count} дорожек")}})
            if(StemEngine.hasPending(this,Uri.parse(source.uri)))body.addView(btn("Удалить незавершённое разделение"){android.app.AlertDialog.Builder(this).setMessage("Удалить только контрольную точку этой песни? Оригинал и сохранённые версии останутся.").setNegativeButton("Отмена",null).setPositiveButton("Удалить"){_,_->stemWork("Удаление контрольной точки…",{StemEngine.discardPending(this,Uri.parse(source.uri))}){toast("Контрольная точка удалена")}}.show()})
            return
        }
        val gains=stemGains[source.uri]?.takeIf{it.size==bundle.count}?:readMixerGains(source.uri,bundle.count).also{stemGains[source.uri]=it}
        if(previewSource!=source.uri){previewSource=source.uri;previewFrame=MixerSession.bookmark?.takeIf{it.source==source.uri}?.frame?:0}
        MixerSession.request?.takeIf{it.source==source.uri&&it.gains.size==gains.size}?.gains?.copyInto(gains)
        
        previewLabel=label("Предпрослушивание",14,accent);body.addView(previewLabel!!)
        previewSeek=SeekBar(this).apply{max=(bundle.frames/441).toInt();progress=(previewFrame/441).toInt();setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onStartTrackingTouch(s:SeekBar){previewDragging=true};override fun onProgressChanged(s:SeekBar,p:Int,user:Boolean){};override fun onStopTrackingTouch(s:SeekBar){val was=MixerSession.active;previewFrame=s.progress*441L;previewDragging=false;if(was)beginPreview(bundle,gains)else {previewLabel?.text="Позиция · ${fmt(previewFrame*1000/44100)}"}}})};body.addView(previewSeek!!)
        previewButton=btn(if(!MixerSession.active)"▶ Слушать микс" else "Ⅱ Пауза микса"){if(!MixerSession.active)beginPreview(bundle,gains)else stopPreview();render()};body.addView(previewButton!!);body.addView(label("Микшер продолжает играть при сворачивании. Остановить можно здесь или из уведомления.",13,muted))
        body.addView(label("${bundle.count} дорожки · настраивайте громкость и создавайте версию. Изменения громкости слышны в режиме предпрослушивания.",14,muted))
        for(i in gains.indices){val panel=column();panel.background=rounded(surface,16);panel.setPadding(dp(10),dp(4),dp(10),dp(4));val title=label("${StemCore.names[i]} · ${(gains[i]*100).toInt()}%",16,Color.WHITE,true);panel.addView(title);val r=row();val slider=SeekBar(this).apply{contentDescription="Громкость: ${StemCore.names[i]}";max=100;progress=(gains[i]*100).toInt();setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onStartTrackingTouch(s:SeekBar){};override fun onStopTrackingTouch(s:SeekBar){persistMixerGains(gains)};override fun onProgressChanged(s:SeekBar,p:Int,user:Boolean){if(!user)return;gains[i]=p/100f;if(MixerSession.request?.source==previewSource)MixerSession.update(gains);title.text="${StemCore.names[i]} · $p%"}})};r.addView(slider,weight());r.addView(btn("Solo"){gains.fill(0f);gains[i]=1f;updatePreview(gains);render()}.apply{contentDescription="Только ${StemCore.names[i]}"});r.addView(btn(if(gains[i]>0)"Mute" else "Unmute"){gains[i]=if(gains[i]>0)0f else 1f;updatePreview(gains);render()}.apply{contentDescription="Включить или выключить ${StemCore.names[i]}"});panel.addView(r);body.addView(panel,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(6)})}
        val presets=row();presets.addView(btn("Караоке"){gains.fill(1f);gains[3]=0f;updatePreview(gains);render()},weight());presets.addView(btn("Только вокал"){gains.fill(0f);gains[3]=1f;updatePreview(gains);render()},weight());presets.addView(btn("Сбросить"){gains.fill(1f);updatePreview(gains);render()},weight());body.addView(presets)
        body.addView(btn("Свести и добавить версию"){val snapshot=gains.copyOf();val name=if(snapshot[3]==0f&&snapshot.indices.filter{it!=3}.all{snapshot[it]==1f})"Караоке" else if(snapshot[3]==1f&&snapshot.indices.filter{it!=3}.all{snapshot[it]==0f})"Вокал" else "Микс ${tracks.count{it.group==source.uri}}";stemWork("Сведение WAV…",{StemEngine.render(this,bundle,snapshot)},discard={file->file.delete()}){file->if(tracks.any{it.uri==source.uri}){val uri=androidx.core.content.FileProvider.getUriForFile(this,"app.remix.player.files",file).toString();val v=Track(uri,source.title+" · "+name,source.artist,source.uri,source.lyrics,tempoRatio=1.0);tracks.add(v);save();start(v);toast("Версия добавлена")}else file.delete()}})
        body.addView(btn("Экспорт всех дорожек WAV (ZIP)"){stemZipSource=bundle;stemZipPicker.launch("RemixPlayer-stems.zip")});body.addView(btn("Удалить кеш дорожек"){android.app.AlertDialog.Builder(this).setMessage("Удалить разделённые дорожки? Созданные версии останутся.").setNegativeButton("Отмена",null).setPositiveButton("Удалить"){_,_->stemWork("Удаление…",{check(bundle.dir.deleteRecursively());Unit}){prefs.edit().remove(source.uri).apply();stemGains.remove(source.uri)}}.show()})
    }
    private fun beginPreview(bundle:StemEngine.Bundle,gains:FloatArray){
        val source=previewSource?.let{libraryIndex.get(it)}?:return
        controller?.pause();if(previewFrame>=bundle.frames)previewFrame=0
        runCatching{MixerSession.start(this,source.uri,source.title,bundle,gains,previewFrame)}.onSuccess{if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED&&!getSharedPreferences("mixer",MODE_PRIVATE).getBoolean("asked_notifications",false)){getSharedPreferences("mixer",MODE_PRIVATE).edit().putBoolean("asked_notifications",true).apply();requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),140)}}.onFailure{toast(it.message?:"Ошибка микшера")}
    }
    private fun showRhythmMap(r:MusicAnalysis.Report,source:Track){val panel=column();panel.addView(label("Анализ ${fmt((r.duration*1000).toLong())}. Окна по 16 с; слабые оценки пропускаются. Это не разметка куплетов и припевов.",14,muted));r.tempoWindows.forEach{w->panel.addView(label("${fmt((w.start*1000).toLong())} – ${fmt((w.end*1000).toLong())}   ${w.bpm.toInt()} BPM · уверенность ${(w.confidence*100).toInt()}%",14))};panel.addView(label("Многопризнаковая карта",17,Color.WHITE,true));val repeatedLyrics=LyricStructure.find(rawLyrics(source));if(repeatedLyrics.isNotEmpty()){panel.addView(label("Повтор текста (возможный припев)",17,Color.WHITE,true));repeatedLyrics.forEach{v->panel.addView(label("${fmt(v.firstMs)} и ${fmt(v.secondMs)} · ${v.lines} совпадающих строк",14,accent))}};val sections=SectionMap.build(r.featureFrames,r.duration);sections.forEach{v->panel.addView(label("${fmt((v.start*1000).toLong())} – ${fmt((v.end*1000).toLong())} · ${v.type}${v.repeatGroup?.let{" · группа $it"}?:""}",14,accent))};panel.addView(label("Динамическая структура",17,Color.WHITE,true));SoundProfile.chorusCandidates(r).forEach{c->panel.addView(label("Возможный повтор/припев: ${fmt((c.first*1000).toLong())} и ${fmt((c.second*1000).toLong())} · только эвристика гармонии и громкости",14,accent))};SectionArrangement.plan(r).let{sections->val merged=mutableListOf<Arrangement.Section>();sections.forEach{v->val old=merged.lastOrNull();if(old!=null&&old.part==v.part){merged[merged.lastIndex]=old.copy(end=v.end)}else merged.add(v)};merged.forEach{v->panel.addView(label("${fmt((v.start*1000).toLong())} – ${fmt((v.end*1000).toLong())} · ${v.part}",14,muted))}};val scroll=ScrollView(this);scroll.addView(panel);android.app.AlertDialog.Builder(this).setTitle("Структура и темп").setView(scroll).setPositiveButton("Закрыть",null).show()}
    private val rhythmPrefs by lazy{getSharedPreferences("manual_rhythm",MODE_PRIVATE)}
    private fun manualBeat(source:Track):BeatCorrection.Manual?=runCatching{val o=JSONObject(rhythmPrefs.getString(source.uri,null)?:return null);BeatCorrection.Manual(o.getDouble("bpm"),o.getDouble("anchor"),o.optBoolean("local"))}.getOrNull()
    private fun editBeat(source:Track){
        val old=manualBeat(source);val r=reports[source.uri];val panel=column()
        panel.addView(label("Если автоматическая сетка ошибается, задайте BPM и время любой доли оригинала. Это не определяет начало такта. Настройка применяется только к новым версиям.",14,muted))
        val bpm=EditText(this).apply{hint="BPM (50–220)";inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL;setText((old?.bpm?:r?.tempo?.bpm)?.let{String.format(java.util.Locale.ROOT,"%.2f",it)}.orEmpty())};panel.addView(bpm)
        val anchor=EditText(this).apply{hint="Время доли, секунды";inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL;setText((old?.anchor?:r?.phaseSeconds?:0.0).toString())};panel.addView(anchor)
        val tap=BeatCorrection.Tap();val hint=label("Нажмите в ритм не менее четырёх раз",14,muted);panel.addView(hint);panel.addView(btn("Тап BPM"){val value=tap.add(SystemClock.elapsedRealtime());if(value!=null){bpm.setText(String.format(java.util.Locale.ROOT,"%.2f",value));hint.text="Измеренный BPM: ${bpm.text}"}else hint.text="Продолжайте нажимать в ритм"})
        panel.addView(btn("Время текущей позиции оригинала"){val p=controller;val t=current();if(p!=null&&t?.uri==source.uri&&!MixerSession.active)anchor.setText(String.format(java.util.Locale.ROOT,"%.3f",p.currentPosition/1000.0))else toast("Включите оригинал композиции")})
        val follow=CheckBox(this).apply{text="Учитывать локальные оценки изменения темпа";setTextColor(Color.WHITE);isChecked=old?.followLocal?:false};panel.addView(follow)
        val scroll=ScrollView(this);scroll.addView(panel);val dialog=android.app.AlertDialog.Builder(this).setTitle("Ручная сетка ритма").setView(scroll).setNegativeButton("Отмена",null).setNeutralButton("Автоматически"){_,_->rhythmPrefs.edit().remove(source.uri).apply();render()}.setPositiveButton("Сохранить",null).create()
        dialog.setOnShowListener{dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener{runCatching{val m=BeatCorrection.Manual(bpm.text.toString().replace(',','.').toDouble(),anchor.text.toString().replace(',','.').toDouble(),follow.isChecked);completeReports[source.uri]?.let{require(m.anchor<it.duration){"Доля за пределами композиции"}};rhythmPrefs.edit().putString(source.uri,JSONObject().put("bpm",m.bpm).put("anchor",m.anchor).put("local",m.followLocal).toString()).apply();dialog.dismiss();render()}.onFailure{toast(it.message?:"Неверная сетка")}}};dialog.show()
    }
    private fun tagExamples(kind:String):List<PersonalTags.Example> = runCatching{val a=JSONArray(getSharedPreferences("personal_tags",MODE_PRIVATE).getString(kind,"[]"));(0 until minOf(a.length(),300)).mapNotNull{i->runCatching{val o=a.getJSONObject(i);val v=o.getJSONArray("v");PersonalTags.Example(o.getString("id"),o.getString("label"),List(PersonalTags.DIM){v.getDouble(it)})}.getOrNull()}}.getOrDefault(emptyList())
    private fun storeTags(kind:String,rows:List<PersonalTags.Example>){val a=JSONArray();rows.takeLast(300).forEach{e->a.put(JSONObject().put("id",e.id).put("label",e.label).put("v",JSONArray(e.values)))};getSharedPreferences("personal_tags",MODE_PRIVATE).edit().putString(kind,a.toString()).apply()}
    private fun chooseGenreBatch(){
        if(stemBusy)return
        if(!AstGenreModel.model(this).isFile){toast("Установите AST в каталоге моделей");showModelCatalog();return}
        val candidates=visibleSongs(searchMatches()).take(200)
        if(candidates.isEmpty())return toast("Нет песен в текущем фильтре")
        val checked=BooleanArray(candidates.size)
        android.app.AlertDialog.Builder(this).setTitle("AI-сортировка · до 20 песен").setMultiChoiceItems(candidates.map{"${it.title} · ${it.artist}"}.toTypedArray(),checked){_,i,b->checked[i]=b}.setNegativeButton("Отмена",null).setNeutralButton("Первые 20"){_,_->runGenreBatch(candidates.take(20))}.setPositiveButton("Анализировать выбранные"){_,_->val chosen=candidates.filterIndexed{i,_->checked[i]};if(chosen.size in 1..20)runGenreBatch(chosen)else toast("Выберите от 1 до 20 песен")}.show()
    }
    private fun runGenreBatch(songs:List<Track>){
        val titles=songs.associate{it.uri to it.title};stemWork("AI-сортировка…",{AstGenreModel.batch(this,songs.map{it.uri}){updateWork(it)}}){rows->
            val accepted=rows.filter{it.result?.accepted==true};val text=rows.joinToString("\n"){row->"${titles[row.uri]} — ${if(row.error!=null)"не обработана: ${row.error.take(100)}" else if(row.result?.accepted==true)row.result.scores.first().label else "неоднозначно"}"}
            val dialog=android.app.AlertDialog.Builder(this).setTitle("Жанры: ${accepted.size}/${rows.size}").setMessage("$text\n\nПесни с неоднозначным результатом не добавляются. Оригиналы и существующие плейлисты не изменяются при анализе.").setNegativeButton("Закрыть",null)
            if(accepted.isNotEmpty())dialog.setPositiveButton("Добавить в жанровые плейлисты"){_,_->var added=0;accepted.forEach{item->val t=libraryIndex.get(item.uri);if(t!=null&&t.group==t.uri&&playlists.getOrPut("AST · ${item.result!!.scores.first().label}"){linkedSetOf()}.add(t.uri))added++};save();render();toast("Добавлено песен: $added")}
            dialog.show()
        }
    }
    private fun classifyGenre(source:Track){
        if(stemBusy)return
        if(!AstGenreModel.model(this).isFile){toast("Установите AST в каталоге моделей");showModelCatalog();return}
        stemWork("Локальный анализ жанра…",{AstGenreModel.classify(this,Uri.parse(source.uri)){updateWork(it)}}){result->
            val top=result.scores.first();val text=result.scores.take(3).joinToString("\n"){"${it.label}: ${(it.probability*100).toInt()}%"}
            val dialog=android.app.AlertDialog.Builder(this).setTitle(if(result.accepted)"AST: ${top.label}" else "AST: неоднозначный жанр").setMessage("$text\n\nПроанализировано фрагментов: ${result.excerpts}. Оценки модели не являются измеренной точностью. Поддерживаются только 10 базовых жанров; фонк, монтаж, hardstyle могут определяться неверно.").setNegativeButton("Закрыть",null)
            if(result.accepted)dialog.setPositiveButton("Добавить в плейлист жанра"){_,_->if(libraryIndex.get(source.uri)!=null){playlists.getOrPut("AST · ${top.label}"){linkedSetOf()}.add(source.uri);save();toast("Добавлено в плейлист")}}
            dialog.show()
        }
    }
    private fun choosePersonalTags(source:Track){val cached=completeReports[source.uri];if(cached!=null)personalTagsDialog(source,cached)else stemWork("Анализ для персональных меток…",{TrackAnalyzer.report(this,Uri.parse(source.uri),full=true)?:error("Не удалось проанализировать")}){r->completeReports[source.uri]=r;reports[source.uri]=r;personalTagsDialog(source,r)}}
    private fun personalTagsDialog(source:Track,r:MusicAnalysis.Report){val features=PersonalTags.features(r)?:return toast("Недостаточно звуковых признаков");val panel=column();panel.addView(label("Локальное обучение на ваших примерах, а не готовая нейросеть. Нужно минимум три разные песни для каждой из двух или более меток. При неоднозначности ответ не выдаётся.",14,muted))
        for((kind,title) in listOf("genre" to "Жанр","mood" to "Настроение")){val rows=tagExamples(kind);val guess=PersonalTags.predict(features,rows,source.uri);val own=rows.firstOrNull{it.id==source.uri};panel.addView(label("$title · ${rows.size} примеров",17,Color.WHITE,true));panel.addView(label("Моя метка: ${own?.label?:"не задана"}\nПредложение: ${guess?.label?:"недостаточно данных или неоднозначно"}",14,accent));val field=EditText(this).apply{hint="Введите метку";setSingleLine();setText(own?.label.orEmpty())};panel.addView(field);panel.addView(btn("Запомнить: $title"){runCatching{val value=field.text.toString().trim();val e=PersonalTags.Example(source.uri,value,features);storeTags(kind,tagExamples(kind).filter{it.id!=source.uri}+e);toast("Метка сохранена; откройте анализ заново")}.onFailure{toast("Введите название до 80 символов")}});if(own!=null)panel.addView(btn("Убрать мою метку: $title"){storeTags(kind,tagExamples(kind).filter{it.id!=source.uri});toast("Метка удалена")})}
        val scroll=ScrollView(this);scroll.addView(panel);android.app.AlertDialog.Builder(this).setTitle("Персональный музыкальный интеллект").setView(scroll).setPositiveButton("Закрыть",null).show()
    }
    private fun alignLyricsDialog(t:Track,raw:String){if(stemBusy)return;val panel=column();panel.addView(label("Вставьте правильные слова песни по строкам. Совпадающие слова получат реальные метки из распознанного текста. При неполном совпадении исходный текст не заменяется.",14,muted));val field=EditText(this).apply{hint="Правильный текст";minLines=5;gravity=Gravity.TOP;inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE};panel.addView(field);android.app.AlertDialog.Builder(this).setTitle("Сверить распознанные слова").setView(panel).setNegativeButton("Отмена",null).setPositiveButton("Сверить"){_,_->val ref=field.text.toString();stemWork("Сопоставление слов…",{LyricAlign.align(raw,ref)}){result->if(!result.complete){android.app.AlertDialog.Builder(this).setTitle("Совпало ${result.matched}/${result.total} слов").setMessage(if(result.ambiguous)"Повторы допускают несколько разных временных привязок. Текст не изменён; уточните строки вручную." else "Строки без полного совпадения: ${result.unmatchedLines.take(30).joinToString()}. Текст не изменён; исправьте распознанные слова в редакторе LRC.").setPositiveButton("ОК",null).show()}else android.app.AlertDialog.Builder(this).setTitle("Совпали все ${result.total} слова").setMessage("Сохранить исправленные строки и пунктуацию с существующими временными метками?").setNegativeButton("Отмена",null).setPositiveButton("Сохранить"){_,_->libraryIndex.get(t.uri)?.let{target->if(rawLyrics(target)==raw){target.lyrics=result.lrc;save();render()}else toast("Текст уже изменился")}}.show()}}.show()}
    private fun alignPhraseDialog(t:Track,raw:String){
        if(stemBusy)return;val panel=column();panel.addView(label("Сопоставление правильного текста с фразами Whisper или LRC. Сохраняются существующие метки начала фраз и полностью совпадающих слов. При неполных или приблизительных совпадениях остаются только метки строк.",14,muted))
        val field=EditText(this).apply{hint="Правильный текст по строкам";minLines=5;gravity=Gravity.TOP;inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE};panel.addView(field)
        val approximate=android.widget.CheckBox(this).apply{text="Разрешить одну ошибку слова в длинной строке";setTextColor(Color.WHITE)};panel.addView(approximate)
        android.app.AlertDialog.Builder(this).setTitle("Сверить фразы").setView(panel).setNegativeButton("Отмена",null).setPositiveButton("Сверить"){_,_->val ref=field.text.toString();val fuzzy=approximate.isChecked;stemWork("Сопоставление фраз…",{PhraseAlign.align(raw,ref,fuzzy)}){r->
            val dialog=android.app.AlertDialog.Builder(this)
            if(!r.complete){dialog.setTitle("Текст не изменён").setMessage(if(r.ambiguous)"Несколько возможных временных привязок. Уточните повторяющиеся строки вручную." else "Последовательно совпало ${r.matched}/${r.total} строк. Проверьте разбиение строк: одна строка может объединять до трёх распознанных фраз, но не делить фразу.").setPositiveButton("ОК",null).show()}
            else dialog.setTitle("Совпало ${r.total} строк").setMessage("Пропущено исходных фраз: ${r.skipped}. Строк с приблизительным совпадением: ${r.corrected}. Сохранить новый текст с существующими метками?").setNegativeButton("Отмена",null).setPositiveButton("Сохранить"){_,_->val target=libraryIndex.get(t.uri);if(target!=null&&rawLyrics(target)==raw){target.lyrics=r.lrc;save();render()}else toast("Текст уже изменился или песня удалена")}.show()
        }}.show()
    }
    private fun editTimedLine(t:Track,raw:String,line:Lyric){
        val edit=runCatching{TimedLineEdit.open(raw,line)}.getOrElse{toast(it.message?:"Нельзя изменить строку");return}
        val panel=column();panel.addView(label("Исправьте распознанные фрагменты. Их начальные метки остаются прежними; новые метки не создаются.",14,muted))
        val fields=edit.fragments.map{f->panel.addView(label(SubtitleCore.stamp(f.ms),13,accent));EditText(this).apply{setSingleLine();setText(f.text);panel.addView(this)}}
        val scroll=ScrollView(this);scroll.addView(panel)
        val dialog=android.app.AlertDialog.Builder(this).setTitle("Исправить слова").setView(scroll).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",null).create()
        dialog.setOnShowListener{dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener{runCatching{val target=libraryIndex.get(t.uri)?:error("Песня удалена");require(rawLyrics(target)==raw){"Текст уже изменился"};target.lyrics=edit.replace(fields.map{it.text.toString()});save();dialog.dismiss();render()}.onFailure{toast(it.message?:"Не удалось сохранить")}}};dialog.show()
    }
    private fun tapLyricsDialog(t:Track){
        if(MixerSession.active||current()?.uri!=t.uri)return toast("Откройте эту версию в обычном плеере")
        val original=rawLyrics(t);val field=EditText(this).apply{hint="Вставьте текст по строкам";minLines=6;gravity=Gravity.TOP;inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE;setText(LyricDocument.plain(original))}
        android.app.AlertDialog.Builder(this).setTitle("Разметка строк вручную").setView(field).setNegativeButton("Отмена",null).setPositiveButton("Начать"){_,_->runCatching{LyricTapSync(field.text.toString())}.onSuccess{tapLyricsPanel(t,it,original)}.onFailure{toast(it.message?:"Некорректный текст")}}.show()
    }
    private fun tapLyricsPanel(t:Track,sync:LyricTapSync,original:String){
        val panel=column();val info=label("",15,muted);val next=label("",23,Color.WHITE,true);panel.addView(info);panel.addView(next)
        fun player():MediaController?=controller?.takeIf{!MixerSession.active&&current()?.uri==t.uri}
        fun refresh(){info.text="Отмечено ${sync.index}/${sync.lines.size}. Нажмите в момент начала строки.";next.text=sync.lines.getOrNull(sync.index)?:"Все строки размечены"};refresh()
        panel.addView(btn("▶ / Ⅱ Воспроизвести или поставить на паузу"){val p=player();if(p==null)toast("Трек изменился")else if(p.playWhenReady)p.pause()else p.play()})
        panel.addView(btn("↶ Назад на 5 секунд"){player()?.let{it.seekTo((it.currentPosition-5000).coerceAtLeast(0))}})
        panel.addView(btn("Отметить начало строки"){val p=player();if(p==null)toast("Трек изменился")else runCatching{sync.mark(p.currentPosition);refresh()}.onFailure{toast(it.message?:"Не удалось отметить")}})
        panel.addView(btn("Отменить последнюю метку"){sync.undo();refresh()})
        val dialog=android.app.AlertDialog.Builder(this).setTitle("Синхронизация с музыкой").setView(panel).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",null).create()
        dialog.setOnShowListener{dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener{runCatching{val lrc=sync.lrc();val track=libraryIndex.get(t.uri)?:error("Песня удалена");require(player()!=null){"Трек изменился"};require(rawLyrics(track)==original){"Текст уже изменился"};track.lyrics=lrc;save();dialog.dismiss();render()}.onFailure{toast(it.message?:"Не удалось сохранить")}}};dialog.show()
    }
    private fun genres(){
        heading("Жанровые ремиксы · эксперимент");body.addView(btn("← Студия"){screen="Студия";render()});if(!stemBusy)genreRecoveryButton()
        val t=current()?:run{body.addView(label("Сначала включите песню",14,muted));return};val source=libraryIndex.get(t.group)?:t
        body.addView(label("Темп адаптируется к жанру с приблизительным сохранением высоты голоса. Новые ударные, бас и переходы подстраиваются под динамику и сетку 4/4. Жанры — процедурные приближения, а не генеративная нейросеть.",14,muted))
        if(stemBusy){studioStatusView=label(stemStatus,15,accent);body.addView(studioStatusView!!);body.addView(ProgressBar(this));body.addView(btn("Отменить"){cancelWork();stemStatus="Отмена…";render()});return}
        val prefs=getSharedPreferences("stem_cache",MODE_PRIVATE);val bundle=prefs.getString(source.uri,null)?.let{StemEngine.load(this,it)}
        val available=bundle!=null||StemEngine.model(this).isFile
        body.addView(label(if(available&&useSeparation)"Продвинутый режим: разделение и замена ударных." else "Быстрый офлайн-режим: оригинальный микс сохраняется, новый ритм и бас добавляются поверх. Без разделения инструментов.",14,muted))
        if(available)body.addView(btn(if(useSeparation)"Перейти в быстрый режим" else "Перейти в режим разделения"){useSeparation=!useSeparation;render()})
        else body.addView(btn("Установить модель для продвинутого режима"){modelPicker.launch(arrayOf("*/*"))});body.addView(btn("Каталог локальных моделей"){showModelCatalog()});body.addView(btn("Скачать проверенную ONNX-модель по ссылке"){downloadModel()})
        body.addView(btn("Настроить аранжировку и сведение"){genreMixDialog(available&&useSeparation)});body.addView(btn(manualBeat(source)?.let{"Ручная сетка · ${it.bpm} BPM"}?:"Исправить BPM / долю вручную"){editBeat(source)});body.addView(btn("Определить жанр · AST (офлайн)"){classifyGenre(source)});body.addView(btn("Определить настроение · MERT (офлайн)"){classifyMood(source)});body.addView(btn("Жанр и настроение · обучить на своих песнях"){choosePersonalTags(source)});body.addView(btn("Подобрать 5 ремиксов по характеру"){
            val cached=completeReports[source.uri]
            if(cached!=null){showRecommendations(source,cached)}else stemWork("Анализ для рекомендаций…",{TrackAnalyzer.report(this,Uri.parse(source.uri),full=true)?:error("Не удалось проанализировать")}){r->completeReports[source.uri]=r;reports[source.uri]=r;showRecommendations(source,r)}
        });body.addView(btn("Предпросмотр аранжировки по тактам…"){
            val cached=completeReports[source.uri]
            if(cached!=null)previewArrangement(source,cached) else stemWork("Анализ для карты аранжировки…",{TrackAnalyzer.report(this,Uri.parse(source.uri),full=true)?:error("Не удалось проанализировать")}){r->completeReports[source.uri]=r;reports[source.uri]=r;previewArrangement(source,r)}
        });body.addView(btn("Создать несколько ремиксов…"){
            val styles=GenreEngine.styles;val selected=BooleanArray(styles.size)
            android.app.AlertDialog.Builder(this).setTitle("Выберите жанры").setMultiChoiceItems(styles.map{it.name}.toTypedArray(),selected){_,i,checked->selected[i]=checked}
                .setNegativeButton("Отмена",null).setNeutralButton("Все 30"){_,_->confirmBatch(source,styles)}.setPositiveButton("Создать"){_,_->val chosen=styles.filterIndexed{i,_->selected[i]};if(chosen.isEmpty())toast("Выберите хотя бы один жанр") else confirmBatch(source,chosen)}.show()
        })
        reports[source.uri]?.let{r->body.addView(label("${r.tempo?.bpm?.toInt()?:"?"} BPM · ${r.key?:"тональность неизвестна"} · ${RemixAdvisor.energyLabel(r)}",16,accent,true));body.addView(label((MusicalIntelligence.profile(r).labels+SoundProfile.descriptors(r.spectrum)).joinToString(" · "),14,muted));if(r.tempoWindows.isNotEmpty()||r.featureFrames.isNotEmpty()){val ref=r.tempo?.bpm;body.addView(label(if(ref!=null&&RhythmMap.unstable(r.tempoWindows,ref))"Темп меняется: новая ритмическая сетка следует локальным оценкам BPM; точные доли не гарантированы." else "Локальные оценки темпа (${r.tempoWindows.size} окон)",14,accent));body.addView(btn("Карта темпа и динамики…"){showRhythmMap(r,source)})};RemixAdvisor.repetitions(r).take(3).forEach{v->body.addView(label("Похожая гармония: ${fmt((v.first*1000).toLong())} / ${fmt((v.second*1000).toLong())} · не обязательно припев",13,muted))}}
        GenreEngine.styles.forEach{style->card(style.name,"Цель: ${style.target} BPM · новые ударные и бас"){generateGenres(source,listOf(style))}}
    }
    private fun confirmBatch(source:Track,styles:List<GenreEngine.Style>){
        android.app.AlertDialog.Builder(this).setTitle("Создать ${styles.size} версий?").setMessage("Анализ и подготовка аудио выполняются один раз. Каждая версия сохраняется в WAV (~10 МБ за минуту). Готовые версии сохраняются для ручного продолжения после отмены или сбоя.").setNegativeButton("Отмена",null).setPositiveButton("Создать"){_,_->generateGenres(source,styles)}.show()
    }
    private val completeReports=ReportCache<String,MusicAnalysis.Report>(8)
    private var useSeparation=true
    private var genreMix=GenreMix()
    private fun loadGenreMix(){val p=getSharedPreferences("genre_mix",MODE_PRIVATE);genreMix=runCatching{GenreMix.from(FloatArray(6){p.getFloat("gain$it",1f)})}.getOrDefault(GenreMix())}
    private fun saveGenreMix(){val edit=getSharedPreferences("genre_mix",MODE_PRIVATE).edit();genreMix.values().forEachIndexed{i,v->edit.putFloat("gain$i",v)};edit.apply()}
    private fun genreMixDialog(advanced:Boolean){
        val panel=column();val values=genreMix.values();val sliders=mutableListOf<SeekBar>();val names=listOf("Новые ударные и переходы","Новый бас","Новая мелодия","Исходные инструменты / микс","Вокал (только разделение)","Исходные ударные (только разделение)")
        val summary=label("100% — уровень жанрового шаблона. Мастеринг может изменить общую громкость.",14,muted);panel.addView(summary)
        for(i in names.indices){val title=label("${names[i]}: ${(values[i]*100).toInt()}%",14);panel.addView(title);val seek=SeekBar(this).apply{max=200;progress=(values[i]*100).toInt();isEnabled=advanced||i<4;setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onStartTrackingTouch(s:SeekBar){};override fun onStopTrackingTouch(s:SeekBar){};override fun onProgressChanged(s:SeekBar,p:Int,user:Boolean){values[i]=p/100f;title.text="${names[i]}: $p%"}})};sliders.add(seek);panel.addView(seek)}
        val profiles=GenreMix.profiles.entries.filter{advanced||it.key !in listOf("Инструментальный","Вокал вперёд")};panel.addView(btn("Готовые варианты сведения…"){android.app.AlertDialog.Builder(this).setTitle("Характер ремикса").setItems(profiles.map{it.key}.toTypedArray()){_,index->profiles[index].value.values().forEachIndexed{i,v->sliders[i].progress=(v*100).toInt()}}.show()})
        val scroll=ScrollView(this);scroll.addView(panel);android.app.AlertDialog.Builder(this).setTitle("Сведение жанровых ремиксов").setView(scroll).setNegativeButton("Отмена",null).setNeutralButton("Сброс"){_,_->genreMix=GenreMix();saveGenreMix();render()}.setPositiveButton("Применить"){_,_->genreMix=GenreMix.from(values);saveGenreMix();toast("Настройки применятся к новым версиям");render()}.show()
    }
    private data class PendingGenre(val id:String,val source:String,val plan:GenreCheckpoint.Plan)
    private fun genrePrefs()=getSharedPreferences("genre_checkpoint",MODE_PRIVATE)
    private fun pendingGenre():PendingGenre? {
        val o=JSONObject(genrePrefs().getString("plan",null)?:return null);val id=o.getString("id");EffectCheckpoint.directory(java.io.File(filesDir,"mixes"),id)
        val a=o.getJSONArray("styles");require(a.length() in 1..30);val styles=List(a.length()){i->GenreEngine.styles.single{it.name==a.getString(i)}}
        val m=o.getJSONArray("mix");require(m.length()==6);val mix=GenreMix.from(FloatArray(6){m.getDouble(it).toFloat()})
        val manual=o.optJSONObject("manual")?.let{BeatCorrection.Manual(it.getDouble("bpm"),it.getDouble("anchor"),it.getBoolean("local"))}
        return PendingGenre(id,o.getString("source"),GenreCheckpoint.Plan(styles,mix,manual,o.getBoolean("advanced")))
    }
    private fun genreRecoveryButton(){if(genrePrefs().contains("plan"))body.addView(btn("Продолжить / удалить пакет жанров…"){recoverGenre()})}
    private fun recoverGenre(){
        if(stemBusy)return
        val job=runCatching{pendingGenre()}.getOrElse{toast("План повреждён. Файлы сохранены.");return}?:return
        val dir=EffectCheckpoint.directory(java.io.File(filesDir,"mixes"),job.id);val parent=libraryIndex.get(job.source)?.takeIf{it.group==it.uri}
        val n=job.plan.styles.indices.count{java.io.File(dir,"version-$it.sha256").isFile}
        val dialog=android.app.AlertDialog.Builder(this).setTitle("Незавершённые жанровые ремиксы").setMessage("${parent?.title?:"Оригинал недоступен"} · $n/${job.plan.styles.size} контрольных точек. Настройки сохранены. Готовые файлы проверяются перед повторным использованием.").setNegativeButton("Закрыть",null).setNeutralButton("Удалить пакет"){_,_->
            if(stemBusy)return@setNeutralButton
            val protected=protectedMixes();if(job.plan.styles.indices.any{"${dir.name}/version-$it.wav" in protected}){toast("Версии уже используются. Продолжите сохранение.");return@setNeutralButton}
            if((!dir.exists()||dir.deleteRecursively())&&genrePrefs().edit().remove("plan").commit()){toast("Пакет удалён");render()}else toast("Не удалось удалить пакет")
        }
        if(parent!=null)dialog.setPositiveButton("Продолжить"){_,_->runGenre(parent,job)};dialog.show()
    }
    private fun generateGenres(source:Track,styles:List<GenreEngine.Style>){
        if(stemBusy)return
        if(genrePrefs().contains("plan")){recoverGenre();return}
        val prefs=getSharedPreferences("stem_cache",MODE_PRIVATE);val stored=prefs.getString(source.uri,null)?.let{StemEngine.load(this,it)}
        val job=PendingGenre(java.util.UUID.randomUUID().toString(),source.uri,GenreCheckpoint.Plan(styles.toList(),genreMix,manualBeat(source),useSeparation&&(stored!=null||StemEngine.model(this).isFile)))
        val o=JSONObject().put("id",job.id).put("source",job.source).put("styles",JSONArray(styles.map{it.name})).put("mix",JSONArray(job.plan.mix.values().map{it.toDouble()})).put("advanced",job.plan.separated)
        job.plan.manual?.let{o.put("manual",JSONObject().put("bpm",it.bpm).put("anchor",it.anchor).put("local",it.followLocal))}
        if(!genrePrefs().edit().putString("plan",o.toString()).commit()){toast("Не удалось сохранить план");return};runGenre(source,job)
    }
    private data class GenreResult(val files:List<Pair<GenreEngine.Style,java.io.File>>,val report:MusicAnalysis.Report,val bpm:Double,val quality:Map<String,RemixQuality.Result>)
    private fun runGenre(source:Track,job:PendingGenre){
        if(stemBusy)return
        val styles=job.plan.styles;val controls=job.plan.mix;val manual=job.plan.manual;val advanced=job.plan.separated;val prefs=getSharedPreferences("stem_cache",MODE_PRIVATE)
        val dir=EffectCheckpoint.directory(java.io.File(filesDir,"mixes"),job.id)
        val referenced=styles.indices.count{libraryIndex.get(batchUri(java.io.File(dir,"version-$it.wav")))!=null};val published=styles.indices.count{val file=java.io.File(dir,"version-$it.wav");file.isFile&&libraryIndex.get(batchUri(file))!=null}
        if(published==styles.size){if(saveLibrary(true)&&runCatching{EffectCheckpoint.finish(dir);genrePrefs().edit().remove("plan").commit()}.getOrDefault(false)){toast("Пакет уже сохранён");render()}else toast("Не удалось подтвердить сохранение");return}
        if(referenced>0){toast("Часть версий уже в библиотеке. Повторная запись заблокирована.");return}
        var lastStatus="";fun status(message:String){if(message!=lastStatus){lastStatus=message;updateWork(message)}}
        stemWork("Полный анализ композиции…",{
            val raw=java.io.File.createTempFile("genre-input-",".pcm",cacheDir)
            try {
                val observer=RenderAnalysis();val frames=StemEngine.decode(this,Uri.parse(source.uri),raw,observer::frame);val report=observer.finish()
                val grid=BeatCorrection.resolve(report,manual)?:error("Сетка не определена. Удалите пакет и укажите BPM и долю вручную.");val bpm=grid.bpm;val phase=grid.phase
                val stems=if(advanced)prefs.getString(source.uri,null)?.let{StemEngine.load(this,it)}?.takeIf{StemEngine.matchesSource(it,raw)}?:StemEngine.separateDecoded(this,Uri.parse(source.uri),raw,::status).also{prefs.edit().putString(source.uri,it.dir.name).apply()} else null
                val inputs=if(stems==null)emptyList()else List(stems.count){java.io.File(stems.dir,"$it.pcm")}
                val sections=SectionArrangement.plan(report,frames/44100.0)
                val files=GenreCheckpoint.render(raw,inputs,dir,job.plan,bpm,{i,style->status("${i+1}/${styles.size} · ${style.name}: готовая версия проверена")}){style,file,i->
                    val plan=TimeStretch.plan(bpm,style.target);val tmp=java.io.File.createTempFile("tempo-",".wav",dir)
                    try{
                        val update:(Int)->Unit={n->status("${i+1}/${styles.size} · ${style.name}: сведение $n%")}
                        val groove=AdaptiveGroove(plan.gridBpm,phase,grid.windows,grid.reference,anchor=grid.anchor)
                        if(stems!=null)GenreEngine.render(stems.dir,frames,stems.count,tmp,style,plan.gridBpm,phase,report.chords,report.energy,groove,controls,sections,update)
                        else GenreEngine.renderFromMix(raw,tmp,style,plan.gridBpm,phase,report.chords,report.energy,groove,controls,sections,update)
                        TimeStretch.render(tmp,file,frames,plan.speed){n->status("${i+1}/${styles.size} · ${style.name}: темп $n%")};Mastering.normalizeGenerated(file)
                    }finally{tmp.delete()}
                }
                val quality=files.associate{(style,file)->status("Проверка · ${style.name}");file.name to RemixQuality.inspect(file,style.target)}
                GenreResult(files,report,bpm,quality)
            } finally {raw.delete()}
        }){result->
            completeReports[source.uri]=result.report;reports[source.uri]=result.report
            val parent=libraryIndex.get(source.uri)?.takeIf{it.group==it.uri}
            if(parent==null){toast("Оригинал удалён или перемещён. Пакет сохранён.")}
            else{val versions=result.files.map{(style,file)->val speed=TimeStretch.plan(result.bpm,style.target).speed;Track(batchUri(file),parent.title+" · "+style.name+(if(advanced)"" else " · Mix"),parent.artist,parent.uri,TimeStretch.lyrics(parent.lyrics,speed),tempoRatio=speed,album=parent.album,folder=parent.folder)}
                val edit=qualityPrefs.edit();versions.zip(result.files).forEach{(v,pair)->result.quality[pair.second.name]?.let{q->edit.putString(v.uri,qualityJson(q).toString())}};check(edit.commit()){ "Не удалось сохранить результаты анализа" }
                tracks.addAll(versions.filter{libraryIndex.get(it.uri)==null});check(saveLibrary(true)){"Не удалось сохранить библиотеку"};EffectCheckpoint.finish(dir);check(genrePrefs().edit().remove("plan").commit()){ "Не удалось подтвердить завершение пакета" };screen="Версии";if(versions.size==1)start(versions.first());toast("Сохранено версий: ${versions.size}")}
        }
    }
    private fun downloads(){heading("Загрузки");body.addView(btn("Свободное аудио · без регистрации"){commonsDialog()});body.addView(btn("Поиск музыки · Jamendo"){catalogDialog()});body.addView(label("Прямая HTTPS-ссылка на разрешённый к скачиванию аудиофайл. Файл сохраняется локально.",14,muted));if(stemBusy){body.addView(label(stemStatus,14,accent));return};val url=EditText(this).apply{hint="https://…/song.mp3";setSingleLine();inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI};body.addView(url);body.addView(btn("Скачать и добавить"){val link=url.text.toString();android.app.AlertDialog.Builder(this).setMessage("Подтвердите, что источник разрешает скачивание файла.").setNegativeButton("Отмена",null).setPositiveButton("Скачать"){_,_->stemWork("Загрузка…",{MusicDownload.fetch(this,link){p->runOnUiThread{if(!isDestroyed&&screen=="Загрузки"){stemStatus="Загрузка: $p%";render()}}}},discard={file->file.delete()}){file->val uri=androidx.core.content.FileProvider.getUriForFile(this,"app.remix.player.files",file).toString();val r=MediaMetadataRetriever();var title=runCatching{Uri.parse(link).lastPathSegment?.substringBeforeLast('.')}.getOrNull()?:"Аудио";var artist="Неизвестный исполнитель";try{r.setDataSource(file.absolutePath);title=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?:title;artist=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)?:artist}catch(_:Exception){}finally{runCatching{r.release()}};tracks.add(Track(uri,title,artist,uri));save();screen="Музыка";toast("Файл добавлен")}}.show()})}
    private fun applyPreset(p:Preset){Presets.active=p;controller?.playbackParameters=PlaybackParameters(p.speed,p.pitch)}
    private var lyricToolsExpanded=false
    private fun lyrics(){heading("Текст песни");val t=libraryIndex.get(MixerSession.request?.source)?:current();if(t==null){body.addView(label("Сначала включите композицию.",14,muted));return};body.addView(btn("Импортировать LRC / TXT"){lyricTarget=t.uri;lyricRevision=lyricRevision(t);lyricPicker.launch(arrayOf("*/*"))});body.addView(btn(if(lyricsBusy)"Поиск текста…" else "Найти синхронный текст (онлайн)"){
        if(!lyricsBusy)android.app.AlertDialog.Builder(this).setTitle("Поиск в LRCLIB").setMessage("Сервису будут переданы название песни, исполнитель и длительность. Сам аудиофайл не отправляется. Найденный текст будет сохранён для офлайн-просмотра.").setNegativeButton("Отмена",null).setPositiveButton("Найти"){_,_->
            val original=if(t.tempoRatio!=null)tracks.find{it.uri==t.group}?:t else t;val before=rawLyrics(t);val originalBefore=original.lyrics;val groupBefore=t.group;val ratioBefore=t.tempoRatio;val seconds=if(MixerSession.active)MixerSession.request?.frames?.div(44100L) else controller?.duration?.takeIf{it>0}?.let{(it*(t.tempoRatio?:1.0)/1000).toLong()};lyricsBusy=true;render();io.execute{val result=runCatching{LyricsLookup.fetch(original.title,original.artist,seconds)};runOnUiThread{if(!isDestroyed){lyricsBusy=false;result.onSuccess{raw->if(raw==null)toast("Синхронизированный текст не найден")else{val target=libraryIndex.get(t.uri);if(target==null||rawLyrics(target)!=before||target.group!=groupBefore||target.tempoRatio!=ratioBefore)toast("Текст или версия изменились; результат поиска не сохранён")else{target.lyrics=if(ratioBefore!=null)TimeStretch.lyrics(raw,ratioBefore)else raw;val origin=libraryIndex.get(original.uri);if(origin!=null&&origin.uri!=target.uri&&origin.lyrics==originalBefore&&origin.lyrics.isBlank())origin.lyrics=raw;save();toast("Текст сохранён")}}}.onFailure{toast("Поиск не удался: ${it.message}")};render()}}}
        }.show()
    });val raw=rawLyrics(t);body.addView(btn("Редактировать текст / LRC"){editLyrics(t)});body.addView(btn("Синхронизировать строки вручную"){tapLyricsDialog(t)});if(!stemBusy&&Lrc.parse(raw).any{WordLyrics.parse(it).words.isNotEmpty()})body.addView(btn("Сверить слова с правильным текстом"){alignLyricsDialog(t,raw)});if(!stemBusy&&Lrc.parse(raw).isNotEmpty())body.addView(btn("Сверить фразы с правильным текстом"){alignPhraseDialog(t,raw)});if(!stemBusy)body.addView(btn("Модели распознавания · каталог"){showModelCatalog()});if(stemBusy){body.addView(label(stemStatus,14,accent));body.addView(btn("Отменить обработку"){cancelWork()})}else{body.addView(btn(if(LocalTranscription.model(this)==null)"Импорт модели распознавания Vosk (ZIP)" else "Заменить модель распознавания"){speechPicker.launch(arrayOf("*/*"))});if(LocalTranscription.model(this)!=null)body.addView(btn("Vosk · распознать слова"){recognizeLyrics(t)});body.addView(btn(if(WhisperLocal.installed(this)!=null)"Whisper · распознать текст" else "Whisper · установить модель"){recognizeWhisper(t)})};activeLyrics=Lrc.parse(raw);if(activeLyrics.isEmpty()){body.addView(label(if(raw.isBlank())"Добавьте текст песни (LRC или TXT)." else "Обычный текст · без синхронизации. Чтобы включить подсветку, разметьте строки вручную.",15,muted));if(raw.isNotBlank()){val plain=label(raw,20,Color.WHITE);plain.setTextIsSelectable(true);body.addView(plain)};return};body.addView(btn("Подстроить синхронизацию ±…"){shiftLyricsDialog(t,raw)});body.addView(btn("Экспортировать LRC / SRT…"){exportSubtitles(t,raw)});body.addView(btn(if(translationBusy)"Перевод…" else "Перевести текст"){chooseTranslation(t,raw)});visibleTranslation=translated(t,raw).takeIf{it.size==activeLyrics.size}.orEmpty();if(visibleTranslation.isNotEmpty())body.addView(btn("Убрать перевод"){getSharedPreferences("translations",MODE_PRIVATE).edit().remove(translationKey(t,raw)).apply();render()});val tools=column();while(body.childCount>1){val view=body.getChildAt(1);body.removeViewAt(1);tools.addView(view)};val toggle=btn(if(lyricToolsExpanded)"Скрыть инструменты текста" else "Инструменты текста…"){};toggle.setOnClickListener{lyricToolsExpanded=!lyricToolsExpanded;tools.visibility=if(lyricToolsExpanded)View.VISIBLE else View.GONE;toggle.text=if(lyricToolsExpanded)"Скрыть инструменты текста" else "Инструменты текста…"};body.addView(toggle);tools.visibility=if(lyricToolsExpanded||stemBusy)View.VISIBLE else View.GONE;body.addView(tools);val scroll=ScrollView(this);lyricScroll=scroll;val lines=column();scroll.addView(lines);body.addView(scroll,LinearLayout.LayoutParams(-1,dp(330)));wordLines=activeLyrics.map(WordLyrics::parse);if(wordLines.any{it.words.isNotEmpty()})body.addView(label("Удерживайте строку, чтобы исправить слова без изменения времени.",13,muted));val tv=mutableListOf<TextView>();lyricViews=activeLyrics.mapIndexed{idx,l->label(wordLines[idx].text,22,muted,true).apply{setOnClickListener{seekLyrics(l.ms)};if(wordLines[idx].words.isNotEmpty())setOnLongClickListener{editTimedLine(t,raw,l);true};lines.addView(this);if(visibleTranslation.isNotEmpty()){val tr=label(visibleTranslation[idx],15,muted);tr.setOnClickListener{seekLyrics(l.ms)};lines.addView(tr);tv.add(tr)}}};translationViews=tv;highlight(if(MixerSession.active)MixerSession.position()*1000/44100 else controller?.currentPosition?:0L)}
    private fun seekLyrics(ms:Long){if(MixerSession.active)runCatching{MixerSession.seek(this,ms*44100/1000)}.onFailure{toast(it.message?:"Ошибка перемотки")}else controller?.seekTo(ms)}
    private fun highlight(ms:Long){
        val i=Lrc.current(activeLyrics,ms);val line=wordLines.getOrNull(i);val w=line?.let{WordLyrics.current(it,ms)}?:-1
        if(i==lastLine&&w==lastWord)return
        if(i!=lastLine){
            translationViews.getOrNull(lastLine)?.setTextColor(muted);translationViews.getOrNull(i)?.setTextColor(Color.WHITE)
            lyricViews.getOrNull(lastLine)?.let{v->v.text=wordLines.getOrNull(lastLine)?.text?:v.text;v.setTextColor(muted)}
            lyricViews.getOrNull(i)?.let{v->v.setTextColor(accent);lyricScroll?.post{lyricScroll?.smoothScrollTo(0,(v.top-dp(110)).coerceAtLeast(0))}}
        }
        if(line!=null&&i in lyricViews.indices){
            val span=android.text.SpannableString(line.text)
            if(w>=0){val word=line.words[w];span.setSpan(android.text.style.ForegroundColorSpan(Color.WHITE),word.start,word.end,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)}
            lyricViews[i].text=span
        }
        lastLine=i;lastWord=w
    }
    private fun updateWork(message:String){runOnUiThread{if(!isDestroyed){stemStatus=message;backupStatus?.text=message;studioStatusView?.text=message}}}
    private var backupStatus:TextView?=null
    private val backupPicker=registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")){dest->
        if(dest!=null&&!stemBusy) runCatching{exportLibrary(dest)}.onFailure{toast(it.message?:"Не удалось подготовить архив");runCatching{contentResolver.delete(dest,null,null)}}
    }
    private val restorePicker=registerForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null&&!stemBusy)restoreLibrary(uri)
    }
    private fun exportLibrary(dest:Uri){
        val snapshot=tracks.map{it.copy()};if(snapshot.isEmpty()){toast("Библиотека пуста");return}
        val ids=snapshot.mapIndexed{i,t->t.uri to i}.toMap();val groups=snapshot.mapIndexed{i,t->ids[t.group]?:i}.let{g->g.mapIndexed{i,parent->if(g[parent]==parent)parent else i}}
        val prefs=mutableMapOf<Int,Int>();snapshot.forEachIndexed{i,t->if(groups[i]==i){val v=ids[versionPrefs.getString(t.uri,null)];if(v!=null&&groups[v]==i)prefs[i]=v}}
        val lists=playlists.mapValues{(_,entries)->entries.mapNotNull{ids[it]}.map{groups[it]}.distinct()}
        BackupCore.validate(groups,prefs,lists.values.toList())
        val a=JSONArray();snapshot.forEachIndexed{i,t->a.put(JSONObject().put("title",t.title).put("artist",t.artist).put("group",groups[i]).put("lyrics",t.lyrics).put("favorite",t.favorite).put("tempoRatio",t.tempoRatio?:JSONObject.NULL).put("album",t.album).put("folder",t.folder))}
        val pl=JSONObject();lists.forEach{(name,v)->pl.put(name,JSONArray(v))};val pv=JSONObject();prefs.forEach{(g,v)->pv.put(g.toString(),v)}
        val grids=JSONObject();val translations=JSONObject();val examples=JSONObject();val presets=JSONArray()
        snapshot.forEachIndexed{i,t->if(groups[i]==i)manualBeat(t)?.let{m->grids.put(i.toString(),JSONObject().put("bpm",m.bpm).put("anchor",m.anchor).put("local",m.followLocal))};val raw=rawLyrics(t);val lines=translated(t,raw);if(PortableSettings.validateTranslation(raw,lines))translations.put(i.toString(),JSONArray(lines))}
        for(kind in listOf("genre","mood")){val rows=JSONArray();tagExamples(kind).forEach{e->val id=ids[e.id];if(id!=null&&groups[id]==id)rows.put(JSONObject().put("id",id).put("label",e.label).put("v",JSONArray(e.values)))};examples.put(kind,rows)}
        customPresets.forEach{p->presets.put(JSONObject().put("name",p.name).put("values",JSONArray(CustomPresetCore.values(p).map{it.toDouble()})))}
        val portable=capturePortablePlayback(ids);val meta=JSONObject().put("playback",PortablePlaybackJson.encode(portable)).put("tracks",a).put("playlists",pl).put("preferred",pv).put("grids",grids).put("translations",translations).put("examples",examples).put("presets",presets).toString().toByteArray(Charsets.UTF_8)
        stemWork("Создание резервной копии…",{
            try{val items=snapshot.map{t->val uri=Uri.parse(t.uri);val ext=android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(contentResolver.getType(uri))?:uri.lastPathSegment?.substringAfterLast('.',"").orEmpty();BackupCore.Item(ext){contentResolver.openInputStream(uri)?:error("Файл недоступен: ${t.title}")}}
                contentResolver.openOutputStream(dest,"w")?.use{out->BackupCore.write(out,meta,items){n->if(n%10==0||n==items.size)updateWork("Резервная копия: $n/${items.size}")}}?:error("Не удалось открыть файл")
            }catch(e:Throwable){runCatching{contentResolver.delete(dest,null,null)};throw e}
        }){toast("Резервная копия сохранена: ${snapshot.size} файлов")}
    }
    private data class RestoredLibrary(val dir:java.io.File,val tracks:List<Track>,val lists:Map<String,Set<String>>,val preferred:Map<String,String>,val grids:Map<String,BeatCorrection.Manual>,val translations:Map<String,List<String>>,val examples:Map<String,List<PersonalTags.Example>>,val presets:List<Preset>,val playback:PortablePlaybackJson.Data?)
    private fun restoreLibrary(uri:Uri){
        stemWork("Проверка резервной копии…",{
            val dir=java.io.File(filesDir,"downloads/restore-"+java.util.UUID.randomUUID())
            dir.parentFile!!.mkdirs()
            try{val restored=contentResolver.openInputStream(uri)?.use{BackupCore.read(it,dir){n,total->if(n%10==0||n==total)updateWork("Восстановление: $n/$total")}}?:error("Архив недоступен")
                val json=JSONObject(restored.metadata.toString(Charsets.UTF_8));val a=json.getJSONArray("tracks");require(a.length()==restored.files.size){"Число записей не совпадает"}
                val groups=(0 until a.length()).map{a.getJSONObject(it).getInt("group")}
                val pl=json.getJSONObject("playlists");val lists=linkedMapOf<String,List<Int>>();pl.keys().forEach{key->require(key.isNotBlank()&&key.length<=80);val arr=pl.getJSONArray(key);lists[key]=(0 until arr.length()).map{arr.getInt(it)}}
                val pv=json.getJSONObject("preferred");val prefs=mutableMapOf<Int,Int>();pv.keys().forEach{key->prefs[key.toInt()]=pv.getInt(key)};BackupCore.validate(groups,prefs,lists.values.toList())
                val ids=restored.files.map{file->androidx.core.content.FileProvider.getUriForFile(this,"app.remix.player.files",file).toString()}
                val entries=ids.mapIndexed{i,id->val t=a.getJSONObject(i);val title=t.getString("title");val artist=t.getString("artist");val lyrics=t.optString("lyrics");require(title.length<=4096&&artist.length<=4096&&lyrics.length<=2_000_000);Track(id,title,artist,ids[groups[i]],lyrics,t.optBoolean("favorite"),t.optDouble("tempoRatio",Double.NaN).takeIf{it.isFinite()&&it in .4..1.8},t.optString("album").take(4096),t.optString("folder").take(4096))}
                val grids=linkedMapOf<Int,BeatCorrection.Manual>();json.optJSONObject("grids")?.let{g->g.keys().forEach{key->val i=key.toInt();require(i in groups.indices&&groups[i]==i);val m=g.getJSONObject(key);grids[i]=BeatCorrection.Manual(m.getDouble("bpm"),m.getDouble("anchor"),m.optBoolean("local"))}}
                val translations=linkedMapOf<String,List<String>>();json.optJSONObject("translations")?.let{tr->tr.keys().forEach{key->val i=key.toInt();require(i in entries.indices);val t=entries[i];val raw=t.lyrics.ifBlank{if(t.tempoRatio!=null)TimeStretch.lyrics(entries[groups[i]].lyrics,t.tempoRatio)else ""};val arr=tr.getJSONArray(key);require(arr.length()<=2000);val lines=(0 until arr.length()).map{arr.getString(it)};require(PortableSettings.validateTranslation(raw,lines));translations[translationKey(t,raw)]=lines}}
                val examples=linkedMapOf<String,List<PersonalTags.Example>>();for(kind in listOf("genre","mood")){val rows=json.optJSONObject("examples")?.optJSONArray(kind)?:JSONArray();require(rows.length()<=300);examples[kind]=(0 until rows.length()).map{i->val e=rows.getJSONObject(i);val id=e.getInt("id");require(id in groups.indices&&groups[id]==id);val v=e.getJSONArray("v");require(v.length()==PersonalTags.DIM);PersonalTags.Example(ids[id],e.getString("label"),List(PersonalTags.DIM){v.getDouble(it)})}}
                val ps=json.optJSONArray("presets")?:JSONArray();require(ps.length()<=100);val presets=(0 until ps.length()).map{i->val e=ps.getJSONObject(i);val v=e.getJSONArray("values");require(v.length()==7);CustomPresetCore.create(e.getString("name"),FloatArray(7){v.getDouble(it).toFloat()})}
                RestoredLibrary(dir,entries,lists.mapValues{(_,v)->v.map{ids[it]}.toSet()},prefs.mapKeys{ids[it.key]}.mapValues{ids[it.value]},PortableSettings.remap(grids,ids),translations,examples,presets,json.optJSONObject("playback")?.let{PortablePlaybackJson.decode(it,ids)})
            }catch(e:Throwable){dir.deleteRecursively();throw e}
        },discard={r->r.dir.deleteRecursively()}){r->
            if(tracks.size.toLong()+r.tracks.size>BackupCore.MAX_TRACKS){r.dir.deleteRecursively();toast("После восстановления будет больше 60 000 файлов");return@stemWork};val previous=tracks.toList();val oldLists=playlists.mapValues{it.value.toMutableSet()};val merged=linkedMapOf<String,MutableSet<String>>();oldLists.forEach{(k,v)->merged[k]=v.toMutableSet()}
            r.lists.forEach{(name,ids)->var candidate=name;var n=2;while(candidate in merged){candidate=name.take(68)+" ($n)";n++};merged[candidate]=ids.toMutableSet()}
            tracks.addAll(r.tracks);playlists.clear();playlists.putAll(merged)
            if(!persistLibrary()){tracks.clear();tracks.addAll(previous);playlists.clear();playlists.putAll(oldLists);reindex();r.dir.deleteRecursively();toast("Не удалось сохранить библиотеку")}
            else{val edit=versionPrefs.edit();r.preferred.forEach{(k,v)->edit.putString(k,v)};edit.apply();val gridEdit=rhythmPrefs.edit();r.grids.forEach{(id,m)->gridEdit.putString(id,JSONObject().put("bpm",m.bpm).put("anchor",m.anchor).put("local",m.followLocal).toString())};gridEdit.apply();val tr=getSharedPreferences("translations",MODE_PRIVATE).edit();r.translations.forEach{(key,lines)->tr.putString(key,JSONArray(lines).toString())};tr.apply();r.examples.forEach{(kind,rows)->storeTags(kind,PortableSettings.mergeExamples(tagExamples(kind),rows))};val mergedPresets=PortableSettings.mergePresets(customPresets,r.presets,Presets.all.map{it.name});customPresets.clear();customPresets.addAll(mergedPresets.items);saveCustomPresets();r.playback?.let{restorePortablePlayback(it,r.tracks.map{t->t.uri})};toast("Восстановлено файлов: ${r.tracks.size}, пресетов: ${mergedPresets.imported}, пропущено: ${mergedPresets.skipped}")}
        }
    }
    private fun capturePortablePlayback(ids:Map<String,Int>):PortablePlaybackJson.Data {
        val c=PortablePlayback.Controls(EqualizerSettings.get(),genreMix.values().toList(),PlaybackOptions.fadeMs,PlaybackOptions.overlapMs,randomVersions)
        val queue=controller?.let{p->if(p.mediaItemCount in 1..QueueSnapshot.LIMIT)PortablePlayback.captureQueue(QueueSnapshot.Saved(List(p.mediaItemCount){p.getMediaItemAt(it).mediaId},p.currentMediaItemIndex,p.currentPosition.coerceAtLeast(0),p.duration.coerceAtLeast(0),p.shuffleModeEnabled,p.repeatMode),ids)else null}
        val gains=linkedMapOf<Int,List<Float>>();val stored=getSharedPreferences("mixer_gains",MODE_PRIVATE)
        stored.all.forEach{(key,value)->ids[key]?.let{i->runCatching{val a=JSONArray(value as String);require(a.length() in listOf(4,6));val v=List(a.length()){a.getDouble(it).toFloat()};if(PortablePlayback.validGains(v))gains[i]=v}}}
        val history=StatsStore.read(this).mapNotNull{e->ids[e.id]?.let{it to e}}.toMap()
        return PortablePlaybackJson.Data(c,queue,gains,history)
    }
    private fun restorePortablePlayback(data:PortablePlaybackJson.Data,ids:List<String>){
        val g=getSharedPreferences("mixer_gains",MODE_PRIVATE).edit();data.gains.forEach{(i,v)->g.putString(ids[i],JSONArray(v.map{it.toDouble()}).toString())};g.apply()
        StatsStore.importHistory(this,data.history.values.toList())
        val options=arrayOf("Эквалайзер, сведение и переходы","Очередь и позиция (текущая музыка остановится)")
        val checked=booleanArrayOf(false,false)
        android.app.AlertDialog.Builder(this).setTitle("Восстановить настройки?").setMultiChoiceItems(options,checked){_,i,value->checked[i]=value}.setNegativeButton("Оставить текущие",null).setPositiveButton("Применить"){_,_->
            if(checked[0]){val c=data.controls;EqualizerSettings.set(c.eq);val eq=getSharedPreferences("eq",MODE_PRIVATE).edit();c.eq.forEachIndexed{i,v->eq.putFloat("band$i",v)};eq.apply();genreMix=GenreMix.from(c.mix.toFloatArray());saveGenreMix();PlaybackOptions.fadeMs=c.fadeMs;PlaybackOptions.overlapMs=c.overlapMs;randomVersions=c.randomVersions;getSharedPreferences("play_options",MODE_PRIVATE).edit().putLong("fade_ms",c.fadeMs).putLong("overlap_ms",c.overlapMs).putBoolean("random_versions",c.randomVersions).apply()}
            if(checked[1]){val q=data.queue?.remap(ids)?.let{QueueSnapshot.restore(it){id->libraryIndex.get(id)}};val p=controller;if(q!=null&&p!=null){stopPreview();p.pause();p.setMediaItems(q.items.map(::item),q.index,q.position);p.shuffleModeEnabled=q.shuffle;p.repeatMode=q.repeat;p.prepare()}else toast("В архиве нет доступной очереди или плеер не подключён")};render()
        }.show()
    }
    private fun persistLibrary():Boolean=saveLibrary(true)
    private fun showModelCatalog(){if(stemBusy)return;val items=ModelCatalog.entries;android.app.AlertDialog.Builder(this).setTitle("Каталог локальных моделей").setItems(items.map{"${it.title} · ~${it.sizeMb} МБ"}.toTypedArray()){_,i->val entry=items[i];android.app.AlertDialog.Builder(this).setTitle(entry.title).setMessage("Размер загрузки: ~${entry.sizeMb} МБ. Лицензия по данным издателя: ${entry.license}.\n"+(if(entry.sha256!=null)"SHA-256 проверяется по закреплённой версии. Совместимость графа проверяется перед установкой." else "Официальный HTTPS-источник; издатель не указал SHA-256. Проверяется ZIP и загрузка модели. Vosk предназначен для речи, качество пения не гарантировано.")+"\nБудет заменена текущая модель данного типа. Музыка не отправляется в интернет.").setNegativeButton("Отмена",null).setNeutralButton("Источник"){_,_->runCatching{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(entry.source)))}}.setPositiveButton("Скачать"){_,_->stemWork("Загрузка ${entry.title}…",{when(entry.kind){ModelCatalog.Kind.SEPARATOR->StemEngine.installCatalog(this,entry){n->updateWork("Загрузка: $n% · проверка модели после загрузки")};ModelCatalog.Kind.GENRE->AstGenreModel.installCatalog(this,entry){n->updateWork("Загрузка AST: $n% · проверка инференса")};ModelCatalog.Kind.SPEECH->LocalTranscription.installCatalog(this,entry){n->updateWork("Загрузка: $n% · распаковка после загрузки")}}}){toast("Модель установлена")}}.show()}.setNegativeButton("Закрыть",null).show()}
    private fun modelManagement(){
        val sep=StemEngine.model(this);val speech=LocalTranscription.model(this);val ast=AstGenreModel.model(this);val mood=MoodModel.model(this)
        body.addView(label("Модели на устройстве",19,Color.WHITE,true));body.addView(btn(WhisperLocal.installed(this)?.let{"${it.title} · установлен"} ?: "Whisper · установить"){whisperModelDialog()});if(WhisperLocal.model(this).isFile)body.addView(btn("Удалить Whisper"){if(!stemBusy)android.app.AlertDialog.Builder(this).setMessage("Удалить модель? Тексты сохранятся.").setNegativeButton("Отмена",null).setPositiveButton("Удалить"){_,_->stemWork("Удаление Whisper…",{check(WhisperLocal.model(this).delete())}){toast("Модель удалена")}}.show()});body.addView(label(if(mood.isFile)"MERT: установлена (${mood.length()/1048576} МиБ)" else "MERT: не установлена",14,muted));body.addView(btn("Импорт / замена MERT ONNX"){moodImport()});if(mood.isFile)body.addView(btn("Удалить MERT"){if(!stemBusy)android.app.AlertDialog.Builder(this).setMessage("Удалить модель настроения? Плейлисты останутся.").setNegativeButton("Отмена",null).setPositiveButton("Удалить"){_,_->stemWork("Удаление MERT…",{check(mood.delete())}){toast("Модель удалена")}}.show()});body.addView(btn("Каталог моделей · скачать"){showModelCatalog()});body.addView(label("Разделение ONNX: "+if(sep.isFile)"${sep.length()/1048576} МБ" else "не установлена",14,muted))
        body.addView(btn(if(sep.isFile)"Заменить ONNX-модель" else "Импорт ONNX-модели"){if(!stemBusy)modelPicker.launch(arrayOf("*/*"))});body.addView(btn("Скачать ONNX по ссылке и SHA-256"){if(!stemBusy)downloadModel()})
        if(sep.isFile)body.addView(btn("Проверить работу ONNX-модели"){if(!stemBusy)stemWork("Тестовый нейросетевой инференс…",{StemEngine.diagnose(this)}){d->val m=d.metrics;android.app.AlertDialog.Builder(this).setTitle("Диагностика модели").setMessage("Дорожек: ${d.count}\nВремя одного блока: ${d.milliseconds} мс\nПик: ${"%.4f".format(m.peak)}\nRMS выхода: ${"%.4f".format(m.rms)}\nОшибка суммы дорожек (RMS): ${"%.4f".format(m.reconstructionRms)}\n"+(if(m.rms<.00001)"Выход почти нулевой; требуется проверка модели." else "Получен конечный ненулевой сигнал.")+"\nТест синтетический; не подтверждает качество разделения музыки.").setPositiveButton("Закрыть",null).show()}})
        if(sep.isFile)body.addView(btn("Удалить ONNX-модель"){if(!stemBusy)android.app.AlertDialog.Builder(this).setMessage("Удалить модель? Уже сохранённые дорожки и ремиксы останутся.").setNegativeButton("Отмена",null).setPositiveButton("Удалить"){_,_->stemWork("Удаление модели…",{check(sep.delete());Unit}){toast("Модель удалена")}}.show()})
        body.addView(label(if(ast.isFile)"AST: установлена (${ast.length()/1048576} МиБ)" else "AST: не установлена",14,muted));if(ast.isFile)body.addView(btn("Удалить AST-модель"){if(!stemBusy)android.app.AlertDialog.Builder(this).setMessage("Удалить модель определения жанра? Плейлисты останутся.").setNegativeButton("Отмена",null).setPositiveButton("Удалить"){_,_->stemWork("Удаление AST…",{check(ast.delete())}){toast("Модель удалена")}}.show()});body.addView(label(if(speech==null)"Vosk: не установлена" else "Vosk: установлена",14,muted));body.addView(btn("Импорт / замена Vosk ZIP"){if(!stemBusy)speechPicker.launch(arrayOf("*/*"))})
        if(speech!=null)body.addView(btn("Удалить Vosk-модель"){if(!stemBusy)android.app.AlertDialog.Builder(this).setMessage("Распознанные тексты сохранятся.").setNegativeButton("Отмена",null).setPositiveButton("Удалить"){_,_->stemWork("Удаление Vosk…",{LocalTranscription.remove(this)}){toast("Модель удалена")}}.show()})
    }
    private fun protectedMixes():Set<String>{val ids=tracks.map{it.uri}.toMutableList();controller?.let{p->for(i in 0 until p.mediaItemCount)ids.add(p.getMediaItemAt(i).mediaId)};runCatching{val a=JSONArray(getSharedPreferences("playback_bookmark",MODE_PRIVATE).getString("queue","[]"));for(i in 0 until minOf(a.length(),QueueSnapshot.LIMIT))ids.add(a.getString(i))};return ids.mapNotNull{val u=Uri.parse(it);if(u.authority=="app.remix.player.files"&&u.pathSegments.firstOrNull()=="mixes")u.pathSegments.drop(1).joinToString("/") else null}.toSet()+runCatching{listOfNotNull(pendingEffects()?.id,pendingGenre()?.id).map{"batch-$it"}.toSet()}.getOrElse{java.io.File(filesDir,"mixes").listFiles().orEmpty().filter{it.name.startsWith("batch-")}.map{it.name}.toSet()}}
    private fun cleanupMixes(){if(stemBusy)return;val dir=java.io.File(filesDir,"mixes");val protected=protectedMixes();stemWork("Поиск неиспользуемых WAV…",{StorageCore.candidates(dir,protected,System.currentTimeMillis())}){files->if(files.isEmpty())toast("Нет старых неиспользуемых WAV")else android.app.AlertDialog.Builder(this).setTitle("Освободить место?").setMessage("Найдено ${files.size} внутренних WAV вне библиотеки и очереди, старше 24 часов. Размер: ${files.sumOf{it.bytes}/1048576} МБ. Скачанные оригиналы и текущие версии не удаляются.").setNegativeButton("Отмена",null).setPositiveButton("Удалить найденные"){_,_->val keep=protectedMixes();stemWork("Очистка…",{StorageCore.delete(dir,files,keep,System.currentTimeMillis())}){(n,bytes)->toast("Удалено $n файлов · ${bytes/1048576} МБ")}}.show()}}
    private fun settingsScreen(){heading("Настройки и память");if(!stemBusy)recoveryButton();body.addView(btn("Таймер сна и переходы"){playbackOptionsDialog()});backupStatus=label(if(stemBusy)stemStatus else "Архив содержит аудио, тексты, группы, избранное, плейлисты, переводы, ручной BPM, метки, собственные эффекты, историю, очередь, EQ и громкость дорожек. Модели, кеш и ключи доступа не включаются.",14,muted);body.addView(backupStatus!!);if(stemBusy){body.addView(btn("Отменить обработку"){cancelWork()});return};body.addView(btn("Создать резервную копию ZIP"){if(tracks.isEmpty())toast("Библиотека пуста")else backupPicker.launch("RemixPlayer-backup.zip")});body.addView(btn("Восстановить из ZIP"){android.app.AlertDialog.Builder(this).setMessage("Файлы будут добавлены отдельными копиями. Текущие песни останутся. Понадобится свободное место на устройстве.").setNegativeButton("Отмена",null).setPositiveButton("Выбрать архив"){_,_->restorePicker.launch(arrayOf("application/zip","application/octet-stream"))}.show()});modelManagement();body.addView(btn("Найти неиспользуемые WAV…"){cleanupMixes()});val dir=java.io.File(filesDir,"stems");val bytes=dir.walkTopDown().filter{it.isFile}.sumOf{it.length()};body.addView(label("Композиции: ${tracks.count{it.uri==it.group}} · файлы: ${tracks.size}\nКеш разделения: ${bytes/1048576} МБ",16,muted));body.addView(btn("Очистить кеш разделённых дорожек"){if(stemBusy)toast("Дождитесь завершения обработки")else android.app.AlertDialog.Builder(this).setMessage("Будут удалены разделённые дорожки и контрольные точки незавершённого разделения. Оригиналы и сохранённые ремиксы останутся.").setNegativeButton("Отмена",null).setPositiveButton("Очистить"){_,_->stemWork("Очистка кеша…",{check(!dir.exists()||dir.deleteRecursively());Unit}){getSharedPreferences("stem_cache",MODE_PRIVATE).edit().clear().apply();stemGains.clear();previewFrame=0;previewSource=null;toast("Кеш очищен")}}.show()});body.addView(label("Распознавание: Vosk, экспериментальное. Перевод: ML Kit, локально после установки языковых моделей. Разделение: HT-Demucs (модель импортируется отдельно).",14,muted));body.addView(btn("← Музыка"){screen="Музыка";render()})}
    private fun commonsDialog(){
        if(stemBusy)return toast("Дождитесь завершения обработки")
        val query=EditText(this).apply{hint="Название или композитор";setSingleLine()}
        val panel=column();panel.addView(label("Wikimedia Commons: записи CC0 и Public domain. Здесь есть классическая музыка, народные записи и другие звуки, не весь коммерческий каталог. Интернет нужен только для поиска и скачивания.",14,muted));panel.addView(query)
        android.app.AlertDialog.Builder(this).setTitle("Свободное аудио").setView(panel).setNegativeButton("Отмена",null).setPositiveButton("Найти"){_,_->val term=query.text.toString().trim();if(term.isBlank())toast("Введите запрос")else stemWork("Поиск свободных записей…",{CommonsAudioCatalog.search(term)}){rows->showCommons(rows)}}.show()
    }
    private fun showCommons(rows:List<CommonsAudioCore.Recording>){
        if(rows.isEmpty())return toast("Нет подходящих свободных записей. Попробуйте другой запрос.")
        android.app.AlertDialog.Builder(this).setTitle("Свободные аудиозаписи").setItems(rows.map{"${it.title} · ${it.artist} · ${it.license}"}.toTypedArray()){_,i->
            val t=rows[i];android.app.AlertDialog.Builder(this).setTitle(t.title).setMessage("Автор: ${t.artist}\nЛицензия по данным Commons: ${t.license}\nРазмер: ${t.bytes/1048576.0} МиБ\nПроверьте условия и статус записи в вашей стране на странице источника.").setNeutralButton("Источник"){_,_->runCatching{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(t.source)))}}.setNegativeButton("Отмена",null).setPositiveButton("Скачать"){_,_->stemWork("Загрузка…",{MusicDownload.fetch(this,t.url){p->updateWork("Загрузка: $p%")}},discard={file->file.delete()}){file->
                val uri=androidx.core.content.FileProvider.getUriForFile(this,"app.remix.player.files",file).toString();tracks.add(Track(uri,t.title,t.artist,uri,album="Wikimedia Commons"));save();screen="Музыка";toast("Файл добавлен")
            }}.show()
        }.setNegativeButton("Закрыть",null).show()
    }
    private fun catalogDialog(){if(stemBusy){toast("Дождитесь завершения обработки");return};val panel=column();val client=EditText(this).apply{hint="Jamendo Client ID";setSingleLine();setText(getSharedPreferences("catalog",MODE_PRIVATE).getString("client",""))};val query=EditText(this).apply{hint="Песня, исполнитель или жанр";setSingleLine()};panel.addView(label("Поиск онлайн. Получите Client ID на devportal.jamendo.com. Музыка сохраняется локально только при разрешении загрузки автором.",14,muted));panel.addView(client);panel.addView(query);android.app.AlertDialog.Builder(this).setTitle("Каталог Jamendo").setView(panel).setNegativeButton("Отмена",null).setPositiveButton("Найти"){_,_->val key=client.text.toString().trim();val term=query.text.toString().trim();if(!key.matches(Regex("[a-zA-Z0-9_-]{3,128}"))||term.isBlank()){toast("Введите Client ID и запрос")}else{getSharedPreferences("catalog",MODE_PRIVATE).edit().putString("client",key).apply();stemWork("Поиск музыки…",{JamendoCatalog.search(key,term)}){songs->showCatalog(songs)}}}.show()}
    private fun showCatalog(songs:List<JamendoCatalog.Song>){if(songs.isEmpty()){toast("Ничего не найдено");return};android.app.AlertDialog.Builder(this).setTitle("Результаты поиска").setItems(songs.map{"${it.title} · ${it.artist}"+(if(it.download==null)" · загрузка запрещена" else " · можно скачать")}.toTypedArray()){_,i->val t=songs[i];val url=t.download;if(url==null){toast("Автор не разрешил загрузку")}else android.app.AlertDialog.Builder(this).setTitle(t.title).setMessage("Скачать для личного прослушивания? Соблюдайте лицензию композиции: ${t.license.ifBlank{"проверьте условия на Jamendo"}}. Разрешение на загрузку не означает разрешение распространять ремикс.").setNegativeButton("Отмена",null).setPositiveButton("Скачать"){_,_->stemWork("Загрузка…",{MusicDownload.fetch(this,url){p->updateWork("Загрузка: $p%")}},discard={file->file.delete()}){file->val uri=androidx.core.content.FileProvider.getUriForFile(this,"app.remix.player.files",file).toString();tracks.add(Track(uri,t.title,t.artist,uri,album=t.album));save();screen="Музыка";toast("Файл добавлен")}}.show()}.setNegativeButton("Закрыть",null).show()}
    private fun downloadModel(){val panel=column();val url=EditText(this).apply{hint="HTTPS-ссылка на совместимую ONNX";setSingleLine()};val hash=EditText(this).apply{hint="SHA-256 от издателя (64 символа)";setSingleLine()};panel.addView(label("Укажите ссылку и контрольную сумму из доверенного источника. Модель должна соответствовать формату приложения и разрешать использование.",14,muted));panel.addView(url);panel.addView(hash);android.app.AlertDialog.Builder(this).setTitle("Загрузка модели").setView(panel).setNegativeButton("Отмена",null).setPositiveButton("Скачать"){_,_->val link=url.text.toString();val sha=hash.text.toString().trim();if(!sha.matches(Regex("[a-fA-F0-9]{64}"))){toast("Нужна контрольная сумма SHA-256")}else stemWork("Загрузка модели…",{StemEngine.installFromUrl(this,link,sha){p->updateWork("Загрузка модели: $p%")}}){toast("Модель проверена и установлена")}}.show()}
    private fun pickVersion(t:Track):Track=if(randomVersions)VersionChoice.random(t,libraryIndex.versions(t.uri))else preferred(t)
    private fun categoryValue(t:Track)=when(categoryMode){1->t.album.ifBlank{"Без альбома"};2->t.folder.ifBlank{"Неизвестная папка"};3->t.artist;else->""}
    private fun chooseCategory(){android.app.AlertDialog.Builder(this).setTitle("Каталог музыки").setItems(arrayOf("Все песни","Альбомы","Папки","Исполнители")){_,i->categoryMode=i;category=null;shownSongs=100;if(i==0){render()}else{val items=tracks.filter{it.uri==it.group}.map(::categoryValue).distinct().sorted();if(items.isEmpty()){render()}else android.app.AlertDialog.Builder(this).setTitle("Выберите раздел").setItems((listOf("Все в разделе")+items).toTypedArray()){_,j->category=items.getOrNull(j-1);render()}.setOnCancelListener{render()}.show()}}.show()}
    private var historyGrouped=true
    private fun historyScreen(){
        heading("История прослушивания")
        val versions=StatsStore.read(this).filter{libraryIndex.get(it.id)!=null}
        val entries=if(historyGrouped)ListeningStats.grouped(versions){libraryIndex.get(it)?.group}else versions
        body.addView(label("Учтено ${ListeningStats.total(entries)/60000} мин · ${entries.size} ${if(historyGrouped)"групп песен" else "версий"}. История ограничена последними 2000 версиями.",14,muted))
        body.addView(btn(if(historyGrouped)"Показывать отдельные версии" else "Объединять оригинал и ремиксы"){historyGrouped=!historyGrouped;render()})
        body.addView(btn("Обновить"){render()})
        if(entries.isEmpty())body.addView(label("Пока нет истории",14,muted))
        fun addEntry(e:ListeningStats.Entry){val t=libraryIndex.get(e.id)?:return;card(t.title,"${e.playedMs/60000} мин · ${t.artist}"){start(if(historyGrouped)pickVersion(t)else t)}}
        body.addView(label("Недавно слушали",18,accent,true));entries.take(50).forEach(::addEntry)
        body.addView(label("Самые прослушиваемые",18,accent,true));entries.sortedByDescending{it.playedMs}.take(20).forEach(::addEntry)
    }
    private fun saveEqVersion(){val t=current()?:return toast("Выберите песню");val parent=libraryIndex.get(t.group)?:return;val levels=EqualizerSettings.get().toList();if(levels.all{it==0f}){toast("Сначала настройте эквалайзер");return};if(stemBusy)return;val rawText=rawLyrics(t)
        android.app.AlertDialog.Builder(this).setTitle("Сохранить эквалайзер в аудио").setMessage("Будет создан новый WAV с текущими настройками EQ. После сохранения эквалайзер плеера сбросится, чтобы не накладывать фильтры повторно. Исходник останется.").setNegativeButton("Отмена",null).setPositiveButton("Создать"){_,_->stemWork("Обработка эквалайзером…",{
            val dir=java.io.File(filesDir,"mixes").apply{mkdirs()};val raw=java.io.File.createTempFile("eq-input-",".pcm",cacheDir);val out=java.io.File.createTempFile("eq-",".wav",dir)
            try{StemEngine.decode(this,Uri.parse(t.uri),raw);EqRender.render(raw,out,levels){n->updateWork("Эквалайзер: $n%")};out}catch(e:Throwable){out.delete();throw e}finally{raw.delete()}
        },discard={file->file.delete()}){file->if(libraryIndex.get(parent.uri)?.group!=parent.uri){file.delete()}else{val uri=androidx.core.content.FileProvider.getUriForFile(this,"app.remix.player.files",file).toString();val version=Track(uri,t.title+" · EQ",t.artist,parent.uri,rawText,tempoRatio=if(t.uri==parent.uri)1.0 else t.tempoRatio);tracks.add(version);save();if(EqualizerSettings.get()==levels){EqualizerSettings.set(List(10){0f});val e=getSharedPreferences("eq",MODE_PRIVATE).edit();repeat(10){e.putFloat("band$it",0f)};e.apply()};screen="Версии";start(version);toast("Версия EQ сохранена")}}}.show()
    }
    private fun equalizerScreen(){heading("10-полосный эквалайзер");body.addView(label("±12 дБ · работает при воспроизведении. Можно отдельно сохранить новую версию с EQ. Автоматический запас громкости.",14,muted));if(stemBusy){studioStatusView=label(stemStatus,14,accent);body.addView(studioStatusView!!);body.addView(btn("Отменить обработку"){cancelWork()});return};body.addView(btn("Сохранить EQ как версию"){saveEqVersion()});val prefs=getSharedPreferences("eq",MODE_PRIVATE);val levels=EqualizerSettings.get().toMutableList();fun saveEq(){EqualizerSettings.set(levels);val edit=prefs.edit();levels.forEachIndexed{i,v->edit.putFloat("band$i",v)};edit.apply()};body.addView(btn("Сбросить в 0 дБ"){levels.fill(0f);saveEq();render()});for(i in levels.indices){val text=label("${EqualizerSettings.frequencies[i]} Гц · ${levels[i].toInt()} дБ",14);body.addView(text);body.addView(SeekBar(this).apply{max=24;progress=levels[i].toInt()+12;setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onStartTrackingTouch(s:SeekBar){};override fun onStopTrackingTouch(s:SeekBar){saveEq()};override fun onProgressChanged(s:SeekBar,p:Int,user:Boolean){if(user){levels[i]=(p-12).toFloat();EqualizerSettings.set(levels);text.text="${EqualizerSettings.frequencies[i]} Гц · ${p-12} дБ"}}})})}}
    private fun previewArrangement(source:Track,report:MusicAnalysis.Report){
        val beat=BeatCorrection.resolve(report,manualBeat(source))?:return toast("Сначала укажите BPM и долю")
        val styles=GenreEngine.styles
        android.app.AlertDialog.Builder(this).setTitle("Предпросмотр жанра").setItems(styles.map{it.name}.toTypedArray()){_,i->
            val style=styles[i];val p=TimeStretch.plan(beat.bpm,style.target);val frames=(report.duration*44100).toLong().coerceIn(1,44100L*900)
            val grid=AdaptiveGroove(p.gridBpm,beat.phase,beat.windows,beat.reference,anchor=beat.anchor)
            val sections=Arrangement.aligned(report.energy,frames,grid,sections=SectionArrangement.plan(report,frames/44100.0))
            val names=mapOf(Arrangement.Part.INTRO to "Вступление",Arrangement.Part.BREAK to "Пауза",Arrangement.Part.BUILD to "Нарастание",Arrangement.Part.DROP to "Дроп",Arrangement.Part.GROOVE to "Основная часть",Arrangement.Part.OUTRO to "Завершение")
            val panel=column();panel.addView(label("Ориентировочная карта будущего ремикса: ${style.target} BPM, сетка 4/4. Время указано после изменения темпа. Доли и структура оцениваются приближённо.",14,muted))
            sections.forEach{v->panel.addView(label("${fmt((v.start/p.speed*1000).toLong())} – ${fmt((v.end/p.speed*1000).toLong())} · ${names[v.part]}",16,accent))}
            val scroll=ScrollView(this);scroll.addView(panel);android.app.AlertDialog.Builder(this).setTitle(style.name).setView(scroll).setNegativeButton("Закрыть",null).setPositiveButton("Создать"){_,_->generateGenres(source,listOf(style))}.show()
        }.setNegativeButton("Отмена",null).show()
    }
    private fun showRecommendations(source:Track,report:MusicAnalysis.Report){
        val goals=RemixAdvisor.Goal.values();android.app.AlertDialog.Builder(this).setTitle("Какой характер ремикса нужен?").setItems(arrayOf("Ближе к оригиналу","Энергичнее","Мягче")){_,i->
            val picks=RemixAdvisor.recommend(report,manualBeat(source)?.bpm,goals[i]);val styles=picks.map{it.style};if(styles.isEmpty()){toast("Темп не определён")}else android.app.AlertDialog.Builder(this).setTitle("Рекомендации · эвристика").setItems(picks.map{"${it.style.name} · ${it.style.target} BPM · скорость ${String.format(java.util.Locale.US,"%.2f",it.speed)}×"}.toTypedArray()){_,j->generateGenres(source,listOf(styles[j]))}.setPositiveButton("Создать все пять"){_,_->confirmBatch(source,styles)}.setNegativeButton("Отмена",null).show()
        }.setNegativeButton("Отмена",null).show()
    }
    private fun save(){saveLibrary(false)}
    private fun saveLibrary(sync:Boolean):Boolean{reindex();val a=JSONArray();tracks.forEach{a.put(JSONObject().put("uri",it.uri).put("title",it.title).put("artist",it.artist).put("group",it.group).put("lyrics",it.lyrics).put("favorite",it.favorite).put("tempoRatio",it.tempoRatio?:JSONObject.NULL).put("album",it.album).put("folder",it.folder))};val p=JSONObject();playlists.forEach{(k,v)->p.put(k,JSONArray(v.toList()))};val edit=getSharedPreferences("library",MODE_PRIVATE).edit().putString("tracks",a.toString()).putString("playlists",p.toString());return if(sync)edit.commit()else{edit.apply();true}}
    private fun load(){
        val raw=getSharedPreferences("library",MODE_PRIVATE).getString("tracks","[]")?:"[]"
        val result=try{val a=JSONArray(raw);LibraryRecovery.recover(a.length(),{i->
            val t=a.getJSONObject(i);val uri=t.getString("uri");require(Uri.parse(uri).scheme=="content")
            Track(uri,t.getString("title"),t.getString("artist"),t.optString("group",uri),t.optString("lyrics"),t.optBoolean("favorite"),t.optDouble("tempoRatio",Double.NaN).takeIf{it.isFinite()&&it in .4..1.8},t.optString("album"),t.optString("folder"))
        },Track::uri,Track::group,{it.copy(group=it.uri,tempoRatio=null)})}catch(e:Exception){preserveDamagedLibrary(raw,"Библиотека не читается");return}
        tracks.addAll(result.items)
        if(result.skipped>0||result.repaired>0)preserveDamagedLibrary(raw,"Пропущено записей: ${result.skipped}; восстановлено групп: ${result.repaired}")
    }
    private fun preserveDamagedLibrary(raw:String,message:String){
        // Keep the original snapshot before a later save can overwrite it. Never overwrite earlier recovery files.
        val recovered=runCatching{val dir=java.io.File(filesDir,"library-recovery");check(dir.isDirectory||dir.mkdirs());val file=java.io.File(dir,java.util.UUID.randomUUID().toString()+".json");val atomic=android.util.AtomicFile(file);val stream=atomic.startWrite();try{stream.write(raw.toByteArray(Charsets.UTF_8));atomic.finishWrite(stream)}catch(e:Throwable){atomic.failWrite(stream);throw e};file}.getOrNull()
        android.app.AlertDialog.Builder(this).setTitle("Восстановление библиотеки").setMessage(message+if(recovered!=null)". Исходные данные сохранены во внутренней папке library-recovery." else ". Не удалось сохранить исходные данные. Не изменяйте библиотеку до резервного копирования.").setPositiveButton("Понятно",null).show()
    }
    override fun onNewIntent(intent:Intent){super.onNewIntent(intent);if(intent.getBooleanExtra("open_mixer",false)){screen="Микшер";render()}}
    override fun onStop(){seekTarget=null;dragging=false;uiStarted=false;handler.removeCallbacks(ticker);super.onStop()}
    override fun onStart(){super.onStart();uiStarted=true;if(::body.isInitialized&&(deferredPlayerRender||screen=="Микшер"||screen=="Текст"))render();deferredPlayerRender=false;handler.removeCallbacks(ticker);handler.post(ticker)}
    override fun onSaveInstanceState(outState:Bundle){super.onSaveInstanceState(outState);outState.putString("exportSource",exportSource);outState.putInt("mp3Bitrate",mp3Bitrate);outState.putString("addingTo",addingTo);outState.putString("lyricTarget",lyricTarget);outState.putString("lyricRevision",lyricRevision);outState.putString("screen",screen);outState.putString("query",query);outState.putInt("shownSongs",shownSongs);outState.putBoolean("onlyFavorites",onlyFavorites);outState.putString("selectedPlaylist",selectedPlaylist);outState.putInt("sortMode",sortMode);outState.putInt("categoryMode",categoryMode);outState.putString("category",category)}
    override fun onDestroy(){uiStarted=false;handler.removeCallbacks(ticker);if(::future.isInitialized)MediaController.releaseFuture(future);io.shutdown();coverIo.shutdownNow();coverCache.evictAll();missingCovers.evictAll();cancelWork();stemIo.shutdown();super.onDestroy()}
}
