package app.remix.player

import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.security.MessageDigest

/** Import and adjust lyrics without altering individual line/word timestamps. */
object LyricDocument {
    const val MAX_BYTES = 1024 * 1024
    const val MAX_CHARS = 500_000
    private val offsetTag = Regex("\\[offset:([+-]?\\d+)]", RegexOption.IGNORE_CASE)
    fun decode(bytes: ByteArray): String {
        require(bytes.size in 1..MAX_BYTES) { "Файл текста слишком большой или пустой" }
        val (charset, skip) = when {
            bytes.size >= 3 && bytes[0] == 0xef.toByte() && bytes[1] == 0xbb.toByte() && bytes[2] == 0xbf.toByte() -> Charsets.UTF_8 to 3
            bytes.size >= 2 && bytes[0] == 0xff.toByte() && bytes[1] == 0xfe.toByte() -> Charsets.UTF_16LE to 2
            bytes.size >= 2 && bytes[0] == 0xfe.toByte() && bytes[1] == 0xff.toByte() -> Charsets.UTF_16BE to 2
            else -> Charsets.UTF_8 to 0
        }
        val text = charset.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(bytes, skip, bytes.size - skip)).toString().replace("\r\n", "\n").replace('\r', '\n')
        require(text.length <= MAX_CHARS && text.isNotBlank() && text.none { it.isISOControl() && it !in "\n\t" }) { "Некорректный текст" }
        return text
    }
    fun plain(raw: String): String = Lrc.parse(raw).let { lines ->
        if (lines.isEmpty()) raw else lines.joinToString("\n") { WordLyrics.parse(it).text }
    }
    /** Positive delta delays the lyrics. Original absolute markers are retained, even when clipped at zero. */
    fun shift(raw: String, deltaMs: Long): String {
        require(raw.length <= MAX_CHARS && Lrc.parse(raw).isNotEmpty()) { "Нужен синхронизированный текст" }
        require(deltaMs in -60_000..60_000) { "Сдвиг за один раз — не более 60 секунд" }
        if (deltaMs == 0L) return raw
        val offset = Lrc.offset(raw) + deltaMs
        require(offset in -Lrc.MAX_MS..Lrc.MAX_MS) { "Слишком большой общий сдвиг" }
        val body = offsetTag.replace(raw, "").trimStart('\r', '\n')
        return "[offset:$offset]\n$body".also { require(it.length <= MAX_CHARS) }
    }
    /** Small durable token for SAF picker state; length framing prevents field ambiguity. */
    fun revision(group: String, ratio: Double?, raw: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        for (part in listOf(group, ratio?.toString().orEmpty(), raw)) {
            val bytes = part.toByteArray(Charsets.UTF_8)
            digest.update(ByteBuffer.allocate(4).putInt(bytes.size).array()); digest.update(bytes)
        }
        return digest.digest().joinToString("") { "%02x".format(it.toInt() and 255) }
    }
}
