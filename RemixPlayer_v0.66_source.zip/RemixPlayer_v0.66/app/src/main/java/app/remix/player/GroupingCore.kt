package app.remix.player

import java.text.Normalizer
import java.util.Locale

/** Conservative title/artist suggestions only. Never changes a library by itself. */
object GroupingCore {
    data class Song(val id:String,val title:String,val artist:String)
    data class Suggestion(val version:String,val original:String,val suffix:String)
    private fun norm(s:String)=Normalizer.normalize(s,Normalizer.Form.NFKC).lowercase(Locale.ROOT).trim().replace(spaces," ")
    private val brackets=Regex("^(.*?)(?:\\s*\\(([^()]*)\\)|\\s*\\[([^\\[\\]]*)\\])\\s*$")
    private val dash=Regex("[·–—-]")
    private val spaces=Regex("\\s+")
    private val kinds=setOf("remix","edit","mix","slowed","super slowed","ultra slowed","sped up","speed up","nightcore","daycore","slowed + reverb","slowed and reverb","slowed & reverb","super slowed + reverb","bass boosted","bass boost","instrumental","acapella","a cappella","karaoke","8d audio","hardstyle remix","phonk remix","drift phonk remix","brazilian phonk remix","montagem remix","jersey club remix","jumpstyle remix","reverb","radio edit","extended mix")
    private val unknown=setOf("","unknown","unknown artist","неизвестный исполнитель","<unknown>","various artists")
    private fun variant(title:String):Pair<String,String>? {
        val clean=title.trim()
        fun candidate(base:String,tag:String):Pair<String,String>? {
            val key=norm(tag);val root=norm(base)
            return if(key in kinds&&root.isNotBlank())root to tag.trim() else null
        }
        brackets.matchEntire(clean)?.let{m->
            candidate(m.groupValues[1],m.groupValues.drop(2).firstOrNull{it.isNotBlank()}.orEmpty())?.let{return it}
        }
        // Inspect only a terminal recognized tag, not the first hyphen in the song name.
        val last=dash.findAll(clean).lastOrNull()?:return null
        return candidate(clean.substring(0,last.range.first),clean.substring(last.range.last+1))
    }
    fun suggest(songs:List<Song>):List<Suggestion>{
        val originals=songs.filter{variant(it.title)==null&&norm(it.artist) !in unknown}.groupBy{norm(it.artist) to norm(it.title)}
        return songs.mapNotNull{s->val v=variant(s.title)?:return@mapNotNull null;val artist=norm(s.artist);if(artist in unknown)return@mapNotNull null;val original=originals[artist to v.first]?.singleOrNull()?:return@mapNotNull null;if(s.id==original.id)null else Suggestion(s.id,original.id,v.second)}
    }
}
