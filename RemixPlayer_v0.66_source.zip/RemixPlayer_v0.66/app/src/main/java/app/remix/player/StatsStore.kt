package app.remix.player
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
object StatsStore {
    @Volatile var revision=0L;private set
    // Activity and playback service share the main thread in the same process.
    fun importHistory(context:Context,incoming:List<ListeningStats.Entry>){save(context,PortablePlayback.mergeHistory(read(context),incoming));revision++}
    fun read(context:Context):List<ListeningStats.Entry> = runCatching{val a=JSONArray(context.getSharedPreferences("listening_stats",Context.MODE_PRIVATE).getString("entries","[]"));ListeningStats.recover(a.length()){val o=a.getJSONObject(it);ListeningStats.Entry(o.getString("id"),o.getLong("ms"),o.getLong("last"))}}.getOrDefault(emptyList())
    fun save(context:Context,entries:List<ListeningStats.Entry>){val a=JSONArray();entries.forEach{a.put(JSONObject().put("id",it.id).put("ms",it.playedMs).put("last",it.lastMs))};context.getSharedPreferences("listening_stats",Context.MODE_PRIVATE).edit().putString("entries",a.toString()).apply()}
}
