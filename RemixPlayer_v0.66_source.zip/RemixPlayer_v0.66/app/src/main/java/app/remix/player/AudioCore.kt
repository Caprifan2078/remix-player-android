package app.remix.player

import kotlin.math.*

data class Preset(val name: String, val speed: Float = 1f, val pitch: Float = 1f, val bass: Float = 0f, val room: Float = 0f, val pan: Float = 0f, val drive: Float = 0f, val muffled: Float = 0f)
object Presets {
    val all = listOf(Preset("Оригинал"), Preset("Sped Up",1.25f), Preset("Nightcore",1.25f,1.25f), Preset("Super Sped Up",1.45f,1.12f), Preset("Slowed",.85f), Preset("Daycore",.85f,.85f), Preset("Slowed + Reverb",.85f,.9f,room=.35f), Preset("Super Slowed",.65f,.75f), Preset("Super Slowed + Reverb",.65f,.75f,room=.5f), Preset("Ultra Slowed",.5f,.65f,room=.25f), Preset("Sped Up + Reverb",1.25f,1.1f,room=.3f), Preset("Bass Boost",bass=.55f), Preset("Deep Bass",bass=.9f), Preset("8D Audio",pan=.8f,room=.15f), Preset("Concert Hall",room=.55f), Preset("Dreamy",room=.45f,muffled=.2f), Preset("Underwater",muffled=.85f), Preset("Vintage",drive=.15f,muffled=.45f), Preset("Distorted",drive=.6f), Preset("Dark Edit",.9f,.9f,bass=.5f,drive=.25f), Preset("Gym Edit",1.12f,1f,bass=.45f,drive=.1f), Preset("Vaporwave effect",.8f,.8f,room=.35f,muffled=.35f),
        Preset("Ultra Sped Up",1.7f,1.35f),
        Preset("Extreme Slowed",.45f,.55f,room=.4f),
        Preset("Slow Dream",.78f,.9f,room=.65f),
        Preset("Nightcore Reverb",1.32f,1.3f,room=.35f),
        Preset("Daycore Echo",.72f,.75f,room=.6f),
        Preset("Deep Space",room=.85f,pan=.4f),
        Preset("Cathedral",room=.92f),
        Preset("Small Room",room=.18f),
        Preset("Next Room",muffled=.92f,room=.18f),
        Preset("Soft Bass",bass=.25f),
        Preset("Bass + Reverb",bass=.65f,room=.45f),
        Preset("Sub Bass",bass=1.15f,muffled=.15f),
        Preset("Overdrive",drive=.35f),
        Preset("Extreme Distortion",drive=.95f),
        Preset("Lo-Fi Filter",muffled=.55f,drive=.08f,room=.12f),
        Preset("Cassette Filter",muffled=.65f,drive=.18f),
        Preset("Radio Filter",muffled=.7f,drive=.3f),
        Preset("Slow Stereo Orbit",.8f,.9f,pan=.95f,room=.3f),
        Preset("Fast Stereo Orbit",1.2f,1.05f,pan=.95f,room=.15f))
    @Volatile var active = all.first()
}

/** Frame-linked peak protection for processed audio. One gain for all channels,
 * instantaneous attack and 20 ms release. Sample peak only, not a true-peak limiter. */
class LinkedPeakGuard(rate:Int) {
    init { require(rate>0) }
    private val release=(1-exp(-1.0/(.020*rate))).toFloat()
    private var gain=1f
    fun reset(){gain=1f}
    fun apply(frame:FloatArray) {
        var peak=0f
        for(i in frame.indices) { if(!frame[i].isFinite())frame[i]=0f;peak=max(peak,abs(frame[i])) }
        val target=if(peak<=.90f)1f else (.90f+.085f*tanh((peak-.90f)/.085f))/peak
        gain=if(target<gain)target else min(target,gain+(1f-gain)*release)
        if(gain<1f)for(i in frame.indices)frame[i]*=gain
    }
}

/** Stateless configuration; history is owned by the playback thread. No per-frame allocation. */
class Dsp(private val rate: Int, private val channels: Int) {
    private val low = FloatArray(channels)
    private val dull = FloatArray(channels)
    private val lengths = intArrayOf((rate*.029).toInt().coerceAtLeast(1), (rate*.047).toInt().coerceAtLeast(1), (rate*.071).toInt().coerceAtLeast(1))
    private val delays = Array(lengths.size) { FloatArray(lengths[it]*channels) }
    private val cursors = IntArray(lengths.size)
    private val bassAlpha = (1-exp(-2*PI*150/rate)).toFloat()
    private var phase = 0.0
    private var previous: Preset? = null
    private var cutoff = 0f
    private var driveNorm = 1f
    private var gain = 1f
    private val guard=LinkedPeakGuard(rate)
    private var processed=false
    fun frame(input: FloatArray, out: FloatArray, p: Preset) {
        if(previous !== p) { previous=p; cutoff=(1-exp(-2*PI*(900.0+(1-p.muffled)*12000)/rate)).toFloat(); driveNorm=tanh(1+p.drive*6); gain=1f/(1f+p.bass*.45f); processed=p.bass!=0f||p.room!=0f||p.pan!=0f||p.drive!=0f||p.muffled!=0f;guard.reset() }
        val sweep = if(p.pan>0 && channels==2)(sin(phase)*p.pan).toFloat() else 0f
        for(c in 0 until channels) {
            // Reject malformed samples before they enter the recursive filters or delay lines.
            val x = input[c].takeIf { it.isFinite() } ?: 0f
            low[c] += bassAlpha*(x-low[c]); dull[c] += cutoff*(x-dull[c])
            var y = (x + p.bass*low[c])*gain
            if(p.muffled>0) y = y*(1-p.muffled)+dull[c]*p.muffled
            var wet = 0f
            for(i in delays.indices) { val j=cursors[i]*channels+c; val d=delays[i][j]; delays[i][j]=(y+d*.32f).coerceIn(-2f,2f); wet+=d/3 }
            y = y*(1-p.room*.45f)+wet*p.room*.65f
            if(p.drive>0) { val k=1+p.drive*6; y=tanh(y*k)/driveNorm }
            if(channels==2 && p.pan>0) y *= if(c==0) sqrt((1-sweep).coerceAtLeast(0f))*.75f else sqrt((1+sweep).coerceAtLeast(0f))*.75f
            out[c]=y
        }
        if(processed)guard.apply(out) else for(c in 0 until channels)out[c]=out[c].coerceIn(-1f,1f)
        for(i in cursors.indices) cursors[i]=(cursors[i]+1)%lengths[i]
        phase += 2*PI*.19/rate; if(phase>2*PI) phase-=2*PI
    }
}

data class Lyric(val ms: Long, val text: String, val offset: Long = 0L)
object Lrc {
    // Bound offsets to the representable LRC timestamp range; ignore malformed metadata.
    const val MAX_MS=59_999_999L
    fun offset(raw:String):Long = Regex("\\[offset:([+-]?\\d+)]",RegexOption.IGNORE_CASE).find(raw)?.groupValues?.get(1)?.toLongOrNull()?.takeIf{it in -MAX_MS..MAX_MS}?:0L
    fun timestamp(base:Long,offset:Long):Long=(base.coerceIn(0L,MAX_MS)+offset.takeIf{it in -MAX_MS..MAX_MS}.orZero()).coerceIn(0L,MAX_MS)
    private fun Long?.orZero()=this?:0L
    private val tag=Regex("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?]")
    fun parse(raw: String): List<Lyric> {
        val offset=offset(raw)
        return raw.lineSequence().flatMap { line -> val hits=tag.findAll(line).toList(); val text=tag.replace(line,"").trim(); hits.asSequence().filter { text.isNotEmpty() && it.groupValues[2].toInt()<60 }.map { m -> Lyric(timestamp(m.groupValues[1].toLong()*60000+m.groupValues[2].toLong()*1000+m.groupValues[3].padEnd(3,'0').toLong(),offset),text,offset) } }.sortedBy { it.ms }.toList()
    }
    fun current(lines: List<Lyric>, ms: Long): Int { var lo=0; var hi=lines.size; while(lo<hi) { val mid=(lo+hi)/2; if(lines[mid].ms<=ms) lo=mid+1 else hi=mid }; return lo-1 }
}
