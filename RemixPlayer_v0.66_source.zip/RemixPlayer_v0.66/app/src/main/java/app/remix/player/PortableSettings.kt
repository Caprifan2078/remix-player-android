package app.remix.player

/** URI-independent optional backup metadata, validated before applying to a new library. */
object PortableSettings {
    fun <T> remap(rows:Map<Int,T>,ids:List<String>):Map<String,T>{require(rows.keys.all{it in ids.indices});require(ids.distinct().size==ids.size);return rows.mapKeys{ids[it.key]}}
    fun validateTranslation(raw:String,lines:List<String>):Boolean=lines.isNotEmpty()&&lines.size<=2000&&lines.sumOf{it.length.toLong()}<=500000L&&lines.size==Lrc.parse(raw).size
    data class PresetsMerge(val items:List<Preset>,val imported:Int,val skipped:Int)
    fun mergePresets(existing:List<Preset>,incoming:List<Preset>,reserved:List<String>,limit:Int=100):PresetsMerge {
        require(limit in 1..100&&existing.size<=limit&&incoming.size<=100)
        val list=existing.toMutableList();val used=(reserved+existing.map{it.name}).map{it.lowercase(java.util.Locale.ROOT)}.toHashSet();var imported=0;var skipped=0
        for(p in incoming){require(CustomPresetCore.exportable(p));if(list.any{it.name.equals(p.name,true)&&CustomPresetCore.values(it).contentEquals(CustomPresetCore.values(p))}||list.size>=limit){skipped++;continue}
            var name=p.name;var n=2;while(name.lowercase(java.util.Locale.ROOT) in used){name=p.name.take(68)+" ($n)";n++};val added=p.copy(name=name);list.add(added);used.add(name.lowercase(java.util.Locale.ROOT));imported++}
        return PresetsMerge(list,imported,skipped)
    }
    fun mergeExamples(existing:List<PersonalTags.Example>,incoming:List<PersonalTags.Example>,limit:Int=300):List<PersonalTags.Example>{require(limit in 1..300);return (existing+incoming).distinctBy{it.id}.take(limit)}
}
