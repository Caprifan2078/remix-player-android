package app.remix.player
import kotlin.math.*
import kotlin.random.Random
/** Deterministic synthesized percussion following the backing's adaptive grid. */
class NeuralDrums(private val style:NeuralInstrumental.Style, seed:Int,private val genre:GenreEngine.Style?=null){
    private val rng=Random(seed xor 0x17ab29)
    private val soft=style==NeuralInstrumental.Style.SOFT
    private val dark=style==NeuralInstrumental.Style.DARK
    private fun wave(sec:Double,body:(Double)->Double):FloatArray {val n=(44100*sec).roundToInt();return FloatArray(n){i->(body(i/44100.0)*minOf(1.0,i/88.0,(n-1-i)/441.0)).toFloat()}}
    private var prior=0.0
    private fun noise():Double{val next=rng.nextDouble(-1.0,1.0);val v=(next-prior)*.5;prior=next;return v}
    private val kick=wave(.15){t->sin(2*PI*((if(dark)40 else 48)*t+2.8*(1-exp(-30*t))))*exp(-24*t)*(if(soft).15 else .27)}
    private val snare=wave(.13){t->(noise()*.8+sin(2*PI*180*t)*.2)*exp(-22*t)*(if(soft).085 else .15)}
    private val hat=wave(.055){t->noise()*exp(-62*t)*(if(soft).045 else .075)}
    data class Plan(val kicks:LongArray,val snares:LongArray,val hats:LongArray,val accents:FloatArray)
    fun plan(boundaries:DoubleArray):Plan {val n=boundaries.size-1;require(n>0&&boundaries.all{it.isFinite()}&&boundaries.asList().zipWithNext().all{(a,b)->b>a});val k=LongArray(n);val s=LongArray(n);val h=LongArray(n);val a=FloatArray(n);var lastK=-1L;var lastS=-1L;var lastH=-1L;var accent=0f
        for(i in 0 until n){val slot=i%16;val frame=boundaries[i].roundToLong();val fill=i/16%4==3;val kickHit=genre?.let{slot in it.kick}?:when(style){NeuralInstrumental.Style.DANCE->slot%4==0;NeuralInstrumental.Style.DARK->slot in listOf(0,6,8,11);NeuralInstrumental.Style.SOFT->slot==0||slot==8};if(kickHit)lastK=frame;if((genre?.let{slot in it.snare}?: (slot==4||slot==12))||(fill&&!soft&&slot==15))lastS=frame;if((genre?.let{slot in it.hat}?: (slot%2==0&&(!soft||slot%4==2)))||(dark&&fill&&slot==15)){lastH=frame;accent=if(slot%4==0).7f else 1f};k[i]=lastK;s[i]=lastS;h[i]=lastH;a[i]=accent};return Plan(k,s,h,a)}
    class Sample(var center:Double=0.0,var side:Double=0.0)
    private fun at(w:FloatArray,now:Long,start:Long):Double{if(start<0)return 0.0;val i=now-start;return if(i>=0&&i<w.size)w[i.toInt()].toDouble()else 0.0}
    fun sample(p:Plan,step:Int,frame:Long,out:Sample){val h=at(hat,frame,p.hats[step])*p.accents[step];out.center=at(kick,frame,p.kicks[step])+at(snare,frame,p.snares[step])+h;out.side=h*.22}
}
