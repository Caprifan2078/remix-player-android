package app.remix.player

/** Ordered playlist membership. The persisted JSON array is the source of truth. */
object PlaylistOrder {
    fun <T> apply(items:List<T>, order:Collection<String>, id:(T)->String):List<T>{
        val byId=items.associateBy(id)
        return order.distinct().mapNotNull{byId[it]}
    }
    fun move(ids:Collection<String>, id:String, position:Int):List<String>?{
        val list=ids.distinct().toMutableList()
        if(id !in list||position !in list.indices)return null
        list.remove(id);list.add(position,id);return list
    }
    fun append(ids:Collection<String>, additions:Collection<String>):List<String> =
        (ids.asSequence()+additions.asSequence()).filter{it.isNotBlank()}.distinct().toList()
    fun merge(ids:Collection<String>, source:String,target:String):List<String>{
        if(source==target)return ids.distinct()
        return if(target in ids)ids.filter{it!=source}.distinct() else ids.map{if(it==source)target else it}.distinct()
    }
}
