package app.remix.player

/** Native output is UTF-8 TSV: segment start and end in 10 ms units, then text.
 * Optional fourth TSV field: comma-separated estimated word starts (10 ms units). Fall back to phrases if invalid. */
object WhisperSegments {
    data class Segment(val startMs:Long,val endMs:Long,val text:String,val wordStarts:List<Long> = emptyList())
    fun parse(raw:String,offsetMs:Long,durationMs:Long):List<Segment>{
        require(offsetMs in 0..900000&&durationMs in 1..30000&&offsetMs+durationMs<=900100)
        return raw.lineSequence().take(1000).mapNotNull{line->val p=line.split('\t',limit=4);if(p.size !in 3..4)return@mapNotNull null;val a=p[0].toLongOrNull()?:return@mapNotNull null;val b=p[1].toLongOrNull()?:return@mapNotNull null;val text=p[2].trim().replace('[','(').replace(']',')').replace('<','(').replace('>',')').take(1000);if(a<0||b<=a||a>durationMs/10||a*10>=durationMs||b>durationMs/10+1||text.isBlank())null else {val times=p.getOrNull(3)?.split(',')?.map{it.toLongOrNull()};val words=Regex("\\S+").findAll(text).count();val starts=if(times!=null&&words in 2..200&&times.size==words&&times.all{it!=null&&it>=a&&it<b&&it*10<durationMs}&&times.zipWithNext().all{(x,y)->x!!<y!!})times.map{offsetMs+it!!*10}else emptyList();Segment(offsetMs+a*10,offsetMs+minOf(b*10,durationMs),text,starts)}}.sortedBy{it.startMs}.toList()
    }
    /** Independent overlapping inference windows. Assign segments by midpoint in the overlap;
     * retain original timestamps. This is a heuristic, not forced alignment. */
    data class Window(val startMs:Long,val endMs:Long,val segments:List<Segment>) {
        init { require(startMs>=0 && endMs>startMs && endMs<=900100 && endMs-startMs<=30000 && segments.all{it.startMs>=startMs&&it.endMs<=endMs&&it.endMs>it.startMs}) }
    }
    private val tokens=Regex("[\\p{L}\\p{N}\\p{M}]+")
    private fun identity(s:Segment)=tokens.findAll(java.text.Normalizer.normalize(s.text,java.text.Normalizer.Form.NFKC).lowercase(java.util.Locale.ROOT)).joinToString(" "){it.value}
    private fun validWords(s:Segment):Boolean {
        val count=Regex("\\S+").findAll(s.text).count()
        return count in 2..200&&s.wordStarts.size==count&&s.wordStarts.all{it in s.startMs until s.endMs}&&s.wordStarts.zipWithNext().all{(a,b)->a<b}
    }
    private data class Candidate(val segment:Segment,val window:Int,val owned:Boolean,val edgeMargin:Long,val key:String)
    private fun overlap(a:Segment,b:Segment)=minOf(a.endMs,b.endMs)-maxOf(a.startMs,b.startMs)
    private fun sameUtterance(a:Candidate,b:Candidate):Boolean {
        val x=a.segment;val y=b.segment
        if(x.startMs==y.startMs)return true // one LRC line can own a given timestamp
        return a.window!=b.window&&a.key.isNotEmpty()&&a.key==b.key&&overlap(x,y)>0&&overlap(x,y)*2>=minOf(x.endMs-x.startMs,y.endMs-y.startMs)
    }
    private fun prefer(a:Candidate,b:Candidate):Boolean {
        // Only compare timing completeness when both transcriptions describe the same words.
        if(a.key.isNotEmpty()&&a.key==b.key&&validWords(a.segment)!=validWords(b.segment))return validWords(a.segment)
        if(a.owned!=b.owned)return a.owned
        if(a.edgeMargin!=b.edgeMargin)return a.edgeMargin>b.edgeMargin
        return a.segment.endMs-a.segment.startMs>b.segment.endMs-b.segment.startMs
    }
    fun merge(windows:List<Window>):List<Segment> {
        require(windows.size<=50 && windows.zipWithNext().all{(a,b)->b.startMs>a.startMs&&b.endMs>a.endMs})
        val all=windows.flatMapIndexed{i,w->
            val low=windows.getOrNull(i-1)?.let{p->if(p.endMs>w.startMs)(p.endMs+w.startMs)/2 else w.startMs}?:w.startMs
            val high=windows.getOrNull(i+1)?.let{n->if(w.endMs>n.startMs)(w.endMs+n.startMs)/2 else w.endMs}?:w.endMs
            w.segments.map{s->val mid=(s.startMs+s.endMs)/2;Candidate(s,i,mid>=low&&mid<high,minOf(s.startMs-w.startMs,w.endMs-s.endMs),identity(s))}
        }
        val chosen=mutableListOf<Candidate>()
        for(c in all.sortedWith(compareByDescending<Candidate>{it.owned}.thenBy{it.segment.startMs}.thenBy{it.window})){
            check(!Thread.currentThread().isInterrupted)
            val duplicates=chosen.filter{sameUtterance(c,it)}
            if(duplicates.size==1){
                val old=duplicates.single()
                if(prefer(c,old)&&chosen.none{it!==old&&overlap(c.segment,it.segment)>0&&overlap(old.segment,it.segment)<=0}){chosen.remove(old);chosen.add(c)}
            }else if(duplicates.isEmpty()&&(c.owned||chosen.none{overlap(c.segment,it.segment)>0}))chosen.add(c)
            // If a broad hypothesis collides with two retained lines, do not collapse them.
        }
        return chosen.map{it.segment}.sortedBy{it.startMs}
    }
    fun lrc(segments:List<Segment>):String { val ordered=segments.filter{it.startMs<it.endMs}.sortedBy{it.startMs}.distinctBy{it.startMs};return ordered.mapIndexed{index,seg->val matches=Regex("\\S+").findAll(seg.text).toList();val next=ordered.getOrNull(index+1)?.startMs?:Long.MAX_VALUE;val valid=validWords(seg)&&seg.wordStarts.all{it<next};val text=if(valid)buildString{var pos=0;for((i,m) in matches.withIndex()){append(seg.text.substring(pos,m.range.first));append("<${SubtitleCore.stamp(seg.wordStarts[i])}>");append(m.value);pos=m.range.last+1};append(seg.text.substring(pos))}else seg.text;"[${SubtitleCore.stamp(seg.startMs)}]$text"}.joinToString("\n") }
}
