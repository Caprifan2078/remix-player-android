package app.remix.player
import kotlin.math.*
/** Gentle high-pass and bounded gain before ASR. Exactly one output sample per input sample. */
object VocalConditioning {
    class Filter(private val gain:Double=1.0,rate:Int=16000){
        init{require(gain.isFinite()&&gain in .5..4.0&&rate>=8000)}
        private val alpha=exp(-2*PI*70/rate);private var prev=0.0;private var y=0.0
        fun sample(input:Short):Short{val x=input.toDouble();y=alpha*(y+x-prev);prev=x;return (y*gain).roundToInt().coerceIn(-32768,32767).toShort()}
    }
    class Measure{private var sum=0.0;private var peak=0.0;private var count=0L
        fun add(s:Short){val x=s/32768.0;sum+=x*x;peak=max(peak,abs(x));count++}
        fun gain():Double{if(count==0L||peak<.003)return 1.0;val rms=sqrt(sum/count);return minOf(.12/rms,.90/peak,4.0).coerceAtLeast(.5)}
    }
}
