package app.remix.player

import java.io.*
import java.util.zip.*

/** Streaming portable archive. No paths supplied by an archive are ever extracted. */
object BackupCore {
    const val MAX_TRACKS=60000
    const val MAX_META=64*1024*1024
    const val MAX_FILE=512L*1024*1024
    const val MAX_TOTAL=64L*1024*1024*1024
    private val extensions=setOf("mp3","wav","flac","m4a","aac","ogg","opus","mp4","webm","amr","aiff","wma","audio")
    fun extension(value:String)=value.lowercase().takeIf{it in extensions}?:"audio"
    private fun copy(input:InputStream,output:OutputStream,limit:Long):Long {
        val b=ByteArray(65536);var count=0L
        while(true){check(!Thread.currentThread().isInterrupted){"Отменено"};val n=input.read(b);if(n<0)break;if(n==0)continue;count+=n;require(count<=limit){"Превышен лимит архива"};output.write(b,0,n)}
        return count
    }
    data class Item(val ext:String,val open:()->InputStream)
    data class Restored(val metadata:ByteArray,val files:List<File>)
    fun write(output:OutputStream,metadata:ByteArray,items:List<Item>,progress:(Int)->Unit={}){
        require(metadata.size in 1..MAX_META && items.size in 1..MAX_TRACKS)
        ZipOutputStream(BufferedOutputStream(output)).use{z->
            z.setLevel(0)
            fun entry(name:String,bytes:ByteArray){z.putNextEntry(ZipEntry(name));z.write(bytes);z.closeEntry()}
            entry("remix-backup-v1",items.size.toString().toByteArray(Charsets.US_ASCII));entry("library.json",metadata)
            var total=0L
            items.forEachIndexed{i,item->z.putNextEntry(ZipEntry("audio/$i.${extension(item.ext)}"));val n=item.open().use{copy(it,z,minOf(MAX_FILE,MAX_TOTAL-total))};require(n>0){"Пустой аудиофайл"};total+=n;z.closeEntry();progress(i+1)}
            entry("complete",byteArrayOf(82,80,66,1))
        }
    }
    /** dir must not exist. On any error, including cancellation, no extracted files survive. */
    fun read(input:InputStream,dir:File,progress:(Int,Int)->Unit={_,_->}):Restored {
        require(!dir.exists()&&dir.mkdirs()){ "Не удалось создать временную папку" }
        try { return ZipInputStream(BufferedInputStream(input)).use{z->
            fun bytes(name:String,limit:Int):ByteArray {require(z.nextEntry?.name==name){"Неверный формат архива"};val out=ByteArrayOutputStream();copy(z,out,limit.toLong());z.closeEntry();return out.toByteArray()}
            val count=bytes("remix-backup-v1",8).toString(Charsets.US_ASCII).toIntOrNull()?:error("Неверное число файлов")
            require(count in 1..MAX_TRACKS)
            val meta=bytes("library.json",MAX_META);require(meta.isNotEmpty())
            var total=0L;val files=ArrayList<File>(count)
            repeat(count){i->val e=z.nextEntry?:error("Архив оборван");val name=e.name;val ext=name.substringAfterLast('.',"");require(!e.isDirectory&&ext in extensions&&name=="audio/$i.$ext"){"Недопустимая запись архива"}
                val file=File(dir,"$i.$ext");val n=file.outputStream().buffered().use{copy(z,it,minOf(MAX_FILE,MAX_TOTAL-total))};require(n>0);total+=n;z.closeEntry();files.add(file);progress(i+1,count)}
            require(bytes("complete",4).contentEquals(byteArrayOf(82,80,66,1))&&z.nextEntry==null){"Архив не завершён или содержит лишние записи"}
            Restored(meta,files)
        }}catch(e:Throwable){dir.deleteRecursively();throw e}
    }
    /** A group must refer directly to an original; preferred versions cannot cross groups. */
    fun validate(groups:List<Int>,preferred:Map<Int,Int>,playlists:List<List<Int>>){
        require(groups.size in 1..MAX_TRACKS)
        require(groups.all{it in groups.indices&&groups[it]==it}){"Повреждены группы"}
        require(preferred.all{(g,v)->g in groups.indices&&v in groups.indices&&groups[g]==g&&groups[v]==g}){"Повреждены выбранные версии"}
        require(playlists.size<=10000&&playlists.all{p->p.size<=groups.size&&p.all{it in groups.indices&&groups[it]==it}}){"Повреждены плейлисты"}
    }
}
