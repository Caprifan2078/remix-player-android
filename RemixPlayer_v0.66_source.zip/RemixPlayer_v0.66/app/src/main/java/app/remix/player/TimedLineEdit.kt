package app.remix.player

/** Edit explicit timed fragments; no inferred timing or changes to other rows. */
class TimedLineEdit private constructor(private val rows:List<String>,private val row:Int,private val ranges:List<IntRange>,val fragments:List<Fragment>){
    data class Fragment(val ms:Long,val text:String)
    fun replace(values:List<String>):String{
        require(values.size==fragments.size){"Число фрагментов не должно меняться"}
        val edited=StringBuilder(rows[row]);for(i in ranges.indices.reversed()){
            val value=values[i].trim();require(value.isNotBlank()&&value.length<=256&&value.none{it in "[]<>"||it.isISOControl()}){"Некорректный фрагмент ${i+1}"}
            val range=ranges[i];edited.replace(range.first,range.last+1,value)
        }
        val out=rows.toMutableList();out[row]=edited.toString();val result=out.joinToString("\n");require(result.length<=500_000);return result
    }
    companion object {
        private val marker=Regex("<(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?>")
        fun open(raw:String,selected:Lyric):TimedLineEdit{
            require(raw.length<=500_000)
            val rows=raw.split('\n');val offset=Lrc.offset(raw);val candidates=rows.indices.filter{i->Lrc.parse("[offset:$offset]\n${rows[i]}").any{it==selected}}
            require(candidates.size==1){"Неоднозначная строка. Используйте редактор LRC."}
            val row=candidates.single();val source=rows[row];require(Lrc.parse("[offset:$offset]\n$source").size==1){"Строка имеет несколько меток. Используйте редактор LRC."}
            val hits=marker.findAll(source).toList();val parsed=WordLyrics.parse(selected);require(hits.size in 1..40&&hits.size==parsed.words.size){"Нужны корректные метки слов (до 40 на строку)"}
            val ranges=hits.mapIndexed{i,m->var a=m.range.last+1;var b=hits.getOrNull(i+1)?.range?.first?:source.length;while(a<b&&source[a].isWhitespace())a++;while(b>a&&source[b-1].isWhitespace())b--;require(a<b);a until b}
            val fragments=ranges.mapIndexed{i,r->Fragment(parsed.words[i].ms,source.substring(r))};return TimedLineEdit(rows,row,ranges,fragments)
        }
    }
}
