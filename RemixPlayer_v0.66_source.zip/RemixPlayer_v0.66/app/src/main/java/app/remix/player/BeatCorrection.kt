package app.remix.player
import kotlin.math.*

/** User overrides do not overwrite or inflate automatic analysis confidence. */
object BeatCorrection {
    data class Manual(val bpm:Double,val anchor:Double,val followLocal:Boolean=false){init{require(bpm.isFinite()&&bpm in 50.0..220.0&&anchor.isFinite()&&anchor in 0.0..900.0)}}
    data class Grid(val bpm:Double,val phase:Double,val windows:List<RhythmMap.Window>,val reference:Double,val anchor:Double=phase)
    fun resolve(report:MusicAnalysis.Report,manual:Manual?):Grid? {
        if(manual!=null){if(manual.anchor>=report.duration)return null;val period=60/manual.bpm;val phase=manual.anchor%period;val ref=report.tempo?.bpm?.takeIf{it.isFinite()&&it in 50.0..220.0}?:manual.bpm;return Grid(manual.bpm,phase,if(manual.followLocal)report.tempoWindows else emptyList(),ref,if(manual.followLocal)manual.anchor else phase)}
        val bpm=report.tempo?.bpm?.takeIf{it.isFinite()&&it in 50.0..220.0}?:return null;val phase=report.phaseSeconds?.takeIf{it.isFinite()&&it>=0&&it<report.duration}?:return null;return Grid(bpm,phase,report.tempoWindows,bpm)
    }
    class Tap {
        private val times=ArrayList<Long>()
        fun clear()=times.clear()
        fun add(ms:Long):Double?{if(times.isNotEmpty()&&(ms<=times.last()||ms-times.last()>2000))times.clear();times.add(ms);if(times.size>9)times.removeAt(0);if(times.size<4)return null;val intervals=times.zipWithNext{a,b->(b-a).toDouble()}.sorted();val median=(intervals[(intervals.size-1)/2]+intervals[intervals.size/2])/2;val valid=intervals.filter{abs(it-median)<=median*.18};if(valid.size<3||valid.size*4<intervals.size*3)return null;return (60000/valid.average()).takeIf{it in 50.0..220.0}}
    }
}
