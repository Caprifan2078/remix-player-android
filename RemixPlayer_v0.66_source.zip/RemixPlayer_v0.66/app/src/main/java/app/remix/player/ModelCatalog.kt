package app.remix.player

import java.net.URI

/** Pinned publisher metadata. Actual model inference must be verified on Android. */
object ModelCatalog {
    enum class Kind { SEPARATOR, SPEECH, GENRE }
    data class Entry(val id:String,val title:String,val kind:Kind,val url:String,val source:String,val sizeMb:Int,val license:String,val sha256:String?)
    private fun speech(id:String,title:String,mb:Int)=Entry(id,title,Kind.SPEECH,"https://alphacephei.com/vosk/models/$id.zip","https://alphacephei.com/vosk/models",mb,"Apache-2.0",null)
    val entries=listOf(
        Entry("htdemucs-fp16","HT-Demucs · 4 дорожки",Kind.SEPARATOR,"https://huggingface.co/StemSplitio/htdemucs-onnx/resolve/d54ed9eb60e258ea82131c6ee14578628816456a/htdemucs_fp16weights.onnx","https://huggingface.co/StemSplitio/htdemucs-onnx/blob/main/htdemucs_fp16weights.onnx",166,"MIT","d05c269d0178d2a72ad484b10b11dd370193fc923201c3b27a99f848745db70a"),
        Entry("htdemucs-6s-fp16","HT-Demucs · 6 дорожек",Kind.SEPARATOR,"https://huggingface.co/StemSplitio/htdemucs-6s-onnx/resolve/49df9b6989cf2150840ea65b0bef77a2e471b678/htdemucs_6s_fp16weights.onnx","https://huggingface.co/StemSplitio/htdemucs-6s-onnx/blob/49df9b6989cf2150840ea65b0bef77a2e471b678/htdemucs_6s_fp16weights.onnx",136,"MIT","7ce55792e2231c93fbf92de95f5fd5b3a5e6c89f7db690dfd693e8f1dce56869"),
        speech("vosk-model-small-ru-0.22","Vosk · русский",45),speech("vosk-model-small-en-us-0.15","Vosk · английский",40),speech("vosk-model-small-es-0.42","Vosk · испанский",39),speech("vosk-model-small-pt-0.3","Vosk · португальский",31),speech("vosk-model-small-ja-0.22","Vosk · японский",48),
        Entry("ast-gtzan-int8","AST · 10 музыкальных жанров",Kind.GENRE,"https://huggingface.co/onnx-community/ast-finetuned-gtzan-ONNX/resolve/7f313d5ef95bdd541b857c5385702194703b8185/onnx/model_int8.onnx","https://huggingface.co/onnx-community/ast-finetuned-gtzan-ONNX/commit/7f313d5ef95bdd541b857c5385702194703b8185",90,"BSD-3-Clause (метаданные издателя)","f7322d9c9a0d40e01bb4fc2feb303864bbfb93b0264e654e2a37f413b86a31bf"))
    fun expectedStems(entry:Entry):Int { require(entry in entries&&entry.kind==Kind.SEPARATOR);return if(entry.id=="htdemucs-6s-fp16")6 else 4 }
    fun allowed(entry:Entry,uri:URI):Boolean {
        if(entry !in entries||uri.scheme!="https"||uri.userInfo!=null||uri.fragment!=null||uri.port !in listOf(-1,443))return false
        val h=uri.host?.lowercase()?:return false
        return when(entry.kind){Kind.SPEECH->h=="alphacephei.com"&&uri.toString()==entry.url;Kind.SEPARATOR,Kind.GENRE->h=="huggingface.co"||h=="cdn-lfs.huggingface.co"||h=="cdn-lfs.hf.co"||h=="cdn-lfs-us-1.hf.co"||h=="cas-bridge.xethub.hf.co"}
    }
    fun redirect(entry:Entry,from:URI,location:String):URI=from.resolve(location).also{require(allowed(entry,it)){"Неподдерживаемое перенаправление модели"}}
}
