package app.remix.player

/** Group changes never modify a media file. Resolve the live root at commit time. */
object GroupEdit {
    data class Entry(val id:String,val group:String,val lyrics:String,val ratio:Double?,val favorite:Boolean)
    private fun ratio(e:Entry):Double?=if(e.id==e.group)1.0 else e.ratio?.takeIf{it.isFinite()&&it in .4..1.8}
    fun importRoot(target:String?,id:String,rootOf:(String)->String?):String {
        val root=target?.let(rootOf)?:return id
        return if(rootOf(root)==root)root else id
    }
    fun detach(entries:List<Entry>,id:String,expectedRoot:String):List<Entry>? {
        val root=entries.firstOrNull{it.id==expectedRoot&&it.group==expectedRoot}?:return null
        val child=entries.firstOrNull{it.id==id&&it.group==expectedRoot&&it.id!=it.group}?:return null
        return entries.map{if(it.id==child.id)it.copy(group=id,lyrics=GroupLyrics.preserve(it.lyrics,root.lyrics,ratio(it)),ratio=null)else it}
    }
    fun promote(entries:List<Entry>,id:String,expectedRoot:String):List<Entry>? {
        val root=entries.firstOrNull{it.id==expectedRoot&&it.group==expectedRoot}?:return null
        val child=entries.firstOrNull{it.id==id&&it.group==expectedRoot&&it.id!=it.group}?:return null
        val divisor=ratio(child)
        return entries.map{e->if(e.group!=expectedRoot)e else {
            val r=ratio(e)
            val relative=if(e.id==id||r==null||divisor==null)null else (r/divisor).takeIf{it.isFinite()&&it in .4..1.8}
            e.copy(group=id,lyrics=GroupLyrics.preserve(e.lyrics,root.lyrics,r),ratio=relative,favorite=if(e.id==id)e.favorite||root.favorite else e.favorite)
        }}
    }
}
