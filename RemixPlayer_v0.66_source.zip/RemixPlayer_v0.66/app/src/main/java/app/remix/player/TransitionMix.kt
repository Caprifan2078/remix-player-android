package app.remix.player
import java.io.*
import kotlin.math.*
/** Render an offline two-song transition. Sources are canonical stereo PCM16 at 44.1 kHz. */
object TransitionMix {
    fun render(first:File,second:File,out:File,seconds:Int,progress:(Int)->Unit={}):Long {
        require(seconds in 1..10&&first.length()>0&&second.length()>0&&first.length()%4==0L&&second.length()%4==0L)
        require(out.canonicalFile!=first.canonicalFile&&out.canonicalFile!=second.canonicalFile)
        val a=first.length()/4;val b=second.length()/4;val overlap=minOf(seconds*44100L,a/2,b/2);require(overlap>=2){"Слишком короткие файлы"};val length=a+b-overlap
        require(length*4<=0xffffffffL-36);require(out.absoluteFile.parentFile!!.usableSpace>44+length*4+1048576){"Недостаточно места"}
        var count=0L;var last=-1
        fun tick(){if(count%8192==0L){check(!Thread.currentThread().isInterrupted){"Отменено"};val p=(count*100/length).toInt();if(p!=last){last=p;progress(p)}}}
        try{first.inputStream().buffered(65536).use{x->second.inputStream().buffered(65536).use{y->out.outputStream().buffered(65536).use{w->StemCore.header(w,length)
            fun copy(r:InputStream,n:Long){repeatFrames(n){tick();repeat(2){StemCore.writeShort(w,StemCore.readShort(r))};count++}}
            copy(x,a-overlap);repeatFrames(overlap){i->tick();val t=i.toDouble()/(overlap-1);val gainA=cos(t*PI/2);val gainB=sin(t*PI/2);val norm=max(1.0,gainA+gainB);repeat(2){val l=StemCore.readShort(x)/32768.0;val r=StemCore.readShort(y)/32768.0;StemCore.writeShort(w,StemCore.pcm(((l*gainA+r*gainB)/norm).toFloat()))};count++};copy(y,b-overlap)
        }}};check(count==length);progress(100);return length}catch(e:Throwable){out.delete();throw e}
    }
    private inline fun repeatFrames(n:Long,block:(Long)->Unit){var i=0L;while(i<n){block(i);i++}}
}
