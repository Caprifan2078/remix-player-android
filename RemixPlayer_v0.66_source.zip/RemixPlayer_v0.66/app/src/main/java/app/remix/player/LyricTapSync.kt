package app.remix.player

/** Manual line timestamps, always explicitly chosen by the listener. */
class LyricTapSync(text:String){
    val lines=text.lines().map{it.trim()}.filter{it.isNotBlank()}
    private val marks=ArrayList<Long>()
    init{require(text.length<=100_000&&lines.size in 1..1000&&lines.none{it.any{c->c in "[]<>"}}){"Введите обычный текст без временных меток"}}
    val index:Int get()=marks.size
    val complete:Boolean get()=marks.size==lines.size
    fun mark(ms:Long){require(!complete&&ms in 0..900_000&&ms>(marks.lastOrNull()?:-1)){"Позиция должна быть позже предыдущей строки"};marks.add(ms)}
    fun undo(){if(marks.isNotEmpty())marks.removeAt(marks.lastIndex)}
    fun lrc():String{check(complete){"Не все строки размечены"};return lines.mapIndexed{i,line->"[${SubtitleCore.stamp(marks[i])}]$line"}.joinToString("\n")}
}
