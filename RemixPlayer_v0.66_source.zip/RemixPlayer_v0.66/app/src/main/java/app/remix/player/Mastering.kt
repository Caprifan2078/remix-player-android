package app.remix.player

import java.io.*
import kotlin.math.*

/** Two-pass bounded-memory PCM mastering. RMS is not perceptual LUFS; no claim of true peak. */
object Mastering {
    data class Stats(val peak:Double,val rms:Double,val samples:Long)
    fun gain(s:Stats,targetDb:Double=-15.0,ceilingDb:Double=-1.0):Double {
        require(targetDb in -30.0..-6.0&&ceilingDb in -6.0..0.0)
        if(s.rms<.001 || s.peak<=0) return 1.0
        return minOf(10.0.pow(targetDb/20)/s.rms,10.0.pow(ceilingDb/20)/s.peak,2.0)
    }
    fun measure(file:File):Stats {
        require(file.length()>44&&(file.length()-44)%4==0L)
        var count=0L;var peak=0.0;var sum=0.0
        file.inputStream().buffered(65536).use { input ->
            val header=ByteArray(44);DataInputStream(input).readFully(header)
            val expected=ByteArrayOutputStream().also{StemCore.header(it,(file.length()-44)/4)}.toByteArray()
            require(header.contentEquals(expected)){"Требуется внутренний PCM WAV"}
            val samples=(file.length()-44)/2
            repeatLoop@ while(count<samples){if(count%8192==0L)check(!Thread.currentThread().isInterrupted);val v=StemCore.readShort(input)/32768.0;peak=max(peak,abs(v));sum+=v*v;count++}
        }
        return Stats(peak,sqrt(sum/count),count)
    }
    /** Only the new generated file is changed. Caller deletes it if cancelled or failed. */
    fun normalizeGenerated(file:File):Stats {
        val stats=measure(file);val g=gain(stats)
        if(abs(g-1.0)<1e-6)return stats
        var peak=0.0;var sum=0.0;var count=0L
        RandomAccessFile(file,"rw").use { f ->
            val bytes=ByteArray(65536);var pos=44L
            while(pos<f.length()){check(!Thread.currentThread().isInterrupted);val n=minOf(bytes.size.toLong(),f.length()-pos).toInt();f.seek(pos);f.readFully(bytes,0,n)
                for(i in 0 until n step 2){val s=((bytes[i].toInt() and 255) or (bytes[i+1].toInt() shl 8)).toShort();val v=(s*g).roundToInt().coerceIn(-32768,32767);bytes[i]=v.toByte();bytes[i+1]=(v shr 8).toByte();val x=v/32768.0;peak=max(peak,abs(x));sum+=x*x;count++}
                f.seek(pos);f.write(bytes,0,n);pos+=n
            }
        };check(count==stats.samples);return Stats(peak,sqrt(sum/count),count)
    }
}
