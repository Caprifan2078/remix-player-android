package app.remix.player

import kotlin.math.*
import java.io.File

/** Heuristic energy structure, not semantic verse/chorus recognition. All times retain source alignment. */
object Arrangement {
    enum class Part { INTRO, BREAK, BUILD, DROP, GROOVE, OUTRO }
    data class Section(val start:Double,val end:Double,val part:Part)
    data class Mix(var drums:Float,var bass:Float,var sourceDrums:Float,var riser:Float)
    private fun mix(part:Part)=when(part){
        Part.INTRO->Mix(.35f,.3f,.75f,0f)
        Part.BREAK->Mix(.18f,.12f,.5f,0f)
        Part.BUILD->Mix(.65f,.45f,.75f,.65f)
        Part.DROP->Mix(1f,1f,1f,0f)
        Part.GROOVE->Mix(.8f,.7f,1f,0f)
        Part.OUTRO->Mix(.30f,.25f,.65f,0f)
    }
    fun plan(energy:List<Double>,duration:Double):List<Section>{
        require(duration.isFinite()&&duration>0)
        val n=ceil(duration/4).toInt();require(n<=10000)
        val values=List(n){energy.getOrNull(it)?.takeIf{v->v.isFinite()&&v>=0}}
        val sorted=values.filterNotNull().sorted();val median=sorted.getOrNull(sorted.size/2)?:0.0
        val peak=sorted.getOrNull((sorted.size*.85).toInt().coerceIn(0,max(0,sorted.lastIndex)))?:0.0
        val parts=values.mapIndexed{i,v->when{
            v==null||peak<.005->Part.GROOVE
            n>=5&&i==0->Part.INTRO
            n>=5&&i==n-1->Part.OUTRO
            v<max(.003,median*.62)->Part.BREAK
            v>=max(median*1.2,peak*.85)->Part.DROP
            else->Part.GROOVE
        }}.toMutableList()
        for(i in 0 until n-1){val a=values[i];val b=values[i+1];if(parts[i] in listOf(Part.GROOVE,Part.BREAK)&&parts[i+1]==Part.DROP&&a!=null&&b!=null&&b>a*1.35&&b-a>.015)parts[i]=Part.BUILD}
        return parts.mapIndexed{i,p->Section(i*4.0,min(duration,(i+1)*4.0),p)}
    }
    /** Snap energy-based changes to the nearest complete four-beat bar on the generated grid.
     * This assumes 4/4; no claim of semantic downbeat or meter recognition. No audio is cut. */
    fun aligned(energy:List<Double>,frames:Long,grid:AdaptiveGroove,rate:Int=44100,sections:List<Section>?=null):List<Section>{
        require(rate in 8000..384000&&frames in 1..rate.toLong()*900)
        val duration=frames.toDouble()/rate
        val original=sections?.takeIf{it.isNotEmpty()&&it.first().start==0.0&&abs(it.last().end-duration)<1e-7&&it.all{s->s.end>s.start}&&it.zipWithNext().all{(a,b)->a.end==b.start}}?:plan(energy,duration)
        val merged=ArrayList<Section>()
        for(s in original){val prev=merged.lastOrNull();if(prev!=null&&prev.part==s.part)merged[merged.lastIndex]=prev.copy(end=s.end)else merged.add(s)}
        if(merged.size<2)return merged
        val startPosition=grid.position(0);val endPosition=grid.position(frames)
        fun nearestBar(time:Double):Long?{
            val target=round(grid.position((time*rate).roundToLong())/16)*16
            if(target<=startPosition||target>=endPosition)return null
            var lo=0L;var hi=frames
            while(hi-lo>1){val mid=lo+(hi-lo)/2;if(grid.position(mid)<target)lo=mid else hi=mid}
            return if(abs(grid.position(lo)-target)<abs(grid.position(hi)-target))lo else hi
        }
        val result=ArrayList<Section>();var start=0L;var part=merged.first().part
        for(i in 1 until merged.size){val at=nearestBar(merged[i].start)?:continue
            // A short terminal section or a duplicate snapped boundary cannot produce a zero-length section.
            if(at-start<rate/4||frames-at<rate/4)continue
            if(part!=merged[i].part){result.add(Section(start.toDouble()/rate,at.toDouble()/rate,part));start=at;part=merged[i].part}
        }
        result.add(Section(start.toDouble()/rate,duration,part));return result
    }
    /** Piecewise smooth envelopes. No cuts or reordering of original vocals. */
    class Envelope(private val sections:List<Section>,private val rate:Int=44100){
        private val levels=sections.map{mix(it.part)};private var index=0;private val current=Mix(0f,0f,0f,0f)
        init{require(rate>0&&sections.isNotEmpty())}
        fun sample(frame:Long):Mix{
            val t=frame.toDouble()/rate
            while(index<sections.lastIndex&&t>=sections[index].end)index++
            while(index>0&&t<sections[index].start)index--
            val s=sections[index];val b=levels[index];val a=levels.getOrElse(index-1){b};val x=((t-s.start)/.35).coerceIn(0.0,1.0).toFloat()
            fun lerp(u:Float,v:Float)=u+(v-u)*x
            val rising=if(s.part==Part.BUILD){val length=s.end-s.start;val taper=((s.end-t)/min(.08,length/2)).coerceIn(0.0,1.0);(((t-s.start)/length).coerceIn(0.0,1.0)*b.riser*taper).toFloat()} else 0f
            val fade=if(s.part==Part.OUTRO)((s.end-t)/min(2.0,s.end-s.start)).coerceIn(0.0,1.0).toFloat() else 1f
            current.drums=lerp(a.drums,b.drums)*fade;current.bass=lerp(a.bass,b.bass)*fade;current.sourceDrums=lerp(a.sourceDrums,b.sourceDrums);current.riser=rising;return current
        }
    }
    /** Original procedural noise sweep, bounded gain. */
    class Sweep {private var rng=987654321;private var low=0f;fun sample(amount:Float):Float{rng=rng xor(rng shl 13);rng=rng xor(rng ushr 17);rng=rng xor(rng shl 5);val x=rng/2147483648f;low+=(x-low)*(.02f+.12f*amount);return (x-low)*amount*.09f}}
    /** Render a selected batch atomically: cancellation or failure removes every newly made file. */
    fun <T> batch(items:List<T>,dir:File,bytesPerFile:Long,render:(T,File,Int)->Unit):List<Pair<T,File>>{
        return batchSized(items,dir,{bytesPerFile},0,render)
    }
    fun <T> batchSized(items:List<T>,dir:File,size:(T)->Long,extra:Long,render:(T,File,Int)->Unit):List<Pair<T,File>>{
        require(items.isNotEmpty()&&items.size<=70&&extra>=0)
        val sizes=items.map(size);require(sizes.all{it>0&&it<=Long.MAX_VALUE/(items.size+2)});val total=sizes.sum();require(extra<=Long.MAX_VALUE-total)
        require(dir.isDirectory&&dir.usableSpace>total+extra+min(32L*1024*1024,Long.MAX_VALUE-total-extra)){"Недостаточно места для пакета"}
        val created=mutableListOf<Pair<T,File>>()
        try{items.forEachIndexed{i,item->check(!Thread.currentThread().isInterrupted){"Отменено"};val file=File.createTempFile("remix-",".wav",dir);created.add(item to file);render(item,file,i);check(file.length()==sizes[i]){"Неполный WAV"}};check(!Thread.currentThread().isInterrupted){"Отменено"};return created.toList()}
        catch(e:Throwable){created.forEach{it.second.delete()};throw e}
    }
}
