package app.remix.player

import java.io.*

/** Freeze every user-controlled rendering input, and bind a checkpoint to canonical PCM. */
object GenreCheckpoint {
    data class Plan(val styles:List<GenreEngine.Style>,val mix:GenreMix,val manual:BeatCorrection.Manual?,val separated:Boolean){
        init{require(styles.size in 1..30&&styles.map{it.name}.distinct().size==styles.size)}
        fun signature():ByteArray=ByteArrayOutputStream().also{b->DataOutputStream(b).use{o->
            o.writeUTF("genre-render-v6");o.writeBoolean(separated);mix.values().forEach{o.writeFloat(it)}
            o.writeBoolean(manual!=null);manual?.let{o.writeDouble(it.bpm);o.writeDouble(it.anchor);o.writeBoolean(it.followLocal)}
            o.writeInt(styles.size);styles.forEach{s->o.writeUTF(s.name);o.writeInt(s.target);listOf(s.kick,s.snare,s.hat).forEach{a->o.writeInt(a.size);a.forEach{o.writeInt(it)}};o.writeFloat(s.drive);o.writeFloat(s.oldDrums);o.writeFloat(s.bass)}
        }}.toByteArray()
    }
    fun render(raw:File,stems:List<File>,dir:File,plan:Plan,bpm:Double,reused:(Int,GenreEngine.Style)->Unit,renderer:(GenreEngine.Style,File,Int)->Unit):List<Pair<GenreEngine.Style,File>>{
        val frames=raw.length()/4;require(raw.isFile&&frames>0&&raw.length()%4==0L)
        require(if(plan.separated) stems.size in listOf(4,6)&&stems.all{it.isFile&&it.length()==raw.length()} else stems.isEmpty())
        val input=(listOf(raw)+stems).joinToString(":"){EffectCheckpoint.hash(it)}
        val signature=ByteArrayOutputStream().also{b->DataOutputStream(b).use{it.write(plan.signature());it.writeDouble(bpm)}}.toByteArray()
        return EffectCheckpoint.renderBatch(dir,plan.styles,input,signature,{s->44+TimeStretch.outputFrames(frames,TimeStretch.plan(bpm,s.target).speed)*4},44+frames*4,reused,renderer)
    }
}
