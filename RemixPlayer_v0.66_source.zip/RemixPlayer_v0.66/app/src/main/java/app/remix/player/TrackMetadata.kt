package app.remix.player
object TrackMetadata {
    data class Fields(val title:String,val artist:String,val album:String)
    fun validated(title:String,artist:String,album:String):Fields {
        fun clean(value:String):String {
            require(value.length<=4096){"Поле слишком длинное"}
            require(value.none{it.isISOControl()||it=='\u2028'||it=='\u2029'}){"Недопустимые символы"}
            return value.trim()
        }
        val name=clean(title);require(name.isNotBlank()){"Введите название песни"}
        return Fields(name,clean(artist).ifBlank{"Неизвестный исполнитель"},clean(album))
    }
    fun <T> replace(items:MutableList<T>,id:String,expected:Fields,next:Fields,key:(T)->String,read:(T)->Fields,update:(T,Fields)->T):Boolean {
        val index=items.indexOfFirst{key(it)==id};if(index<0)return false
        val current=items[index];if(read(current)!=expected)return false
        items[index]=update(current,next);return true
    }
}
