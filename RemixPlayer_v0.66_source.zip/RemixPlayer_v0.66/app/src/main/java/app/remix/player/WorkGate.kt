package app.remix.player

/** One file-producing operation per process, including UI commit/rollback. */
class WorkGate {
    class Ticket internal constructor(val id:String,val title:String){
        @Volatile var cancelled=false; internal set
        internal var thread:Thread?=null
    }
    private var active:Ticket?=null
    @Synchronized fun current():Ticket?=active
    @Synchronized fun begin(title:String,persist:(Ticket)->Boolean):Ticket? {
        if(active!=null)return null
        require(title.isNotBlank()&&title.length<=512)
        val t=Ticket(java.util.UUID.randomUUID().toString(),title)
        if(!persist(t))return null
        active=t;return t
    }
    @Synchronized fun enter(t:Ticket):Boolean {
        if(active!==t||t.cancelled||t.thread!=null)return false
        t.thread=Thread.currentThread();return true
    }
    @Synchronized fun leave(t:Ticket){if(active===t&&t.thread===Thread.currentThread())t.thread=null}
    @Synchronized fun cancel(t:Ticket){if(active===t){t.cancelled=true;t.thread?.interrupt()}}
    @Synchronized fun finish(t:Ticket,persist:()->Unit):Boolean {
        if(active!==t||t.thread!=null)return false
        try{persist()}finally{active=null};return true
    }
}
