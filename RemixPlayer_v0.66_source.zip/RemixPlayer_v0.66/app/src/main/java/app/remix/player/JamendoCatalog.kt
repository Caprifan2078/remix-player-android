package app.remix.player
import org.json.JSONObject
import java.net.URI
import java.net.URLEncoder
import java.net.HttpURLConnection
/** Official Jamendo read endpoint. Do not offer download when the artist disabled it. */
object JamendoCatalog {
    data class Song(val id:String,val title:String,val artist:String,val album:String,val download:String?,val license:String)
    fun parse(json:String):List<Song>{val root=JSONObject(json);require(root.getJSONObject("headers").optString("status")=="success"){"Каталог вернул ошибку"};val a=root.getJSONArray("results");return (0 until minOf(a.length(),50)).mapNotNull{i->val o=a.optJSONObject(i)?:return@mapNotNull null;val id=o.optString("id");if(id.isBlank())return@mapNotNull null;val raw=o.optString("audiodownload");val uri=runCatching{URI(raw)}.getOrNull();val allowed=o.optBoolean("audiodownload_allowed",false)&&uri!=null&&uri.scheme=="https"&&uri.host!=null&&uri.userInfo==null&&uri.fragment==null;Song(id,o.optString("name","Аудио"),o.optString("artist_name","Неизвестный исполнитель"),o.optString("album_name"),raw.takeIf{allowed},o.optString("license_ccurl"))}}
    fun search(client:String,query:String):List<Song>{require(client.matches(Regex("[a-zA-Z0-9_-]{3,128}"))){"Некорректный Client ID"};require(query.isNotBlank()&&query.length<=200);val url="https://api.jamendo.com/v3.0/tracks/?format=json&limit=30&audiodlformat=mp32&client_id="+URLEncoder.encode(client,"UTF-8")+"&search="+URLEncoder.encode(query.trim(),"UTF-8");val c=URI(url).toURL().openConnection() as HttpURLConnection;try{c.instanceFollowRedirects=false;c.connectTimeout=15000;c.readTimeout=15000;require(c.responseCode==200){"HTTP ${c.responseCode}"};val data=c.inputStream.use{input->val out=java.io.ByteArrayOutputStream();val buf=ByteArray(8192);while(true){val n=input.read(buf);if(n<0)break;require(out.size()+n<=2*1024*1024);out.write(buf,0,n)};out.toString("UTF-8")};return parse(data)}finally{c.disconnect()}}
}
