package app.remix.player

import java.io.*
import kotlin.math.*

/** Stereo-linked waveform-similarity overlap/add. Bounded memory, approximate pitch preservation. */
object TimeStretch {
    data class Plan(val speed:Double,val effectiveBpm:Double,val gridBpm:Double)
    fun plan(source:Double,target:Int):Plan {
        require(source.isFinite()&&source in 50.0..220.0&&target in 50..220)
        // Half/double-time interpretation avoids extreme changes to the singer.
        val base=listOf(source/2,source,source*2).filter{it in 50.0..220.0}.minByOrNull{abs(ln(target/it))}!!
        val speed=(target/base).coerceIn(.75,1.33)
        return Plan(speed,base*speed,base)
    }
    /** Split large ratios into safe WSOLA passes; equal ratios avoid one extreme pass. */
    fun stages(speed:Double):List<Double> {
        require(speed.isFinite()&&speed in .25..3.7)
        if(abs(speed-1.0)<1e-6)return emptyList()
        val count=ceil(if(speed<1)ln(speed)/ln(.75) else ln(speed)/ln(1.33)).toInt().coerceAtLeast(1)
        val stage=speed.pow(1.0/count).coerceIn(.75,1.33)
        return List(count){stage}
    }
    fun stagedFrames(frames:Long,speed:Double):Long=stages(speed).fold(frames){n,r->outputFrames(n,r)}
    fun outputFrames(frames:Long,speed:Double):Long {require(frames>0&&speed.isFinite()&&speed in .75..1.33);return (frames/speed).roundToLong().coerceAtLeast(1)}
    fun render(input:File,output:File,frames:Long,speed:Double,progress:(Int)->Unit={}) {
        require(input.canonicalFile!=output.canonicalFile&&input.length()==44+frames*4)
        val target=outputFrames(frames,speed)
        if(speed==1.0){try{input.inputStream().buffered().use{r->output.outputStream().buffered().use{w->val b=ByteArray(65536);while(true){check(!Thread.currentThread().isInterrupted);val n=r.read(b);if(n<0)break;w.write(b,0,n)}}};progress(100);return}catch(e:Throwable){output.delete();throw e}}
        val hop=882;val window=hop*2;val search=352
        val previous=ShortArray(window*2);val next=ShortArray(window*2);val scan=ShortArray((window+search*2)*2);val bytes=ByteArray(scan.size*2)
        try {RandomAccessFile(input,"r").use{r->output.outputStream().buffered(65536).use{w->
            StemCore.header(w,target)
            fun load(start:Long,n:Int,dst:ShortArray){dst.fill(0);val take=min(n.toLong(),frames-start).coerceAtLeast(0).toInt();if(take==0)return;r.seek(44+start*4);r.readFully(bytes,0,take*4);for(i in 0 until take*2)dst[i]=((bytes[i*2].toInt() and 255) or (bytes[i*2+1].toInt() shl 8)).toShort()}
            load(0,window,previous);var outPos=0L
            while(outPos<target){check(!Thread.currentThread().isInterrupted){"Отменено"};val count=min(hop.toLong(),target-outPos).toInt()
                if(outPos==0L){for(i in 0 until count*2)StemCore.writeShort(w,previous[i])}
                else {val expected=(outPos*speed).roundToLong().coerceIn(0, max(0,frames-window));val low=max(0,expected-search);val high=min(max(0,frames-window),expected+search);val range=(high-low).toInt();load(low,range+window,scan)
                    fun score(k:Int):Double{var xy=0.0;var xx=0.0;var yy=0.0;for(i in 0 until hop step 8){for(c in 0..1){val a=previous[(hop+i)*2+c].toDouble();val b=scan[(k+i)*2+c].toDouble();xy+=a*b;xx+=a*a;yy+=b*b}};return if(xx*yy<1.0) -abs(k-(expected-low))*.00001 else xy/sqrt(xx*yy)-abs(k-(expected-low))*.00002}
                    var best=(expected-low).toInt();var value=score(best);for(k in 0..range step 4){val v=score(k);if(v>value){best=k;value=v}};val coarse=best;for(k in max(0,coarse-3)..min(range,coarse+3)){val v=score(k);if(v>value){best=k;value=v}}
                    scan.copyInto(next,0,best*2,best*2+window*2)
                    for(i in 0 until count){val a=i.toDouble()/hop;for(c in 0..1){val x=previous[(hop+i)*2+c]*(1-a)+next[i*2+c]*a;StemCore.writeShort(w,x.roundToInt().coerceIn(-32768,32767).toShort())}};next.copyInto(previous)
                };outPos+=count;if(outPos/hop%50==0L)progress((outPos*100/target).toInt())
            }
        }};progress(100)}catch(e:Throwable){output.delete();throw e}
    }
    /** Retimes both LRC line and word markers, folding global offset into timestamps. */
    fun lyrics(raw:String,speed:Double):String {require(speed.isFinite()&&speed in .4..1.8);if(raw.isBlank()||speed==1.0)return raw
        val offsetTag=Regex("\\[offset:([+-]?\\d+)]",RegexOption.IGNORE_CASE);val offset=Lrc.offset(raw)
        val tags=Regex("(\\[|<)(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?(]|>)")
        return tags.replace(offsetTag.replace(raw,"")){m->val g=m.groupValues;if(g[3].toInt()>=60||(g[1]=="["&&g[5]!="]")||(g[1]=="<"&&g[5]!=">"))m.value else {val t=(Lrc.timestamp(g[2].toLong()*60000+g[3].toLong()*1000+g[4].padEnd(3,'0').toLong(),offset)/speed).roundToLong().coerceIn(0,Lrc.MAX_MS);"${g[1]}%02d:%02d.%03d${g[5]}".format(java.util.Locale.ROOT,t/60000,t/1000%60,t%1000)}}
    }
}
