package app.remix.player
import java.io.*
import kotlin.math.*
/** Offline two-layer mix with base timeline preserved. No invented beat matching. */
object AccompanimentMix {
    data class Settings(val offsetMs:Int=0,val baseGain:Float=1f,val backingGain:Float=.65f,val fadeMs:Int=20){init{require(offsetMs in -60000..60000&&baseGain in 0f..2f&&backingGain in 0f..2f&&fadeMs in 0..1000)}}
    fun render(base:File,backing:File,out:File,s:Settings,progress:(Int)->Unit={}):Long{
        require(base.isFile&&backing.isFile&&base.length()>0&&backing.length()>0&&base.length()%4==0L&&backing.length()%4==0L)
        require(out.canonicalFile!=base.canonicalFile&&out.canonicalFile!=backing.canonicalFile)
        val n=base.length()/4;val m=backing.length()/4;val shift=s.offsetMs*44100L/1000;val a=max(0L,shift);val b=min(n,shift+m);require(b>a){"Инструментал не пересекается с оригиналом"};val fade=min(s.fadeMs*44100L/1000,(b-a)/2);val norm=max(1f,s.baseGain+s.backingGain)
        require(n*4<=0xffffffffL-36&&out.absoluteFile.parentFile!!.usableSpace>44+n*4+1048576){"Недостаточно места"}
        try{base.inputStream().buffered(65536).use{x->FileInputStream(backing).use{f->f.channel.position((a-shift)*4);f.buffered(65536).use{y->out.outputStream().buffered(65536).use{w->StemCore.header(w,n);var i=0L;var last=-1;while(i<n){if(i%8192==0L){check(!Thread.currentThread().isInterrupted);val p=(100*i/n).toInt();if(p!=last){last=p;progress(p)}};val active=i in a until b;val env=if(!active)0f else if(fade==0L)1f else minOf(1f,(i-a).toFloat()/fade,(b-1-i).toFloat()/fade).coerceAtLeast(0f);repeat(2){val v=StemCore.readShort(x)/32768f;val u=if(active)StemCore.readShort(y)/32768f else 0f;StemCore.writeShort(w,StemCore.pcm((v*s.baseGain+u*s.backingGain*env)/norm))};i++}}}}};progress(100);return n}catch(e:Throwable){out.delete();throw e}
    }
}
