package app.remix.player
import android.content.Context
import android.media.MediaMetadataRetriever
import java.io.File
import java.net.URI
import java.net.HttpURLConnection
import java.util.UUID

/** Explicit user-authorized HTTPS audio downloads. No streaming service extraction. */
object MusicDownload {
    fun fetch(context:Context,url:String,progress:(Int)->Unit):File{
        val uri=URI(url.trim());require(uri.scheme.equals("https",true)&&uri.host!=null&&uri.userInfo==null&&uri.fragment==null){"Нужна прямая HTTPS-ссылка на аудио"}
        val dir=File(context.filesDir,"downloads").apply{mkdirs()};val file=File(dir,UUID.randomUUID().toString()+".part");val conn=uri.toURL().openConnection() as HttpURLConnection
        try{conn.instanceFollowRedirects=false;conn.connectTimeout=15000;conn.readTimeout=15000;conn.setRequestProperty("Accept","audio/*, application/octet-stream");require(conn.responseCode==200){"HTTP ${conn.responseCode}; редиректы не поддерживаются"};val type=conn.contentType?.substringBefore(';')?.lowercase()?:"";require(type.startsWith("audio/")||type in setOf("application/octet-stream","application/ogg")){"Ссылка не ведёт на аудиофайл"};val max=200L*1024*1024;val length=conn.contentLengthLong;require(length<=max);var total=0L;var last=-1
            conn.inputStream.buffered().use{input->file.outputStream().buffered().use{out->val b=ByteArray(65536);while(true){check(!Thread.currentThread().isInterrupted);val n=input.read(b);if(n<0)break;total+=n;require(total<=max&&dir.usableSpace>8L*1024*1024){"Размер или свободное место"};out.write(b,0,n);if(length>0){val p=(100*total/length).toInt().coerceIn(0,100);if(p!=last){last=p;progress(p)}}}}};require(total>0&&(length<0||total==length)){"Неполная загрузка"}
            val r=MediaMetadataRetriever();try{r.setDataSource(file.absolutePath);require((r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?:0)>0&&r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)=="yes"){"Аудиофайл не распознан"}}finally{r.release()}
            val ext=when(type){"audio/mpeg"->"mp3";"audio/flac","audio/x-flac"->"flac";"audio/wav","audio/x-wav"->"wav";"audio/ogg","application/ogg","audio/opus"->"ogg";"audio/mp4","audio/aac"->"m4a";else->"audio"};val done=File(dir,file.nameWithoutExtension+".$ext");check(file.renameTo(done));return done
        }finally{conn.disconnect();file.delete()}
    }
}
