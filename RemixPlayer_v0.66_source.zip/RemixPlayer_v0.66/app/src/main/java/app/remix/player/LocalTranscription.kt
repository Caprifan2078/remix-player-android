package app.remix.player

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File

/** Experimental speech-to-text on local audio. Singing is not a validated Vosk use case. */
object LocalTranscription {
    private fun prefs(c:Context)=c.getSharedPreferences("speech_model",Context.MODE_PRIVATE)
    fun model(c:Context):File?=prefs(c).getString("path",null)?.let(::File)?.takeIf{it.isDirectory}
    fun install(c:Context,uri:Uri){val input=c.contentResolver.openInputStream(uri)?:error("ZIP не открывается");input.use{installStream(c,it)}}
    fun installCatalog(c:Context,entry:ModelCatalog.Entry,progress:(Int)->Unit){require(entry.kind==ModelCatalog.Kind.SPEECH);val tmp=File(c.cacheDir,"speech-"+java.util.UUID.randomUUID()+".zip");try{CatalogDownload.fetch(entry,tmp,progress);tmp.inputStream().use{installStream(c,it)}}finally{tmp.delete()}}
    private fun installStream(c:Context,input:java.io.InputStream){val dir=File(c.filesDir,"speech-"+java.util.UUID.randomUUID());try{val candidate=SubtitleCore.unpack(input,dir);Model(candidate.absolutePath).use{};val old=model(c);check(prefs(c).edit().putString("path",candidate.absolutePath).commit());old?.let{val parent=if(it.name.startsWith("speech-"))it else it.parentFile;if(parent!=null&&parent.parentFile==c.filesDir&&parent.name.startsWith("speech-"))parent.deleteRecursively()}}catch(e:Throwable){dir.deleteRecursively();throw e}}
    fun remove(c:Context){val old=model(c)?:return;val parent=if(old.name.startsWith("speech-"))old else old.parentFile;require(parent!=null&&parent.parentFile==c.filesDir&&parent.name.startsWith("speech-"));check(prefs(c).edit().remove("path").commit());check(parent.deleteRecursively()){"Не удалось полностью удалить файлы модели"}}
    fun transcribe(c:Context,uri:Uri,stem:StemEngine.Bundle?,status:(String)->Unit):String {
        val model=model(c)?:error("Импортируйте модель Vosk");val tmp=if(stem==null)File.createTempFile("speech-",".pcm",c.cacheDir)else null;var prepared:File?=null
        try{if(tmp!=null){status("Декодирование аудио…");StemEngine.decode(c,uri,tmp)};val source=tmp?:File(stem!!.dir,"3.pcm");val words=mutableListOf<SubtitleCore.Word>();status("Подготовка вокала…")
            val mono=File.createTempFile("speech16-",".pcm",c.cacheDir);prepared=mono
            val measure=VocalConditioning.Measure();val pre=VocalConditioning.Filter()
            mono.outputStream().buffered(65536).use{out->source.inputStream().buffered(65536).use{input->SubtitleCore.mono16k(input,adaptive=true){val s=pre.sample(it);measure.add(s);StemCore.writeShort(out,s)}}}
            val gain=measure.gain();status("Локальное распознавание…")
            Model(model.absolutePath).use{m->Recognizer(m,16000f).use{r->r.setWords(true);fun collect(json:String){val a=JSONObject(json).optJSONArray("result")?:return;for(i in 0 until a.length()){val w=a.getJSONObject(i);words.add(SubtitleCore.Word(w.getString("word"),w.getDouble("start"),w.getDouble("end"),w.optDouble("conf",0.0)))}}
                val block=ShortArray(4000);var used=0;var total=0L;mono.inputStream().buffered(65536).use{input->repeat((mono.length()/2).toInt()){block[used++]=kotlin.math.round(StemCore.readShort(input)*gain).toInt().coerceIn(-32768,32767).toShort();if(used==block.size){check(!Thread.currentThread().isInterrupted);if(r.acceptWaveForm(block,used))collect(r.result);used=0;total+=block.size;if(total%160000==0L)status("Распознано ${total/16000} с")}}};if(used>0&&r.acceptWaveForm(block,used))collect(r.result);collect(r.finalResult)}}
            return SubtitleCore.enhanced(words).also{require(it.isNotBlank()){"Не удалось уверенно распознать слова"}}
        }finally{tmp?.delete();prepared?.delete()}
    }
}
