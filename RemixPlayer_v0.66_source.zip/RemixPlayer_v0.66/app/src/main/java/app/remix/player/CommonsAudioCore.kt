package app.remix.player

import java.net.URI
import java.net.URLEncoder
import java.util.Locale

/** Strict allowlist: downloadable audio from Commons with explicit CC0 or public-domain metadata. */
object CommonsAudioCore {
    const val MAX_BYTES=200L*1024*1024
    data class Recording(val title:String,val artist:String,val source:String,val url:String,val license:String,val bytes:Long)
    fun query(term:String):String {
        require(term.isNotBlank()&&term.length<=200)
        // Quotes and control characters cannot inject search operators into the user phrase.
        val clean=term.replace(Regex("[\\p{Cntrl}\\\"\\\\]")," ").trim()
        require(clean.isNotBlank())
        val q=URLEncoder.encode("\"$clean\" filetype:audio", "UTF-8")
        return "https://commons.wikimedia.org/w/api.php?action=query&format=json&formatversion=2&generator=search&gsrnamespace=6&gsrlimit=40&gsrsearch=$q&prop=imageinfo&iiprop=url%7Cmime%7Csize%7Cmediatype%7Cextmetadata&iiextmetadatafilter=LicenseShortName%7CLicenseUrl%7CArtist%7CRestrictions%7CUsageTerms"
    }
    private fun strict(raw:String,host:String,path:String):Boolean=runCatching {
        val u=URI(raw);u.scheme=="https"&&u.host==host&&u.port in listOf(-1,443)&&u.userInfo==null&&u.fragment==null&&u.rawQuery==null&&u.path.startsWith(path)&&u.normalize().path==u.path
    }.getOrDefault(false)
    fun recording(title:String,artist:String,source:String,url:String,mime:String,media:String,license:String,licenseUrl:String,restrictions:String,bytes:Long):Recording? {
        if(title.isBlank()||title.length>512||bytes !in 1..MAX_BYTES||media!="AUDIO"||mime.lowercase(Locale.ROOT) !in setOf("audio/mpeg","audio/ogg","application/ogg","audio/flac","audio/x-flac","audio/wav","audio/x-wav","audio/opus"))return null
        if(!strict(source,"commons.wikimedia.org","/wiki/File:")||!strict(url,"upload.wikimedia.org","/wikipedia/commons/"))return null
        if(restrictions.isNotBlank())return null
        val l=license.trim().lowercase(Locale.ROOT)
        val cc0=l=="cc0"||l=="cc0 1.0"
        val pd=l=="public domain"
        val correct=if(cc0)licenseUrl.trimEnd('/')=="https://creativecommons.org/publicdomain/zero/1.0" else pd&&(licenseUrl.trimEnd('/') in setOf("https://creativecommons.org/publicdomain/mark/1.0","https://commons.wikimedia.org/wiki/Help:Public_domain"))
        if(!correct)return null
        return Recording(title.removePrefix("File:").substringBeforeLast('.'),artist.take(500).ifBlank{"Неизвестный автор"},source,url,if(cc0)"CC0 1.0" else "Public domain",bytes)
    }
}
