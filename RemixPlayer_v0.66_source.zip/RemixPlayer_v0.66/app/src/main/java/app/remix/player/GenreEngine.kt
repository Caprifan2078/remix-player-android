package app.remix.player
import kotlin.math.*
import java.io.*

/** Original synthesized percussion; no third-party loops. Patterns operate at detected source tempo. */
object GenreEngine {
    data class Style(val name:String,val target:Int,val kick:IntArray,val snare:IntArray,val hat:IntArray,val drive:Float,val oldDrums:Float,val bass:Float)
    val styles=listOf(
        Style("House",124,intArrayOf(0,4,8,12),intArrayOf(4,12),intArrayOf(2,6,10,14),.08f,.10f,1.1f),
        Style("Hardstyle",150,intArrayOf(0,4,8,12),intArrayOf(4,12),intArrayOf(2,6,10,14),.85f,0f,1.15f),
        Style("Jumpstyle",145,intArrayOf(0,4,8,10,12),intArrayOf(4,12),intArrayOf(2,6,14),.55f,.05f,1.1f),
        Style("Hardtekk",160,intArrayOf(0,4,8,12,14),intArrayOf(4,12),intArrayOf(2,6,10,14,15),.95f,0f,1.05f),
        Style("Drift Phonk",140,intArrayOf(0,6,10,14),intArrayOf(4,12),intArrayOf(0,2,4,6,8,10,12,14,15),.65f,.05f,1.3f),
        Style("Brazilian Funk",130,intArrayOf(0,3,6,10,13),intArrayOf(4,7,12,15),intArrayOf(2,6,10,14),.45f,.05f,1.2f),
        Style("Montagem",135,intArrayOf(0,3,6,8,11,14),intArrayOf(4,7,12,15),intArrayOf(2,5,10,13,15),.7f,0f,1.25f),
        Style("Jersey Club",145,intArrayOf(0,4,8,10,12,14),intArrayOf(4,12),intArrayOf(2,6,10,14),.22f,.05f,1.05f),
        Style("Drum & Bass",174,intArrayOf(0,10),intArrayOf(4,12),intArrayOf(0,2,3,6,8,10,14,15),.30f,.1f,1.25f),
        Style("Breakcore",180,intArrayOf(0,3,7,10,14),intArrayOf(4,6,12,15),intArrayOf(1,2,5,8,9,11,13,15),.40f,.08f,1.05f),
        Style("Afro House",122,intArrayOf(0,4,8,12),intArrayOf(3,7,11,14),intArrayOf(2,5,6,10,13,14),.05f,.12f,1f),
        Style("Lo-Fi",85,intArrayOf(0,7,10),intArrayOf(4,12),intArrayOf(2,6,10,14),.04f,.12f,.85f),
        Style("Hard Techno",155,intArrayOf(0,4,8,12),intArrayOf(4,12,15),intArrayOf(2,6,10,14,15),.78f,0f,1.1f),
        Style("Speed Garage",135,intArrayOf(0,6,10),intArrayOf(4,12),intArrayOf(2,6,9,14,15),.2f,.05f,1.2f),
        Style("Amapiano",112,intArrayOf(0,7,10,14),intArrayOf(4,12),intArrayOf(2,5,6,10,13,15),.1f,.12f,1.15f),
        Style("Hypertechno",150,intArrayOf(0,4,8,12),intArrayOf(4,12),intArrayOf(1,2,6,9,10,14),.45f,.02f,1.12f),
        Style("Brazilian Phonk",140,intArrayOf(0,3,6,8,10,13),intArrayOf(4,7,12,15),intArrayOf(1,3,5,7,9,11,13,15),.82f,0f,1.15f),
        Style("Automotivo",135,intArrayOf(0,2,5,8,11,14),intArrayOf(3,7,11,15),intArrayOf(2,6,10,14),.64f,0f,1.2f),
        Style("Krushfunk",145,intArrayOf(0,3,7,9,12,15),intArrayOf(4,6,12,14),intArrayOf(1,4,7,10,13,15),.91f,0f,1.05f),
        Style("Rawstyle",155,intArrayOf(0,4,8,12,15),intArrayOf(4,12),intArrayOf(2,6,10,13,14),.98f,0f,1f),
        Style("Frenchcore",200,intArrayOf(0,2,4,6,8,10,12,14),intArrayOf(4,12),intArrayOf(1,5,9,13),.95f,0f,1f),
        Style("Hardcore",180,intArrayOf(0,4,8,10,12,14),intArrayOf(4,12),intArrayOf(2,6,10,14),.9f,0f,1.08f),
        Style("Memphis Phonk",100,intArrayOf(0,7,8,11),intArrayOf(4,12),intArrayOf(0,2,6,7,8,10,14,15),.42f,.08f,1.15f),
        Style("House Phonk",128,intArrayOf(0,4,8,12),intArrayOf(4,12),intArrayOf(2,6,10,12,14),.52f,.05f,1.2f),
        Style("Hyperflip",160,intArrayOf(0,3,5,8,11,13,15),intArrayOf(4,7,12),intArrayOf(1,6,9,14,15),.62f,.02f,1.1f),
        Style("Slap House",124,intArrayOf(0,4,8,12),intArrayOf(4,12),intArrayOf(2,6,10,14,15),.17f,.08f,1.25f),
        Style("UK Garage",130,intArrayOf(0,6,9,14),intArrayOf(4,12),intArrayOf(2,3,7,10,11,15),.16f,.08f,1.15f),
        Style("Trap",140,intArrayOf(0,6,11),intArrayOf(8),intArrayOf(0,2,4,6,7,8,10,12,14,15),.28f,.06f,1.25f),
        Style("Dubstep",140,intArrayOf(0,6,10,14),intArrayOf(8,15),intArrayOf(2,5,10,13),.7f,.03f,1.25f),
        Style("Synthwave",100,intArrayOf(0,4,8,10,12),intArrayOf(4,12),intArrayOf(0,2,4,6,8,10,12,14),.12f,.12f,1.05f))
    class Beat(private val style:Style,bpm:Double,phase:Double,private val rate:Int=44100,private val grid:AdaptiveGroove=AdaptiveGroove(bpm,phase,rate=rate)){
        init{require(bpm in 50.0..220.0&&phase.isFinite()&&rate>0)}
        private val palette=DrumPalette.voice(style);private var last=Long.MIN_VALUE;private var accent=1.0
        private var kickAt=Long.MIN_VALUE;private var previousKickAt=Long.MIN_VALUE;private var snareAt=Long.MIN_VALUE;private var previousSnareAt=Long.MIN_VALUE;private var hatAt=Long.MIN_VALUE;private var previousHatAt=Long.MIN_VALUE;private var rng=1234567
        // Precompute deterministic voice curves once per render; noise still advances per frame.
        private val kicks=DoubleArray(ceil(.36*rate).toInt()){i->val age=i.toDouble()/rate;val wave=sin(2*PI*(palette.kickHz*age+palette.sweepHz*.025*(1-exp(-age/.025))));tanh(wave*exp(-age/palette.decay)*(1+style.drive*9))*.52*minOf(1.0,age/.001,(.36-age)/.012)}
        private val kickLevels=FloatArray(kicks.size){i->exp(-i.toDouble()/rate/.065).toFloat()}
        private fun taper(age:Double,end:Double)=minOf(1.0,age/.002,(end-age)/.008).coerceAtLeast(0.0)
        private val snareNoise=DoubleArray(ceil(.16*rate).toInt()){i->val age=i.toDouble()/rate;exp(-age/.045)*.22*taper(age,.16)}
        private val snareTone=DoubleArray(snareNoise.size){i->sin(2*PI*palette.snareHz*i/rate)}
        private val hats=DoubleArray(ceil(.07*rate).toInt()){i->val age=i.toDouble()/rate;sin(2*PI*palette.hatHz*age)*exp(-age/.013)*.12*taper(age,.07)}
        private fun index(frame:Long,at:Long,size:Int):Int=if(at==Long.MIN_VALUE||frame<at||frame-at>=size) -1 else (frame-at).toInt()
        private fun value(v:DoubleArray,i:Int)=if(i<0)0.0 else v[i]
        private fun snare(i:Int,n:Double)=if(i<0)0.0 else (.75*n+.25*snareTone[i])*snareNoise[i]
        private fun blend(frame:Long,at:Long,seconds:Double)=if(at==Long.MIN_VALUE)1.0 else ((frame-at)/(seconds*rate)).coerceIn(0.0,1.0)
        private fun noise():Double{rng=rng xor (rng shl 13);rng=rng xor (rng ushr 17);rng=rng xor (rng shl 5);return rng/2147483648.0}
        var kickEnvelope=0f;private set
        fun sample(frame:Long):Float{val position=grid.position(frame);val step=floor(DrumPalette.swing(position,palette.swing)).toLong();if(step!=last){last=step;val i=Math.floorMod(step,16L).toInt();if(position>=0){if(i in style.kick){previousKickAt=kickAt;kickAt=frame};if(i in style.snare||(DrumPalette.fill(step,palette)&&i==15)){previousSnareAt=snareAt;snareAt=frame};if(i in style.hat||DrumPalette.fill(step,palette)){previousHatAt=hatAt;hatAt=frame};accent=if(i%4==0)1.0 else .72}}
            val k=index(frame,kickAt,kicks.size);val s=index(frame,snareAt,snareNoise.size);val h=index(frame,hatAt,hats.size)
            kickEnvelope=if(k<0)0f else kickLevels[k]
            val kb=blend(frame,kickAt,.004);val sb=blend(frame,snareAt,.004);val hb=blend(frame,hatAt,.004)
            var y=value(kicks,k)*kb
            if(kb<1)y+=value(kicks,index(frame,previousKickAt,kicks.size))*(1-kb)
            val n=noise();y+=snare(s,n)*sb;if(sb<1)y+=snare(index(frame,previousSnareAt,snareNoise.size),n)*(1-sb)
            y+=n*accent*(value(hats,h)*hb+if(hb<1)value(hats,index(frame,previousHatAt,hats.size))*(1-hb) else 0.0)
            return y.toFloat()}
    }
    /** Preserve source timing and original bass harmony; replace percussion. */
    private fun sum(samples:ShortArray,beat:Float,style:Style,newBass:Float,sourceDrumScale:Float,controls:GenreMix):Float{require(samples.size in 4..6);var sum=samples[0]/32768f*style.oldDrums*sourceDrumScale*controls.oldDrums*controls.source+samples[1]/32768f*style.bass*controls.source;for(i in 2 until samples.size)sum+=samples[i]/32768f*(if(i==3)controls.vocals else controls.source);return sum*.67f+beat*.67f+newBass}
    fun mix(samples:ShortArray,beat:Float,style:Style,newBass:Float=0f,sourceDrumScale:Float=1f,controls:GenreMix=GenreMix()):Float{val y=sum(samples,beat,style,newBass,sourceDrumScale,controls);return if(abs(y)<=.85f)y else sign(y)*(.85f+.15f*tanh((abs(y)-.85f)/.15f))}
    fun render(dir:File,frames:Long,count:Int,out:File,style:Style,bpm:Double,phase:Double,harmonies:List<Harmony.Chord> = emptyList(),energy:List<Double> = emptyList(), grid:AdaptiveGroove=AdaptiveGroove(bpm,phase), controls:GenreMix=GenreMix(), sections:List<Arrangement.Section>?=null, progress:(Int)->Unit){require(frames>0&&count in listOf(4,6));val inputs=mutableListOf<InputStream>();try{repeat(count){inputs.add(File(dir,"$it.pcm").inputStream().buffered(65536))};val b=Beat(style,bpm,phase,grid=grid);val bass=Harmony.Bass(harmonies,bpm,phase,style.drive,style.kick,energy,grid=grid,swing=DrumPalette.voice(style).swing);val lead=LeadSynth(harmonies,bpm,phase,style,grid=grid);val samples=ShortArray(count);val right=ShortArray(count);val space=VocalSpace();val envelope=Arrangement.Envelope(Arrangement.aligned(energy,frames,grid,sections=sections));val sweep=Arrangement.Sweep();val dynamics=GenreDynamics();val kickSpace=KickSpace();out.outputStream().buffered(65536).use{w->StemCore.header(w,frames);for(f in 0 until frames){if(f%8192==0L){check(!Thread.currentThread().isInterrupted);progress((f*100/frames).toInt())};val levels=envelope.sample(f);val beat=(b.sample(f)*levels.drums+sweep.sample(levels.riser))*controls.drums;val kickGain=kickSpace.sample(b.kickEnvelope,levels.drums*controls.drums);val newBass=bass.sample(f)*levels.bass*controls.bass*kickGain+lead.sample(f,levels.drums)*controls.lead;for(i in samples.indices){samples[i]=StemCore.readShort(inputs[i]);right[i]=StemCore.readShort(inputs[i])};val duck=space.sample(samples[3],right[3],controls.vocals);dynamics.frame(sum(samples,beat*(.75f+.25f*duck),style,newBass*duck,levels.sourceDrums,controls),sum(right,beat*(.75f+.25f*duck),style,newBass*duck,levels.sourceDrums,controls));StemCore.writeShort(w,StemCore.pcm(dynamics.left));StemCore.writeShort(w,StemCore.pcm(dynamics.right))}};progress(100)}catch(e:Throwable){out.delete();throw e}finally{inputs.forEach{runCatching{it.close()}}}}
    /** Offline fallback: preserves the original stereo mix; cannot remove individual instruments. */
    fun renderFromMix(raw:File,out:File,style:Style,bpm:Double,phase:Double,harmonies:List<Harmony.Chord>,energy:List<Double>,grid:AdaptiveGroove=AdaptiveGroove(bpm,phase),controls:GenreMix=GenreMix(),sections:List<Arrangement.Section>?=null,progress:(Int)->Unit={}) {
        require(raw.canonicalFile!=out.canonicalFile&&raw.length()>0&&raw.length()%4==0L)
        val frames=raw.length()/4
        val beat=Beat(style,bpm,phase,grid=grid);val bass=Harmony.Bass(harmonies,bpm,phase,style.drive,style.kick,energy,grid=grid,swing=DrumPalette.voice(style).swing)
        val lead=LeadSynth(harmonies,bpm,phase,style,grid=grid);val envelope=Arrangement.Envelope(Arrangement.aligned(energy,frames,grid,sections=sections));val sweep=Arrangement.Sweep();val dynamics=GenreDynamics();val kickSpace=KickSpace()
        try {raw.inputStream().buffered(65536).use{r->out.outputStream().buffered(65536).use{w->
            StemCore.header(w,frames)
            for(f in 0 until frames){
                if(f%8192==0L){check(!Thread.currentThread().isInterrupted);progress((f*100/frames).toInt())}
                val levels=envelope.sample(f);val drums=(beat.sample(f)*levels.drums*.38f+sweep.sample(levels.riser)*.5f)*controls.drums;val kickGain=kickSpace.sample(beat.kickEnvelope,levels.drums*controls.drums);val b=drums+bass.sample(f)*levels.bass*.38f*controls.bass*kickGain+lead.sample(f,levels.drums)*controls.lead
                val l=StemCore.readShort(r)/32768f*.72f*controls.source+b;val rr=StemCore.readShort(r)/32768f*.72f*controls.source+b;dynamics.frame(l,rr);StemCore.writeShort(w,StemCore.pcm(dynamics.left));StemCore.writeShort(w,StemCore.pcm(dynamics.right))
            }
        }};progress(100)}catch(e:Throwable){out.delete();throw e}
    }
}
