package app.remix.player

/** One gain per stem, advanced once per stereo frame, never once per channel. */
class GainRamp(initial:FloatArray,private val frames:Int=441) {
    init{require(initial.size in listOf(4,6)&&frames>0&&initial.all{it.isFinite()&&it in 0f..1f})}
    val current=initial.copyOf();private val target=initial.copyOf();private val steps=FloatArray(initial.size);private var left=0
    fun set(values:FloatArray){require(values.size==current.size&&values.all{it.isFinite()&&it in 0f..1f});if(target.contentEquals(values))return;values.copyInto(target);for(i in current.indices)steps[i]=(target[i]-current[i])/frames;left=frames}
    fun advance(){if(left==0)return;if(--left==0)target.copyInto(current)else for(i in current.indices)current[i]=(current[i]+steps[i]).coerceIn(0f,1f)}
}
/** A late completion must not terminate a newer playback request. Main-thread confined. */
class MixerGeneration {
    private var sequence=0L
    var active:Long?=null;private set
    fun begin():Long{sequence++;active=sequence;return sequence}
    fun finish(token:Long):Boolean{if(active!=token)return false;active=null;return true}
    fun cancel(){active=null}
}
