package app.remix.player
import kotlin.math.*
/** Offline measured descriptors, not semantic mood or genre classification. */
object MusicalIntelligence {
    data class Profile(val pulse:Double?,val brightness:Double?,val contrast:Double?,val tempo:Double?,val labels:List<String>)
    fun profile(r:MusicAnalysis.Report):Profile {
        if(!r.duration.isFinite()||r.duration<8||!r.rms.isFinite()||r.rms<.005)return Profile(null,null,null,null,emptyList())
        val frames=r.featureFrames.filter{it.rms.isFinite()&&it.rms>=.005&&it.onset in 0.0..1.0}
        val pulse=frames.takeIf{it.size>=4}?.map{it.onset}?.average()
        val bright=r.spectrum?.takeIf{it.frames>=4&&it.centroidHz.isFinite()&&it.centroidHz>=0}?.let{(it.centroidHz/6000).coerceIn(0.0,1.0)}
        val e=r.energy.filter{it.isFinite()&&it>=0};val contrast=e.takeIf{it.size>=3&&it.average()>=.005}?.let{v->val m=v.average();(sqrt(v.sumOf{(it-m).pow(2)}/v.size)/m).coerceIn(0.0,2.0)}
        val tempo=r.tempo?.takeIf{it.confidence>=.30&&it.bpm in 50.0..220.0}?.bpm
        val labels=buildList {
            pulse?.let{add(when{it<.15->"Мало выраженных атак";it>.45->"Частые ритмические атаки";else->"Умеренные ритмические атаки"})}
            bright?.let{add(when{it<.15->"Тёмный спектр";it>.45->"Яркий спектр";else->"Средняя спектральная яркость"})}
            contrast?.let{add(if(it>.45)"Контрастная динамика" else "Ровная динамика")}
            tempo?.let{add("Оценка темпа ${it.roundToInt()} BPM")}
        }
        return Profile(pulse,bright,contrast,tempo,labels)
    }
}
/** Structure-aware envelopes. Source audio stays in order; no invented semantic labels. */
object SectionArrangement {
    fun plan(report:MusicAnalysis.Report,duration:Double=report.duration):List<Arrangement.Section> {
        val fallback=Arrangement.plan(report.energy,duration);val frames=report.featureFrames
        if(abs(report.duration-duration)>.1||frames.size<4||frames.first().start!=0.0||frames.zipWithNext().any{(a,b)->abs(b.start-a.start-2.0)>.05}||duration-frames.last().start>2.05)return fallback
        val sections=SectionMap.build(frames,duration)
        if(sections.isEmpty()||sections.first().start!=0.0||sections.last().end!=duration)return fallback
        val audible=frames.map{it.rms}.filter{it>=.005}.sorted();if(audible.size<4)return fallback
        val median=audible[audible.size/2]
        val parts=sections.map{section->
            val avg=frames.filter{it.start>=section.start&&it.start<section.end}.map{it.rms}.average()
            val p=when {
                !avg.isFinite()->Arrangement.Part.GROOVE
                avg<max(.005,median*.40)->Arrangement.Part.BREAK
                section.repeatGroup!=null&&avg>=median*.85->Arrangement.Part.DROP
                avg>=median*1.35->Arrangement.Part.DROP
                section.start==0.0&&section.end-section.start<=12&&avg<median*.85->Arrangement.Part.INTRO
                section.end==duration&&section.end-section.start<=12&&avg<median*.85->Arrangement.Part.OUTRO
                else->Arrangement.Part.GROOVE
            };Arrangement.Section(section.start,section.end,p)
        }
        val result=mutableListOf<Arrangement.Section>()
        for((i,s) in parts.withIndex()){
            val build=parts.getOrNull(i+1)?.part==Arrangement.Part.DROP&&s.part==Arrangement.Part.GROOVE&&s.end-s.start>=4.0
            if(build){result.add(s.copy(end=s.end-2));result.add(Arrangement.Section(s.end-2,s.end,Arrangement.Part.BUILD))}else result.add(s)
        };return result
    }
}
