package app.remix.player
import java.text.Normalizer
import java.util.Locale
/** Align reference lines to ASR starts; preserve complete existing word timings only for exact matches. */
object PhraseAlign {
    data class Result(val lrc:String,val matched:Int,val total:Int,val ambiguous:Boolean,val skipped:Int,val corrected:Int) {
        val complete get()=matched==total&&!ambiguous&&lrc.isNotBlank()
    }
    private data class Span(val start:Int,val end:Int,val corrected:Boolean)
    private val word=Regex("[\\p{L}\\p{N}][\\p{L}\\p{N}\\p{M}]*(?:['’][\\p{L}\\p{N}][\\p{L}\\p{N}\\p{M}]*)*")
    private fun tokens(s:String)=word.findAll(Normalizer.normalize(s,Normalizer.Form.NFKC).lowercase(Locale.ROOT).replace('’','\'')).map{it.value}.toList()
    fun align(raw:String,reference:String,allowCorrection:Boolean=false):Result {
        require(raw.length<=500_000&&reference.length<=100_000)
        val heard=Lrc.parse(raw);require(heard.size in 1..1000&&heard.zipWithNext().all{(a,b)->a.ms<b.ms}){"Нужны однозначные метки фраз"}
        val parsed=heard.map(WordLyrics::parse)
        require(parsed.none{it.text.any{c->c in "<>"}}){"Некорректные метки слов"}
        val times=parsed.mapIndexed{i,line->
            val expected=tokens(line.text);val marked=line.words.map{tokens(line.text.substring(it.start,it.end))}
            val next=heard.getOrNull(i+1)?.ms?:Long.MAX_VALUE
            if(expected.isNotEmpty()&&marked.all{it.size==1}&&marked.flatten()==expected&&line.words.zipWithNext().all{(a,b)->a.ms<b.ms}&&line.words.all{it.ms>=heard[i].ms&&it.ms<next})line.words.map{it.ms} else emptyList()
        }
        val lines=reference.lines().map{it.trim()}.filter{it.isNotBlank()}
        require(lines.size in 1..1000&&lines.all{it.length<=1000&&it.none{c->c in "[]<>"||c.isISOControl()}}){"Вставьте обычный текст по строкам"}
        val wanted=lines.map(::tokens);require(wanted.all{it.size in 1..100}){"Некорректная строка текста"}
        val spans=ArrayList<Pair<Span,List<String>>>()
        for(i in heard.indices){var words=emptyList<String>();for(j in i..minOf(i+2,heard.lastIndex)){
            if(j>i&&(heard[j].ms-heard[j-1].ms>7000||heard[j].ms-heard[i].ms>15000))break
            val part=tokens(parsed[j].text);if(part.isEmpty())break;words=words+part
            if(words.size>100)break;spans.add(Span(i,j,false) to words)
        }}
        val bySize=spans.groupBy{it.second.size}
        val candidates=wanted.map{line->
            check(!Thread.currentThread().isInterrupted)
            bySize[line.size].orEmpty().mapNotNull{(span,words)->
                val errors=line.indices.count{line[it]!=words[it]}
                when {errors==0->span;allowCorrection&&line.size>=5&&errors==1->span.copy(corrected=true);else->null}
            }
        }
        // Earliest-ending and latest-starting feasible paths bound ordered alignments.
        val forward=ArrayList<Span>();var after=-1
        for(c in candidates){val s=c.filter{it.start>after}.minWithOrNull(compareBy<Span>{it.end}.thenBy{it.start})?:break;forward.add(s);after=s.end}
        if(forward.size!=lines.size)return Result("",forward.size,lines.size,false,0,0)
        val backward=ArrayList<Span>();var before=heard.size
        for(c in candidates.asReversed()){val s=c.filter{it.end<before}.maxWithOrNull(compareBy<Span>{it.start}.thenBy{it.end})?:error("Несогласованное сопоставление");backward.add(s);before=s.start}
        backward.reverse()
        if(forward!=backward)return Result("",lines.size,lines.size,true,0,0)
        val lrc=forward.mapIndexed{i,s->
            val line=lines[i];val existing=(s.start..s.end).flatMap{times[it]};val matches=word.findAll(line).toList()
            val content=if(!s.corrected&&existing.size==wanted[i].size&&matches.size==existing.size&&existing.zipWithNext().all{(a,b)->a<b})buildString{
                var cursor=0;for((k,m) in matches.withIndex()){append(line.substring(cursor,m.range.first));append("<${SubtitleCore.stamp(existing[k])}>");cursor=m.range.first};append(line.substring(cursor))
            }else line
            "[${SubtitleCore.stamp(heard[s.start].ms)}]$content"
        }.joinToString("\n")
        return Result(lrc,lines.size,lines.size,false,heard.size-forward.sumOf{it.end-it.start+1},forward.count{it.corrected})
    }
}
