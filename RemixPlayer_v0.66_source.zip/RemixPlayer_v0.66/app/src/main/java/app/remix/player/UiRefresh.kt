package app.remix.player

/** UI cadence only; never controls playback or background jobs. */
object UiRefresh {
    fun delayMs(playing:Boolean, karaoke:Boolean, busy:Boolean):Long = when {
        playing && karaoke -> 100L
        playing -> 250L
        busy -> 250L
        else -> 500L
    }
    fun progress(position:Long,duration:Long):Int = if(duration<=0L) 0 else
        (position.coerceIn(0L,duration).toDouble()/duration*1000).toInt().coerceIn(0,1000)
}
