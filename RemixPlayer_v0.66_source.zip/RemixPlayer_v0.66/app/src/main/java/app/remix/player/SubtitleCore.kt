package app.remix.player

import java.io.*
import java.util.zip.ZipInputStream
import kotlin.math.*

/** No invented timestamps: only recognizer-provided word starts. */
object SubtitleCore {
    data class Word(val text:String,val start:Double,val end:Double,val confidence:Double)
    fun stamp(ms:Long):String = "%02d:%02d.%03d".format(java.util.Locale.ROOT,ms/60000,ms/1000%60,ms%1000)
    fun enhanced(words:List<Word>):String {
        val lines=mutableListOf<List<Word>>();val line=mutableListOf<Word>();var last=-1.0
        for(w in words){if(!w.start.isFinite()||!w.end.isFinite()||!w.confidence.isFinite()||w.start<last||w.start<0||w.end<w.start||w.end>900||w.confidence<0.45||w.text.isBlank()||w.text.any{it in "[]<>\r\n"})continue
            if(line.isNotEmpty()&&(line.size>=8||w.start-line.last().end>1.0||w.end-line.first().start>5.5)){lines.add(line.toList());line.clear()};line.add(w);last=w.start
        };if(line.isNotEmpty())lines.add(line.toList())
        return lines.joinToString("\n"){l->"[${stamp((l.first().start*1000).roundToLong())}]"+l.joinToString(" "){"<${stamp((it.start*1000).roundToLong())}>${it.text}"}}
    }
    /** Band-limited 44.1 kHz stereo to 16 kHz PCM, preserving sample count.
     * Adaptive downmix is optional: avoid destructive cancellation in the ASR input. */
    fun mono16k(input:InputStream,adaptive:Boolean=false,emit:(Short)->Unit){
        val rs=StemCore.Resampler(44100,16000){l,_->emit(StemCore.pcm(l))}
        fun sample(x:Double){val f=x.toFloat();rs.frame(f,f)}
        val mono=if(adaptive)AnalysisMono(::sample) else null
        var frames=0L
        while(true){val lo=input.read();if(lo<0)break;val hi=input.read();if(hi<0)throw EOFException();val l=(lo or (hi shl 8)).toShort();val r=StemCore.readShort(input)
            if(mono!=null)mono.frame(l/32768.0,r/32768.0) else sample((l.toInt()+r.toInt())/65536.0)
            if(++frames%8192==0L)check(!Thread.currentThread().isInterrupted)
        }
        mono?.finish();rs.finish()
    }
    /** Extract a user-provided model into a new private directory, with size/entry limits. */
    fun unpack(input:InputStream,dir:File,limit:Long=1024L*1024*1024):File {
        require(dir.mkdir());val root=dir.canonicalFile;var total=0L;var entries=0
        try{ZipInputStream(input).use{z->while(true){val e=z.nextEntry?:break;require(++entries<=10000);require(!e.name.contains('\\')&&!e.name.startsWith('/'));val file=File(root,e.name).canonicalFile;require(file.path.startsWith(root.path+File.separator)){"Недопустимый путь в ZIP"};if(e.isDirectory){require(file.isDirectory||file.mkdirs())}else{file.parentFile?.mkdirs();require(!file.exists());file.outputStream().buffered().use{out->val b=ByteArray(65536);while(true){check(!Thread.currentThread().isInterrupted);val n=z.read(b);if(n<0)break;total+=n;require(total<=limit){"Модель слишком большая"};out.write(b,0,n)}}};z.closeEntry()}}
            val candidates=(listOf(root)+root.listFiles().orEmpty().filter{it.isDirectory}).filter{File(it,"am/final.mdl").isFile&&File(it,"conf/model.conf").isFile};require(candidates.size==1){"ZIP не содержит одну модель Vosk"};return candidates.single()
        }catch(e:Throwable){dir.deleteRecursively();throw e}
    }
}
