package app.remix.player

/** A persisted queue is a list of exact versions, not a new selection from the library. */
object QueueSnapshot {
    const val LIMIT=300
    data class Saved(val ids:List<String>,val index:Int,val position:Long,val duration:Long,val shuffle:Boolean,val repeat:Int)
    data class Restored<T>(val items:List<T>,val index:Int,val position:Long,val shuffle:Boolean,val repeat:Int)
    fun <T> restore(saved:Saved,lookup:(String)->T?):Restored<T>? {
        if(saved.ids.isEmpty()||saved.ids.size>LIMIT||saved.index !in saved.ids.indices)return null
        val items=ArrayList<T>();var selected=-1;var next=-1
        saved.ids.forEachIndexed{i,id->
            if(id.isBlank()||id.length>8192)return@forEachIndexed
            val item=lookup(id)?:return@forEachIndexed
            if(i==saved.index)selected=items.size
            if(i>saved.index&&next<0)next=items.size
            items.add(item)
        }
        if(items.isEmpty())return null
        val index=if(selected>=0)selected else if(next>=0)next else items.lastIndex
        val pos=if(selected>=0)PlaybackBookmark.position(saved.position,saved.duration)else 0L
        return Restored(items,index,pos,saved.shuffle,saved.repeat.coerceIn(0,2))
    }
}
