package app.remix.player
import java.io.File

/** Conservative cleanup: only regular, old, unreferenced files inside the app's mixes folder or a completed effect batch. */
object StorageCore {
    data class Candidate(val name:String,val bytes:Long,val modified:Long)
    const val MIN_AGE=24L*60*60*1000
    fun candidates(dir:File,protectedNames:Set<String>,now:Long):List<Candidate>{
        val root=dir.canonicalFile;if(!root.isDirectory)return emptyList()
        val files=root.listFiles().orEmpty().flatMap{f->
            if(f.isDirectory&&f.canonicalFile==f.absoluteFile&&f.name.matches(Regex("batch-[0-9a-f-]{36}"))&&!File(f,"source.sha256").exists()&&f.name !in protectedNames)
                f.listFiles().orEmpty().filter{it.name.matches(Regex("version-[0-9]{1,2}\\.wav"))}
            else listOf(f)
        }
        return files.mapNotNull{f->val name=f.relativeTo(root).invariantSeparatorsPath;val time=f.lastModified();if(!f.isFile||f.canonicalFile!=f.absoluteFile||!name.endsWith(".wav",true)||name in protectedNames||time<=0||now-time<MIN_AGE)null else Candidate(name,f.length(),time)}.sortedByDescending{it.bytes}
    }
    fun delete(dir:File,approved:List<Candidate>,protectedNames:Set<String>,now:Long):Pair<Int,Long>{
        val current=candidates(dir,protectedNames,now).associateBy{it.name};var count=0;var bytes=0L
        for(c in approved.distinctBy{it.name}){check(!Thread.currentThread().isInterrupted);if(current[c.name]!=c)continue;val f=File(dir,c.name);if(f.delete()){count++;bytes+=c.bytes}}
        return count to bytes
    }
}
