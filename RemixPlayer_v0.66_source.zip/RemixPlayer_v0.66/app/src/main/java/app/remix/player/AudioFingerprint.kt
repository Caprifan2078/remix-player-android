package app.remix.player
import kotlin.math.*
/** Conservative local spectral sequence comparison; never auto-merges. */
object AudioFingerprint {
    const val RATE=8000
    const val MAX_SECONDS=32
    private const val N=2048
    private const val HOP=2000
    private const val BANDS=60
    private val hann=DoubleArray(N){.5-.5*cos(2*PI*it/(N-1))}
    data class Print(val frames:List<FloatArray>)
    data class Match(val score:Double,val speed:Double,val pitchSemitones:Int,val offsetSeconds:Double)
    fun make(pcm:FloatArray):Print {
        require(pcm.size<=RATE*MAX_SECONDS && pcm.all{it.isFinite()})
        val rows=ArrayList<FloatArray>();val re=DoubleArray(N);val im=DoubleArray(N)
        for(start in 0..(pcm.size-N) step HOP){
            check(!Thread.currentThread().isInterrupted)
            var energy=0.0;for(i in 0 until N){val x=pcm[start+i].toDouble();energy+=x*x;re[i]=x*hann[i];im[i]=0.0}
            val bands=FloatArray(BANDS)
            if(energy/N>1e-6){fft(re,im);val mag=DoubleArray(N/2){hypot(re[it],im[it])};val peak=mag.maxOrNull()?:0.0
                for(i in 2 until N/2-1){val a=mag[i-1];val b=mag[i];val c=mag[i+1];if(b<=a||b<c||b<peak*.035)continue
                    val delta=(.5*(a-c)/(a-2*b+c)).coerceIn(-.5,.5);val midi=69+12*ln((i+delta)*RATE/N/440)/ln(2.0)-42
                    val idx=floor(midi).toInt();val weight=sqrt(b/peak).toFloat();val frac=(midi-idx).toFloat()
                    if(idx in bands.indices)bands[idx]+=weight*(1-frac);if(idx+1 in bands.indices)bands[idx+1]+=weight*frac
                }
                val norm=sqrt(bands.sumOf{it.toDouble()*it});if(norm>0)for(i in bands.indices)bands[i]=(bands[i]/norm).toFloat()
            };rows.add(bands)
        };return Print(rows)
    }
    private fun dot(a:FloatArray,b:FloatArray,shift:Int):Double{var s=0.0;for(i in a.indices){val j=i+shift;if(j in b.indices)s+=a[i]*b[j]};return s.coerceIn(0.0,1.0)}
    private fun distinctive(p:Print):Boolean {
        if(p.frames.size<40)return false
        val audible=p.frames.filter{it.any{v->v>0f}};if(audible.size<p.frames.size*.8)return false
        val avg=FloatArray(BANDS);for(a in audible)for(i in avg.indices)avg[i]+=a[i]/audible.size
        return avg.sumOf{it.toDouble()*it}<.68
    }
    fun compare(a:Print,b:Print):Match? {
        if(!distinctive(a)||!distinctive(b))return null
        var best:Match?=null
        for(step in 14..28){val speed=step/20.0;val pitch=(12*ln(speed)/ln(2.0)).roundToInt()
            for(shift in setOf(0,pitch))for(offset in -16..16){
                check(!Thread.currentThread().isInterrupted)
                var score=0.0;var strong=0;var count=0
                for(i in a.frames.indices){val j=(i/speed).roundToInt()+offset;if(j !in b.frames.indices)continue
                    val x=dot(a.frames[i],b.frames[j],shift);score+=x;count++;if(x>=.75)strong++}
                if(count<40||count<minOf(a.frames.size,(b.frames.size*speed).toInt())*.80)continue
                val mean=score/count;if(mean<.83||strong<count*.75)continue
                if(mean>(best?.score?:0.0))best=Match(mean,speed,shift,offset*HOP.toDouble()/RATE)
            }
        };return best
    }
    private fun fft(r:DoubleArray,i:DoubleArray){var j=0;for(k in 1 until N){var b=N shr 1;while(j and b!=0){j=j xor b;b=b shr 1};j=j xor b;if(k<j){val v=r[k];r[k]=r[j];r[j]=v}};var len=2;while(len<=N){val a=-2*PI/len;val cr=cos(a);val ci=sin(a);for(start in 0 until N step len){var wr=1.0;var wi=0.0;for(k in 0 until len/2){val p=start+k;val q=p+len/2;val x=r[q]*wr-i[q]*wi;val y=r[q]*wi+i[q]*wr;r[q]=r[p]-x;i[q]=i[p]-y;r[p]+=x;i[p]+=y;val next=wr*cr-wi*ci;wi=wr*ci+wi*cr;wr=next}};len*=2}}
}
