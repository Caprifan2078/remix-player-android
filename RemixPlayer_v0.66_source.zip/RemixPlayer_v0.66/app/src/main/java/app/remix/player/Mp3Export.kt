package app.remix.player
import java.io.*
object Mp3Export {
    val available:Boolean by lazy{runCatching{System.loadLibrary("remixmp3")}.isSuccess}
    private external fun open(bitrate:Int):Long
    private external fun encodeBlock(h:Long,pcm:ShortArray,frames:Int,out:ByteArray):Int
    private external fun finish(h:Long,out:ByteArray):Int
    private external fun close(h:Long)
    fun encode(input:InputStream,out:OutputStream,bitrate:Int=256){require(available){"MP3-кодировщик не включён в сборку"};require(bitrate in listOf(128,192,256,320));val h=ByteArray(44);DataInputStream(input).readFully(h);fun tag(i:Int,s:String)=h.copyOfRange(i,i+s.length).contentEquals(s.toByteArray(Charsets.US_ASCII))
        fun le(i:Int,n:Int):Long{var v=0L;for(k in 0 until n)v=v or ((h[i+k].toLong() and 255) shl (8*k));return v}
        require(tag(0,"RIFF")&&tag(8,"WAVEfmt ")&&tag(36,"data")&&le(16,4)==16L&&le(20,2)==1L&&le(22,2)==2L&&le(24,4)==44100L&&le(34,2)==16L){"Нужен PCM WAV 44.1 кГц"};val size=le(40,4);require(size>0&&size%4==0L&&le(4,4)==size+36)
        val handle=open(bitrate);check(handle!=0L){"Не удалось запустить MP3-кодировщик"};try{val pcm=ShortArray(8192*2);val buf=ByteArray(18000);var remain=size/4;while(remain>0){check(!Thread.currentThread().isInterrupted);val frames=minOf(remain,8192).toInt();repeat(frames*2){pcm[it]=StemCore.readShort(input)};val n=encodeBlock(handle,pcm,frames,buf);check(n in 0..buf.size);out.write(buf,0,n);remain-=frames};val n=finish(handle,buf);check(n in 0..buf.size);out.write(buf,0,n);out.flush()}finally{close(handle)}
    }
}
