package app.remix.player
import java.io.*
import kotlin.math.*
/** Frontend for a user-supplied MERT emotion ONNX with the documented 24 kHz contract. */
object MoodCore {
    const val RATE=24000
    const val SAMPLES=RATE*15
    data class Result(val valence:Float,val arousal:Float,val consistent:Boolean=true){
        init{require(valence.isFinite()&&arousal.isFinite()&&valence in 0f..1f&&arousal in 0f..1f){"Некорректный выход модели"}}
        val label:String? get()=if(!consistent||abs(valence-.5f)<.07f||abs(arousal-.5f)<.07f)null else when {
            valence>=.5f&&arousal>=.5f->"Бодрое";valence<.5f&&arousal>=.5f->"Напряжённое";valence<.5f&&arousal<.5f->"Меланхоличное";else->"Спокойное"
        }
    }
    fun starts(frames:Long):List<Long>{
        require(frames>=44100L*3)
        val last=(frames-44100L*15).coerceAtLeast(0)
        return if(last<44100L*15)listOf(last/2) else listOf(0,last/2,last).distinct()
    }
    fun combine(results:List<Result>):Result{
        require(results.size in 1..3)
        val mean=Result(results.map{it.valence.toDouble()}.average().toFloat(),results.map{it.arousal.toDouble()}.average().toFloat())
        val label=mean.label
        val agreeing=results.count{label!=null&&it.label==label}
        return mean.copy(consistent=label!=null&&agreeing*3>=results.size*2)
    }
    fun input(raw:File,start:Long?=null):FloatArray{
        require(raw.isFile&&raw.length()%4==0L&&raw.length()>=44100*4L*3){"Нужно не менее 3 секунд звука"}
        val sourceCount=44100*15;val frames=raw.length()/4;val count=minOf(frames,sourceCount.toLong()).toInt()
        val out=AnalysisPcm.excerpt(raw,(start?:((frames-sourceCount).coerceAtLeast(0)/2)),count,sourceCount,RATE)
        val audible=(count.toLong()*RATE/44100).toInt().coerceAtLeast(1)
        var energy=0.0;for(i in 0 until audible)energy+=out[i].toDouble()*out[i]
        require(sqrt(energy/audible)>.003){"Фрагмент слишком тихий"};return out
    }
}
