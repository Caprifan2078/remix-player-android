package app.remix.player
import kotlin.math.*

/** Heuristic recommendations and repeated harmony detection, not a trained genre/mood classifier. */
object RemixAdvisor {
    data class Repetition(val first:Double,val second:Double,val duration:Double,val similarity:Double)
    enum class Goal { ORIGINAL, ENERGETIC, SOFT }
    data class Suggestion(val style:GenreEngine.Style,val score:Double,val speed:Double=1.0)
    fun recommend(report:MusicAnalysis.Report,manualBpm:Double?=null,goal:Goal=Goal.ORIGINAL):List<Suggestion>{
        val bpm=(manualBpm?:report.tempo?.bpm)?.takeIf{it.isFinite()&&it in 50.0..220.0}?:return emptyList()
        val profile=MusicalIntelligence.profile(report)
        val targetDrive=when(goal){Goal.ENERGETIC->.85;Goal.SOFT->.08;Goal.ORIGINAL->profile.pulse?.let{(.10+.85*it).coerceIn(.1,.8)}?:.35}
        val speedWeight=if(goal==Goal.ORIGINAL)1.5 else .7
        return GenreEngine.styles.map{style->val plan=TimeStretch.plan(bpm,style.target)
            val stretch=abs(ln(plan.speed));val miss=abs(ln(plan.effectiveBpm/style.target));val drive=abs(style.drive-targetDrive)
            Suggestion(style,-speedWeight*stretch-2.5*miss-(if(goal==Goal.ORIGINAL).35 else 1.0)*drive,plan.speed)
        }.sortedByDescending{it.score}.take(5)
    }
    fun repetitions(report:MusicAnalysis.Report):List<Repetition> = StructureCore.repetitions(report)
    fun energyLabel(report:MusicAnalysis.Report):String {val e=report.energy.filter{it.isFinite()&&it>=0};if(e.isEmpty())return "Недостаточно данных";val avg=e.average();return when{avg<.015->"Тихий сигнал";e.maxOrNull()!!>avg*1.6->"Контрастная динамика";else->"Ровная динамика"}}
}
