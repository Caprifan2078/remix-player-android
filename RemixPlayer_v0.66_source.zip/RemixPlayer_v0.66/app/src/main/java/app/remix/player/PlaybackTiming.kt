package app.remix.player
import kotlin.math.*
/** Non-overlapping fades for one player. Crossfade needs two synchronized audio sources. */
object PlaybackTiming {
    fun gain(position:Long,duration:Long,fadeMs:Long,fadeIn:Boolean,fadeOut:Boolean):Float {
        if(duration<=0||fadeMs<=0)return 1f
        val window=min(fadeMs,duration/2).coerceAtLeast(1);val pos=position.coerceIn(0,duration)
        val a=if(fadeIn)(pos.toDouble()/window).coerceIn(0.0,1.0)else 1.0
        val b=if(fadeOut)((duration-pos).toDouble()/window).coerceIn(0.0,1.0)else 1.0
        return sin(PI/2*min(a,b)).toFloat()
    }
    fun deadline(now:Long,minutes:Int):Long {require(now>=0&&minutes in 1..120);return Math.addExact(now,minutes*60000L)}
    fun remaining(now:Long,deadline:Long):Long=if(deadline<=0||now>=deadline)0 else deadline-now.coerceAtLeast(0)
}
object PlaybackOptions {
    @Volatile var fadeMs=0L
    @Volatile var overlapMs=0L
    @Volatile var sleepDeadline=0L
}
