package app.remix.player

object CustomPresetCore {
    val minimum=floatArrayOf(.4f,.5f,0f,0f,0f,0f,0f)
    val maximum=floatArrayOf(1.8f,1.5f,1.15f,1f,1f,1f,1f)
    fun values(p:Preset)=floatArrayOf(p.speed,p.pitch,p.bass,p.room,p.pan,p.drive,p.muffled)
    fun create(name:String,v:FloatArray):Preset {
        val n=name.trim();require(n.length in 1..80&&v.size==7&&v.indices.all{v[it].isFinite()&&v[it] in minimum[it]..maximum[it]}){"Некорректные настройки"}
        return Preset(n,v[0],v[1],v[2],v[3],v[4],v[5],v[6])
    }
    fun exportable(p:Preset)=runCatching{create(p.name,values(p))}.isSuccess
}
