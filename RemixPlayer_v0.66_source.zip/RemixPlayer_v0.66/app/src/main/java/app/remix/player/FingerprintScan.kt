package app.remix.player
import android.content.Context
import android.net.Uri
import java.io.File
object FingerprintScan {
    data class Candidate(val id:String,val match:AudioFingerprint.Match)
    data class Result(val matches:List<Candidate>,val failed:Int)
    private fun read(c:Context,id:String):AudioFingerprint.Print {
        val raw=File.createTempFile("fingerprint-",".pcm",c.cacheDir)
        try{StemEngine.decode(c,Uri.parse(id),raw);val frames=minOf(raw.length()/4,44100L*AudioFingerprint.MAX_SECONDS);val chunks=ArrayList<FloatArray>();var start=0L
            while(start<frames){val count=minOf(44100L*15,frames-start).toInt();chunks.add(AnalysisPcm.excerpt(raw,start,count,targetRate=AudioFingerprint.RATE));start+=count}
            val pcm=FloatArray(chunks.sumOf{it.size}.coerceAtMost(AudioFingerprint.RATE*AudioFingerprint.MAX_SECONDS));var at=0
            for(chunk in chunks){val n=minOf(chunk.size,pcm.size-at);chunk.copyInto(pcm,at,0,n);at+=n};return AudioFingerprint.make(pcm)
        }finally{raw.delete()}
    }
    fun scan(c:Context,source:String,ids:List<String>,status:(String)->Unit):Result{
        require(ids.size in 1..12&&ids.distinct().size==ids.size&&source !in ids)
        status("Отпечаток оригинала…");val ref=read(c,source);val matches=ArrayList<Candidate>();var failed=0
        for((i,id) in ids.withIndex()){check(!Thread.currentThread().isInterrupted);status("Сравнение ${i+1}/${ids.size}…");try{AudioFingerprint.compare(ref,read(c,id))?.let{matches.add(Candidate(id,it))}}catch(e:Exception){if(Thread.currentThread().isInterrupted||e is InterruptedException||e is java.util.concurrent.CancellationException)throw e;failed++}}
        return Result(matches.sortedByDescending{it.match.score},failed)
    }
}
