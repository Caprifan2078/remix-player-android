package app.remix.player
import kotlin.math.*

/** Measured spectral energy distribution; labels are descriptive, not a trained classifier. */
object SoundProfile {
    data class Features(val low:Double,val mid:Double,val high:Double,val centroidHz:Double,val frames:Int)
    class Collector(private val sampleRate:Int,private val size:Int){
        init{require(sampleRate>0&&size>0)}
        private var low=0.0;private var mid=0.0;private var high=0.0;private var centroid=0.0;private var total=0.0;private var count=0
        fun spectrum(re:DoubleArray,im:DoubleArray){require(re.size==size&&im.size==size);var sum=0.0;var weighted=0.0;var a=0.0;var b=0.0;var c=0.0
            for(i in 1 until size/2){val hz=i.toDouble()*sampleRate/size;if(hz<40||hz>12000)continue;val power=re[i]*re[i]+im[i]*im[i];if(!power.isFinite())continue;sum+=power;weighted+=power*hz;when{hz<250->a+=power;hz<2500->b+=power;else->c+=power}}
            if(sum<1e-7)return;low+=a;mid+=b;high+=c;centroid+=weighted;total+=sum;count++
        }
        fun finish():Features?=if(total>0&&count>0)Features(low/total,mid/total,high/total,centroid/total,count)else null
    }
    fun descriptors(f:Features?):List<String>{if(f==null)return emptyList();return listOf(when{f.low>.60->"Преобладают низкие частоты";f.high>.40->"Выраженные высокие частоты";f.mid>.65->"Преобладают средние частоты";else->"Смешанный спектр"},"Спектральный центр ${f.centroidHz.roundToInt()} Гц")}
    data class Candidate(val first:Double,val second:Double,val duration:Double,val contrast:Double,val similarity:Double)
    /** Repeated, relatively loud passages are chorus candidates only, never semantic labels. */
    fun chorusCandidates(report:MusicAnalysis.Report):List<Candidate>{val e=report.energy;if(e.size<6||e.any{!it.isFinite()||it<0})return emptyList();val median=e.sorted()[e.size/2];if(median<.005)return emptyList()
        fun mean(start:Double,duration:Double):Double{val a=(start/4).toInt().coerceIn(0,e.lastIndex);val b=ceil((start+duration)/4).toInt().coerceIn(a+1,e.size);return e.subList(a,b).average()}
        return StructureCore.repetitions(report).mapNotNull{r->val contrast=min(mean(r.first,r.duration),mean(r.second,r.duration))/median;if(contrast>=1.25)Candidate(r.first,r.second,r.duration,contrast,r.similarity)else null}.sortedByDescending{it.contrast*it.similarity}.take(4)
    }
}
