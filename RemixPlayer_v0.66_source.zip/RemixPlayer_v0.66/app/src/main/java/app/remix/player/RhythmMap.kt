package app.remix.player
import kotlin.math.*
/** Local tempo observations; no invented beat/downbeat or semantic labels. */
object RhythmMap {
    data class Window(val start:Double,val end:Double,val bpm:Double,val confidence:Double)
    class Collector(private val hz:Int=100){
        init{require(hz in 50..200)}
        private val pending=ArrayList<Double>(16*hz);private val found=ArrayList<Window>();private var ticks=0L
        fun add(rms:Double){if(ticks>=900L*hz)return;pending.add(rms.takeIf{it.isFinite()&&it>=0}?:0.0);ticks++;if(pending.size==16*hz)flush()}
        private fun flush(){val t=Tempo.estimate(pending,hz);if(t!=null&&t.confidence>=.30)found.add(Window((ticks-pending.size).toDouble()/hz,ticks.toDouble()/hz,t.bpm,t.confidence));pending.clear()}
        fun finish():List<Window>{if(pending.isNotEmpty())flush();return found.toList()}
    }
    /** Normalize half/double tempo to reference for comparison; don't silently modify source tempo. */
    fun relative(bpm:Double,reference:Double):Double=listOf(bpm/2,bpm,bpm*2).minByOrNull{abs(ln(it/reference))}!!
    fun unstable(windows:List<Window>,reference:Double):Boolean{if(windows.size<2||!reference.isFinite()||reference<=0)return false;val v=windows.map{relative(it.bpm,reference)};return v.maxOrNull()!!/v.minOrNull()!!>1.12}
}
