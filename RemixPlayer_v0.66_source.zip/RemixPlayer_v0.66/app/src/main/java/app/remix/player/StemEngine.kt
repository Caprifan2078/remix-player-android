package app.remix.player

import android.content.Context
import android.media.*
import android.net.Uri
import android.os.SystemClock
import ai.onnxruntime.*
import java.io.*
import java.nio.*
import kotlin.math.*

/** Local model inference; no remote audio transmission. Model imported by the user. */
object StemEngine {
    private const val MAX_FRAMES=44100L*60*15
    fun model(context:Context)=File(context.filesDir,"separator.onnx")
    fun install(context:Context,uri:Uri){
        val tmp=File(context.filesDir,"separator.tmp")
        try {
            context.contentResolver.openInputStream(uri)?.use{input->tmp.outputStream().buffered().use{out->val b=ByteArray(65536);var total=0L;while(true){val n=input.read(b);if(n<0)break;total+=n;require(total<=600L*1024*1024){"Модель больше 600 МБ"};out.write(b,0,n)}}}?:error("Модель не открывается")
            require(tmp.length()>0){"Пустой файл"}
            // Validate graph I/O before replacing previous model.
            session(tmp){s->stemCount(s)}
            require(tmp.renameTo(model(context))){"Не удалось сохранить модель"}
        }finally{tmp.delete()}
    }
    fun installFromUrl(context:Context,url:String,sha:String,progress:(Int)->Unit){val tmp=File(context.filesDir,"separator-download.tmp");require(!tmp.exists()||tmp.delete());try{VerifiedDownload.fetch(url,sha,tmp,progress);session(tmp){s->stemCount(s)};require(tmp.renameTo(model(context))){"Не удалось установить модель"}}finally{tmp.delete()}}
    fun installCatalog(context:Context,entry:ModelCatalog.Entry,progress:(Int)->Unit){require(entry.kind==ModelCatalog.Kind.SEPARATOR&&entry.sha256!=null);val tmp=File(context.filesDir,"separator-"+java.util.UUID.randomUUID()+".tmp");try{CatalogDownload.fetch(entry,tmp,progress);session(tmp){s->require(stemCount(s)==ModelCatalog.expectedStems(entry))};require(tmp.renameTo(model(context))){"Не удалось установить модель"}}finally{tmp.delete()}}
    private fun <T> session(file:File, block:(OrtSession)->T):T {
        require(file.isFile){"Сначала импортируйте модель ONNX"}
        val env=OrtEnvironment.getEnvironment()
        return OrtSession.SessionOptions().use{opts->opts.setIntraOpNumThreads(2);opts.setInterOpNumThreads(1);env.createSession(file.absolutePath,opts).use(block)}
    }
    private fun stemCount(s:OrtSession):Int {
        val input=s.inputInfo["mix"]?.info as? TensorInfo ?: error("Нет входа mix")
        val output=s.outputInfo["stems"]?.info as? TensorInfo ?: error("Нет выхода stems")
        require(s.inputNames==setOf("mix") && input.type==OnnxJavaType.FLOAT && output.type==OnnxJavaType.FLOAT)
        require(input.shape.contentEquals(longArrayOf(1,2,StemCore.BLOCK.toLong()))) {"Неподдерживаемый вход модели"}
        val shape=output.shape;require(shape.size==4&&shape[0]==1L&&shape[1] in listOf(4L,6L)&&shape[2]==2L&&shape[3]==StemCore.BLOCK.toLong()){ "Неподдерживаемый выход модели" }
        return shape[1].toInt()
    }
    data class Diagnostic(val count:Int,val milliseconds:Long,val metrics:ModelDiagnostic.Result)
    fun diagnose(context:Context):Diagnostic=session(model(context)){s->
        val n=stemCount(s);val frames=StemCore.BLOCK;val data=FloatArray(frames*2)
        for(i in 0 until frames){val envelope=sin(PI*i/frames).toFloat();data[i]=(.12*sin(2*PI*440*i/44100)*envelope).toFloat();data[frames+i]=(.12*sin(2*PI*660*i/44100)*envelope).toFloat()}
        val start=SystemClock.elapsedRealtime();OnnxTensor.createTensor(OrtEnvironment.getEnvironment(),FloatBuffer.wrap(data),longArrayOf(1,2,frames.toLong())).use{tensor->s.run(mapOf("mix" to tensor)).use{result->val output=result.get("stems").orElseThrow{IllegalStateException("Нет дорожек")} as OnnxTensor;val b=output.floatBuffer;require(b.remaining()==n*frames*2);Diagnostic(n,SystemClock.elapsedRealtime()-start,ModelDiagnostic.inspect(data,n,frames){i->b.get(i)})}}
    }
    /** Decode to 44.1k stereo signed PCM16 on disk. */
    fun decode(context:Context,uri:Uri,raw:File,observe:((Short,Short)->Unit)?=null):Long {
        val ext=MediaExtractor();var codec:MediaCodec?=null
        try{
            ext.setDataSource(context,uri,null);val t=(0 until ext.trackCount).firstOrNull{ext.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/")==true}?:error("Нет аудио")
            ext.selectTrack(t);val f=ext.getTrackFormat(t);val d=MediaCodec.createDecoderByType(f.getString(MediaFormat.KEY_MIME)!!);codec=d;d.configure(f,null,null,0);d.start()
            return raw.outputStream().buffered(65536).use{out->
                var rate=f.getInteger(MediaFormat.KEY_SAMPLE_RATE);var channels=f.getInteger(MediaFormat.KEY_CHANNEL_COUNT);var encoding=AudioFormat.ENCODING_PCM_16BIT
                var frames=0L;var sourceFrames=0L;fun makeResampler()=StemCore.Resampler(rate){l,r->require(frames<MAX_FRAMES){"Максимальная длительность 15 минут"};val a=StemCore.pcm(l);val b=StemCore.pcm(r);StemCore.writeShort(out,a);StemCore.writeShort(out,b);observe?.invoke(a,b);frames++}
                var rs=makeResampler();var inputDone=false;var done=false;var last=SystemClock.elapsedRealtime();val info=MediaCodec.BufferInfo()
                while(!done){check(!Thread.currentThread().isInterrupted){"Отменено"};check(SystemClock.elapsedRealtime()-last<15000){"Декодер не отвечает"}
                    if(!inputDone){val i=d.dequeueInputBuffer(5000);if(i>=0){val b=d.getInputBuffer(i)!!;b.clear();val n=ext.readSampleData(b,0);if(n<0){d.queueInputBuffer(i,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputDone=true}else{d.queueInputBuffer(i,0,n,ext.sampleTime,0);ext.advance()};last=SystemClock.elapsedRealtime()}}
                    when(val i=d.dequeueOutputBuffer(info,5000)){
                        MediaCodec.INFO_OUTPUT_FORMAT_CHANGED->{val o=d.outputFormat;val nr=o.getInteger(MediaFormat.KEY_SAMPLE_RATE);val nc=o.getInteger(MediaFormat.KEY_CHANNEL_COUNT);val ne=if(o.containsKey(MediaFormat.KEY_PCM_ENCODING))o.getInteger(MediaFormat.KEY_PCM_ENCODING) else AudioFormat.ENCODING_PCM_16BIT;require(sourceFrames==0L||nr==rate&&nc==channels&&ne==encoding){"Смена формата в середине трека"};if(sourceFrames==0L){rate=nr;channels=nc;encoding=ne;rs=makeResampler()};last=SystemClock.elapsedRealtime()}
                        else->if(i>=0){try{val b=d.getOutputBuffer(i);if(b!=null&&info.size>0&&info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG==0){require(channels in 1..2){"Поддерживается моно и стерео"};require(encoding==AudioFormat.ENCODING_PCM_FLOAT||encoding==AudioFormat.ENCODING_PCM_16BIT){"Неизвестный PCM"};val bytes=if(encoding==AudioFormat.ENCODING_PCM_FLOAT)4 else 2;b.position(info.offset);b.limit(info.offset+info.size);b.order(ByteOrder.nativeOrder());fun sample():Float { return if(bytes==4)b.float else b.short/32768f };while(b.remaining()>=bytes*channels){val l=sample();val r=if(channels==2)sample() else l;rs.frame(l,r);sourceFrames++}};done=info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM!=0}finally{d.releaseOutputBuffer(i,false)};last=SystemClock.elapsedRealtime()}
                    }
                };rs.finish();require(frames>0){"Пустое аудио"};frames
            }
        }finally{runCatching{codec?.stop()};runCatching{codec?.release()};ext.release()}
    }
    data class Bundle(val dir:File,val frames:Long,val count:Int)
    @Synchronized fun separate(context:Context,uri:Uri,progress:(String)->Unit):Bundle {
        val root=File(context.filesDir,"stems").apply{mkdirs()}
        require(root.usableSpace>200L*1024*1024){"Недостаточно места для декодирования (нужно от 200 МБ)"}
        root.listFiles().orEmpty().filter{it.isFile&&it.name.startsWith("decode-")&&it.name.endsWith(".pcm")}.forEach{it.delete()}
        val raw=File.createTempFile("decode-",".pcm",root)
        try{progress("Декодирование…");decode(context,uri,raw);return separateDecoded(context,uri,raw,progress)}finally{raw.delete()}
    }
    /** The studio already has canonical PCM; don't decode it a second time. */
    @Synchronized fun separateDecoded(context:Context,uri:Uri,raw:File,progress:(String)->Unit):Bundle {
        require(raw.isFile&&raw.length()%4==0L&&raw.length()/4 in 1..MAX_FRAMES)
        val frames=raw.length()/4;val root=File(context.filesDir,"stems").apply{mkdirs()}
        val sourceId=java.util.UUID.nameUUIDFromBytes(uri.toString().toByteArray(Charsets.UTF_8)).toString()
        val dir=File(root,"pending-$sourceId")
        progress("Проверка исходника и модели…");val modelFile=model(context);val sourceHash=StemCheckpoint.hash(raw);val signature="stem-v1:"+sourceHash+":"+StemCheckpoint.hash(modelFile)
            val finalId=java.util.UUID.nameUUIDFromBytes((sourceId+":"+signature).toByteArray(Charsets.UTF_8)).toString()
            load(context,finalId)?.let{cached->EffectCheckpoint.atomicText(File(cached.dir,"input.sha256"),sourceHash);return cached}
            val count=session(modelFile){s->
                val n=stemCount(s);val checkpoint=StemCheckpoint.open(dir,signature,frames,n)
                require(root.usableSpace>(frames-checkpoint.committedFrames)*4*n+64L*1024*1024){"Недостаточно места для оставшихся дорожек"}
                val block=StemCore.BLOCK
                RandomAccessFile(raw,"r").use{input->for(index in checkpoint.next until checkpoint.starts.size){
                    check(!Thread.currentThread().isInterrupted){"Отменено"};progress("Разделение: ${index+1}/${checkpoint.starts.size} · готовые блоки сохранены")
                    val start=checkpoint.starts[index];val len=min(block.toLong(),frames-start).toInt();val planar=FloatArray(block*2);val bytes=ByteArray(len*4);input.seek(start*4);input.readFully(bytes);val b=ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);repeat(len){i->planar[i]=b.short/32768f;planar[block+i]=b.short/32768f}
                    OnnxTensor.createTensor(OrtEnvironment.getEnvironment(),FloatBuffer.wrap(planar),longArrayOf(1,2,block.toLong())).use{tensor->s.run(mapOf("mix" to tensor)).use{res->
                        val output=res.get("stems").orElseThrow{IllegalStateException("Нет дорожек")} as OnnxTensor;val values=output.floatBuffer;require(values.remaining()==n*2*block)
                        checkpoint.commit{values.get(it)}
                    }}
                }};n
            }
            repeat(count){require(File(dir,"$it.pcm").length()==frames*4){"Неполная дорожка"}}
            FileOutputStream(File(dir,"meta")).use{it.write("$frames\n$count".toByteArray());it.fd.sync()}
            EffectCheckpoint.atomicText(File(dir,"input.sha256"),sourceHash)
            val dest=File(root,finalId);require(!dest.exists()||dest.deleteRecursively())
            java.nio.file.Files.move(dir.toPath(),dest.toPath(),java.nio.file.StandardCopyOption.ATOMIC_MOVE)
            File(dest,"state.bin").delete();File(dest,"state.part").delete()
            return Bundle(dest,frames,count)
    }
    /** Legacy caches without a source hash cannot be trusted for new genre jobs. */
    fun matchesSource(bundle:Bundle,raw:File):Boolean=runCatching {
        bundle.frames==raw.length()/4&&File(bundle.dir,"input.sha256").readText()==StemCheckpoint.hash(raw)
    }.getOrDefault(false)
    private fun pendingDir(context:Context,uri:Uri)=File(File(context.filesDir,"stems"),"pending-"+java.util.UUID.nameUUIDFromBytes(uri.toString().toByteArray(Charsets.UTF_8)))
    fun hasPending(context:Context,uri:Uri):Boolean=pendingDir(context,uri).isDirectory
    @Synchronized fun discardPending(context:Context,uri:Uri){val dir=pendingDir(context,uri);check(!dir.exists()||dir.deleteRecursively()){ "Не удалось удалить контрольную точку" }}
    fun load(context:Context,id:String):Bundle?=runCatching{require(id.matches(Regex("[a-f0-9-]{36}")));val dir=File(File(context.filesDir,"stems"),id);val m=File(dir,"meta").readLines();val frames=m[0].toLong();val count=m[1].toInt();require(frames in 1..MAX_FRAMES && count in listOf(4,6));repeat(count){require(File(dir,"$it.pcm").length()==frames*4)};Bundle(dir,frames,count)}.getOrNull()
    fun render(context:Context,bundle:Bundle,gains:FloatArray):File {
        require(gains.size==bundle.count&&gains.all{it.isFinite()&&it in 0f..1f});val dir=File(context.filesDir,"mixes").apply{mkdirs()};require(dir.usableSpace>bundle.frames*4+1024*1024){"Недостаточно места"};val file=File(dir,java.util.UUID.randomUUID().toString()+".wav");val inputs=ArrayList<InputStream>()
        try{repeat(bundle.count){inputs.add(File(bundle.dir,"$it.pcm").inputStream().buffered(65536))};file.outputStream().buffered(65536).use{out->StemCore.header(out,bundle.frames);val samples=ShortArray(inputs.size);var remain=bundle.frames*2;while(remain-->0){if(remain%8192==0L)check(!Thread.currentThread().isInterrupted);for(i in inputs.indices)samples[i]=StemCore.readShort(inputs[i]);StemCore.writeShort(out,StemCore.mix(samples,gains))}};return file}catch(e:Throwable){file.delete();throw e}finally{inputs.forEach{runCatching{it.close()}}}
    }
}
