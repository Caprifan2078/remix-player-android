package app.remix.player
import kotlin.math.*
/** 30 profile-conditioned symbolic melody model. Trained on generated patterns. */
object GenrePhrase {
    fun family(index:Int):NeuralInstrumental.Style {
        val g=GenreEngine.styles[index]
        return when{g.target<=112&&g.drive<.2f->NeuralInstrumental.Style.SOFT;g.drive>=.4f->NeuralInstrumental.Style.DARK;else->NeuralInstrumental.Style.DANCE}
    }
    fun probabilities(genre:Int,minor:Boolean,slot:Int,previous:Int,temperature:Double):DoubleArray {
        require(genre in 0..29&&slot in 0..15&&previous in 0..8&&temperature in .3..2.0)
        val h=DoubleArray(32){j->tanh((GenrePhraseWeights.b1[j]+GenrePhraseWeights.w1[genre*32+j]+(if(minor)GenrePhraseWeights.w1[30*32+j]else 0f)+GenrePhraseWeights.w1[(31+slot)*32+j]+GenrePhraseWeights.w1[(47+previous)*32+j]).toDouble())}
        val z=DoubleArray(9){k->GenrePhraseWeights.b2[k]+h.indices.sumOf{j->h[j]*GenrePhraseWeights.w2[j*9+k]}};val m=z.maxOrNull()!!;val p=DoubleArray(9){exp((z[it]-m)/temperature)};val sum=p.sum();return DoubleArray(9){p[it]/sum}
    }
}
