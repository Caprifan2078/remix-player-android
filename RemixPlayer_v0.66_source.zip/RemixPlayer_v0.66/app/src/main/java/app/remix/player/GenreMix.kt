package app.remix.player

/** Immutable per-job mix controls. 1 = current template level, 0 = mute. */
data class GenreMix(val drums:Float=1f,val bass:Float=1f,val lead:Float=1f,val source:Float=1f,val vocals:Float=1f,val oldDrums:Float=1f){
    init{require(listOf(drums,bass,lead,source,vocals,oldDrums).all{it.isFinite()&&it in 0f..2f})}
    fun values()=floatArrayOf(drums,bass,lead,source,vocals,oldDrums)
    companion object {
        fun from(v:FloatArray):GenreMix{require(v.size==6);return GenreMix(v[0],v[1],v[2],v[3],v[4],v[5])}
        val profiles=linkedMapOf("Баланс" to GenreMix(),"Вокал вперёд" to GenreMix(.75f,.65f,.25f,.8f,1.4f,.5f),"Клубный" to GenreMix(1.4f,1.35f,.85f,.8f,1f,.3f),"Минимал" to GenreMix(.8f,.55f,0f,1f,1f,.5f),"Инструментальный" to GenreMix(1f,1f,1f,1f,0f,.5f))
    }
}
