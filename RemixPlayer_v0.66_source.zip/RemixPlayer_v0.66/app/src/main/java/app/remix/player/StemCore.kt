package app.remix.player

import java.io.*
import kotlin.math.*

/** Original block mixer. Model output is [stem][channel][frame]. */
object StemCore {
    const val RATE = 44100
    const val BLOCK = 343980
    const val OVERLAP = 85995
    const val HOP = BLOCK - OVERLAP
    val names = listOf("Ударные", "Бас", "Инструменты", "Вокал", "Гитара", "Фортепиано")
    fun starts(frames: Long, block: Int = BLOCK, overlap: Int = OVERLAP): Sequence<Long> = sequence {
        require(frames > 0 && overlap in 1 until block && overlap <= block/2)
        var p=0L
        while(true){yield(p);if(p+block>=frames)break;p+=block-overlap}
    }
    fun blend(previous: Float, next: Float, index: Int, overlap: Int): Float {
        val w=(index+1f)/(overlap+1f);return previous*(1-w)+next*w
    }
    fun pcm(x: Float): Short = if(x.isFinite()) (x.coerceIn(-1f,1f)*32768f).roundToInt().coerceIn(-32768,32767).toShort() else 0
    fun mix(samples: ShortArray, gains: FloatArray): Short {
        require(samples.size==gains.size)
        var sum=0f;for(i in samples.indices)sum+=samples[i]/32768f*gains[i]
        return pcm(sum)
    }
    fun header(out: OutputStream, frames: Long, channels: Int=2, rate: Int=RATE) {
        require(channels in 1..32767&&rate>0)
        val blockAlign=channels*2L
        require(rate.toLong()*blockAlign<=0xffffffffL&&frames in 0..((0xffffffffL-36)/blockAlign))
        val size=frames*blockAlign
        fun ascii(s:String){out.write(s.toByteArray(Charsets.US_ASCII))}
        fun le(v:Long,n:Int){repeat(n){out.write((v shr (8*it)).toInt() and 255)}}
        ascii("RIFF");le(size+36,4);ascii("WAVEfmt ");le(16,4);le(1,2);le(channels.toLong(),2);le(rate.toLong(),4);le(rate.toLong()*channels*2,4);le(channels*2L,2);le(16,2);ascii("data");le(size,4)
    }
    fun writeShort(out: OutputStream, s:Short){out.write(s.toInt() and 255);out.write((s.toInt() shr 8) and 255)}
    fun readShort(input:InputStream):Short {val a=input.read();val b=input.read();if(a<0||b<0)throw EOFException();return (a or (b shl 8)).toShort()}
    /** Bounded-memory, polyphase windowed-sinc converter. Exact bypass at 44.1 kHz. */
    class Resampler(private val rate:Int, private val targetRate:Int=RATE, private val emit:(Float,Float)->Unit){
        init{require(rate in 8000..384000 && targetRate in 8000..48000){"Неподдерживаемая частота дискретизации"}}
        private val radius=ceil(24*max(1.0,rate.toDouble()/targetRate)).toInt()
        private val taps=radius*2
        private val phases=256
        private val coefficients=if(rate==targetRate)emptyArray() else Array(phases){p->
            val frac=p.toDouble()/phases;val cutoff=.94*min(1.0,targetRate.toDouble()/rate)
            val c=DoubleArray(taps){j->val x=j-radius+1-frac;val a=PI*x/radius
                val window=if(abs(x)>=radius)0.0 else .42+.5*cos(a)+.08*cos(2*a)
                val sinc=if(abs(x)<1e-12)cutoff else sin(PI*cutoff*x)/(PI*x)
                sinc*window
            };val total=c.sum();FloatArray(taps){(c[it]/total).toFloat()}
        }
        private val capacity=taps+8;private val left=FloatArray(capacity);private val right=FloatArray(capacity)
        private var frames=0L;private var next=0L;private var firstL=0f;private var firstR=0f;private var lastL=0f;private var lastR=0f;private var finished=false
        fun frame(l:Float,r:Float){check(!finished)
            // Isolate corrupted samples before they enter the sinc filter history.
            val cleanL=if(l.isFinite())l else 0f;val cleanR=if(r.isFinite())r else 0f
            if(frames==0L){firstL=cleanL;firstR=cleanR};lastL=cleanL;lastR=cleanR
            if(rate==targetRate){frames++;emit(cleanL,cleanR);return}
            val slot=(frames%capacity).toInt();left[slot]=cleanL;right[slot]=cleanR;frames++
            while(next/targetRate+radius<frames)output()
        }
        private fun output(){val center=next/targetRate;val phase=((next%targetRate)*phases/targetRate).toInt();val c=coefficients[phase];var l=0.0;var r=0.0
            for(j in c.indices){val k=center-radius+1+j;val w=c[j].toDouble();when{ k<0->{l+=firstL*w;r+=firstR*w};k>=frames->{l+=lastL*w;r+=lastR*w};else->{check(k>=frames-capacity);val i=(k%capacity).toInt();l+=left[i]*w;r+=right[i]*w}}}
            emit(l.toFloat(),r.toFloat());next+=rate
        }
        fun finish(){if(finished)return;finished=true;if(rate!=targetRate)while(next<frames*targetRate)output()}
    }
}
