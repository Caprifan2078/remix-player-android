package app.remix.player

import android.text.Html
import org.json.JSONObject
import java.net.URI
import java.net.HttpURLConnection

object CommonsAudioCatalog {
    fun search(term:String):List<CommonsAudioCore.Recording>{
        val c=URI(CommonsAudioCore.query(term)).toURL().openConnection() as HttpURLConnection
        try {
            c.instanceFollowRedirects=false;c.connectTimeout=15000;c.readTimeout=15000
            c.setRequestProperty("User-Agent","RemixPlayer/0.59 (Android; user-initiated audio search)")
            require(c.responseCode==200){"HTTP ${c.responseCode}"}
            val json=c.inputStream.use{input->val out=java.io.ByteArrayOutputStream();val buf=ByteArray(8192);while(true){check(!Thread.currentThread().isInterrupted);val n=input.read(buf);if(n<0)break;require(out.size()+n<=4*1024*1024){"Слишком большой ответ каталога"};out.write(buf,0,n)};out.toString("UTF-8")}
            return parse(json)
        } finally {c.disconnect()}
    }
    fun parse(json:String):List<CommonsAudioCore.Recording>{
        val root=JSONObject(json);require(!root.has("error")){"Ошибка Wikimedia Commons"};val pages=root.optJSONObject("query")?.optJSONArray("pages")?:return emptyList()
        return (0 until minOf(40,pages.length())).mapNotNull{i->
            val p=pages.optJSONObject(i)?:return@mapNotNull null;val f=p.optJSONArray("imageinfo")?.optJSONObject(0)?:return@mapNotNull null;val meta=f.optJSONObject("extmetadata")?:return@mapNotNull null
            fun value(key:String)=meta.optJSONObject(key)?.optString("value").orEmpty()
            val artist=Html.fromHtml(value("Artist").take(4000),Html.FROM_HTML_MODE_LEGACY).toString().trim()
            CommonsAudioCore.recording(p.optString("title"),artist,f.optString("descriptionurl"),f.optString("url"),f.optString("mime"),f.optString("mediatype"),value("LicenseShortName"),value("LicenseUrl"),value("Restrictions"),f.optLong("size",-1))
        }.distinctBy{it.url}
    }
}
