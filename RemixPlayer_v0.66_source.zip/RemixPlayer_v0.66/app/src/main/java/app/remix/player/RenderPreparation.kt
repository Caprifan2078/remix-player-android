package app.remix.player

/** A small LRU for expensive reports. Activity-owned; access from one thread only. */
class ReportCache<K,V>(private val capacity:Int):LinkedHashMap<K,V>(capacity.coerceAtLeast(1),.75f,true){
    init{require(capacity in 1..128)}
    override fun removeEldestEntry(eldest:MutableMap.MutableEntry<K,V>?):Boolean=size>capacity
}

/** Observe canonical samples as they are written, avoiding a second source decode. */
class RenderAnalysis {
    private val analyzer=MusicAnalysis.Analyzer(StemCore.RATE)
    private val mono=AnalysisMono{analyzer.sample(it)}
    private var frames=0L;private var finished=false
    fun frame(l:Short,r:Short){check(!finished);if(frames%8192==0L)check(!Thread.currentThread().isInterrupted);require(frames<44100L*900);mono.frame(l/32768.0,r/32768.0);frames++}
    fun finish():MusicAnalysis.Report {check(!finished&&frames>0);finished=true;mono.finish();return analyzer.finish()}
}
