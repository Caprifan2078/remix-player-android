package app.remix.player
import kotlin.math.*

/** Output sanity only: a synthetic diagnostic cannot establish source separation quality. */
object ModelDiagnostic {
    data class Result(val peak:Double,val rms:Double,val reconstructionRms:Double,val inputRms:Double)
    fun inspect(input:FloatArray,stems:Int,frames:Int,value:(Int)->Float):Result {
        require(stems in listOf(4,6)&&frames>0&&input.size==frames*2)
        var peak=0.0;var power=0.0;var diff=0.0;var inputPower=0.0
        for(i in input.indices){if(i%8192==0)check(!Thread.currentThread().isInterrupted);val x=input[i].toDouble();require(x.isFinite());inputPower+=x*x;var sum=0.0
            for(st in 0 until stems){val v=value(st*frames*2+i).toDouble();require(v.isFinite()&&abs(v)<=32){"Модель вернула нечисловой или экстремальный сигнал"};peak=max(peak,abs(v));power+=v*v;sum+=v};diff+=(sum-x)*(sum-x)}
        return Result(peak,sqrt(power/(input.size*stems)),sqrt(diff/input.size),sqrt(inputPower/input.size))
    }
}
