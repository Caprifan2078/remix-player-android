package app.remix.player
import kotlin.math.*

/** Local example-based classifier. Abstains on ambiguity and insufficient examples. No pretrained model. */
object PersonalTags {
    const val DIM=10
    data class Example(val id:String,val label:String,val values:List<Double>){init{require(id.isNotBlank()&&label.length in 1..80&&values.size==DIM&&values.all{it.isFinite()&&it in 0.0..1.0})}}
    data class Prediction(val label:String,val distance:Double,val margin:Double,val examples:Int)
    fun features(r:MusicAnalysis.Report):List<Double>? {
        val t=r.tempo?.bpm?.takeIf{it in 50.0..220.0}?:return null;val s=r.spectrum?:return null;val e=r.energy.filter{it.isFinite()&&it>=0};if(e.size<3||r.duration<12||r.rms<.005||r.featureFrames.isEmpty())return null
        val mean=e.average();val cv=sqrt(e.map{(it-mean).pow(2)}.average())/mean.coerceAtLeast(.001);val pulse=r.featureFrames.map{it.onset}.average()
        val values=listOf((t-50)/170,s.low,s.mid,s.high,s.centroidHz/12000,ln1p(r.rms*100)/ln(101.0),cv/2,pulse,if(r.key?.endsWith("minor")==true)1.0 else if(r.key==null).5 else 0.0,r.keyConfidence)
        return values.takeIf{it.all{v->v.isFinite()}}?.map{it.coerceIn(0.0,1.0)}
    }
    fun predict(values:List<Double>,examples:List<Example>,exclude:String?=null):Prediction? {
        if(values.size!=DIM||values.any{!it.isFinite()||it !in 0.0..1.0})return null
        val groups=examples.filter{it.id!=exclude}.distinctBy{it.id}.groupBy{it.label}.filterValues{it.size>=3};if(groups.size<2)return null
        val weights=doubleArrayOf(1.4,1.2,1.0,1.2,.8,.5,1.0,1.2,.25,.25)
        fun dist(v:List<Double>)=sqrt(values.indices.sumOf{weights[it]*(values[it]-v[it]).pow(2)}/weights.sum())
        val ranked=groups.map{(label,rows)->Triple(label,rows.map{dist(it.values)}.sorted().take(3).average(),rows.size)}.sortedBy{it.second}
        val best=ranked[0];val margin=ranked[1].second-best.second
        return if(best.second<=.22&&margin>=.045)Prediction(best.first,best.second,margin,best.third)else null
    }
}
