package app.remix.player

import kotlin.math.*
import kotlin.random.Random

object VersionChoice {
    fun <T> random(original:T, versions:List<T>, rng:Random=Random.Default):T = versions.ifEmpty { listOf(original) }.random(rng)
}
object ListeningStats {
    data class Entry(val id:String,val playedMs:Long,val lastMs:Long)
    /** Aggregate surviving original and remix versions without overflow. */
    fun grouped(entries:List<Entry>,groupOf:(String)->String?):List<Entry>{
        val groups=linkedMapOf<String,Entry>()
        for(e in entries){
            if(e.playedMs<=0||e.lastMs<0)continue
            val id=groupOf(e.id)?.takeIf{it.isNotBlank()}?:continue
            val old=groups[id]
            groups[id]=Entry(id,saturatedAdd(old?.playedMs?:0L,e.playedMs),maxOf(old?.lastMs?:0L,e.lastMs))
        }
        return groups.values.sortedWith(compareByDescending<Entry>{it.lastMs}.thenBy{it.id})
    }
    private fun saturatedAdd(a:Long,b:Long):Long = a.coerceAtMost(Long.MAX_VALUE-b)+b
    fun total(entries:List<Entry>):Long = entries.fold(0L){sum,e->saturatedAdd(sum,e.playedMs.coerceAtLeast(0))}
    /** Keep healthy rows when one persisted record is malformed; newest wins for duplicates. */
    fun recover(count:Int,read:(Int)->Entry):List<Entry>{
        val rows=LinkedHashMap<String,Entry>();for(i in 0 until count.coerceIn(0,2000)){
            val e=try{read(i)}catch(e:Exception){if(e is InterruptedException)throw e;continue}
            if(e.id.isBlank()||e.id.length>8192||e.playedMs<=0||e.lastMs<0)continue
            val old=rows[e.id];if(old==null||e.lastMs>old.lastMs||(e.lastMs==old.lastMs&&e.playedMs>old.playedMs))rows[e.id]=e
        };return rows.values.sortedByDescending{it.lastMs}
    }
    fun add(entries:List<Entry>,id:String,elapsed:Long,now:Long,limit:Int=2000):List<Entry>{
        require(limit in 1..10000)
        if(id.isBlank()||elapsed !in 1..15000||now<0)return entries
        val old=entries.firstOrNull{it.id==id};val total=(old?.playedMs?:0).coerceIn(0,Long.MAX_VALUE-elapsed)+elapsed
        return (listOf(Entry(id,total,now))+entries.filterNot{it.id==id}).take(limit)
    }
}
/** 10 independent peaking filters; headroom is automatic. Playback only, not applied to exports. */
object EqualizerSettings {
    val frequencies=listOf(31,62,125,250,500,1000,2000,4000,8000,16000)
    @Volatile private var levels=List(10){0f}
    fun get():List<Float> = levels
    /** Strict setters remain strict; disk values are repaired per band. */
    fun restore(read:(Int)->Float){set(List(10){i->val v=try{read(i)}catch(e:Exception){if(e is InterruptedException)throw e;0f};if(v.isFinite())v.coerceIn(-12f,12f)else 0f})}
    fun set(values:List<Float>){require(values.size==10&&values.all{it.isFinite()&&it in -12f..12f});levels=values.toList()}
}
class GraphicEq(private val rate:Int,private val channels:Int,levels:List<Float>){
    init{require(rate>0&&channels>0&&levels.size==10&&levels.all{it.isFinite()&&it in -12f..12f})}
    private class Filter(val b0:Double,val b1:Double,val b2:Double,val a1:Double,val a2:Double,channels:Int){val z1=DoubleArray(channels);val z2=DoubleArray(channels);fun next(x:Double,c:Int):Double{val y=b0*x+z1[c];z1[c]=b1*x-a1*y+z2[c];z2[c]=b2*x-a2*y;return y}}
    private val filters=EqualizerSettings.frequencies.zip(levels).filter{(f,g)->f<rate*.45&&g!=0f}.map{(f,g)->val a=10.0.pow(g/40.0);val w=2*PI*f/rate;val alpha=sin(w)/(2*1.4);val c=cos(w);val d=1+alpha/a;Filter((1+alpha*a)/d,-2*c/d,(1-alpha*a)/d,-2*c/d,(1-alpha/a)/d,channels)}
    private val headroom=10.0.pow(-levels.maxOrNull()!!.coerceAtLeast(0f)/20.0)
    fun sample(x:Float,c:Int):Float {val clean=if(x.isFinite())x else 0f;if(filters.isEmpty())return clean;var y=clean*headroom;for(f in filters)y=f.next(y,c);return y.coerceIn(-1.0,1.0).toFloat()}
}
