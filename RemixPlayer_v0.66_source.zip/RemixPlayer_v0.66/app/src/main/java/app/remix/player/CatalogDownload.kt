package app.remix.player
import java.io.File
import java.net.URI
import java.net.HttpURLConnection
object CatalogDownload {
    fun fetch(entry:ModelCatalog.Entry,file:File,progress:(Int)->Unit){
        require(entry in ModelCatalog.entries&&!file.exists());var uri=URI(entry.url);val max=if(entry.kind==ModelCatalog.Kind.SEPARATOR)600L*1024*1024 else 128L*1024*1024
        try{for(hop in 0..5){check(!Thread.currentThread().isInterrupted);require(ModelCatalog.allowed(entry,uri));val c=uri.toURL().openConnection() as HttpURLConnection
            try{c.instanceFollowRedirects=false;c.connectTimeout=15000;c.readTimeout=15000;c.setRequestProperty("Accept-Encoding","identity");val code=c.responseCode
                if(code in listOf(301,302,303,307,308)){require(hop<5);uri=ModelCatalog.redirect(entry,uri,c.getHeaderField("Location")?:error("Нет адреса перенаправления"));continue}
                require(code==200){"HTTP $code"};val len=c.contentLengthLong;require(len<=max);var total=0L;var last=-1
                c.inputStream.buffered().use{input->file.outputStream().buffered().use{out->val b=ByteArray(65536);while(true){check(!Thread.currentThread().isInterrupted){"Отменено"};val n=input.read(b);if(n<0)break;total+=n;require(total<=max&&file.parentFile!!.usableSpace>32L*1024*1024){"Лимит загрузки или свободного места"};out.write(b,0,n);if(len>0){val p=(total*99/len).toInt().coerceIn(0,99);if(p!=last){last=p;progress(p)}}}}};require(total>0&&(len<0||len==total));entry.sha256?.let{require(VerifiedDownload.matches(file,it)){"SHA-256 не совпадает"}};progress(100);return
            }finally{c.disconnect()}
        };error("Слишком много перенаправлений")}catch(e:Throwable){file.delete();throw e}
    }
}
