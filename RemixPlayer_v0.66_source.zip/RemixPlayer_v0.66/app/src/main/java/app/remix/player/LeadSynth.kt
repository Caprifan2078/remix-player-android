package app.remix.player
import kotlin.math.*
/** Original chord-tone arpeggio, restricted to reliable harmonic segments. No samples. */
class LeadSynth(chords:List<Harmony.Chord>,bpm:Double,phase:Double,private val style:GenreEngine.Style,private val rate:Int=44100,private val grid:AdaptiveGroove=AdaptiveGroove(bpm,phase,rate=rate)){
    private val timeline=Harmony.timeline(chords);private var index=-1;private var oscillator=0.0;private var gain=0.0;private var freq=0.0;private var lastMidi=Int.MIN_VALUE
    private val pattern=when(style.name){"Hardstyle","Rawstyle","Hardcore","Frenchcore"->intArrayOf(0,2,4,6,8,10,12,14);"Drift Phonk","Brazilian Phonk","Montagem","Krushfunk","Automotivo"->intArrayOf(0,3,6,9,12,15);else->intArrayOf(0,4,7,10,14)}
    private val notesBySlot=IntArray(16){pattern.indexOf(it)}
    private val swing=DrumPalette.voice(style).swing
    private val enabled=style.name !in listOf("Lo-Fi","Breakcore","Drum & Bass")
    fun sample(frame:Long,level:Float):Float{if(!enabled)return 0f;val sec=frame.toDouble()/rate;while(index+1<timeline.size&&timeline[index+1].seconds<=sec)index++;val chord=timeline.getOrNull(index)?.takeIf{sec-it.seconds<=.8};val pos=DrumPalette.swing(grid.position(frame),swing);val step=floor(pos).toLong();val slot=Math.floorMod(step,16L).toInt();val frac=pos-floor(pos);val note=notesBySlot[slot];val active=enabled&&chord!=null&&pos>=0&&note>=0&&level>.35f
        if(active&&chord!=null){val interval=when(note%4){0->0;1->if(chord.minor)3 else 4;2->7;else->12};val midi=Harmony.leadNote(chord.root,interval,lastMidi);if(midi!=lastMidi){freq=440*2.0.pow((midi-69)/12.0);lastMidi=midi}}
        val target=if(active)minOf(1.0,frac*20)*exp(-frac*3.0)*level else 0.0;gain+=(target-gain)*.008;oscillator=(oscillator+2*PI*freq/rate)%(2*PI);return ((sin(oscillator)+style.drive*.23*sin(oscillator*3))*gain*.065).toFloat()
    }
}
