package app.remix.player

import java.io.*
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.zip.CRC32

/** Durable PCM prefixes and exact overlap state. Commit only after all tracks are synced. */
class StemCheckpoint private constructor(val dir:File,private val signature:String,val frames:Long,val count:Int,private val block:Int,private val overlap:Int) {
    private val hop=block-overlap
    val starts=StemCore.starts(frames,block,overlap).toList()
    private val state=File(dir,"state.bin")
    private var checks=mutableListOf<LongArray>()
    private var tail=FloatArray(count*2*overlap)
    val next:Int get()=checks.size
    val committedFrames:Long get()=if(next==starts.size)frames else next.toLong()*hop
    private fun file(st:Int)=File(dir,"$st.pcm")
    private fun crc(bytes:ByteArray)=CRC32().also{it.update(bytes)}.value
    private fun writeSize(i:Int)=if(i==starts.lastIndex)(frames-starts[i]).toInt() else hop
    private fun restore(){
        require(state.length() in 1..8_000_000L)
        val bytes=state.readBytes();require(bytes.size>=8)
        val payload=bytes.copyOf(bytes.size-8)
        require(DataInputStream(ByteArrayInputStream(bytes,bytes.size-8,8)).readLong()==crc(payload))
        DataInputStream(ByteArrayInputStream(payload)).use{r->
            require(r.readUTF()=="STEM-1"&&r.readUTF()==signature&&r.readLong()==frames&&r.readInt()==count&&r.readInt()==block&&r.readInt()==overlap)
            val n=r.readInt();require(n in 1..starts.size)
            checks=MutableList(n){LongArray(count){r.readLong()}}
            tail=FloatArray(tail.size){r.readFloat()};require(r.read()==-1)
        }
        for(st in 0 until count){RandomAccessFile(file(st),"rw").use{r->
            require(r.length()>=committedFrames*4)
            for(i in 0 until next){check(!Thread.currentThread().isInterrupted);val chunk=ByteArray(writeSize(i)*4);r.readFully(chunk);require(crc(chunk)==checks[i][st])}
            r.setLength(committedFrames*4);r.fd.sync()
        }}
    }
    private fun reset(){
        dir.listFiles().orEmpty().filter{it.name=="state.bin"||it.name=="state.part"||it.name=="meta"||it.name.matches(Regex("[0-5]\\.pcm"))}.forEach{require(it.delete())}
        checks.clear();tail.fill(0f)
    }
    fun commit(values:(Int)->Float){
        check(!Thread.currentThread().isInterrupted);check(next<starts.size)
        val index=next;val size=writeSize(index);val digests=LongArray(count);val newTail=FloatArray(tail.size)
        for(st in 0 until count){
            check(!Thread.currentThread().isInterrupted)
            val bytes=ByteArray(size*4);var pos=0
            for(i in 0 until size){for(ch in 0..1){
                val channel=st*2+ch;val v=values(channel*block+i)
                val mixed=if(index>0&&i<overlap)StemCore.blend(tail[channel*overlap+i],v,i,overlap) else v
                val s=StemCore.pcm(mixed).toInt();bytes[pos++]=s.toByte();bytes[pos++]=(s shr 8).toByte()
            }}
            if(index<starts.lastIndex)for(ch in 0..1)for(i in 0 until overlap){val channel=st*2+ch;newTail[channel*overlap+i]=values(channel*block+hop+i)}
            RandomAccessFile(file(st),"rw").use{r->r.setLength(committedFrames*4);r.seek(committedFrames*4);r.write(bytes);r.fd.sync()};digests[st]=crc(bytes)
        }
        check(!Thread.currentThread().isInterrupted)
        val payload=ByteArrayOutputStream().also{b->DataOutputStream(b).use{w->
            w.writeUTF("STEM-1");w.writeUTF(signature);w.writeLong(frames);w.writeInt(count);w.writeInt(block);w.writeInt(overlap);w.writeInt(index+1)
            checks.forEach{a->a.forEach{w.writeLong(it)}};digests.forEach{w.writeLong(it)};newTail.forEach{w.writeFloat(it)}
        }}.toByteArray()
        val tmp=File(dir,"state.part")
        FileOutputStream(tmp).use{out->val w=DataOutputStream(out);w.write(payload);w.writeLong(crc(payload));w.flush();out.fd.sync()}
        Files.move(tmp.toPath(),state.toPath(),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING)
        checks.add(digests);tail=newTail
    }
    companion object {
        fun hash(file:File):String {val d=MessageDigest.getInstance("SHA-256");file.inputStream().buffered().use{r->val b=ByteArray(65536);while(true){check(!Thread.currentThread().isInterrupted);val n=r.read(b);if(n<0)break;d.update(b,0,n)}};return d.digest().joinToString(""){"%02x".format(it)}}
        fun open(dir:File,signature:String,frames:Long,count:Int,block:Int=StemCore.BLOCK,overlap:Int=StemCore.OVERLAP):StemCheckpoint {
            require(signature.length in 1..512&&frames in 1..(44100L*60*15)&&count in listOf(4,6)&&block in 2..StemCore.BLOCK&&overlap in 1..block/2&&overlap<=StemCore.OVERLAP)
            require((frames-1)/(block-overlap)<=10000);require(dir.isDirectory||dir.mkdirs());val c=StemCheckpoint(dir,signature,frames,count,block,overlap)
            if(c.state.exists())try{c.restore()}catch(e:IllegalArgumentException){c.reset()}catch(e:EOFException){c.reset()}else c.reset()
            return c
        }
    }
}
