package app.remix.player
import java.text.Normalizer
import java.util.Locale

/** Independent evidence for repeated passages from actual timed lyrics, not inferred verse labels. */
object LyricStructure {
    data class Repeat(val firstMs:Long,val secondMs:Long,val firstEndMs:Long?,val secondEndMs:Long?,val lines:Int)
    private fun normalize(s:String)=Normalizer.normalize(s,Normalizer.Form.NFKC).lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}]+")," ").trim()
    fun find(raw:String):List<Repeat>{
        if(raw.length>2_000_000)return emptyList()
        val lines=Lrc.parse(raw).filter{it.ms>=0}.take(1200).map{it.ms to normalize(WordLyrics.parse(it).text)}.filter{it.second.length>=4}
        if(lines.size<6)return emptyList()
        val out=mutableListOf<Repeat>();val n=lines.size;val runs=Array(n+1){IntArray(n+1)}
        for(i in n-1 downTo 0)for(j in n-1 downTo i+1){
            if(lines[i].second!=lines[j].second||lines[j].first-lines[i].first<3000)continue
            runs[i][j]=1+runs[i+1][j+1]
            val len=minOf(runs[i][j],j-i,16);if(len<3)continue
            if(i>0&&j>0&&lines[i-1].second==lines[j-1].second)continue
            if(lines.subList(i,i+len).map{it.second}.distinct().size<2)continue
            if(lines[i+len-1].first-lines[i].first<2000||lines[j+len-1].first-lines[j].first<2000)continue
            out.add(Repeat(lines[i].first,lines[j].first,lines.getOrNull(i+len)?.first,lines.getOrNull(j+len)?.first,len))
        }
        val selected=mutableListOf<Repeat>();for(r in out.sortedByDescending{it.lines}){if(selected.none{kotlin.math.abs(it.firstMs-r.firstMs)<4000&&kotlin.math.abs(it.secondMs-r.secondMs)<4000})selected.add(r);if(selected.size==8)break};return selected.sortedBy{it.firstMs}
    }
}
