package app.remix.player

import kotlin.math.*

/** Kaldi-style log mel frontend for the pinned AST GTZAN checkpoint.
 * 16 kHz normalized PCM, 25 ms Hann window, 10 ms shift, 128 mel bins.
 * Right-pad unnormalized features to 1024 frames, then apply AST normalization. */
object AstGenreCore {
    const val RATE=16000
    const val BINS=128
    const val FRAMES=1024
    const val CLIP=RATE*10
    private const val WINDOW=400
    private const val HOP=160
    private const val FFT=512
    private const val MEAN=-4.2677393
    private const val STD=4.5689974
    val labels=listOf("Блюз","Классика","Кантри","Диско","Хип-хоп","Джаз","Метал","Поп","Регги","Рок")
    private fun norm(x:Double)=((x-MEAN)/(2*STD)).toFloat()
    private fun mel(hz:Double)=1127.0*ln1p(hz/700.0)
    private val window=DoubleArray(WINDOW){.5-.5*cos(2*PI*it/(WINDOW-1))}
    private val filters=Array(BINS){b->
        val low=mel(20.0);val step=(mel(8000.0)-low)/(BINS+1)
        val left=low+b*step;val center=left+step;val right=center+step
        (0 until FFT/2).mapNotNull{k->val m=mel(k.toDouble()*RATE/FFT);val w=min((m-left)/(center-left),(right-m)/(right-center));if(w>0) k to w else null}
    }
    private fun fft(re:DoubleArray,im:DoubleArray){
        var j=0;for(i in 1 until FFT){var bit=FFT/2;while(j and bit!=0){j=j xor bit;bit=bit shr 1};j=j xor bit;if(i<j){val x=re[i];re[i]=re[j];re[j]=x}}
        var len=2;while(len<=FFT){val angle=-2*PI/len;val cr=cos(angle);val ci=sin(angle)
            for(start in 0 until FFT step len){var wr=1.0;var wi=0.0;for(k in 0 until len/2){val a=start+k;val b=a+len/2;val r=re[b]*wr-im[b]*wi;val i=re[b]*wi+im[b]*wr;re[b]=re[a]-r;im[b]=im[a]-i;re[a]+=r;im[a]+=i;val next=wr*cr-wi*ci;wi=wr*ci+wi*cr;wr=next}};len*=2}
    }
    fun features(pcm:FloatArray):FloatArray {
        require(pcm.size in WINDOW..(RATE*11)&&pcm.all{it.isFinite()&&it in -1f..1f})
        val out=FloatArray(FRAMES*BINS){norm(0.0)};val re=DoubleArray(FFT);val im=DoubleArray(FFT);val powers=DoubleArray(FFT/2)
        val frames=min(FRAMES,1+(pcm.size-WINDOW)/HOP)
        for(t in 0 until frames){if(t%32==0)check(!Thread.currentThread().isInterrupted);val start=t*HOP
            var mean=0.0;for(i in 0 until WINDOW)mean+=pcm[start+i];mean/=WINDOW
            re.fill(0.0);im.fill(0.0);var prev=pcm[start]-mean
            for(i in 0 until WINDOW){val value=pcm[start+i]-mean;re[i]=(value-.97*prev)*window[i];prev=value}
            fft(re,im);for(k in powers.indices)powers[k]=re[k]*re[k]+im[k]*im[k]
            for(b in 0 until BINS){var e=0.0;for((k,w) in filters[b])e+=powers[k]*w;out[t*BINS+b]=norm(ln(max(e,1.1920928955078125e-7)))}
        };return out
    }
    /** Three non-identical, evenly-spaced excerpts at most, without padding short recordings. */
    fun windows(total:Long,length:Int):List<Long>{require(total>0&&length>0);val last=(total-length).coerceAtLeast(0);return if(last<length/2)listOf(last/2)else if(last<length)listOf(0,last)else listOf(0,last/2,last).distinct()}
    fun audible(pcm:FloatArray)=pcm.size>=RATE*3&&pcm.all{it.isFinite()}&&sqrt(pcm.sumOf{it.toDouble()*it}/pcm.size)>=.005
    fun probabilities(logits:FloatArray):DoubleArray{require(logits.size==labels.size&&logits.all{it.isFinite()});val max=logits.maxOrNull()!!.toDouble();val exp=DoubleArray(logits.size){exp(logits[it]-max)};val sum=exp.sum();return DoubleArray(exp.size){exp[it]/sum}}
    data class Score(val label:String,val probability:Double)
    data class Result(val scores:List<Score>,val excerpts:Int,val accepted:Boolean)
    fun combine(logits:List<FloatArray>):Result {require(logits.size in 1..3);val ps=logits.map(::probabilities);val scores=labels.indices.map{i->Score(labels[i],ps.map{it[i]}.average())}.sortedByDescending{it.probability};return Result(scores,ps.size,scores[0].probability>=.55&&scores[0].probability-scores[1].probability>=.15)}
}
