package app.remix.player
/** Edit the queue without replacing or seeking the active media item. */
object QueueEdit {
    sealed interface Action {
        data class Insert(val index:Int):Action
        data class Move(val from:Int,val to:Int):Action
        enum class Refused:Action { EMPTY, CURRENT, PRESENT, FULL, SHUFFLE, INVALID }
    }
    fun plan(ids:List<String>,current:Int,id:String,next:Boolean,shuffle:Boolean,limit:Int=QueueSnapshot.LIMIT):Action {
        if(id.isBlank()||id.length>8192||limit !in 1..QueueSnapshot.LIMIT||ids.size>limit)return Action.Refused.INVALID
        if(ids.isEmpty())return Action.Refused.EMPTY
        if(current !in ids.indices)return Action.Refused.INVALID
        if(next&&shuffle)return Action.Refused.SHUFFLE
        if(ids[current]==id)return Action.Refused.CURRENT
        val existing=ids.indexOf(id)
        if(!next)return if(existing>=0)Action.Refused.PRESENT else if(ids.size>=limit)Action.Refused.FULL else Action.Insert(ids.size)
        if(existing==current+1)return Action.Refused.PRESENT
        if(existing>=0)return Action.Move(existing,if(existing<current)current else current+1)
        return if(ids.size>=limit)Action.Refused.FULL else Action.Insert(current+1)
    }
    data class Batch(val additions:List<String>,val duplicates:Int,val overflow:Int,val invalid:Int)
    /** Append only; leave the active item and existing timeline untouched. */
    fun appendBatch(existing:List<String>,requested:Iterable<String>,limit:Int=QueueSnapshot.LIMIT):Batch {
        require(limit in 1..QueueSnapshot.LIMIT)
        val seen=existing.toHashSet();val additions=ArrayList<String>();var duplicates=0;var overflow=0;var invalid=0
        val room=(limit-existing.size).coerceAtLeast(0)
        for(id in requested){
            if(id.isBlank()||id.length>8192){invalid++;continue}
            if(!seen.add(id)){duplicates++;continue}
            if(additions.size>=room){overflow++;continue}
            additions.add(id)
        }
        return Batch(additions,duplicates,overflow,invalid)
    }
    fun sameTimeline(rendered:List<String>,actual:List<String>):Boolean=rendered==actual
}
