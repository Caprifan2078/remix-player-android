package app.remix.player

import android.content.Context
import android.net.Uri
import ai.onnxruntime.*
import java.io.File
import java.nio.FloatBuffer

/** Optional pretrained classifier, independent of the separator and Vosk. */
object AstGenreModel {
    fun model(c:Context)=File(c.filesDir,"genre-ast.onnx")
    private fun <T> session(file:File,work:(OrtSession)->T):T {
        require(file.isFile){"Установите AST из каталога"}
        return OrtSession.SessionOptions().use{opts->opts.setIntraOpNumThreads(2);opts.setInterOpNumThreads(1);OrtEnvironment.getEnvironment().createSession(file.absolutePath,opts).use{s->
            val input=s.inputInfo["input_values"]?.info as? TensorInfo?:error("Нет входа input_values")
            val output=s.outputInfo["logits"]?.info as? TensorInfo?:error("Нет выхода logits")
            require(s.inputNames==setOf("input_values")&&input.type==OnnxJavaType.FLOAT&&output.type==OnnxJavaType.FLOAT)
            require(input.shape.size==3&&input.shape[0] in listOf(-1L,1L)&&input.shape[1] in listOf(-1L,1024L)&&input.shape[2] in listOf(-1L,128L))
            require(output.shape.size==2&&output.shape[0] in listOf(-1L,1L)&&output.shape[1]==10L)
            work(s)
        }}
    }
    private fun infer(s:OrtSession,features:FloatArray):FloatArray=OnnxTensor.createTensor(OrtEnvironment.getEnvironment(),FloatBuffer.wrap(features),longArrayOf(1,1024,128)).use{tensor->
        s.run(mapOf("input_values" to tensor)).use{result->val output=result.get("logits").orElseThrow{IllegalStateException("Нет оценок") } as OnnxTensor;val b=output.floatBuffer;require(b.remaining()==10);FloatArray(10).also{b.get(it);AstGenreCore.probabilities(it)}}
    }
    fun installCatalog(c:Context,entry:ModelCatalog.Entry,progress:(Int)->Unit){
        require(entry.kind==ModelCatalog.Kind.GENRE&&entry.sha256!=null);val tmp=File(c.filesDir,"genre-"+java.util.UUID.randomUUID()+".tmp")
        try{CatalogDownload.fetch(entry,tmp,progress);session(tmp){s->infer(s,FloatArray(AstGenreCore.FRAMES*AstGenreCore.BINS))};check(tmp.renameTo(model(c))){"Не удалось установить модель"}}finally{tmp.delete()}
    }
    fun classify(c:Context,uri:Uri,status:(String)->Unit):AstGenreCore.Result = session(model(c)){s->classify(c,uri,s,status)}
    data class BatchItem(val uri:String,val result:AstGenreCore.Result?,val error:String?)
    fun batch(c:Context,uris:List<String>,status:(String)->Unit):List<BatchItem>{
        require(uris.size in 1..20&&uris.distinct().size==uris.size)
        return session(model(c)){s->uris.mapIndexed{i,id->
            check(!Thread.currentThread().isInterrupted);try{BatchItem(id,classify(c,Uri.parse(id),s){msg->status("${i+1}/${uris.size} · $msg")},null)}catch(e:Exception){if(Thread.currentThread().isInterrupted||e is InterruptedException)throw e;BatchItem(id,null,e.message?:"Не удалось проанализировать")}
        }}
    }
    private fun classify(c:Context,uri:Uri,s:OrtSession,status:(String)->Unit):AstGenreCore.Result {
        val raw=File.createTempFile("genre-input-",".pcm",c.cacheDir)
        try{status("Декодирование песни…");StemEngine.decode(c,uri,raw);require(raw.length()%4==0L);val total=raw.length()/4;val clip=441000
            val logits=mutableListOf<FloatArray>();val starts=AstGenreCore.windows(total,clip)
            starts.forEachIndexed{i,start->
                check(!Thread.currentThread().isInterrupted);status("Анализ жанра: ${i+1}/${starts.size}")
                val count=minOf(clip.toLong(),total-start).toInt()
                val pcm=AnalysisPcm.excerpt(raw,start,count,targetRate=AstGenreCore.RATE)
                if(AstGenreCore.audible(pcm)){logits.add(infer(s,AstGenreCore.features(pcm)))}
            }
            require(logits.isNotEmpty()){"Недостаточно слышимого сигнала"};return AstGenreCore.combine(logits)
        }finally{raw.delete()}
    }
}
