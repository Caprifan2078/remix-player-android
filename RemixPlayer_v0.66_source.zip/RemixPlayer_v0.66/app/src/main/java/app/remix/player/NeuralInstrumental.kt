package app.remix.player

import java.io.File
import kotlin.math.*
import kotlin.random.Random

/** Small trained autoregressive symbolic model, followed by an original synthesizer.
 * This generates notes, NOT a diffusion/audio foundation model. Training is synthetic. */
object NeuralInstrumental {
    enum class Style(val title:String){DANCE("Танцевальный"),DARK("Тёмный электронный"),SOFT("Мягкий")}
    data class Mix(val drums:Int=100,val bass:Int=100,val chords:Int=100,val lead:Int=100){init{require(listOf(drums,bass,chords,lead).all{it in 0..100})}}
    data class Settings(val style:Style,val bpm:Int,val root:Int,val minor:Boolean,val bars:Int,val seed:Int,val variation:Int=50,val structured:Boolean=true,val mix:Mix=Mix(),val genre:Int?=null){init{require(genre==null||genre in GenreEngine.styles.indices);require(bpm in 60..200&&root in 0..11&&bars in 1..1000&&variation in 0..100)}}
    fun probabilities(style:Style,minor:Boolean,slot:Int,previous:Int,temperature:Double=.9):DoubleArray{
        require(slot in 0..15&&previous in 0..8&&temperature.isFinite()&&temperature in .3..2.0)
        val h=DoubleArray(24){j->tanh((PhraseWeights.b1[j]+PhraseWeights.w1[style.ordinal*24+j]+(if(minor)PhraseWeights.w1[3*24+j]else 0f)+PhraseWeights.w1[(4+slot)*24+j]+PhraseWeights.w1[(20+previous)*24+j]).toDouble())}
        val z=DoubleArray(9){k->PhraseWeights.b2[k]+h.indices.sumOf{j->h[j]*PhraseWeights.w2[j*9+k]}};val m=z.maxOrNull()!!;val p=DoubleArray(9){exp((z[it]-m)/temperature)};val sum=p.sum();return DoubleArray(9){p[it]/sum}
    }
    /** Reuse a two-bar motif in alternating two-bar phrases, with seed-controlled variation.
     * The model still predicts new tokens; reuse operates in relative scale/chord degrees. */
    fun notes(s:Settings):IntArray {
        val random=Random(s.seed xor ((s.genre?.plus(1)?:0)*0x1f123bb5));var prev=0;val out=IntArray(s.bars*16)
        val temperature=.45+s.variation*.009
        for(i in out.indices){
            val p=s.genre?.let{GenrePhrase.probabilities(it,s.minor,i%16,prev,temperature)}?:probabilities(s.style,s.minor,i%16,prev,temperature)
            var r=random.nextDouble();var note=8
            for(k in p.indices){r-=p[k];if(r<=0){note=k;break}}
            if(s.structured&&i>=32&&i/32%2==1){
                val repeatChance=1.0-s.variation/100.0
                if(random.nextDouble()<repeatChance)note=out[i-32]
            }
            out[i]=note;prev=note
        };return out
    }
    /** Smooth section levels evaluated once per sixteenth-note boundary, not per sample. */
    fun sectionLevels(s:Settings,step:Int):DoubleArray {
        require(step in 0..s.bars*16)
        if(!s.structured||s.bars<8)return doubleArrayOf(1.0,1.0,1.0,1.0)
        val bar=step/16.0;val end=s.bars.toDouble()
        val intro=(bar/2).coerceIn(0.0,1.0);val outro=((end-bar)/2).coerceIn(0.0,1.0)
        val main=minOf(intro,outro)
        // Two-bar breakdown preceding the second half, except in short arrangements.
        val breakAmount=if(s.bars>=12)(1.0-abs(bar-(end/2-1))/1.0).coerceIn(0.0,1.0)else 0.0
        return doubleArrayOf((.35+.65*main)*(1-.65*breakAmount),(.25+.75*main)*(1-.5*breakAmount),.65+.35*main,(.4+.6*main)*(1-.4*breakAmount))
    }
    private val major=intArrayOf(0,2,4,5,7,9,11);private val minor=intArrayOf(0,2,3,5,7,8,10)
    private fun hz(m:Int)=440.0*2.0.pow((m-69)/12.0)
    /** Times are in the source song, not the generated backing. Unknown harmony is deliberately silent. */
    data class Follow(val chords:List<Harmony.Chord>,val bpm:Double,val offsetMs:Int,val windows:List<RhythmMap.Window> = emptyList()){init{require(bpm.isFinite()&&bpm in 60.0..200.0&&offsetMs in 0..2000)}}
    /** Boundaries in backing frames; the rhythm map is evaluated in original-song time. */
    fun boundaries(s:Settings,follow:Follow?=null):DoubleArray {
        val bpm=follow?.bpm?:s.bpm.toDouble();val steps=s.bars*16
        if(follow==null||follow.windows.isEmpty())return DoubleArray(steps+1){it*44100.0*15/bpm}
        val start=(follow.offsetMs*44.1).roundToLong();val grid=AdaptiveGroove(bpm,start/44100.0,follow.windows,bpm)
        val origin=grid.position(start);val result=DoubleArray(steps+1);var previous=start
        for(i in 1..steps){var lo=previous;var hi=lo+ceil(44100.0*15/(bpm*.7)).toLong()+2
            while(grid.position(hi)-origin<i)hi+=44100L
            while(hi-lo>1){val mid=lo+(hi-lo)/2;if(grid.position(mid)-origin<i)lo=mid else hi=mid}
            result[i]=(hi-start).toDouble();previous=hi
        };return result
    }
    fun barsForDuration(seconds:Double,bpm:Double,phaseMs:Int,windows:List<RhythmMap.Window>):Int {
        require(seconds.isFinite()&&seconds in 0.0..900.0&&bpm in 60.0..200.0&&phaseMs in 0..2000)
        if(windows.isEmpty())return ceil(seconds*bpm/240).toInt().coerceIn(1,1000)
        val start=(phaseMs*44.1).roundToLong();val grid=AdaptiveGroove(bpm,start/44100.0,windows,bpm)
        return ceil((grid.position(maxOf(start,ceil(seconds*44100).toLong()))-grid.position(start))/16).toInt().coerceIn(1,1000)
    }
    data class Voice(val bass:Int,val chord:List<Int>,val lead:Int?)
    fun voices(s:Settings,follow:Follow?=null):List<Voice?> = voicesAt(s,follow,boundaries(s,follow))
    private fun voicesAt(s:Settings,follow:Follow?,boundaries:DoubleArray):List<Voice?> {
        val tokens=notes(s);val scale=if(s.minor)minor else major;val progression=if(s.minor)intArrayOf(0,5,2,6)else intArrayOf(0,4,5,3)
        val timeline=Harmony.timeline(follow?.chords.orEmpty());var j=-1;var previous=-1
        return tokens.mapIndexed{i,token->
            if(follow==null){val d=progression[(i/16)%4];val lead=if(token==0)null else 60+s.root+scale[(d+token-1)%7]+12*((d+token-1)/7);Voice(36+s.root+scale[d],List(3){k->val n=d+2*k;48+s.root+scale[n%7]+12*(n/7)},lead)}
            else {val sec=follow.offsetMs/1000.0+boundaries[i]/44100.0;while(j+1<timeline.size&&timeline[j+1].seconds<=sec)j++;val c=timeline.getOrNull(j)?.takeIf{sec-it.seconds<=.8};if(c==null){previous=-1;null}else{val third=if(c.minor)3 else 4;val intervals=intArrayOf(0,third,7,12,7,third,0,12);val lead=if(token==0)null else Harmony.leadNote(c.root,intervals[token-1],previous).also{previous=it};Voice(36+c.root,listOf(48+c.root,48+c.root+third,48+c.root+7),lead)}}
        }
    }
    /** Independent gate lengths: sustained pads, quarter-note bass, short lead notes.
     * A change or unknown chord always closes the old gate before the boundary. */
    private class Gates(voices:List<Voice?>,boundaries:DoubleArray,part:(Voice?)->Any?,limit:Int){
        val start=DoubleArray(voices.size);val end=DoubleArray(voices.size)
        init{var i=0;while(i<voices.size){val key=part(voices[i]);var j=i+1
            while(j<voices.size&&j/limit==i/limit&&part(voices[j])==key)j++
            for(k in i until j){start[k]=boundaries[i];end[k]=boundaries[j]};i=j
        }}
        fun level(step:Int,frame:Long,attack:Double,release:Double):Double {
            val length=end[step]-start[step];val a=minOf(attack*44100,length*.4);val r=minOf(release*44100,length*.4)
            val x=minOf(1.0,(frame-start[step])/a,(end[step]-frame)/r).coerceIn(0.0,1.0)
            return x*x*(3-2*x)
        }
    }
    fun render(out:File,s:Settings,follow:Follow?=null,progress:(Int)->Unit={}):Long{
        val boundaries=boundaries(s,follow);val voices=voicesAt(s,follow,boundaries);val frames=boundaries.last().roundToLong();var step=0;require(out.absoluteFile.parentFile!!.usableSpace>frames*4+1048576)
        val padGate=Gates(voices,boundaries,{it?.chord},Int.MAX_VALUE);val bassGate=Gates(voices,boundaries,{it?.bass},4)
        val drums=NeuralDrums(s.style,s.seed,s.genre?.let{GenreEngine.styles[it]});val drumPlan=drums.plan(boundaries);val percussion=NeuralDrums.Sample()
        val levels=Array(voices.size+1){sectionLevels(s,it)};val gains=doubleArrayOf(s.mix.drums/100.0,s.mix.bass/100.0,s.mix.chords/100.0,s.mix.lead/100.0);var last=-1;val lead=NeuralTone.Oscillator(s.style,NeuralTone.Part.LEAD);val bass=NeuralTone.Oscillator(s.style,NeuralTone.Part.BASS);val chord=Array(3){NeuralTone.Oscillator(s.style,NeuralTone.Part.PAD)};var lastPercent=-1
        try{out.outputStream().buffered(65536).use{w->StemCore.header(w,frames);for(i in 0L until frames){
            if(i%8192==0L){check(!Thread.currentThread().isInterrupted);val percent=(100*i/frames).toInt();if(percent!=lastPercent){progress(percent);lastPercent=percent}}
            while(step<voices.lastIndex&&i>=boundaries[step+1])step++;val t=(i-boundaries[step])/44100.0;val stepSeconds=(boundaries[step+1]-boundaries[step])/44100.0
            if(step!=last){val v=voices[step];lead.tune(v?.lead?.let(::hz)?:0.0);bass.tune(v?.bass?.let(::hz)?:0.0);for(k in 0..2){chord[k].tune(v?.chord?.get(k)?.let(::hz)?:0.0)};last=step}
            val envelope=minOf(1.0,t/.009,((stepSeconds-t)/.014).coerceAtLeast(0.0)) ;val soft=s.style==Style.SOFT
            val p0=chord[0].next();val p1=chord[1].next();val p2=chord[2].next();val pad=p0+p1+p2
            val melody=lead.next()*envelope*exp(-t*(if(soft)2 else 4))*.18
            val bassEnvelope=bassGate.level(step,i,.008,.028);val padEnvelope=padGate.level(step,i,.025,.045)
            val low=bass.next()*bassEnvelope*.19
            drums.sample(drumPlan,step,i,percussion)
            val chordSound=pad/3*.13*padEnvelope;val frac=((i-boundaries[step])/(boundaries[step+1]-boundaries[step])).coerceIn(0.0,1.0)
            fun gain(k:Int)=gains[k]*(levels[step][k]+(levels[step+1][k]-levels[step][k])*frac)
            val drumGain=gain(0);val leadGain=gain(3);val edge=minOf(1.0,i/441.0,(frames-1-i)/882.0).coerceAtLeast(0.0)
            val padGain=gain(2);val padSide=(p0-p2)*.018*padEnvelope*padGain;val mono=(low*gain(1)+chordSound*padGain+percussion.center*drumGain)*edge;StemCore.writeShort(w,StemCore.pcm((mono+(melody*.95*leadGain+percussion.side*drumGain+padSide)*edge).toFloat()));StemCore.writeShort(w,StemCore.pcm((mono+(melody*.95*leadGain-percussion.side*drumGain-padSide)*edge).toFloat()))
        }};progress(100);return frames}catch(e:Throwable){out.delete();throw e}
    }
}
