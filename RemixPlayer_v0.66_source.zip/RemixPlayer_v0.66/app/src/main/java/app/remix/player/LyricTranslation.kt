package app.remix.player

import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.*
import java.util.concurrent.TimeUnit

object LyricTranslation {
    val languages=linkedMapOf("en" to "Английский","ru" to "Русский","es" to "Испанский","de" to "Немецкий","fr" to "Французский","pt" to "Португальский","ja" to "Японский","ko" to "Корейский","zh" to "Китайский","uk" to "Украинский","tr" to "Турецкий","it" to "Итальянский")
    fun translate(lines:List<String>,source:String,target:String,download:Boolean):List<String>{require(lines.size in 1..2000);require(source!=target);val s=TranslateLanguage.fromLanguageTag(source)?:error("Язык не поддерживается");val t=TranslateLanguage.fromLanguageTag(target)?:error("Язык не поддерживается");val client=Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(s).setTargetLanguage(t).build());try{if(download)Tasks.await(client.downloadModelIfNeeded(DownloadConditions.Builder().requireWifi().build()),10,TimeUnit.MINUTES);val cache=hashMapOf<String,String>();return lines.map{line->check(!Thread.currentThread().isInterrupted);if(line.isBlank())"" else cache.getOrPut(line){Tasks.await(client.translate(line),30,TimeUnit.SECONDS)}}}finally{client.close()}}
}
