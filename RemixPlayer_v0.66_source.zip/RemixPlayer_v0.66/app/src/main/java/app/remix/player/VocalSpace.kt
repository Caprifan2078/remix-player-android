package app.remix.player
import kotlin.math.*

/** Vocal-triggered attenuation of NEW arrangement layers, not vocal modification. */
class VocalSpace(rate:Int=44100){
    init{require(rate in 8000..192000)}
    private val attack=1-exp(-1.0/(.025*rate));private val release=1-exp(-1.0/(.22*rate));private var envelope=0.0
    private var gain=1.0
    fun sample(left:Short,right:Short,vocalLevel:Float=1f):Float{val x=max(abs(left.toInt()),abs(right.toInt()))/32768.0*vocalLevel;val a=if(x>envelope)attack else release;envelope+=(x-envelope)*a
        val target=1-.45*((envelope-.035)/.18).coerceIn(0.0,1.0);gain+=(target-gain)*(if(target<gain)attack else release);return gain.toFloat()}
}
