package app.remix.player

import java.io.File
import java.io.ByteArrayOutputStream
import java.io.RandomAccessFile
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest

/** A single resumable effect batch. Only atomically published, verified WAVs are reused. */
object EffectCheckpoint {
    fun directory(root:File,id:String):File {
        require(java.util.UUID.fromString(id).toString()==id)
        val dir=File(root.canonicalFile,"batch-$id")
        require(dir.canonicalFile==dir.absoluteFile && dir.canonicalFile.parentFile==root.canonicalFile)
        return dir
    }
    internal fun hash(file:File):String {
        val d=MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use{input->val b=ByteArray(65536);while(true){check(!Thread.currentThread().isInterrupted);val n=input.read(b);if(n<0)break;d.update(b,0,n)}}
        return d.digest().joinToString(""){"%02x".format(it)}
    }
    internal fun atomicText(file:File,text:String){val tmp=File(file.parentFile,file.name+".part");java.io.FileOutputStream(tmp).use{it.write(text.toByteArray(Charsets.US_ASCII));it.fd.sync()};Files.move(tmp.toPath(),file.toPath(),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING)}
    fun valid(file:File,bytes:Long):Boolean=runCatching{
        if(!file.isFile||file.length()!=bytes||bytes<48||(bytes-44)%4!=0L)return false
        val expected=ByteArrayOutputStream().also{StemCore.header(it,(bytes-44)/4)}.toByteArray()
        RandomAccessFile(file,"r").use{r->val actual=ByteArray(44);r.readFully(actual);actual.contentEquals(expected)}
    }.getOrDefault(false)
    fun render(raw:File,dir:File,presets:List<Preset>,progress:(Int,Preset,Int)->Unit,renderer:(File,File,Preset,(Int)->Unit)->Unit={a,b,p,cb->EffectRender.render(a,b,p,cb)}):List<Pair<Preset,File>> {
        require(presets.size in 1..70&&presets.all(CustomPresetCore::exportable)&&raw.length()>0&&raw.length()%4==0L)
        val planBytes=ByteArrayOutputStream().also{b->java.io.DataOutputStream(b).use{out->out.writeUTF("dsp-peak-guard-v60");out.writeInt(presets.size);presets.forEach{p->out.writeUTF(p.name);CustomPresetCore.values(p).forEach{out.writeFloat(it)}}}}.toByteArray()
        return renderBatch(dir,presets,hash(raw),planBytes,{p->EffectRender.outputBytes(raw.length()/4,p)},0,{i,p->progress(i,p,100)}){p,tmp,i->renderer(raw,tmp,p){n->progress(i,p,n)}}
    }
    /** The completion marker is removed only after a durable library commit. */
    fun finish(dir:File){dir.listFiles().orEmpty().filter{it.name.endsWith(".sha256")}.forEach{check(it.delete()||!it.exists()){ "Не удалось удалить контрольную точку" }}}
    fun <T> renderBatch(dir:File,items:List<T>,inputSignature:String,planBytes:ByteArray,size:(T)->Long,extra:Long,reused:(Int,T)->Unit,renderer:(T,File,Int)->Unit):List<Pair<T,File>> {
        require(items.size in 1..70&&extra in 0..Long.MAX_VALUE/4&&inputSignature.length in 1..1024&&planBytes.size in 1..65536)
        require(dir.isDirectory||dir.mkdirs());dir.listFiles().orEmpty().filter{it.isFile&&it.name.matches(Regex("(?:pitch-|stretch-|tempo-).+\\.wav|version-[0-9]+\\.part\\.wav|(?:source|version-[0-9]+)\\.sha256\\.part"))}.forEach{check(it.delete()) {"Не удалось удалить временный файл"}};val fingerprint=File(dir,"source.sha256");val planHash=MessageDigest.getInstance("SHA-256").digest(planBytes).joinToString(""){"%02x".format(it)};val signature=inputSignature+"\n"+planHash
        if(fingerprint.exists())require(fingerprint.readText()==signature){"Исходное аудио или настройки изменились. Отмените старый пакет."}else atomicText(fingerprint,signature)
        val result=ArrayList<Pair<T,File>>()
        for((i,p) in items.withIndex()){
            check(!Thread.currentThread().isInterrupted);val bytes=size(p);require(bytes in 48..0xffffffffL+8)
            val out=File(dir,"version-$i.wav");val checksum=File(dir,"version-$i.sha256")
            if(valid(out,bytes)&&checksum.isFile&&checksum.readText()==hash(out)){reused(i,p);result.add(p to out);continue}
            val tmp=File(dir,"version-$i.part.wav");tmp.delete();require(dir.usableSpace>bytes+extra+32L*1024*1024){"Недостаточно места"}
            try{renderer(p,tmp,i);check(!Thread.currentThread().isInterrupted);require(valid(tmp,bytes)){"Неполный WAV"};RandomAccessFile(tmp,"rw").use{it.fd.sync()};val digest=hash(tmp);Files.move(tmp.toPath(),out.toPath(),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);atomicText(checksum,digest);result.add(p to out)}finally{tmp.delete()}
        };return result
    }
}
