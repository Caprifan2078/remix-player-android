package app.remix.player
import java.io.*
import kotlin.math.*

/** Offline counterpart to the playback effects. Pitch resampling + stereo-linked stretch + DSP.
 * Input: signed little-endian 44.1 kHz stereo PCM; output: canonical WAV. Disk-backed, bounded memory. */
object EffectRender {
    fun render(raw:File,output:File,preset:Preset,progress:(Int)->Unit={}) {
        require(raw.canonicalFile!=output.canonicalFile&&raw.length()>0&&raw.length()%4==0L)
        val speed=preset.speed.toDouble();val requestedPitch=preset.pitch.toDouble();val virtualRate=(44100*requestedPitch).roundToInt();val pitch=virtualRate/44100.0;val ratio=speed/pitch
        require(speed in .4f.toDouble()..1.8f.toDouble()&&requestedPitch in .5..1.5){"Этот набор скорости и тона не поддерживает офлайн-экспорт"}
        var lastProgress=-1;fun notify(value:Int){if(value!=lastProgress){lastProgress=value;progress(value)}}
        val frames=raw.length()/4;val pitched=(frames/pitch).roundToLong().coerceAtLeast(1)
        val stages=TimeStretch.stages(ratio)
        val stretched=TimeStretch.stagedFrames(pitched,ratio)
        val dir=output.absoluteFile.parentFile!!;require(dir.usableSpace>(max(pitched,stretched)*2+stretched)*4+32L*1024*1024){"Недостаточно места"}
        val a=File.createTempFile("pitch-",".wav",dir);var intermediate=a;var previousFrames=pitched;val temporary=mutableListOf(a)
        try{
            raw.inputStream().buffered(65536).use{input->a.outputStream().buffered(65536).use{out->
                StemCore.header(out,pitched)
                // A higher virtual input rate raises pitch. The shared bandlimited converter
                // suppresses frequencies above the new Nyquist instead of folding them back.
                var written=0L
                val resampler=StemCore.Resampler(virtualRate){l,r->if(written<pitched){StemCore.writeShort(out,StemCore.pcm(l));StemCore.writeShort(out,StemCore.pcm(r));written++}}
                for(i in 0 until frames){if(i%8192==0L){check(!Thread.currentThread().isInterrupted);notify((i*25/frames).toInt())};resampler.frame(StemCore.readShort(input)/32768f,StemCore.readShort(input)/32768f)}
                resampler.finish();check(written==pitched){"Неверная длина после изменения тона"}
            }}
            stages.forEachIndexed{i,stage->
                val next=File.createTempFile("stretch-",".wav",dir);temporary.add(next)
                TimeStretch.render(intermediate,next,previousFrames,stage){p->notify(25+(i*100+p)*50/(stages.size*100))}
                intermediate.delete();intermediate=next;previousFrames=TimeStretch.outputFrames(previousFrames,stage)
            }
            intermediate.inputStream().buffered(65536).use{input->DataInputStream(input).readFully(ByteArray(44));output.outputStream().buffered(65536).use{out->
                val count=(intermediate.length()-44)/4;StemCore.header(out,count);val dsp=Dsp(44100,2);val frame=FloatArray(2);val result=FloatArray(2)
                for(i in 0 until count){if(i%8192==0L){check(!Thread.currentThread().isInterrupted);notify(75+(i*25/count).toInt())};for(c in 0..1)frame[c]=StemCore.readShort(input)/32768f;dsp.frame(frame,result,preset);for(x in result)StemCore.writeShort(out,StemCore.pcm(x))}
            }};notify(100)
        }catch(e:Throwable){output.delete();throw e}finally{temporary.forEach{it.delete()}}
    }
    fun outputBytes(frames:Long,preset:Preset):Long {
        require(frames>0)
        val pitch=(44100*preset.pitch.toDouble()).roundToInt()/44100.0;val ratio=preset.speed.toDouble()/pitch
        require(preset.speed.toDouble() in .4f.toDouble()..1.8f.toDouble()&&preset.pitch.toDouble() in .5..1.5)
        val pitched=(frames/pitch).roundToLong().coerceAtLeast(1)
        val count=TimeStretch.stagedFrames(pitched,ratio)
        return 44+count*4
    }
    fun batch(raw:File,dir:File,presets:List<Preset>,progress:(Int,Preset,Int)->Unit):List<Pair<Preset,File>> {
        require(raw.length()>0&&raw.length()%4==0L&&presets.isNotEmpty())
        val frames=raw.length()/4
        val extra=presets.maxOf{p->max((frames/p.pitch.toDouble()).roundToLong()*4,outputBytes(frames,p))*3+132}
        return Arrangement.batchSized(presets,dir,{outputBytes(frames,it)},extra){p,file,i->render(raw,file,p){n->progress(i,p,n)}}
    }
}
