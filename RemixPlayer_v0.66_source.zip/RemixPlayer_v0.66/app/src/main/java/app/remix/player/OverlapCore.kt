package app.remix.player

import kotlin.math.*

/** Pure plan for opt-in overlap, independent of Media3. All times are media milliseconds. */
object OverlapCore {
    data class Window(val start:Long,val duration:Long)
    data class Gains(val outgoing:Float,val incoming:Float)
    fun window(currentDuration:Long,nextDuration:Long,requested:Long):Window? {
        if(currentDuration<2000||nextDuration<2000||requested !in 1000..8000)return null
        val overlap=minOf(requested,currentDuration/3,nextDuration/3)
        return if(overlap<500)null else Window(currentDuration-overlap,overlap)
    }
    fun gains(elapsed:Long,duration:Long):Gains {
        require(duration>0)
        val x=(elapsed.toDouble()/duration).coerceIn(0.0,1.0)
        // Constant-sum headroom; no added sample peak even for correlated inputs.
        val a=cos(x*PI/2);val b=sin(x*PI/2);val norm=max(1.0,a+b)
        return Gains((a/norm).toFloat(),(b/norm).toFloat())
    }
    fun eligible(speed:Float,pitch:Float,repeatOne:Boolean,loop:Boolean,processing:Boolean,mixer:Boolean):Boolean =
        speed==1f&&pitch==1f&&!repeatOne&&!loop&&!processing&&!mixer
    fun drift(expected:Long,actual:Long)=abs(expected-actual)>350
    fun handoffPosition(preview:Long,nextDuration:Long):Long=if(nextDuration>0)preview.coerceIn(0,nextDuration-1)else 0
}
