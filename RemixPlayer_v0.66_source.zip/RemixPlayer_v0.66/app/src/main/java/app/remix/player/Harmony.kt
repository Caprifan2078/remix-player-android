package app.remix.player
import kotlin.math.*
/** Conservative triad detection; unknown sections remain unknown. */
object Harmony {
    data class Chord(val seconds:Double,val root:Int,val minor:Boolean,val confidence:Double)
    fun timeline(chords:List<Chord>)=chords.filter{it.seconds.isFinite()&&it.seconds>=0&&it.root in 0..11&&it.confidence.isFinite()&&it.confidence in .075..1.0}.sortedBy{it.seconds}
    /** Keep chord tones in a two-octave register, avoiding large boundary jumps. */
    fun leadNote(root:Int,interval:Int,previous:Int):Int {
        require(root in 0..11&&interval in 0..12)
        val original=60+root+interval
        if(previous !in 60..83)return original
        val pitchClass=(root+interval)%12
        val low=60+pitchClass;val high=low+12
        return if(abs(low-previous)<abs(high-previous))low else if(abs(high-previous)<abs(low-previous))high else original
    }
    fun detect(chroma:DoubleArray,time:Double):Chord? {
        require(chroma.size==12)
        if(!time.isFinite()||time<0)return null
        if(chroma.any{!it.isFinite()||it<0})return null
        val sum=chroma.sum();if(sum<.001)return null
        val scores=ArrayList<Triple<Int,Boolean,Double>>()
        for(root in 0..11)for(minor in listOf(false,true)){
            val r=chroma[root]/sum;val third=chroma[(root+(if(minor)3 else 4))%12]/sum;val fifth=chroma[(root+7)%12]/sum
            if(minOf(r,third,fifth)<.055)continue
            val score=r+third+fifth-.3*(maxOf(r,third,fifth)-minOf(r,third,fifth))
            scores.add(Triple(root,minor,score))
        }
        val sorted=scores.sortedByDescending{it.third};val best=sorted.firstOrNull()?:return null
        val margin=best.third-(sorted.getOrNull(1)?.third?:0.0)
        if(best.third<.58||margin<.075)return null
        return Chord(time,best.first,best.second,margin.coerceIn(0.0,1.0))
    }
    /** Original oscillator; retain source bass, supplement only confidently analyzed parts. */
    class Bass(chords:List<Chord>,bpm:Double,phase:Double,private val drive:Float,private val pattern:IntArray,private val energy:List<Double>,private val rate:Int=44100,private val grid:AdaptiveGroove=AdaptiveGroove(bpm,phase,rate=rate),private val swing:Double=0.0){
        private val timeline=Harmony.timeline(chords);private var index=-1;private val slots=BooleanArray(16){it in pattern};private var osc=0.0;private var gain=0.0;private var frequency=0.0;private var lastRoot=-1
        init{require(rate>0&&bpm in 50.0..220.0&&phase.isFinite())}
        fun sample(frame:Long):Float {
            val sec=frame.toDouble()/rate
            while(index+1<timeline.size&&timeline[index+1].seconds<=sec)index++
            val chord=timeline.getOrNull(index)?.takeIf{sec-it.seconds<=.8}
            val position=DrumPalette.swing(grid.position(frame),swing);val step=floor(position).toLong();val within=position-floor(position)
            val active=chord!=null&&position>=0&&slots[Math.floorMod(step,16L).toInt()]
            if(active&&chord!!.root!=lastRoot){lastRoot=chord.root;val midi=36+lastRoot;frequency=440*2.0.pow((midi-69)/12.0)}
            val envelope=if(active) minOf(1.0,within*30)*exp(-within*3.2) else 0.0
            val section=energy.getOrNull((sec/4).toInt());val level=if(section!=null&&section<.025) .25 else 1.0
            gain+=(envelope*level-gain)*.006
            osc=(osc+2*PI*frequency/rate)%(2*PI)
            return (tanh((sin(osc)+.22*sin(osc*2))*(1+drive*2))*gain*.19).toFloat()
        }
    }
}
