package app.remix.player
import kotlin.math.*
/** Linked stereo soft knee, immediate attack and smoothed release. */
class GenreDynamics(rate:Int=44100){
    init{require(rate in 8000..192000)}
    private val release=(1-exp(-1.0/(.045*rate))).toFloat()
    private var gain=1f
    var left=0f;private set
    var right=0f;private set
    fun frame(l:Float,r:Float){
        val peak=max(abs(l),abs(r))
        val target=if(peak<=.85f)1f else (.85f+.15f*tanh((peak-.85f)/.15f))/peak
        gain=if(target<gain)target else min(target,gain+(1f-gain)*release)
        left=(l*gain).coerceIn(-1f,1f);right=(r*gain).coerceIn(-1f,1f)
    }
}
/** Duck added bass during generated kicks, not original vocals. */
class KickSpace(rate:Int=44100){
    init{require(rate in 8000..192000)}
    private val attack=(1-exp(-1.0/(.003*rate))).toFloat()
    private val release=(1-exp(-1.0/(.095*rate))).toFloat()
    private var gain=1f
    fun sample(kickEnvelope:Float,drumLevel:Float):Float{
        val target=1f-.62f*(kickEnvelope*drumLevel).coerceIn(0f,1f)
        gain+=(target-gain)*(if(target<gain)attack else release)
        return gain
    }
}
