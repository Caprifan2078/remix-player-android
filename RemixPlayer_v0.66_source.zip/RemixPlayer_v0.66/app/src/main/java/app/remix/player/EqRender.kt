package app.remix.player
import java.io.*

/** Render an explicitly chosen 10-band EQ into a new file; the source stays untouched. */
object EqRender {
    fun render(raw:File,output:File,levels:List<Float>,progress:(Int)->Unit={}){
        require(raw.canonicalFile!=output.canonicalFile&&raw.length()>0&&raw.length()%4==0L)
        val eq=GraphicEq(44100,2,levels);val flat=levels.all{it==0f};val frames=raw.length()/4;require(output.absoluteFile.parentFile!!.usableSpace>raw.length()+32L*1024*1024){"Недостаточно места"}
        try{raw.inputStream().buffered(65536).use{r->output.outputStream().buffered(65536).use{w->StemCore.header(w,frames);var last=-1
            for(i in 0 until frames){if(i%4096==0L){check(!Thread.currentThread().isInterrupted){"Отменено"};val p=(i*100/frames).toInt();if(p!=last){last=p;progress(p)}};for(c in 0..1){val s=StemCore.readShort(r);StemCore.writeShort(w,if(flat)s else StemCore.pcm(eq.sample(s/32768f,c)))}}
        }};progress(100)}catch(e:Throwable){output.delete();throw e}
    }
}
