package app.remix.player

import java.io.*
import kotlin.math.*

/** Conservative, optional global alignment. This is not elastic beat warping or downbeat detection. */
object BackingFit {
    data class Options(val tempo:Boolean=true,val key:Boolean=false,val phase:Boolean=true)
    data class Plan(val speed:Double,val semitones:Int,val offsetMs:Int,val notes:List<String>){
        val pitch get()=2.0.pow(semitones/12.0)
        val changed get()=abs(speed-1.0)>1e-6||semitones!=0
    }
    private val roots=listOf("C","C♯","D","D♯","E","F","F♯","G","G♯","A","A♯","B")
    private fun relativeMajor(key:String?):Int? {
        val parts=key?.split(' ')?:return null
        if(parts.size!=2)return null
        val i=roots.indexOf(parts[0]);if(i<0)return null
        return when(parts[1]){"major"->i;"minor"->(i+3)%12;else->null}
    }
    private fun tempo(r:MusicAnalysis.Report?)=r?.tempo?.takeIf{it.bpm.isFinite()&&it.bpm in 50.0..220.0&&it.confidence.isFinite()&&it.confidence>=.30}
    fun plan(base:MusicAnalysis.Report?,backing:MusicAnalysis.Report?,options:Options,manualMs:Int=0):Plan {
        require(manualMs in -60000..60000)
        val notes=mutableListOf<String>();val a=tempo(base);val b=tempo(backing);var speed=1.0;var factor=1.0;var tempoAligned=false
        if(options.tempo){
            if(a==null||b==null)notes.add("Темп: недостаточная уверенность, без изменения")
            else if(RhythmMap.unstable(base!!.tempoWindows,a.bpm)||RhythmMap.unstable(backing!!.tempoWindows,b.bpm))notes.add("Темп меняется внутри песни: автоматическая подгонка отключена")
            else {factor=listOf(.5,1.0,2.0).minByOrNull{abs(ln(a.bpm/(b.bpm*it)))}!!;val ratio=a.bpm/(b.bpm*factor)
                if(ratio !in .75..1.33)notes.add("Темп: требуется слишком сильное изменение, без изменения")
                else{speed=ratio;tempoAligned=true;notes.add("Темп инструментала: ${"%.3f".format(java.util.Locale.ROOT,speed)}×"+(if(factor!=1.0)" (полу-/двойной темп)" else ""))}}
        }
        var semitones=0
        if(options.key){val x=relativeMajor(base?.key);val y=relativeMajor(backing?.key)
            if(x==null||y==null||base==null||backing==null||!(base.keyConfidence>=.06)||!(backing.keyConfidence>=.06))notes.add("Тональность: недостаточная уверенность, без изменения")
            else {val shift=Math.floorMod(x-y+6,12)-6;if(abs(shift)>5)notes.add("Тональность: слишком большой сдвиг, без изменения")else{semitones=shift;notes.add("Тональность: $shift полутонов (относительные мажор/минор)")}}}
        var offset=manualMs
        if(options.phase){val ap=base?.phaseSeconds;val bp=backing?.phaseSeconds
            if(tempoAligned&&factor==1.0&&a!=null&&ap!=null&&bp!=null&&ap.isFinite()&&bp.isFinite()&&ap>=0&&bp>=0){val period=60/a.bpm;val delta=ap-bp/speed;val shift=((delta-round(delta/period)*period)*1000).roundToInt();val result=manualMs+shift
                if(result in -60000..60000){offset=result;notes.add("Приблизительная привязка доли: ${shift} мс")}else notes.add("Привязка доли выходит за пределы смещения")
            }else notes.add("Привязка доли: недостаточная уверенность или неоднозначный темп")}
        return Plan(speed,semitones,offset,notes.toList())
    }
    /** Transform backing only; base audio and lyric timeline are untouched. */
    fun prepare(raw:File,out:File,plan:Plan,progress:(Int)->Unit={}):File {
        require(raw.isFile&&raw.length()>0&&raw.length()%4==0L&&raw.canonicalFile!=out.canonicalFile)
        if(!plan.changed)return raw
        val wav=File.createTempFile("fit-",".wav",out.absoluteFile.parentFile)
        try{EffectRender.render(raw,wav,Preset("Backing fit",speed=plan.speed.toFloat(),pitch=plan.pitch.toFloat())){progress(it*95/100)}
            wav.inputStream().buffered(65536).use{r->DataInputStream(r).readFully(ByteArray(44));out.outputStream().buffered(65536).use{w->AudioFileCore.copy(r,w)}}
            check(out.length()==wav.length()-44&&out.length()>0);progress(100);return out
        }catch(e:Throwable){out.delete();throw e}finally{wav.delete()}
    }
}
