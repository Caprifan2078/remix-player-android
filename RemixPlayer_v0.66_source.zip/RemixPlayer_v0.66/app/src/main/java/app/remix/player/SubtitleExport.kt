package app.remix.player
import java.util.Locale
/** SRT requires end times: derive them from the next line and cap silent gaps. */
object SubtitleExport {
    fun srt(raw:String):String{
        val lines=Lrc.parse(raw).filter{it.ms in 0..(24*3600000L)}.groupBy{it.ms}.toSortedMap().map{(ms,items)->ms to items.map{WordLyrics.parse(it).text.trim()}.filter{it.isNotBlank()}.distinct().joinToString("\n")}.filter{it.second.isNotBlank()}
        require(lines.isNotEmpty()){"Нет синхронизированного текста"}
        fun stamp(ms:Long)=String.format(Locale.ROOT,"%02d:%02d:%02d,%03d",ms/3600000,ms/60000%60,ms/1000%60,ms%1000)
        return lines.mapIndexed{i,(start,text)->val end=minOf(start+6000,lines.getOrNull(i+1)?.first?:start+4000);"${i+1}\n${stamp(start)} --> ${stamp(end)}\n$text"}.joinToString("\n\n",postfix="\n")
    }
}
