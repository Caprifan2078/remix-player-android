package app.remix.player

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.media3.common.*
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.roundToInt

@UnstableApi
class RemixProcessor : BaseAudioProcessor() {
    private var dsp: Dsp? = null
    private var eq:GraphicEq?=null;private var eqLevels:List<Float>?=null
    private var lastPreset:Preset?=null
    private var a=FloatArray(0); private var b=FloatArray(0)
    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if(inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) return AudioProcessor.AudioFormat.NOT_SET
        return inputAudioFormat
    }
    override fun onFlush() { if(inputAudioFormat.channelCount>0 && inputAudioFormat.sampleRate>0) { a=FloatArray(inputAudioFormat.channelCount); b=FloatArray(a.size); dsp=Dsp(inputAudioFormat.sampleRate,a.size);lastPreset=null;eqLevels=null;eq=null } }
    override fun queueInput(inputBuffer: ByteBuffer) {
        val out=replaceOutputBuffer(inputBuffer.remaining()).order(ByteOrder.nativeOrder()); inputBuffer.order(ByteOrder.nativeOrder())
        val p=Presets.active
        if(lastPreset!==p){lastPreset=p;dsp=if(a.isNotEmpty())Dsp(inputAudioFormat.sampleRate,a.size) else null}
        val levels=EqualizerSettings.get();if(eqLevels!=levels&&a.isNotEmpty()){eqLevels=levels;eq=GraphicEq(inputAudioFormat.sampleRate,a.size,levels)}
        val d=dsp
        if((p==Presets.all.first() && levels.all{it==0f}) || d==null || a.isEmpty() || inputBuffer.remaining()%(a.size*2)!=0) { out.put(inputBuffer) } else {
            while(inputBuffer.hasRemaining()) { for(c in a.indices) a[c]=inputBuffer.short/32768f; d.frame(a,b,p); for(c in b.indices) out.putShort(((eq?.sample(b[c],c)?:b[c])*32768).roundToInt().coerceIn(-32768,32767).toShort()) }
        }
        out.flip()
    }
}
@UnstableApi
class PlaybackService : MediaSessionService() {
    private var session: MediaSession?=null
    private var overlap:LiveOverlap?=null
    private val handler=android.os.Handler(android.os.Looper.getMainLooper())
    private var hadQueue=false
    private var lastQueueIds:List<String>?=null
    private fun bookmark(){val p=session?.player?:return
        if(p.mediaItemCount==0){if(hadQueue){getSharedPreferences("playback_bookmark",MODE_PRIVATE).edit().remove("id").putString("queue","[]").putInt("index",-1).apply();lastQueueIds=null;hadQueue=false};return}
        val id=p.currentMediaItem?.mediaId?:return;hadQueue=true
        val ids=(0 until minOf(p.mediaItemCount,QueueSnapshot.LIMIT)).map{p.getMediaItemAt(it).mediaId}
        val editor=getSharedPreferences("playback_bookmark",MODE_PRIVATE).edit().putString("id",id).putLong("position",p.currentPosition.coerceAtLeast(0)).putLong("duration",p.duration).putBoolean("shuffle",p.shuffleModeEnabled).putInt("repeat",p.repeatMode).putInt("index",p.currentMediaItemIndex)
        if(ids!=lastQueueIds){editor.putString("queue",org.json.JSONArray(ids).toString());lastQueueIds=ids}
        editor.apply()
    }
    private var historyRevision=StatsStore.revision;private var history=listOf<ListeningStats.Entry>();private var lastTick=0L;private var lastId:String?=null;private var lastPlaying=false
    private fun historyTick(){val p=session?.player?:return;val now=android.os.SystemClock.elapsedRealtime();val id=p.currentMediaItem?.mediaId;val delta=now-lastTick
        if(historyRevision!=StatsStore.revision){history=StatsStore.read(this);historyRevision=StatsStore.revision}
        if(lastPlaying&&lastId!=null&&delta in 1..15000){history=ListeningStats.add(history,lastId!!,delta,System.currentTimeMillis());StatsStore.save(this,history)}
        lastTick=now;lastId=id;lastPlaying=p.isPlaying
    }
    private val playbackClock=object:Runnable{override fun run(){val p=session?.player?:return;val now=android.os.SystemClock.elapsedRealtime();val deadline=PlaybackOptions.sleepDeadline
        if(deadline>0&&now>=deadline){PlaybackOptions.sleepDeadline=0;p.pause();if(MixerSession.active)MixerSession.stop(this@PlaybackService)}
        val loop=RepeatRegion.active;LoopCore.seek(loop,p.currentMediaItem?.mediaId,p.currentPosition,p.isPlaying)?.let{p.seekTo(it)}
        val params=p.playbackParameters
        val eligible=OverlapCore.eligible(params.speed,params.pitch,p.repeatMode==Player.REPEAT_MODE_ONE,RepeatRegion.active!=null,Presets.active!=Presets.all.first()||EqualizerSettings.get().any{it!=0f},MixerSession.active)
        val mixing=overlap?.tick(PlaybackOptions.overlapMs,eligible)==true
        if(!mixing){val target=PlaybackTiming.gain(p.currentPosition,p.duration,if(PlaybackOptions.overlapMs>0)0 else PlaybackOptions.fadeMs,true,true);if(kotlin.math.abs(p.volume-target)>.002f)p.volume=target}
        handler.postDelayed(this,if((PlaybackOptions.fadeMs>0||PlaybackOptions.overlapMs>0||RepeatRegion.active!=null)&&p.isPlaying)50 else 500)
    }}
    private val checkpoint=object:Runnable{override fun run(){bookmark();historyTick();handler.postDelayed(this,5000)}}
    override fun onCreate() {
        super.onCreate();PlaybackOptions.fadeMs=getSharedPreferences("play_options",MODE_PRIVATE).getLong("fade_ms",0).coerceIn(0,5000);PlaybackOptions.overlapMs=getSharedPreferences("play_options",MODE_PRIVATE).getLong("overlap_ms",0).takeIf{it in 1000..8000}?:0L;history=StatsStore.read(this);val prefs=getSharedPreferences("eq",MODE_PRIVATE);EqualizerSettings.restore{prefs.getFloat("band$it",0f)}
        val renderers=object: DefaultRenderersFactory(this) {
            override fun buildAudioSink(context: Context, enableFloatOutput: Boolean, enableAudioTrackPlaybackParams: Boolean): AudioSink = DefaultAudioSink.Builder(context).setEnableFloatOutput(false).setEnableAudioTrackPlaybackParams(false).setAudioProcessors(arrayOf(RemixProcessor())).build()
        }
        val player=ExoPlayer.Builder(this,renderers).build()
        overlap=LiveOverlap(this,player)
        player.setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),true)
        player.setHandleAudioBecomingNoisy(true)
        player.addListener(object: Player.Listener { override fun onEvents(player:Player,events:Player.Events){if(events.contains(Player.EVENT_TIMELINE_CHANGED)||events.contains(Player.EVENT_POSITION_DISCONTINUITY)||events.contains(Player.EVENT_PLAY_WHEN_READY_CHANGED)||events.contains(Player.EVENT_REPEAT_MODE_CHANGED)||events.contains(Player.EVENT_SHUFFLE_MODE_ENABLED_CHANGED))bookmark()}; override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { if(RepeatRegion.active?.id!=mediaItem?.mediaId)RepeatRegion.active=null;Presets.active=Presets.all.first(); player.playbackParameters=PlaybackParameters.DEFAULT } })
        val open=PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        session=MediaSession.Builder(this,player).setSessionActivity(open).setCallback(object: MediaSession.Callback {
            override fun onAddMediaItems(mediaSession: MediaSession, controller: MediaSession.ControllerInfo, mediaItems: MutableList<MediaItem>): com.google.common.util.concurrent.ListenableFuture<MutableList<MediaItem>> {
                val resolved=mediaItems.map { item -> val uri=item.requestMetadata.mediaUri ?: item.localConfiguration?.uri
                    if(uri==null || uri.scheme!="content") return com.google.common.util.concurrent.Futures.immediateFailedFuture(IllegalArgumentException("Only local content URIs"))
                    item.buildUpon().setUri(uri).build() }.toMutableList()
                return com.google.common.util.concurrent.Futures.immediateFuture(resolved)
            }
        }).build()
        player.addListener(object:Player.Listener{override fun onEvents(player:Player,events:Player.Events){if(player.isPlaying&&MixerSession.active)MixerSession.stop(this@PlaybackService);if(events.contains(Player.EVENT_IS_PLAYING_CHANGED)||events.contains(Player.EVENT_POSITION_DISCONTINUITY)||events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION)||events.contains(Player.EVENT_TIMELINE_CHANGED)||events.contains(Player.EVENT_REPEAT_MODE_CHANGED)||events.contains(Player.EVENT_SHUFFLE_MODE_ENABLED_CHANGED)){bookmark();historyTick()}}})
        handler.postDelayed(checkpoint,5000);handler.post(playbackClock)
    }
    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession?=session
    override fun onDestroy() { handler.removeCallbacks(checkpoint);handler.removeCallbacks(playbackClock);bookmark();historyTick();overlap?.close();overlap=null;session?.let { it.player.release(); it.release() }; session=null; super.onDestroy() }
}
