package app.remix.player

import kotlin.math.*

/** Audio-derived sections. Names describe measured traits, not semantic song lyrics. */
object SectionMap {
    data class Frame(val start:Double,val rms:Double,val low:Double,val mid:Double,val high:Double,val onset:Double,val chroma:List<Double>)
    data class Section(val start:Double,val end:Double,val type:String,val repeatGroup:Int?)
    private fun tonal(a:List<Double>,b:List<Double>):Double {
        if(a.size!=12||b.size!=12)return 0.0
        val aa=a.sumOf{it*it};val bb=b.sumOf{it*it};if(aa<1e-9||bb<1e-9)return 0.0
        return (a.indices.sumOf{a[it]*b[it]}/sqrt(aa*bb)).coerceIn(0.0,1.0)
    }
    private fun distance(a:Frame,b:Frame):Double {
        val spectrum=(abs(a.low-b.low)+abs(a.mid-b.mid)+abs(a.high-b.high))/2
        val energy=abs(ln1p(a.rms*100)-ln1p(b.rms*100))/ln(101.0)
        val pulse=abs(a.onset-b.onset).coerceAtMost(1.0)
        val harmony=if(a.chroma.sum()<.001||b.chroma.sum()<.001)0.0 else 1-tonal(a.chroma,b.chroma)
        return .30*spectrum+.30*energy+.16*pulse+.24*harmony
    }
    private fun label(avg:Double,median:Double,repeated:Boolean)=when{avg<median*.40->"Тихий фрагмент";repeated&&avg>=median*1.15->"Повторяющийся энергичный фрагмент";repeated->"Повторяющийся фрагмент";avg>=median*1.25->"Энергичный фрагмент";else->"Основной фрагмент"}
    fun build(frames:List<Frame>,duration:Double):List<Section> {
        if(!duration.isFinite()||duration<=0||frames.size<4||frames.size>450)return emptyList()
        if(frames.any{f->!f.start.isFinite()||!f.rms.isFinite()||f.rms<0||listOf(f.low,f.mid,f.high,f.onset).any{!it.isFinite()||it<0||it>1}||f.chroma.size!=12||f.chroma.any{!it.isFinite()||it<0}}||frames.zipWithNext().any{(a,b)->b.start<=a.start}||frames.first().start<0||frames.last().start>=duration)return emptyList()
        val allLevels=frames.map{it.rms}.sorted()
        val audible=allLevels.filter{it>=.001};if(audible.size<2)return emptyList()
        val median=allLevels[frames.size/2].takeIf{it>=.001}?:audible[audible.size/2]
        val cuts=mutableListOf(0)
        for(i in 2 until frames.size-1){if(i-cuts.last()<2)continue;val d=distance(frames[i-1],frames[i])
            if(d>.28||((frames[i].rms<median*.40)!=(frames[i-1].rms<median*.40)))cuts.add(i)}
        if(frames.size-cuts.last()<2&&cuts.size>1)cuts.removeAt(cuts.lastIndex)
        cuts.add(frames.size)
        val parts=cuts.zipWithNext();val groups=IntArray(parts.size);var group=0
        for(i in parts.indices){if(groups[i]!=0)continue;val (a,b)=parts[i];if(b-a<3)continue
            for(j in i+1 until parts.size){val (c,d)=parts[j];if(groups[j]!=0||abs((b-a)-(d-c))>1||d-c<3)continue
                val count=min(b-a,d-c);val sim=(0 until count).map{1-distance(frames[a+it],frames[c+it])}.average()
                val harmonic=(0 until count).map{tonal(frames[a+it].chroma,frames[c+it].chroma)}.average()
                if(sim>.88&&harmonic>.84){if(groups[i]==0)groups[i]=++group;groups[j]=groups[i]}}
        }
        // When cuts fail to expose repeats, find a non-overlapping sequence of
        // similar frames. Stationary textures and silent runs are not evidence of
        // repetition. Bounded O(n²) matching, with no allocation per candidate.
        if(groups.none{it!=0}){
            val n=frames.size;val runs=Array(n+1){IntArray(n+1)}
            val changes=IntArray(n+1)
            for(i in 0 until n)changes[i+1]=changes[i]+if(i>0&&distance(frames[i-1],frames[i])>.045)1 else 0
            var bestA=-1;var bestB=-1;var bestLen=0
            for(i in n-1 downTo 0)for(j in n-1 downTo i+1){
                val a=frames[i];val b=frames[j]
                if(a.rms<median*.40||b.rms<median*.40||tonal(a.chroma,b.chroma)<.92||distance(a,b)>.10)continue
                runs[i][j]=1+runs[i+1][j+1]
                val len=minOf(runs[i][j],j-i,32)
                if(len>=4&&len>bestLen&&changes[i+len]-changes[i+1]>=2){bestA=i;bestB=j;bestLen=len}
            }
            if(bestLen>=4){
                // Keep both seed matches and collect every other non-overlapping
                // occurrence against the same reference, including earlier ones.
                val starts=sortedSetOf(bestA,bestB)
                for(candidate in 0..n-bestLen){
                    if(starts.any{abs(it-candidate)<bestLen})continue
                    val first=min(candidate,bestA);val second=max(candidate,bestA)
                    if(runs[first][second]>=bestLen)starts.add(candidate)
                }
                val boundaries=sortedSetOf(0,n)
                for(start in starts){boundaries.add(start);boundaries.add(start+bestLen)}
                // Preserve existing cuts outside the matched passages.
                for(c in cuts)if(starts.none{c>it&&c<it+bestLen})boundaries.add(c)
                return boundaries.toList().zipWithNext().map{(a,b)->
                    val repeated=a in starts&&b-a==bestLen
                    val avg=frames.subList(a,b).map{it.rms}.average()
                    Section(frames[a].start,if(b==n)duration else frames[b].start,label(avg,median,repeated),if(repeated)1 else null)
                }
            }
        }
        return parts.mapIndexed{i,(a,b)->val avg=frames.subList(a,b).map{it.rms}.average();val type=label(avg,median,groups[i]>0);Section(frames[a].start,if(b==frames.size)duration else frames[b].start,type,groups[i].takeIf{it>0})}
    }
}
