package app.remix.player

/** A/B repeat is tied to one media ID; never seeks a different item. Main-thread state. */
object LoopCore {
    data class Region(val id:String,val start:Long,val end:Long)
    fun create(id:String,a:Long,b:Long,duration:Long):Region? = if(id.isNotBlank()&&duration>0&&a>=0&&b<duration-100&&b>a&&b-a>=500)Region(id,a,b)else null
    fun seek(region:Region?,id:String?,position:Long,playing:Boolean):Long? = region?.takeIf{playing&&it.id==id&&position>=it.end}?.start
}
object RepeatRegion { @Volatile var active:LoopCore.Region?=null }
