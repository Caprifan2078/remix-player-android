package app.remix.player
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONObject

/** Explicit opt-in lookup. Only title, artist and optional duration leave the device. */
object LyricsLookup {
    fun fetch(title:String,artist:String,durationSeconds:Long?):String? {
        fun enc(s:String)=URLEncoder.encode(s,"UTF-8")
        val url=URL("https://lrclib.net/api/get?track_name=${enc(title)}&artist_name=${enc(artist)}"+(durationSeconds?.takeIf{it>0}?.let{"&duration=$it"}?:""))
        val c=url.openConnection() as HttpURLConnection
        try{c.connectTimeout=10000;c.readTimeout=10000;c.instanceFollowRedirects=false;c.setRequestProperty("User-Agent","RemixPlayer/0.2 (Android lyrics lookup)");c.setRequestProperty("Accept","application/json")
            val code=c.responseCode;if(code==404)return null;require(code==200){"LRCLIB: HTTP $code"}
            val text=c.inputStream.use{input->val out=java.io.ByteArrayOutputStream();val b=ByteArray(8192);var total=0;while(true){val n=input.read(b);if(n<0)break;total+=n;require(total<=1024*1024){"Ответ слишком большой"};out.write(b,0,n)};out.toString("UTF-8")}
            val json=JSONObject(text);if(json.isNull("syncedLyrics"))return null;return json.optString("syncedLyrics").takeIf{Lrc.parse(it).isNotEmpty()}
        }finally{c.disconnect()}
    }
}
