package app.remix.player
import kotlin.math.*
/** Additive timbres, with harmonic cutoff and interpolated shared tables. */
internal object NeuralTone {
    enum class Part { LEAD, BASS, PAD }
    private const val SIZE=4096
    private val recipes=arrayOf(
        arrayOf(doubleArrayOf(1.0,.34,.20,.09,.045),doubleArrayOf(1.0,.18,.12,.06),doubleArrayOf(1.0,.14,.085)),
        arrayOf(doubleArrayOf(1.0,.13,.36,.04,.15),doubleArrayOf(1.0,.28,.30,.08,.10),doubleArrayOf(1.0,.08,.20,.04)),
        arrayOf(doubleArrayOf(1.0,.07,.025),doubleArrayOf(1.0,.08),doubleArrayOf(1.0,.04,.025)))
    private val tables=Array(recipes.size){style->Array(Part.entries.size){part->Array(recipes[style][part].size){last->
        val h=recipes[style][part];val norm=maxOf(1.0,(0..last).sumOf{abs(h[it])}/1.35)
        DoubleArray(SIZE+1){i->(0..last).sumOf{k->h[k]*sin(2*PI*i*(k+1)/SIZE)}/norm}
    }}}
    class Oscillator(style:NeuralInstrumental.Style,part:Part){
        private val options=tables[style.ordinal][part.ordinal]
        private var phase=0.0;private var increment=0.0;private var active=false;private var table=options[0]
        fun tune(frequency:Double){require(frequency.isFinite()&&frequency>=0&&frequency<22050);active=frequency>0;increment=frequency*SIZE/44100.0
            if(active)table=options[floor(19845/frequency).toInt().coerceIn(1,options.size)-1]}
        fun next():Double{if(!active)return 0.0;phase+=increment;if(phase>=SIZE)phase-=SIZE;val i=phase.toInt();val f=phase-i;return table[i]+(table[i+1]-table[i])*f}
    }
}
