package app.remix.player

import android.app.*
import android.content.*
import android.media.AudioManager
import android.os.*
import androidx.core.content.ContextCompat

/** Process-local controller. All methods called on the main thread. Never holds an Activity. */
object MixerSession {
    data class Request(val token:Long,val source:String,val title:String,val bundleId:String,val frame:Long,val frames:Long,val gains:FloatArray)
    data class Bookmark(val source:String,val frame:Long,val gains:FloatArray)
    private val generation=MixerGeneration()
    var request:Request?=null;private set
    private var player:LiveStemPlayer?=null
    var bookmark:Bookmark?=null;private set
    var error:String?=null;private set
    val active get()=request!=null
    fun position():Long=player?.position()?:request?.frame?:bookmark?.frame?:0
    fun start(context:Context,source:String,title:String,bundle:StemEngine.Bundle,gains:FloatArray,frame:Long){
        require(gains.size==bundle.count&&gains.all{it.isFinite()&&it in 0f..1f})
        player?.close();player=null;error=null
        val token=generation.begin();request=Request(token,source,title,bundle.dir.name,frame.coerceIn(0,bundle.frames-1),bundle.frames,gains.copyOf())
        try{ContextCompat.startForegroundService(context,Intent(context,MixerService::class.java).putExtra("token",token))}catch(e:Exception){finish(token,e.message?:"Не удалось запустить микшер");throw e}
    }
    fun attach(token:Long,p:LiveStemPlayer):Boolean{if(generation.active!=token)return false;player=p;return true}
    fun update(gains:FloatArray){val r=request?:return;if(gains.size!=r.gains.size)return;require(gains.all{it.isFinite()&&it in 0f..1f});request=r.copy(gains=gains.copyOf());player?.update(gains)}
    fun finish(token:Long,failure:String?=null):Boolean{
        if(!generation.finish(token))return false
        val r=request;val p=player;val frame=if(p?.reachedEnd==true)0L else position()
        if(r!=null)bookmark=Bookmark(r.source,frame,r.gains.copyOf())
        player=null;request=null;p?.close();error=failure;return true
    }
    fun stop(context:Context){val token=generation.active?:return;val attached=player!=null;finish(token);if(attached)context.stopService(Intent(context,MixerService::class.java))}
    fun seek(context:Context,frame:Long){val r=request?:return;val bundle=StemEngine.load(context,r.bundleId)?:error("Дорожки недоступны");start(context,r.source,r.title,bundle,r.gains,frame)}
    fun takeError():String?=error.also{error=null}
}

/** Started only from a visible user action. No restart after process death. */
class MixerService:Service(){
    private val handler=Handler(Looper.getMainLooper());private var owned:Long?=null
    private val sleepCheck=object:Runnable{override fun run(){val deadline=PlaybackOptions.sleepDeadline;if(deadline>0&&android.os.SystemClock.elapsedRealtime()>=deadline){PlaybackOptions.sleepDeadline=0;MixerSession.stop(this@MixerService)};handler.postDelayed(this,500)}}
    private val noisy=object:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){MixerSession.stop(this@MixerService)}}
    override fun onCreate(){super.onCreate();handler.post(sleepCheck);val nm=requireNotNull(getSystemService(NotificationManager::class.java));nm.createNotificationChannel(NotificationChannel("stem_playback","Воспроизведение микшера",NotificationManager.IMPORTANCE_LOW));ContextCompat.registerReceiver(this,noisy,IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),ContextCompat.RECEIVER_NOT_EXPORTED)}
    override fun onBind(intent:Intent?):IBinder?=null
    private fun notification(title:String,token:Long):Notification{
        val open=PendingIntent.getActivity(this,14,Intent(this,MainActivity::class.java).putExtra("open_mixer",true).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop=PendingIntent.getService(this,15,Intent(this,MixerService::class.java).setAction("STOP").setData(android.net.Uri.parse("remix-mixer://stop/$token")).putExtra("token",token),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this,"stem_playback").setSmallIcon(android.R.drawable.ic_media_play).setContentTitle(title).setContentText("Микшер инструментов · локально").setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true).setCategory(Notification.CATEGORY_TRANSPORT).addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this,android.R.drawable.ic_media_pause),"Остановить",stop).build()).build()
    }
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{
        val token=intent?.getLongExtra("token",-1)?:-1
        if(intent?.action=="STOP"){if(MixerSession.finish(token)){owned=null;stopForeground(STOP_FOREGROUND_REMOVE);stopSelf()}else if(MixerSession.request==null)stopSelf();return START_NOT_STICKY}
        val r=MixerSession.request
        // Honor the foreground-service deadline even if the request was cancelled before dispatch.
        startForeground(140,notification(r?.title?:"Микшер",r?.token?:token))
        if(r==null){stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return START_NOT_STICKY}
        if(r.token!=token||owned==token)return START_NOT_STICKY
        owned=token
        try{val b=StemEngine.load(this,r.bundleId)?:error("Разделённые дорожки недоступны");require(b.count==r.gains.size&&b.frames==r.frames)
            lateinit var p:LiveStemPlayer
            p=LiveStemPlayer(applicationContext,b,r.gains){handler.post{if(MixerSession.finish(token,p.failure)){owned=null;stopForeground(STOP_FOREGROUND_REMOVE);stopSelf()}}}
            check(MixerSession.attach(token,p));p.play(r.frame)
        }catch(e:Exception){MixerSession.finish(token,e.message?:"Ошибка микшера");owned=null;stopForeground(STOP_FOREGROUND_REMOVE);stopSelf()}
        return START_NOT_STICKY
    }
    override fun onDestroy(){handler.removeCallbacks(sleepCheck);owned?.let{MixerSession.finish(it)};owned=null;runCatching{unregisterReceiver(noisy)};super.onDestroy()}
}
