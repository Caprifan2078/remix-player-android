package app.remix.player
import android.content.Context
import android.net.Uri
import ai.onnxruntime.*
import java.io.File
import java.nio.FloatBuffer
/** No bundled weights, manual import only until provenance and checksum are verified. */
object MoodModel {
    const val SOURCE="https://huggingface.co/huyleit/mert-v1-95m-music-emotion-int8"
    fun model(c:Context)=File(c.filesDir,"mood-mert.onnx")
    private fun <T> session(file:File,work:(OrtSession)->T):T{
        require(file.isFile){"Импортируйте совместимую модель MERT"}
        return OrtSession.SessionOptions().use{opt->opt.setIntraOpNumThreads(2);opt.setInterOpNumThreads(1);OrtEnvironment.getEnvironment().createSession(file.absolutePath,opt).use{s->
            val input=s.inputInfo["audio_waveform"]?.info as? TensorInfo?:error("Нет входа audio_waveform");val output=s.outputInfo["valence_arousal"]?.info as? TensorInfo?:error("Нет выхода valence_arousal")
            require(s.inputNames==setOf("audio_waveform")&&input.type==OnnxJavaType.FLOAT&&output.type==OnnxJavaType.FLOAT&&input.shape.size==2&&input.shape[0] in listOf(1L,-1L)&&input.shape[1] in listOf(MoodCore.SAMPLES.toLong(),-1L)&&output.shape.size==2&&output.shape[0] in listOf(1L,-1L)&&output.shape[1]==2L){"Несовместимая модель"};work(s)
        }}
    }
    private fun infer(s:OrtSession,pcm:FloatArray):MoodCore.Result=OnnxTensor.createTensor(OrtEnvironment.getEnvironment(),FloatBuffer.wrap(pcm),longArrayOf(1,MoodCore.SAMPLES.toLong())).use{t->s.run(mapOf("audio_waveform" to t)).use{r->val b=(r.get("valence_arousal").orElseThrow{IllegalStateException("Нет результата")} as OnnxTensor).floatBuffer;require(b.remaining()==2);MoodCore.Result(b.get(),b.get())}}
    fun install(c:Context,uri:Uri,status:(String)->Unit){val tmp=File.createTempFile("mood-",".onnx",c.filesDir);try{c.contentResolver.openInputStream(uri)?.use{input->tmp.outputStream().buffered().use{out->val buf=ByteArray(65536);var total=0L;while(true){check(!Thread.currentThread().isInterrupted);val n=input.read(buf);if(n<0)break;total+=n;require(total<=512L*1024*1024){"Модель больше 512 МиБ"};out.write(buf,0,n)}}}?:error("Файл недоступен");status("Проверка графа и тестового инференса…");session(tmp){s->infer(s,FloatArray(MoodCore.SAMPLES){i->(.05*kotlin.math.sin(i*0.05)).toFloat()})};check(!Thread.currentThread().isInterrupted);check(tmp.renameTo(model(c))){"Не удалось установить модель"}}finally{tmp.delete()}}
    fun classify(c:Context,uri:Uri,status:(String)->Unit):MoodCore.Result=session(model(c)){s->classify(c,uri,s,status)}
    data class BatchItem(val uri:String,val result:MoodCore.Result?,val error:String?)
    fun batch(c:Context,uris:List<String>,status:(String)->Unit):List<BatchItem>{
        require(uris.size in 1..20&&uris.distinct().size==uris.size)
        return session(model(c)){s->uris.mapIndexed{i,id->check(!Thread.currentThread().isInterrupted);try{BatchItem(id,classify(c,Uri.parse(id),s){status("${i+1}/${uris.size} · $it")},null)}catch(e:Exception){if(Thread.currentThread().isInterrupted||e is InterruptedException)throw e;BatchItem(id,null,e.message?:"Ошибка анализа")}}}
    }
    private fun classify(c:Context,uri:Uri,s:OrtSession,status:(String)->Unit):MoodCore.Result{val raw=File.createTempFile("mood-",".pcm",c.cacheDir);try{status("Декодирование…");StemEngine.decode(c,uri,raw);val starts=MoodCore.starts(raw.length()/4);val results=mutableListOf<MoodCore.Result>();for((i,start) in starts.withIndex()){check(!Thread.currentThread().isInterrupted);status("Оценка настроения MERT · ${i+1}/${starts.size}…");val pcm=try{MoodCore.input(raw,start)}catch(e:IllegalArgumentException){if(e.message=="Фрагмент слишком тихий")continue else throw e};results.add(infer(s,pcm))};require(results.isNotEmpty()){"Все фрагменты слишком тихие"};val combined=MoodCore.combine(results);return combined.copy(consistent=combined.consistent&&results.size*3>=starts.size*2)}finally{raw.delete()}}
}
