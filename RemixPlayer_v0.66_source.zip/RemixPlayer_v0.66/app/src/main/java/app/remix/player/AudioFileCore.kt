package app.remix.player
import java.io.*
import kotlin.math.*

/** Canonical PCM writer and non-destructive sample-accurate clip editor. */
object AudioFileCore {
    data class Clip(val start:Long,val end:Long,val fadeIn:Long=0,val fadeOut:Long=0){
        init{require(start>=0&&end>start&&fadeIn>=0&&fadeOut>=0&&fadeIn<=end-start&&fadeOut<=end-start)}
        val frames get()=end-start
    }
    fun copy(input:InputStream,out:OutputStream){val buffer=ByteArray(65536);while(true){check(!Thread.currentThread().isInterrupted){"Отменено"};val n=input.read(buffer);if(n<0)return;if(n>0)out.write(buffer,0,n)}}
    fun write(raw:File,out:OutputStream,clip:Clip=Clip(0,raw.length()/4),progress:(Int)->Unit={}){
        require(raw.isFile&&raw.length()%4==0L&&clip.end<=raw.length()/4)
        StemCore.header(out,clip.frames);var last=-1
        RandomAccessFile(raw,"r").use{r->r.seek(clip.start*4);val buffer=ByteArray(65536);var i=0L
            while(i<clip.frames){check(!Thread.currentThread().isInterrupted){"Отменено"};val n=minOf(buffer.size/4L,clip.frames-i).toInt();r.readFully(buffer,0,n*4)
                if(clip.fadeIn>0||clip.fadeOut>0){for(f in 0 until n){val k=i+f;val a=if(clip.fadeIn==0L)1.0 else min(1.0,k.toDouble()/clip.fadeIn);val b=if(clip.fadeOut==0L)1.0 else min(1.0,(clip.frames-1-k).toDouble()/clip.fadeOut);val g=min(a,b);if(g<1.0)for(c in 0..1){val p=f*4+c*2;val x=((buffer[p].toInt() and 255) or (buffer[p+1].toInt() shl 8)).toShort();val y=(x*g).roundToInt();buffer[p]=y.toByte();buffer[p+1]=(y shr 8).toByte()}}}
                out.write(buffer,0,n*4);i+=n;val p=(i*100/clip.frames).toInt();if(p!=last){progress(p);last=p}
            }
        }
    }
    /** Copy an already canonical WAV exactly, including duration beyond the decoder limit.
     * Rejects extra chunks, partial data and inconsistent lengths. Caller owns temp cleanup. */
    fun copyCanonical(input:InputStream,out:OutputStream):Long {
        val header=ByteArray(44);DataInputStream(input).readFully(header)
        var bytes=0L;for(i in 0..3)bytes=bytes or ((header[40+i].toLong() and 255) shl (8*i))
        require(bytes>0&&bytes%4==0L)
        val expected=ByteArrayOutputStream().also{StemCore.header(it,bytes/4)}.toByteArray();require(header.contentEquals(expected)){"Не канонический WAV"}
        out.write(header);val b=ByteArray(65536);var remain=bytes
        while(remain>0){check(!Thread.currentThread().isInterrupted);val n=input.read(b,0,minOf(remain,b.size.toLong()).toInt());if(n<=0)throw EOFException("Оборванный WAV");out.write(b,0,n);remain-=n}
        require(input.read()==-1){"Лишние данные WAV"};return bytes/4
    }
    fun clipFromMs(start:Long,end:Long,fade:Long,frames:Long):Clip {require(start in 0..900000&&end in 1..900000&&fade in 0..10000);val a=start*44100/1000;val b=minOf(end*44100/1000,frames);val f=minOf(fade*44100/1000,(b-a)/2);return Clip(a,b,f,f)}
}
