package app.remix.player
import java.text.Normalizer
import java.util.Locale

/** Conservative text-to-timed-token alignment. Only completely matched lines receive word markers.
 * Incomplete reference lines are reported and never silently dropped or assigned invented times. */
object LyricAlign {
    data class Result(val lrc:String,val matched:Int,val total:Int,val unmatchedLines:List<Int>,val complete:Boolean,val ambiguous:Boolean=false)
    private data class Token(val normalized:String,val start:Int,val end:Int)
    private val word=Regex("[\\p{L}\\p{N}][\\p{L}\\p{N}\\p{M}]*(?:['’][\\p{L}\\p{N}][\\p{L}\\p{N}\\p{M}]*)*")
    private fun tokens(s:String)=word.findAll(s).map{m->Token(Normalizer.normalize(m.value,Normalizer.Form.NFKC).lowercase(Locale.ROOT).replace('’','\''),m.range.first,m.range.last+1)}.toList()
    fun align(timed:String,reference:String):Result {
        require(timed.length<=1_000_000&&reference.length<=100_000)
        val heard=ArrayList<Pair<String,Long>>()
        for(line in Lrc.parse(timed)){val parsed=WordLyrics.parse(line);for(w in parsed.words){val words=tokens(parsed.text.substring(w.start,w.end));if(words.size==1)heard.add(words[0].normalized to w.ms)}}
        require(heard.size in 1..3000&&heard.zipWithNext().all{it.first.second<=it.second.second}){"Нужен корректный текст с временными метками слов"}
        val lines=reference.lines().map{it.trim()}.filter{it.isNotBlank()};require(lines.size in 1..1000&&lines.none{it.any{c->c in "[]<>"}}){"Нужен обычный текст без служебных меток"}
        val byLine=lines.map(::tokens);val wanted=byLine.flatten();require(wanted.size in 1..3000&&byLine.all{it.isNotEmpty()})
        val n=wanted.size;val m=heard.size;val stride=m+1;val moves=ByteArray((n+1)*stride);var prev=IntArray(stride);var cur=IntArray(stride)
        // LCS, ties prefer retaining the earlier audible occurrence. A partial match cannot be saved silently.
        for(i in 1..n){check(!Thread.currentThread().isInterrupted);cur[0]=0;for(j in 1..m){val diag=if(wanted[i-1].normalized==heard[j-1].first)prev[j-1]+1 else -1;val up=prev[j];val left=cur[j-1];when{left>=diag&&left>=up->{cur[j]=left;moves[i*stride+j]=2};up>=diag->{cur[j]=up;moves[i*stride+j]=1};else->{cur[j]=diag;moves[i*stride+j]=3}}};val tmp=prev;prev=cur;cur=tmp}
        val matched=prev[m];val mapping=IntArray(n){-1};var i=n;var j=m;while(i>0&&j>0){when(moves[i*stride+j].toInt()){3->{mapping[i-1]=j-1;i--;j--};2->j--;else->i--}}
        var offset=0;val output=ArrayList<String>();val missing=ArrayList<Int>();var last=-1L
        lines.forEachIndexed{idx,line->val words=byLine[idx];val positions=words.indices.map{mapping[offset+it]};offset+=words.size
            // A repeated word may align to a distant occurrence; reject implausibly long gaps within a line.
            val ok=positions.all{it>=0}&&positions.zipWithNext().all{(a,b)->heard[b].second-heard[a].second in 0..3500}&&heard[positions.first()].second>last
            if(!ok){missing.add(idx+1)}else{val first=heard[positions.first()].second;val b=StringBuilder("[${SubtitleCore.stamp(first)}]");var cursor=0;for(k in words.indices){val w=words[k];b.append(line.substring(cursor,w.start));b.append('<').append(SubtitleCore.stamp(heard[positions[k]].second)).append('>');cursor=w.start};b.append(line.substring(cursor));output.add(b.toString());last=heard[positions.last()].second}
        }
        // If the entire text matches, ensure repeated choruses cannot silently attach to two different occurrences.
        var ambiguous=false
        if(matched==n&&missing.isEmpty()){
            val early=LongArray(n);val late=LongArray(n);var a=0;var b=m-1
            for(k in 0 until n){while(heard[a].first!=wanted[k].normalized)a++;early[k]=heard[a++].second}
            for(k in n-1 downTo 0){while(heard[b].first!=wanted[k].normalized)b--;late[k]=heard[b--].second}
            ambiguous=early.indices.any{early[it]!=late[it]}
        }
        return Result(output.joinToString("\n"),matched,n,missing,missing.isEmpty()&&matched==n&&!ambiguous,ambiguous)
    }
}
