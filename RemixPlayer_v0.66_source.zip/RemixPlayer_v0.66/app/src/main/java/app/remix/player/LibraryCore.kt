package app.remix.player

/** Pure, indexed library logic shared with the host regression tests. */
class LibraryIndex<T>(items: List<T>, private val id: (T)->String, group: (T)->String) {
    private val byId = items.associateBy(id)
    private val groups = items.groupBy(group)
    fun get(key:String?):T? = byId[key]
    fun versions(key:String):List<T> = groups[key].orEmpty()
    fun preferred(original:T, requested:String?):T = versions(id(original)).firstOrNull { id(it)==requested } ?: original
    fun queue(originals:List<T>, chosen:T, chosenGroup:String, preferredId:(String)->String?, limit:Int=300, choose:((T)->T)?=null):List<T> {
        require(limit in 1..1000)
        val selected=originals.indexOfFirst{ id(it)==chosenGroup }
        if(selected<0)return emptyList()
        // Bound IPC size and keep as many subsequent songs as possible.
        val start=(selected-limit/4).coerceIn(0,(originals.size-limit).coerceAtLeast(0))
        return originals.subList(start,minOf(originals.size,start+limit)).map { if(id(it)==chosenGroup)chosen else choose?.invoke(it) ?: preferred(it,preferredId(id(it))) }
    }
}
object PlaybackBookmark {
    fun position(value:Long,duration:Long):Long = if(duration>0) value.coerceIn(0,(duration-1).coerceAtLeast(0)) else value.coerceAtLeast(0)
    fun transfer(position:Long,fromRatio:Double?,toRatio:Double?):Long {
        if(fromRatio==null||toRatio==null||!fromRatio.isFinite()||!toRatio.isFinite()||fromRatio<=0||toRatio<=0)return 0
        return (position.coerceAtLeast(0)*fromRatio/toRatio).toLong().coerceAtLeast(0)
    }
}

/** Recover independently readable rows. Never infer relationships from ambiguous broken chains. */
object LibraryRecovery {
    /** Remap playlist members to existing originals and isolate malformed rows. */
    fun playlist(count:Int,read:(Int)->String,groupOf:(String)->String?):Set<String>{
        val result=linkedSetOf<String>();for(i in 0 until count.coerceIn(0,60000)){
            val id=try{read(i)}catch(e:Exception){if(e is InterruptedException)throw e;continue}
            if(id.isNotBlank()&&id.length<=8192)groupOf(id)?.let{result.add(it)}
        };return result
    }
    data class Result<T>(val items:List<T>,val skipped:Int,val repaired:Int)
    fun <T> recover(count:Int,read:(Int)->T,id:(T)->String,group:(T)->String,promote:(T)->T):Result<T>{
        require(count>=0)
        val byId=LinkedHashMap<String,T>();var skipped=0
        for(i in 0 until count){
            // Do not swallow cancellation, VM failures or memory exhaustion.
            val item=try{read(i)}catch(e:Exception){if(e is InterruptedException)throw e;skipped++;continue}
            val key=id(item)
            if(key.isBlank()||key in byId){skipped++;continue}
            byId[key]=item
        }
        var repaired=0
        val items=byId.values.map{item->val target=byId[group(item)]
            if(target==null||group(target)!=id(target)){repaired++;promote(item)}else item}
        return Result(items,skipped,repaired)
    }
}

/** Materialize inherited timestamps before changing the original; never guess a new tempo ratio. */
object GroupLyrics {
    fun preserve(own:String,original:String,ratio:Double?):String = if(own.isNotBlank())own else if(ratio!=null&&ratio.isFinite()&&ratio in .4..1.8)TimeStretch.lyrics(original,ratio)else ""
}
