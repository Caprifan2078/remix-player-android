package app.remix.player
import java.io.File
import java.net.URI
import java.net.HttpURLConnection
import java.security.MessageDigest
object VerifiedDownload {
    fun matches(file:File,expected:String):Boolean {require(expected.matches(Regex("[a-fA-F0-9]{64}")));val digest=MessageDigest.getInstance("SHA-256");file.inputStream().buffered().use{input->val b=ByteArray(65536);while(true){val n=input.read(b);if(n<0)break;digest.update(b,0,n)}};return digest.digest().joinToString(""){"%02x".format(it)}.equals(expected,true)}
    fun fetch(url:String,sha:String,file:File,progress:(Int)->Unit){require(sha.matches(Regex("[a-fA-F0-9]{64}")));val uri=URI(url.trim());require(uri.scheme=="https"&&uri.host!=null&&uri.userInfo==null&&uri.fragment==null);require(!file.exists());val c=uri.toURL().openConnection() as HttpURLConnection
        try{c.instanceFollowRedirects=false;c.connectTimeout=15000;c.readTimeout=15000;require(c.responseCode==200){"HTTP ${c.responseCode}"};val max=600L*1024*1024;val len=c.contentLengthLong;require(len<=max);var total=0L;var prev=-1;c.inputStream.buffered().use{input->file.outputStream().buffered().use{out->val b=ByteArray(65536);while(true){check(!Thread.currentThread().isInterrupted);val n=input.read(b);if(n<0)break;total+=n;require(total<=max&&file.parentFile!!.usableSpace>16L*1024*1024);out.write(b,0,n);if(len>0){val p=(100*total/len).toInt().coerceIn(0,100);if(p!=prev){prev=p;progress(p)}}}}};require(total>0&&(len<0||len==total));require(matches(file,sha)){"SHA-256 не совпадает"};progress(100)}catch(e:Throwable){file.delete();throw e}finally{c.disconnect()}}
}
