package app.remix.player

/** Blockwise stereo analysis downmix. Negative correlation uses a difference signal,
 * with a short coefficient ramp to avoid artificial clicks at block boundaries.
 * Only the analysis signal is affected; original and rendered stereo remain intact. */
class AnalysisMono(private val emit:(Double)->Unit){
    private val left=DoubleArray(1024);private val right=DoubleArray(1024);private var size=0
    private var initialized=false;private var priorL=.5;private var priorR=.5
    fun frame(l:Double,r:Double){left[size]=l.takeIf{it.isFinite()}?.coerceIn(-1.0,1.0)?:0.0;right[size]=r.takeIf{it.isFinite()}?.coerceIn(-1.0,1.0)?:0.0;if(++size==left.size)flush()}
    fun finish(){flush()}
    private fun flush(){if(size==0)return;var ll=0.0;var rr=0.0;var lr=0.0;for(i in 0 until size){ll+=left[i]*left[i];rr+=right[i]*right[i];lr+=left[i]*right[i]}
        val correlation=if(ll*rr>1e-16)lr/kotlin.math.sqrt(ll*rr) else 0.0
        val a:Double;val b:Double
        when{ll>rr*16->{a=1.0;b=0.0};rr>ll*16->{a=0.0;b=1.0};correlation<-.65->{a=.5;b=-.5};else->{a=.5;b=.5}}
        if(!initialized){priorL=a;priorR=b;initialized=true}
        for(i in 0 until size){val t=(i/128.0).coerceIn(0.0,1.0);emit(left[i]*(priorL+(a-priorL)*t)+right[i]*(priorR+(b-priorR)*t))};priorL=a;priorR=b;size=0
    }
}
