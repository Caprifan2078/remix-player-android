package app.remix.player

import android.content.Context
import android.net.Uri
import java.io.File
import kotlin.math.sqrt

/** Optional local native Whisper backend; the model stays in private storage. */
object WhisperLocal {
    val available:Boolean by lazy{runCatching{System.loadLibrary("remixwhisper")}.isSuccess}
    // Retain the old private path for upgrade compatibility.
    fun model(c:Context)=File(c.filesDir,"whisper-tiny.bin")
    fun installed(c:Context)=WhisperModelSpec.bySize(model(c).length())
    private fun checkMemory(c:Context,spec:WhisperModelSpec.Model){
        val am=c.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val info=android.app.ActivityManager.MemoryInfo();am.getMemoryInfo(info)
        require(!info.lowMemory&&info.availMem>=spec.minFreeRam){"Недостаточно свободной ОЗУ для ${spec.id}; выберите меньшую модель"}
    }
    private external fun open(path:String):Long
    private external fun recognize(handle:Long,pcm:FloatArray,language:String,threads:Int):ByteArray?
    private external fun close(handle:Long)
    fun install(c:Context,uri:Uri):String{
        require(available){"Whisper не включён в сборку"};val tmp=File.createTempFile("whisper-",".bin",c.filesDir)
        try{
            c.contentResolver.openInputStream(uri)?.use{input->tmp.outputStream().buffered().use{out->val buf=ByteArray(65536);var size=0L;while(true){check(!Thread.currentThread().isInterrupted);val n=input.read(buf);if(n<0)break;size+=n;require(size<=WhisperModelSpec.maxBytes&&c.filesDir.usableSpace>16L*1024*1024){"Файл слишком большой или недостаточно места"};out.write(buf,0,n)}}}?:error("Файл не открывается")
            val spec=WhisperModelSpec.bySize(tmp.length())?:error("Неподдерживаемый размер: выберите ggml-tiny, base или small")
            require(VerifiedDownload.matches(tmp,spec.sha)){"SHA-256 не совпадает"};checkMemory(c,spec)
            val h=open(tmp.absolutePath);check(h!=0L){"Не удалось загрузить Whisper"};close(h);check(!Thread.currentThread().isInterrupted)
            java.nio.file.Files.move(tmp.toPath(),model(c).toPath(),java.nio.file.StandardCopyOption.ATOMIC_MOVE,java.nio.file.StandardCopyOption.REPLACE_EXISTING)
            return spec.id
        }finally{tmp.delete()}
    }
    fun transcribe(c:Context,uri:Uri,stem:StemEngine.Bundle?,language:String,status:(String)->Unit):String{
        require(available){"Whisper не включён в сборку"};val spec=installed(c)?:error("Установите Whisper");checkMemory(c,spec);require(language in listOf("auto","ru","en","es","pt","ja"));val tmp=if(stem==null)File.createTempFile("whisper-src-",".pcm",c.cacheDir)else null;val result=ArrayList<WhisperSegments.Window>();var handle=0L
        try{if(tmp!=null){status("Декодирование…");StemEngine.decode(c,uri,tmp)};val source=tmp?:File(stem!!.dir,"3.pcm");require(source.length() in 4..(900L*44100*4)&&source.length()%4==0L);handle=open(model(c).absolutePath);check(handle!=0L){"Не удалось загрузить Whisper"};val block=FloatArray(16000*25);val overlap=16000*2;var n=0;var start=0L;var fresh=0;val filter=VocalConditioning.Filter()
            fun flush(full:Boolean){if(n==0||fresh==0)return;check(!Thread.currentThread().isInterrupted);val ms=n*1000L/16000
                if(ms>=250){var sum=0.0;for(i in 0 until n)sum+=block[i].toDouble()*block[i];val offset=start*1000/16000
                    val segments=if(sqrt(sum/n)>.001){val out=recognize(handle,block.copyOf(n),language,Runtime.getRuntime().availableProcessors().coerceIn(1,4))?:error("Ошибка инференса Whisper");check(!Thread.currentThread().isInterrupted);WhisperSegments.parse(out.toString(Charsets.UTF_8),offset,ms)}else emptyList()
                    result.add(WhisperSegments.Window(offset,offset+ms,segments))
                };status("Whisper: ${(start+n)/16000} с")
                if(full){block.copyInto(block,0,n-overlap,n);start+=n-overlap;n=overlap;fresh=0}else{n=0;fresh=0}
            }
            source.inputStream().buffered(65536).use{input->SubtitleCore.mono16k(input,adaptive=true){block[n++]=filter.sample(it)/32768f;fresh++;if(n==block.size)flush(true)}};flush(false);return WhisperSegments.lrc(WhisperSegments.merge(result)).also{require(it.isNotBlank()){ "Whisper не нашёл текст" }}
        }finally{if(handle!=0L)close(handle);tmp?.delete()}}
}
