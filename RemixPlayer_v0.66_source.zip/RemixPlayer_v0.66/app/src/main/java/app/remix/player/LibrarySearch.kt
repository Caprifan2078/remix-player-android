package app.remix.player

import java.text.Normalizer
import java.util.Locale

/** Each result belongs to one original. Query terms must match one version (plus its original), not unrelated siblings. */
class LibrarySearch<T>(items:List<T>, private val id:(T)->String, group:(T)->String, fields:(T)->List<String>){
    private data class Row<T>(val item:T,val text:String)
    private val roots=items.filter{ id(it)==group(it) }.associateBy(id)
    private val rootText=roots.mapValues{(_,item)->normalize(fields(item).joinToString(" "))}
    private val rows=items.filter{group(it) in roots}.groupBy(group).mapValues{(key,versions)->versions.map{Row(it, if(id(it)==key)rootText.getValue(key)else rootText.getValue(key)+" "+normalize(fields(it).joinToString(" ")))}}
    data class Match<T>(val original:T,val originalMatches:Boolean,val versions:List<T>)
    private var previousTerms:List<String>?=null
    private var previousResult:Map<String,Match<T>> = emptyMap()
    @Synchronized fun find(query:String):Map<String,Match<T>>{
        val terms=normalize(query).split(' ').filter{it.isNotEmpty()}.distinct()
        val old=previousTerms
        if(old==terms)return previousResult
        if(terms.isEmpty()){
            previousTerms=terms
            previousResult=roots.mapValues{(_,root)->Match(root,true,emptyList())}
            return previousResult
        }
        // Every previous term must still be implied by a new term. Otherwise a deleted
        // word or changed spelling can bring back groups, so start from the entire index.
        val keys=if(old!=null&&old.isNotEmpty()&&old.all{prior->terms.any{it.contains(prior)}})previousResult.keys else roots.keys
        val out=linkedMapOf<String,Match<T>>()
        for(key in keys){
            val root=roots.getValue(key)
            val originalMatches=terms.all{rootText.getValue(key).contains(it)}
            val versions=rows[key].orEmpty().filter{row->id(row.item)!=key&&terms.all{row.text.contains(it)}}.map{it.item}
            if(originalMatches||versions.isNotEmpty())out[key]=Match(root,originalMatches,versions)
        }
        previousTerms=terms;previousResult=out
        return out
    }
    companion object{
        private val marks=Regex("\\p{M}+")
        private val separators=Regex("[^\\p{L}\\p{N}]+")
        fun normalize(s:String):String=Normalizer.normalize(s.lowercase(Locale.ROOT),Normalizer.Form.NFKD)
            .replace(marks,"").replace(separators," ").trim()
    }
}
