package app.remix.player
import kotlin.math.*

/** Continuous local tempo grid. Integrates rates, never jumps phase at a window boundary.
 * Local BPM estimates are not downbeat observations. */
class AdaptiveGroove(private val bpm:Double,private val phase:Double,windows:List<RhythmMap.Window> = emptyList(),reference:Double=bpm,private val rate:Int=44100,anchor:Double=phase){
    private data class Knot(val t:Double,val v:Double,val integral:Double)
    private val knots:List<Knot>
    private val offset:Double
    init{require(bpm in 50.0..220.0&&phase.isFinite()&&anchor.isFinite()&&anchor>=0&&reference.isFinite()&&reference>0&&rate>0)
        val observations=windows.filter{it.start.isFinite()&&it.end.isFinite()&&it.start>=0&&it.end>it.start&&it.end<=900&&it.bpm in 50.0..220.0&&it.confidence>=.45}.sortedBy{it.start}.take(100)
        val points=mutableListOf(0.0 to bpm)
        for(w in observations){val center=(w.start+w.end)/2;val local=(bpm*RhythmMap.relative(w.bpm,reference)/reference).coerceIn(bpm*.70,bpm*1.30);if(center>points.last().first){if(w.start-points.last().first>20)points.add(w.start to bpm);points.add(center to local)}}
        if(observations.isNotEmpty()){val end=observations.last().end;if(end>points.last().first)points.add(end to points.last().second)}
        var sum=0.0;knots=points.mapIndexed{i,(t,v)->if(i>0){val(a,b)=points[i-1];sum+=(t-a)*(b+v)/2};Knot(t,v,sum)}
        // Anchor an actual beat in the integrated tempo map, not in a constant-BPM approximation.
        val a=knots.last { it.t<=anchor };val b=knots.getOrNull(knots.indexOf(a)+1);val dt=anchor-a.t
        val area=a.integral+a.v*dt+(if(b==null)0.0 else (b.v-a.v)*dt*dt/(2*(b.t-a.t)))
        offset=if(anchor==phase)area else ((area%60)+60)%60
        
    }
    private var cursor=0;private var previousFrame=Long.MIN_VALUE;private var previousPosition=0.0
    fun position(frame:Long):Double{if(frame==previousFrame)return previousPosition;val t=frame.toDouble()/rate
        while(cursor<knots.lastIndex&&t>=knots[cursor+1].t)cursor++
        while(cursor>0&&t<knots[cursor].t)cursor--
        val a=knots[cursor];val dt=t-a.t;val b=knots.getOrNull(cursor+1)
        val area=if(b==null)a.v*dt else a.v*dt+(b.v-a.v)*dt*dt/(2*(b.t-a.t))
        previousFrame=frame;previousPosition=(a.integral+area-offset)/15.0;return previousPosition
    }
}

/** Genre-specific oscillator percussion. Every voice is synthesized, not sampled. */
object DrumPalette {
    data class Voice(val kickHz:Double,val sweepHz:Double,val decay:Double,val snareHz:Double,val hatHz:Double,val fill:Boolean,val swing:Double)
    fun voice(style:GenreEngine.Style):Voice=when(style.name){
        "Hardstyle","Rawstyle","Hardcore","Frenchcore","Hardtekk","Hard Techno"->Voice(49.0,155.0,.15,185.0,7800.0,true,.0)
        "Drift Phonk","Brazilian Phonk","Memphis Phonk","House Phonk","Montagem","Automotivo","Krushfunk","Brazilian Funk"->Voice(42.0,110.0,.12,230.0,6500.0,true,.055)
        "Drum & Bass","Breakcore"->Voice(58.0,100.0,.075,205.0,8800.0,true,.025)
        "Lo-Fi","Synthwave"->Voice(54.0,62.0,.09,165.0,4800.0,false,.075)
        "Amapiano","Afro House"->Voice(47.0,75.0,.105,260.0,5900.0,true,.10)
        "Trap","Dubstep"->Voice(40.0,95.0,.14,210.0,8200.0,true,.045)
        "UK Garage","Speed Garage","Jersey Club"->Voice(55.0,100.0,.09,245.0,7400.0,true,.12)
        else->Voice(51.0,90.0,.10,195.0,7100.0,true,.025)
    }
    fun swing(position:Double,amount:Double):Double{val base=floor(position/2)*2;val x=position-base;val midpoint=1+amount;return base+if(x<midpoint)x/midpoint else 1+(x-midpoint)/(2-midpoint)}
    fun fill(step:Long,voice:Voice):Boolean=voice.fill&&Math.floorMod(step,64L) in 60L..63L
}
