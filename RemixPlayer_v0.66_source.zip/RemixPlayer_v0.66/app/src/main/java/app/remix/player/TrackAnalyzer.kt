package app.remix.player
import android.content.Context
import android.media.*
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.*

/** Quick analysis: up to 120 seconds; full mode: up to 15 minutes with a 5-minute deadline. BPM envelope uses first 120 seconds; harmony/energy cover all decoded frames. */
object TrackAnalyzer {
    fun analyze(context: Context, uri: Uri): Tempo.Result? = report(context,uri)?.tempo
    fun report(context: Context, uri: Uri, full:Boolean=false): MusicAnalysis.Report? {
        val extractor=MediaExtractor();var codec:MediaCodec?=null
        try {
            extractor.setDataSource(context,uri,null)
            val track=(0 until extractor.trackCount).firstOrNull{extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/")==true}?:return null
            extractor.selectTrack(track);val format=extractor.getTrackFormat(track);val mime=format.getString(MediaFormat.KEY_MIME)?:return null
            val decoder=MediaCodec.createDecoderByType(mime);codec=decoder;decoder.configure(format,null,null,0);decoder.start()
            var rate=format.getInteger(MediaFormat.KEY_SAMPLE_RATE);var channels=format.getInteger(MediaFormat.KEY_CHANNEL_COUNT);var encoding=AudioFormat.ENCODING_PCM_16BIT
            if(rate !in 8000..384000)return null;var inputDone=false;var outputDone=false;val info=MediaCodec.BufferInfo();var analyzer=MusicAnalysis.Analyzer(rate);var mono=AnalysisMono{analyzer.sample(it)};var frames=0L;var idle=0;val limit=if(full)900L else 120L;val deadline=android.os.SystemClock.elapsedRealtime()+(if(full)300000L else 45000L)
            while(!outputDone&&frames<rate*limit&&idle<150&&android.os.SystemClock.elapsedRealtime()<deadline&&!Thread.currentThread().isInterrupted){var progressed=false
                if(!inputDone){val index=decoder.dequeueInputBuffer(5000);if(index>=0){val buf=decoder.getInputBuffer(index)?:error("No input buffer");buf.clear();val size=extractor.readSampleData(buf,0);if(size<0){decoder.queueInputBuffer(index,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputDone=true}else{decoder.queueInputBuffer(index,0,size,extractor.sampleTime,0);extractor.advance()};progressed=true}}
                when(val index=decoder.dequeueOutputBuffer(info,5000)){
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED->{val f=decoder.outputFormat;val nextRate=f.getInteger(MediaFormat.KEY_SAMPLE_RATE);if(frames>0&&nextRate!=rate)return null;rate=nextRate;channels=f.getInteger(MediaFormat.KEY_CHANNEL_COUNT);encoding=if(f.containsKey(MediaFormat.KEY_PCM_ENCODING))f.getInteger(MediaFormat.KEY_PCM_ENCODING)else AudioFormat.ENCODING_PCM_16BIT;if(frames==0L){if(rate !in 8000..384000)return null;analyzer=MusicAnalysis.Analyzer(rate);mono=AnalysisMono{analyzer.sample(it)}};progressed=true}
                    else->if(index>=0){val b=decoder.getOutputBuffer(index);if(b!=null&&info.size>0&&info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG==0){b.position(info.offset);b.limit(info.offset+info.size);b.order(ByteOrder.nativeOrder());val bytes=if(encoding==AudioFormat.ENCODING_PCM_FLOAT)4 else 2;if(encoding!=AudioFormat.ENCODING_PCM_FLOAT&&encoding!=AudioFormat.ENCODING_PCM_16BIT)return null;if(channels<=0||rate<=0)return null
                        while(b.remaining()>=channels*bytes&&frames<rate*limit){var sum=0.0;var l=0.0;var r=0.0;repeat(channels){c->val v=if(bytes==4)b.float.toDouble()else b.short/32768.0;val safe=v.takeIf{it.isFinite()}?:0.0;sum+=safe;if(c==0)l=safe;if(c==1)r=safe};if(channels==2)mono.frame(l,r)else{mono.finish();analyzer.sample(sum/channels)};frames++}}
                        decoder.releaseOutputBuffer(index,false);outputDone=info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM!=0;progressed=true}
                };idle=if(progressed)0 else idle+1
            };check(!Thread.currentThread().isInterrupted){"Отменено"};if(full)check(outputDone){"Не удалось завершить полный анализ (лимит 15 минут или тайм-аут)"};mono.finish();return analyzer.finish().takeIf{it.duration>0}
        } finally {runCatching{codec?.stop()};runCatching{codec?.release()};extractor.release()}
    }
}
