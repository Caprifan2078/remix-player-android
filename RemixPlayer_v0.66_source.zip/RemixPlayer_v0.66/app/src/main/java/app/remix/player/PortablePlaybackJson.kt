package app.remix.player

import org.json.JSONArray
import org.json.JSONObject

/** Format v1 is optional inside the existing ZIP format. */
object PortablePlaybackJson {
    data class Data(val controls:PortablePlayback.Controls,val queue:PortablePlayback.Queue?,val gains:Map<Int,List<Float>>,val history:Map<Int,ListeningStats.Entry>)
    fun encode(data:Data):JSONObject {
        val c=data.controls;val g=JSONObject();data.gains.forEach{(i,v)->g.put(i.toString(),JSONArray(v.map{it.toDouble()}))}
        val h=JSONObject();data.history.forEach{(i,v)->h.put(i.toString(),JSONObject().put("ms",v.playedMs).put("last",v.lastMs))}
        val o=JSONObject().put("version",1).put("eq",JSONArray(c.eq.map{it.toDouble()})).put("mix",JSONArray(c.mix.map{it.toDouble()})).put("fade",c.fadeMs).put("overlap",c.overlapMs).put("random",c.randomVersions).put("gains",g).put("history",h)
        data.queue?.let{q->o.put("queue",JSONObject().put("rows",JSONArray(q.rows)).put("index",q.index).put("position",q.position).put("duration",q.duration).put("shuffle",q.shuffle).put("repeat",q.repeat))};return o
    }
    fun decode(o:JSONObject,ids:List<String>):Data {
        require(o.getInt("version")==1);fun floats(a:JSONArray,n:Int):List<Float>{require(a.length()==n);return List(n){a.getDouble(it).toFloat()}}
        val c=PortablePlayback.Controls(floats(o.getJSONArray("eq"),10),floats(o.getJSONArray("mix"),6),o.getLong("fade"),o.getLong("overlap"),o.getBoolean("random"))
        val q=o.optJSONObject("queue")?.let{v->val a=v.getJSONArray("rows");require(a.length() in 1..QueueSnapshot.LIMIT);PortablePlayback.Queue(List(a.length()){a.getInt(it)},v.getInt("index"),v.getLong("position"),v.getLong("duration"),v.getBoolean("shuffle"),v.getInt("repeat")).also{it.remap(ids)}}
        val g=linkedMapOf<Int,List<Float>>();o.getJSONObject("gains").let{v->require(v.length()<=ids.size);v.keys().forEach{k->val i=k.toInt();require(i in ids.indices&&i !in g);val a=v.getJSONArray(k);require(a.length() in listOf(4,6));g[i]=floats(a,a.length()).also{require(PortablePlayback.validGains(it))}}}
        val h=linkedMapOf<Int,ListeningStats.Entry>();o.getJSONObject("history").let{v->require(v.length()<=2000);v.keys().forEach{k->val i=k.toInt();require(i in ids.indices&&i !in h);val a=v.getJSONObject(k);val ms=a.getLong("ms");val last=a.getLong("last");require(ms>0&&last>=0);h[i]=ListeningStats.Entry(ids[i],ms,last)}}
        return Data(c,q,g,h)
    }
}
