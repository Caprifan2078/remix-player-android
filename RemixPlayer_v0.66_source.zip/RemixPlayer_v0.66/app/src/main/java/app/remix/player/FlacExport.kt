package app.remix.player
import java.io.*

/** Lossless FLAC: constant, verbatim and fixed-predictor subframes with Rice coding. */
object FlacExport {
    private fun OutputStream.be(v:Long,n:Int){for(i in n-1 downTo 0)write((v shr (8*i)).toInt() and 255)}
    private fun crc(bytes:ByteArray,bits:Int,poly:Int):Int{var v=0;val mask=(1 shl bits)-1;for(b in bytes){v=v xor ((b.toInt() and 255) shl (bits-8));repeat(8){v=if(v and (1 shl (bits-1))!=0)((v shl 1) xor poly) and mask else (v shl 1) and mask}};return v}
    private fun OutputStream.number(n:Int){if(n<128){write(n);return};val size=if(n<2048)2 else if(n<65536)3 else 4;write(((255 shl (8-size)) and 255) or (n shr (6*(size-1))));for(i in size-2 downTo 0)write(128 or ((n shr (i*6)) and 63))}
    private class Bits(val out:OutputStream){var byte=0;var used=0
        fun put(v:Int,n:Int){for(i in n-1 downTo 0){byte=(byte shl 1) or ((v ushr i) and 1);if(++used==8){out.write(byte);used=0;byte=0}}}
        fun unary(q:Int){require(q>=0);var n=q;while(n>0&&used!=0){put(0,1);n--};while(n>=8){out.write(0);n-=8};put(0,n);put(1,1)}
        fun finish(){if(used>0)put(0,8-used)}
    }
    private fun residual(s:IntArray,i:Int,order:Int):Int=when(order){0->s[i];1->s[i]-s[i-1];2->s[i]-2*s[i-1]+s[i-2];3->s[i]-3*s[i-1]+3*s[i-2]-s[i-3];else->s[i]-4*s[i-1]+6*s[i-2]-4*s[i-3]+s[i-4]}
    private fun unsigned(v:Int)=(v shl 1) xor (v shr 31)
    private fun subframe(bits:Bits,s:IntArray,n:Int){
        if((1 until n).all{s[it]==s[0]}){bits.put(0,8);bits.put(s[0],16);return}
        var bestCost=n*16L;var bestOrder=-1;var bestK=0
        // No escape coding; choose verbatim if no Rice representation is smaller.
        for(order in 0..minOf(4,n-1)){
            val sums=LongArray(15)
            for(i in order until n){val u=unsigned(residual(s,i,order));for(k in 0..14)sums[k]+=(u ushr k).toLong()}
            for(k in 0..14){val cost=order*16L+10L+sums[k]+(n-order).toLong()*(k+1);if(cost<bestCost){bestCost=cost;bestOrder=order;bestK=k}}
        }
        if(bestOrder<0){bits.put(2,8);for(i in 0 until n)bits.put(s[i],16);return}
        bits.put((8+bestOrder) shl 1,8);for(i in 0 until bestOrder)bits.put(s[i],16)
        bits.put(0,2);bits.put(0,4);bits.put(bestK,4)
        for(i in bestOrder until n){val u=unsigned(residual(s,i,bestOrder));bits.unary(u ushr bestK);bits.put(u,bestK)}
    }
    fun encode(input:InputStream,out:OutputStream){val h=ByteArray(44);DataInputStream(input).readFully(h);fun tag(i:Int,s:String)=h.copyOfRange(i,i+s.length).contentEquals(s.toByteArray(Charsets.US_ASCII))
        fun le(i:Int,n:Int):Long{var v=0L;for(k in 0 until n)v=v or ((h[i+k].toLong() and 255) shl (8*k));return v}
        require(tag(0,"RIFF")&&tag(8,"WAVEfmt ")&&tag(36,"data")&&le(16,4)==16L&&le(20,2)==1L&&le(22,2)==2L&&le(24,4)==44100L&&le(34,2)==16L&&le(32,2)==4L&&le(28,4)==176400L){"Нужен созданный приложением PCM WAV 44.1 кГц"}
        val size=le(40,4);require(size>0&&size%4==0L&&le(4,4)==size+36);val frames=size/4;val block=4096
        out.write("fLaC".toByteArray());out.write(128);out.be(34,3);out.be(block.toLong(),2);out.be(block.toLong(),2);out.be(0,3);out.be(0,3);out.be((44100L shl 44) or (1L shl 41) or (15L shl 36) or frames,8);out.write(ByteArray(16))
        val pcm=Array(2){IntArray(block)};var remaining=frames;var index=0
        while(remaining>0){check(!Thread.currentThread().isInterrupted){"Отменено"};val n=minOf(block.toLong(),remaining).toInt();for(i in 0 until n)for(c in 0..1)pcm[c][i]=StemCore.readShort(input).toInt()
            val f=ByteArrayOutputStream(n*4+32);f.write(byteArrayOf(0xff.toByte(),0xf8.toByte(),0x79,0x18));f.number(index++);f.be((n-1).toLong(),2);f.write(crc(f.toByteArray(),8,7));val bits=Bits(f);for(c in 0..1)subframe(bits,pcm[c],n);bits.finish();val raw=f.toByteArray();out.write(raw);out.be(crc(raw,16,0x8005).toLong(),2);remaining-=n
        };out.flush()
    }
}
