package app.remix.player

/** Identity is independent of duration: a timeline refresh may refine the duration. */
object PlayerUiSafety {
    data class Target(val mixer:Boolean,val id:String,val generation:Long)
    fun seekPosition(captured:Target?, current:Target?, duration:Long, progress:Int):Long? {
        if(captured==null || captured!=current || duration<=0) return null
        val p=progress.coerceIn(0,1000)
        return (duration/1000)*p+(duration%1000)*p/1000
    }
    /** A power-of-two sample factor with rounded-up dimension bound. */
    fun coverSample(width:Int,height:Int,limit:Int=768):Int? {
        if(width<=0||height<=0||limit<2)return null
        val largest=maxOf(width,height).toLong();var sample=1
        while((largest+sample-1)/sample>limit)sample*=2
        return sample
    }
}
