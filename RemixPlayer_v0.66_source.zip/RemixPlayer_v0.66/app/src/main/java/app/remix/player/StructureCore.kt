package app.remix.player
import kotlin.math.*
/** Order-sensitive repeated chord progression detection; not semantic verse/chorus labels. */
object StructureCore {
    fun repetitions(report:MusicAnalysis.Report):List<RemixAdvisor.Repetition>{
        val slots=(report.duration*2).toInt().coerceIn(0,1800);if(slots<48)return emptyList()
        val grid=IntArray(slots){-1};val confidence=DoubleArray(slots)
        for(c in report.chords){if(!c.seconds.isFinite()||!c.confidence.isFinite()||c.confidence<.075||c.root !in 0..11)continue;val i=(c.seconds*2).roundToInt();if(i in grid.indices&&c.confidence>confidence[i]){grid[i]=c.root+if(c.minor)12 else 0;confidence[i]=c.confidence}}
        val out=ArrayList<RemixAdvisor.Repetition>()
        for(a in 0..slots-16 step 4){if(grid.sliceArray(a until a+16).filter{it>=0}.distinct().size<2)continue
            for(b in a+16..slots-16 step 4){var best=0.0;for(shift in -1..1){var compared=0;var same=0;for(k in 0 until 16){val j=b+k+shift;if(j !in grid.indices)continue;val x=grid[a+k];val y=grid[j];if(x>=0&&y>=0){compared++;if(x==y)same++}};if(compared>=12)best=max(best,same/compared.toDouble())};if(best>=.88){out.add(RemixAdvisor.Repetition(a/2.0,b/2.0,8.0,best))}}
        }
        val selected=mutableListOf<RemixAdvisor.Repetition>();for(r in out.sortedByDescending{it.similarity}){if(selected.none{abs(it.first-r.first)<4&&abs(it.second-r.second)<4})selected.add(r);if(selected.size==8)break};return selected
    }
    fun profile(r:MusicAnalysis.Report):List<String>{val result=mutableListOf<String>();r.tempo?.let{result.add(when{it.bpm<95->"Медленный темп";it.bpm<140->"Средний темп";else->"Быстрый темп"})};r.key?.let{result.add(if(it.endsWith("minor"))"Минорная тональность" else "Мажорная тональность")};val e=r.energy.filter{it.isFinite()&&it>=0};if(e.isNotEmpty()&&e.average()>.001){val avg=e.average();val cv=sqrt(e.map{(it-avg).pow(2)}.average())/avg;result.add(if(cv>.45)"Контрастная динамика" else "Ровная динамика")};return result}
}
