package app.remix.player

/** Only portable preferences. No tokens, model paths, live timers or URI permissions. */
object PortablePlayback {
    data class Controls(val eq:List<Float>,val mix:List<Float>,val fadeMs:Long,val overlapMs:Long,val randomVersions:Boolean){
        init{require(eq.size==10&&eq.all{it.isFinite()&&it in -12f..12f});require(mix.size==6&&mix.all{it.isFinite()&&it in 0f..2f});require(fadeMs in 0..5000);require(overlapMs==0L||overlapMs in 1000..8000)}
    }
    data class Queue(val rows:List<Int>,val index:Int,val position:Long,val duration:Long,val shuffle:Boolean,val repeat:Int){
        init{require(rows.size in 1..QueueSnapshot.LIMIT&&rows.all{it>=0}&&index in rows.indices&&position>=0&&duration>=0&&repeat in 0..2)}
        fun remap(ids:List<String>):QueueSnapshot.Saved{require(rows.all{it in ids.indices});return QueueSnapshot.Saved(rows.map{ids[it]},index,PlaybackBookmark.position(position,duration),duration,shuffle,repeat)}
    }
    fun captureQueue(saved:QueueSnapshot.Saved,indices:Map<String,Int>):Queue?{
        val restored=QueueSnapshot.restore(saved){indices[it]}?:return null
        return Queue(restored.items,restored.index,restored.position,saved.duration.coerceAtLeast(0),restored.shuffle,restored.repeat)
    }
    fun validGains(values:List<Float>)=values.size in listOf(4,6)&&values.all{it.isFinite()&&it in 0f..1f}
    fun mergeHistory(existing:List<ListeningStats.Entry>,incoming:List<ListeningStats.Entry>):List<ListeningStats.Entry> =
        (existing+incoming).filter{it.id.isNotBlank()&&it.playedMs>0&&it.lastMs>=0}.groupBy{it.id}.values.map{rows->rows.maxWithOrNull(compareBy<ListeningStats.Entry>{it.playedMs}.thenBy{it.lastMs})!!}.sortedByDescending{it.lastMs}.take(2000)
}
