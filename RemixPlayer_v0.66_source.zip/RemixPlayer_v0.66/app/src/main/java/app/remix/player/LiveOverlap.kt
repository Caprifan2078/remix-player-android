package app.remix.player

import android.content.Context
import android.os.SystemClock
import androidx.media3.common.C
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer

/** Optional two-decoder overlap. Primary player owns audio focus and the MediaSession.
 * Main looper only. The preview never requests focus. No DSP/loop/speed changes during overlap.
 * Aborts on a stale queue, a seek, paused/buffering primary, or decoder failure.
 */
@UnstableApi
class LiveOverlap(private val context:Context,private val main:ExoPlayer) {
    private var preview:ExoPlayer?=null
    private var from=-1;private var to=-1;private var fromId="";private var toId=""
    private var started=false;private var handing=false;private var handoffAt=0L;private var handoffTarget=-1L;private var internalSeek=false;private var autoPending=false
    private var lastPosition=-1L;private var lastTime=0L;private var rejectedId:String?=null
    private val listener=object:Player.Listener {
        override fun onPositionDiscontinuity(oldPosition:Player.PositionInfo,newPosition:Player.PositionInfo,reason:Int){
            if(internalSeek||(handing&&reason==Player.DISCONTINUITY_REASON_SEEK&&newPosition.mediaItemIndex==to&&kotlin.math.abs(newPosition.positionMs-handoffTarget)<150))return
            if(reason==Player.DISCONTINUITY_REASON_AUTO_TRANSITION&&started&&newPosition.mediaItemIndex==to){autoPending=true;return}
            if(preview!=null)abort(true)
        }
        override fun onTimelineChanged(timeline:androidx.media3.common.Timeline,reason:Int){if(preview!=null&&!queueMatches())abort(true)}
        override fun onPlayWhenReadyChanged(playWhenReady:Boolean,reason:Int){if(!playWhenReady)abort(true)}
    }
    init{main.addListener(listener)}
    private fun queueMatches():Boolean=from in 0 until main.mediaItemCount&&to in 0 until main.mediaItemCount&&main.getMediaItemAt(from).mediaId==fromId&&main.getMediaItemAt(to).mediaId==toId
    private fun abort(reject:Boolean){if(reject&&preview!=null)rejectedId=fromId;preview?.release();preview=null;started=false;handing=false;internalSeek=false;autoPending=false;handoffTarget=-1L;lastPosition=-1;main.volume=1f}
    fun close(){main.removeListener(listener);abort(false)}
    private fun handoff(){val p=preview?:return;if(handing)return
        if(!queueMatches()||p.playbackState!=Player.STATE_READY){abort(true);return}
        handing=true;handoffAt=SystemClock.elapsedRealtime();main.volume=0f;p.volume=1f
        handoffTarget=OverlapCore.handoffPosition(p.currentPosition,p.duration);internalSeek=true;try{main.seekTo(to,handoffTarget)}finally{internalSeek=false}
    }
    /** true means this coordinator owns gain. Otherwise caller applies normal single-player fades. */
    fun tick(requested:Long,eligible:Boolean):Boolean {
        if(requested<=0||!eligible||!main.playWhenReady){if(preview!=null)abort(true);return false}
        val now=SystemClock.elapsedRealtime()
        if(autoPending){autoPending=false;handoff()}
        if(handing){val p=preview?:return false
            if(!queueMatches()||main.currentMediaItemIndex!=to||now-handoffAt>1200||p.playbackState!=Player.STATE_READY){abort(true);return false}
            // Once the primary has resumed at the incoming position, release the preview.
            if(main.isPlaying){val error=kotlin.math.abs(main.currentPosition-p.currentPosition);if(error<=200||now-handoffAt>300){abort(false);return false}}
            return true
        }
        val id=main.currentMediaItem?.mediaId?:return false
        if(rejectedId!=null&&rejectedId!=id)rejectedId=null
        val next=main.nextMediaItemIndex;val duration=main.duration;val pos=main.currentPosition
        if(!main.isPlaying||duration<=0||next==C.INDEX_UNSET||next==main.currentMediaItemIndex||rejectedId==id){if(preview!=null)abort(true);return false}
        if(preview!=null&&(!queueMatches()||main.currentMediaItemIndex!=from||next!=to)){abort(true);return false}
        if(preview==null&&duration-pos<=requested+5000&&duration-pos>500){
            val item=main.getMediaItemAt(next);val uri=item.localConfiguration?.uri?:item.requestMetadata.mediaUri
            if(uri?.scheme!="content"||item.mediaId==id){rejectedId=id;return false}
            try{val p=ExoPlayer.Builder(context).build();preview=p;from=main.currentMediaItemIndex;to=next;fromId=id;toId=item.mediaId
                p.setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),false);p.volume=0f;p.setMediaItem(MediaItem.fromUri(uri));p.prepare()
            }catch(e:Exception){abort(true);return false}
        }
        val p=preview?:return false
        if(p.playerError!=null){abort(true);return false}
        if(p.playbackState!=Player.STATE_READY){if(started||duration-pos<300)abort(true);return false}
        val w=OverlapCore.window(duration,p.duration,requested)?:run{abort(true);return false}
        if(pos<w.start){if(started){abort(true);return false};return false}
        val elapsed=(pos-w.start).coerceAtLeast(0)
        if(!started){if(elapsed>350){abort(true);return false};started=true;p.seekTo(elapsed);p.play();lastPosition=pos;lastTime=now;return true}
        if(lastPosition>=0&&kotlin.math.abs((pos-lastPosition)-(now-lastTime))>350){abort(true);return false};lastPosition=pos;lastTime=now
        if(OverlapCore.drift(elapsed,p.currentPosition)&&elapsed>400){abort(true);return false}
        val g=OverlapCore.gains(elapsed,w.duration);main.volume=g.outgoing;p.volume=g.incoming
        if(duration-pos<=100)handoff()
        return true
    }
}
