package app.remix.player

import java.io.File
import java.io.RandomAccessFile

/** Shared phase-aware frontend for classifiers. Read a bounded excerpt, then optionally pad. */
object AnalysisPcm {
    fun excerpt(raw:File,start:Long,count:Int,padded:Int=count,targetRate:Int):FloatArray {
        require(raw.isFile && raw.length()%4==0L && start>=0 && count>0 && count<=44100*15 && padded in count..(44100*15))
        require(start<=raw.length()/4-count && targetRate in 8000..48000)
        val out=FloatArray(((padded.toLong()*targetRate+44099)/44100).toInt());var n=0
        val res=StemCore.Resampler(44100,targetRate){l,_->check(n<out.size);out[n++]=l.coerceIn(-1f,1f)}
        val mono=AnalysisMono{v->res.frame(v.toFloat(),v.toFloat())}
        RandomAccessFile(raw,"r").use{f->f.seek(start*4);val buf=ByteArray(8192*4);var remaining=count
            while(remaining>0){check(!Thread.currentThread().isInterrupted);val frames=minOf(remaining,8192);f.readFully(buf,0,frames*4)
                fun short(i:Int)=((buf[i].toInt() and 255) or (buf[i+1].toInt() shl 8)).toShort()/32768.0
                repeat(frames){i->mono.frame(short(i*4),short(i*4+2))};remaining-=frames
            }}
        mono.finish();repeat(padded-count){i->if(i%8192==0)check(!Thread.currentThread().isInterrupted);res.frame(0f,0f)};res.finish();check(n==out.size);return out
    }
}
