package app.remix.player

/** Enhanced LRC <mm:ss.xxx> word markers. No fabricated word timings. */
object WordLyrics {
    data class Word(val ms:Long,val start:Int,val end:Int)
    data class Line(val text:String,val words:List<Word>)
    private val marker=Regex("<(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?>")
    fun parse(line:Lyric):Line {
        val matches=marker.findAll(line.text).toList()
        if(matches.isEmpty())return Line(line.text,emptyList())
        val b=StringBuilder();val words=mutableListOf<Word>();var prev=0L
        for((i,m) in matches.withIndex()){
            if(i==0)b.append(line.text.substring(0,m.range.first))
            val end=matches.getOrNull(i+1)?.range?.first?:line.text.length
            val part=line.text.substring(m.range.last+1,end);val start=b.length;b.append(part)
            val ms=Lrc.timestamp(m.groupValues[1].toLong()*60000+m.groupValues[2].toLong()*1000+m.groupValues[3].padEnd(3,'0').toLong(),line.offset)
            if(m.groupValues[2].toInt()<60&&part.isNotBlank()&&ms>=line.ms&&ms>=prev){words.add(Word(ms,start,b.length));prev=ms}
        }
        return Line(b.toString(),words)
    }
    fun current(line:Line,ms:Long):Int {
        var lo=0;var hi=line.words.size
        while(lo<hi){val mid=lo+(hi-lo)/2;if(line.words[mid].ms<=ms)lo=mid+1 else hi=mid}
        return lo-1
    }
}
