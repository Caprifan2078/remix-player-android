package app.remix.player
/** Page navigation caps live view count independently of the size of the library. */
object LibraryPage {
    const val SIZE=100
    data class Window(val start:Int,val end:Int,val total:Int){
        val previousEnd:Int? get()=if(start>0)start else null
        val nextEnd:Int? get()=if(end<total)end+minOf(SIZE,total-end) else null
        val anchor:Int get()=end
    }
    fun window(total:Int,requestedEnd:Int):Window {
        require(total>=0)
        if(total==0)return Window(0,0,0)
        val page=((requestedEnd.coerceAtLeast(1)-1)/SIZE).coerceAtMost((total-1)/SIZE)
        val start=page*SIZE
        return Window(start,start+minOf(SIZE,total-start),total)
    }
}
