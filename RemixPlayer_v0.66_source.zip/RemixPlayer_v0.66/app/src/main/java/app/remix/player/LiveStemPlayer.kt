package app.remix.player
import android.content.Context
import android.media.*
import java.io.RandomAccessFile
import java.util.concurrent.atomic.AtomicReference

/** One synchronized PCM output for all stems. Owned by the foreground service. */
class LiveStemPlayer(private val context:Context,private val bundle:StemEngine.Bundle,initial:FloatArray,private val ended:()->Unit){
    private val gains=AtomicReference(initial.copyOf());@Volatile private var stop=false;@Volatile private var track:AudioTrack?=null;private var thread:Thread?=null
    private val manager=context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val attributes=AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
    private val focus=AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(attributes).setOnAudioFocusChangeListener{if(it!=AudioManager.AUDIOFOCUS_GAIN)close()}.build()
    @Volatile var failure:String?=null;private set
    @Volatile var finished=false;private set
    @Volatile var startFrame=0L;private set
    @Volatile private var finalFrame:Long?=null
    @Volatile var reachedEnd=false;private set
    fun position():Long=finalFrame?:(startFrame+(runCatching{track?.playbackHeadPosition?.toLong()?.and(0xffffffffL)}.getOrNull()?:0)).coerceAtMost(bundle.frames)
    fun update(v:FloatArray){require(v.size==bundle.count&&v.all{it.isFinite()&&it in 0f..1f});gains.set(v.copyOf())}
    fun play(frame:Long=0){check(thread==null);startFrame=frame.coerceIn(0,bundle.frames-1);require(manager.requestAudioFocus(focus)==AudioManager.AUDIOFOCUS_REQUEST_GRANTED){"Аудиофокус недоступен"};try{thread=Thread({run()} ,"stem-preview").apply{start()}}catch(e:Throwable){manager.abandonAudioFocusRequest(focus);throw e}}
    private fun run(){val files=mutableListOf<RandomAccessFile>();var audio:AudioTrack?=null;try{repeat(bundle.count){files.add(RandomAccessFile(java.io.File(bundle.dir,"$it.pcm"),"r").apply{seek(startFrame*4)})};val min=AudioTrack.getMinBufferSize(44100,AudioFormat.CHANNEL_OUT_STEREO,AudioFormat.ENCODING_PCM_16BIT);require(min>0);val t=AudioTrack.Builder().setAudioAttributes(attributes).setAudioFormat(AudioFormat.Builder().setSampleRate(44100).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build()).setBufferSizeInBytes(maxOf(min,8192)).setTransferMode(AudioTrack.MODE_STREAM).build();audio=t;track=t;check(t.state==AudioTrack.STATE_INITIALIZED);if(stop)return;t.play();val raw=Array(bundle.count){ByteArray(4096)};val out=ShortArray(2048);val samples=ShortArray(bundle.count);val ramp=GainRamp(gains.get());var remain=bundle.frames-startFrame
        while(!stop&&remain>0){val frames=minOf(1024L,remain).toInt();val bytes=frames*4;files.forEachIndexed{i,f->f.readFully(raw[i],0,bytes)};ramp.set(gains.get());for(j in 0 until frames*2){if(j%2==0)ramp.advance();for(i in samples.indices){val b=raw[i];samples[i]=((b[j*2].toInt() and 255) or (b[j*2+1].toInt() shl 8)).toShort()};out[j]=StemCore.mix(samples,ramp.current)};var p=0;while(!stop&&p<frames*2){val n=t.write(out,p,frames*2-p,AudioTrack.WRITE_BLOCKING);if(n<=0)error("AudioTrack write: $n");p+=n};remain-=frames};if(!stop){val deadline=android.os.SystemClock.elapsedRealtime()+2000;while(!stop&&position()<bundle.frames&&android.os.SystemClock.elapsedRealtime()<deadline)Thread.sleep(20);reachedEnd=!stop&&position()>=bundle.frames}
        }catch(e:Exception){if(!stop)failure=e.message?:"Ошибка воспроизведения"}finally{finalFrame=position();track=null;runCatching{audio?.stop()};runCatching{audio?.release()};files.forEach{runCatching{it.close()}};runCatching{manager.abandonAudioFocusRequest(focus)};finished=true;ended()}}
    fun close(){finalFrame=position();stop=true;runCatching{track?.pause()}}
}
