package app.remix.player
import java.io.*
import kotlin.math.*

/** Objective PCM checks; does not predict musical taste or perceived loudness. */
object RemixQuality {
    data class Result(val seconds:Double,val peak:Double,val rms:Double,val clippedFraction:Double,val internalSilenceSeconds:Double,val dc:Double,val measuredBpm:Double?,val targetBpm:Int?) {
        val score:Int get(){if(rms<.001)return 0;val peakPenalty=if(peak>.999)10.0 else 0.0;val levelPenalty=(abs(20*log10(rms)+15)-3).coerceAtLeast(0.0)*1.4
            val tempoPenalty=if(measuredBpm!=null&&targetBpm!=null)min(20.0,100*listOf(measuredBpm,measuredBpm*2,measuredBpm/2).minOf{abs(ln(it/targetBpm))})else 0.0
            return (100-peakPenalty-min(45.0,clippedFraction*5000)-min(25.0,levelPenalty)-min(20.0,internalSilenceSeconds/seconds*150)-min(15.0,dc*500)-tempoPenalty).roundToInt().coerceIn(0,100)
        }
        fun warnings():List<String> = buildList{if(rms<.001)add("Почти тишина");if(clippedFraction>.0001)add("Есть срезанные пики");if(internalSilenceSeconds>1)add("Длинная внутренняя пауза");if(dc>.02)add("Смещение постоянной составляющей");if(measuredBpm==null&&targetBpm!=null)add("Темп не подтверждён");if(measuredBpm!=null&&targetBpm!=null&&listOf(measuredBpm,measuredBpm*2,measuredBpm/2).minOf{abs(ln(it/targetBpm))}>.08)add("Темп отличается от цели")}
    }
    fun inspect(file:File,targetBpm:Int?=null):Result {
        require(file.length()>44&&(file.length()-44)%4==0L);require(targetBpm==null||targetBpm in 50..220)
        val frames=(file.length()-44)/4;require(frames<=44100L*60*40)
        var peak=0.0;var power=0.0;var leftDc=0.0;var rightDc=0.0;var clipped=0L
        val envelope=ArrayList<Double>(12000);var env=0.0;var envN=0;var block=0.0;var blockN=0;var seenSignal=false;var gap=0.0;var internal=0.0
        fun finishBlock(){if(blockN==0)return;val seconds=blockN/44100.0;if(sqrt(block/blockN)<.0005){if(seenSignal)gap+=seconds}else{if(gap>=.5)internal+=gap;gap=0.0;seenSignal=true};block=0.0;blockN=0}
        file.inputStream().buffered(65536).use{r->val header=ByteArray(44);DataInputStream(r).readFully(header);require(header.contentEquals(ByteArrayOutputStream().also{StemCore.header(it,frames)}.toByteArray())){"Требуется внутренний PCM WAV"}
            for(i in 0 until frames){if(i%8192==0L)check(!Thread.currentThread().isInterrupted){"Отменено"};val l=StemCore.readShort(r)/32768.0;val right=StemCore.readShort(r)/32768.0;peak=max(peak,max(abs(l),abs(right)));leftDc+=l;rightDc+=right;if(abs(l)>=32767/32768.0)clipped++;if(abs(right)>=32767/32768.0)clipped++;val p=(l*l+right*right)/2;power+=p;block+=p;blockN++;if(blockN==4410)finishBlock();if(envelope.size<12000){env+=p;envN++;if(envN==441){envelope.add(sqrt(env/envN));env=0.0;envN=0}}}
            finishBlock();check(r.read()==-1)
        }
        return Result(frames/44100.0,peak,sqrt(power/frames),clipped/(frames*2.0),internal,max(abs(leftDc),abs(rightDc))/frames,Tempo.estimate(envelope)?.bpm,targetBpm)
    }
}
