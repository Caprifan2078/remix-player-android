package app.remix.player
import java.io.*
import java.util.zip.*

object StemZip {
    private val names=listOf("drums","bass","other","vocals","guitar","piano")
    fun export(dir:File,frames:Long,count:Int,output:OutputStream,progress:(Int)->Unit={}){
        require(frames in 1..44100L*60*15 && count in listOf(4,6))
        val files=(0 until count).map{File(dir,"$it.pcm")};require(files.all{it.isFile&&it.length()==frames*4}){"Кеш дорожек неполный"}
        ZipOutputStream(BufferedOutputStream(output)).use{zip->zip.setLevel(1);val bytes=ByteArray(65536)
            files.forEachIndexed{i,file->zip.putNextEntry(ZipEntry(names[i]+".wav"));StemCore.header(zip,frames);file.inputStream().buffered().use{input->var remain=frames*4;while(remain>0){check(!Thread.currentThread().isInterrupted){"Отменено"};val n=input.read(bytes,0,minOf(bytes.size.toLong(),remain).toInt());check(n>0){"Неполная дорожка"};zip.write(bytes,0,n);remain-=n};check(input.read()==-1){"Длина дорожки изменилась"}};zip.closeEntry();progress(i+1)}
        }
    }
}
