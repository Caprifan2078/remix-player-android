package app.remix.player

import android.content.ComponentName
import android.content.Intent
import android.os.SystemClock
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.math.sin

/** Real local PCM fixture; requires installed APK and Android instrumentation. */
@RunWith(AndroidJUnit4::class)
@UnstableApi
class PlaybackInstrumentedTest {
    private val inst=InstrumentationRegistry.getInstrumentation()
    private fun main(block:()->Unit)=inst.runOnMainSync { block() }
    private fun await(message:String,timeout:Long=12000,predicate:()->Boolean){val end=SystemClock.elapsedRealtime()+timeout;while(SystemClock.elapsedRealtime()<end){var ok=false;main{ok=predicate()};if(ok)return;SystemClock.sleep(50)};fail(message)}
    @Test fun commonsMetadataParsing(){
        val root=org.json.JSONObject("""{"query":{"pages":[{"title":"File:Music.ogg","imageinfo":[{"descriptionurl":"https://commons.wikimedia.org/wiki/File:Music.ogg","url":"https://upload.wikimedia.org/wikipedia/commons/a/aa/Music.ogg","mime":"application/ogg","mediatype":"AUDIO","size":12345,"extmetadata":{"Artist":{"value":"<b>Composer</b>"},"LicenseShortName":{"value":"CC0"},"LicenseUrl":{"value":"https://creativecommons.org/publicdomain/zero/1.0/"}}}]}]}}""")
        val results=CommonsAudioCatalog.parse(root.toString());assertEquals(1,results.size);assertEquals("Composer",results.single().artist);assertEquals("Music",results.single().title)
        root.getJSONObject("query").getJSONArray("pages").getJSONObject(0).getJSONArray("imageinfo").getJSONObject(0).getJSONObject("extmetadata").getJSONObject("LicenseUrl").put("value","https://example.org/")
        assertTrue(CommonsAudioCatalog.parse(root.toString()).isEmpty())
    }
    @Test fun portablePlaybackJsonRoundTrip(){
        val ids=listOf("content://new/a","content://new/b")
        val controls=PortablePlayback.Controls(List(10){it.toFloat()},List(6){.5f},2000L,5000L,true)
        val queue=PortablePlayback.Queue(listOf(1,0,1),1,1234,10000,true,2)
        val data=PortablePlaybackJson.Data(controls,queue,mapOf(0 to List(4){.75f}),mapOf(1 to ListeningStats.Entry("old",5000,100)))
        val json=PortablePlaybackJson.encode(data);val restored=PortablePlaybackJson.decode(org.json.JSONObject(json.toString()),ids)
        assertEquals(controls,restored.controls);assertEquals(queue,restored.queue);assertEquals(data.gains,restored.gains)
        assertEquals(ids[1],restored.history[1]?.id);assertEquals(5000L,restored.history[1]!!.playedMs)
        assertEquals(listOf(ids[1],ids[0],ids[1]),restored.queue!!.remap(ids).ids)
        json.getJSONObject("queue").put("index",99);assertTrue(runCatching{PortablePlaybackJson.decode(json,ids)}.isFailure)
    }
    @Test fun decodeAndTrimRealLocalWav(){
        val context=inst.targetContext;val dir=File(context.filesDir,"mixes").apply{mkdirs()};val source=File.createTempFile("qa-conversion-",".wav",dir);val raw=File.createTempFile("qa-conversion-",".pcm",context.cacheDir);val clip=File.createTempFile("qa-clip-",".wav",context.cacheDir)
        try{source.outputStream().buffered().use{out->StemCore.header(out,44100);repeat(44100){i->val s=(sin(2*Math.PI*i*440/44100)*8000).toInt().toShort();StemCore.writeShort(out,s);StemCore.writeShort(out,(-s).toShort())}}
            val uri=FileProvider.getUriForFile(context,"app.remix.player.files",source);val frames=StemEngine.decode(context,uri,raw);assertEquals(44100L,frames);assertArrayEquals(source.readBytes().copyOfRange(44,source.length().toInt()),raw.readBytes())
            val range=AudioFileCore.clipFromMs(200,800,50,frames);clip.outputStream().buffered().use{AudioFileCore.write(raw,it,range)};assertEquals(44+26460L*4,clip.length());assertTrue(clip.readBytes().takeLast(4).all{it==0.toByte()})
        }finally{source.delete();raw.delete();clip.delete()}
    }
    @Test fun nativeEncodersAndLocalDecode(){
        val c=inst.targetContext;val dir=File(c.filesDir,"mixes").apply{mkdirs()}
        val source=File.createTempFile("qa-native-",".wav",dir);val mp3=File.createTempFile("qa-native-",".mp3",dir);val decoded=File.createTempFile("qa-native-",".pcm",c.cacheDir)
        try{assertTrue("Missing native MP3 library",Mp3Export.available);assertTrue("Missing native Whisper library",WhisperLocal.available)
            source.outputStream().buffered().use{w->StemCore.header(w,44100L*2);repeat(88200){i->val v=(sin(2*Math.PI*i*440/44100)*8000).toInt().toShort();StemCore.writeShort(w,v);StemCore.writeShort(w,v)}}
            source.inputStream().buffered().use{input->mp3.outputStream().buffered().use{out->Mp3Export.encode(input,out,192)}}
            assertTrue(mp3.length()>10000);val uri=FileProvider.getUriForFile(c,"app.remix.player.files",mp3)
            val frames=StemEngine.decode(c,uri,decoded);assertTrue("Unexpected MP3 decoded length: $frames",frames in 84000L..94000L);assertEquals(frames*4,decoded.length())
            assertTrue("Decoded MP3 is silent",decoded.inputStream().buffered().use{r->var peak=0;repeat(minOf(frames*2,44100L).toInt()){peak=maxOf(peak,kotlin.math.abs(StemCore.readShort(r).toInt()))};peak>1000})
        }finally{source.delete();mp3.delete();decoded.delete()}
    }
    @Test fun localPlaybackSeekQueueAndPause(){
        val context=inst.targetContext
        val activity=inst.startActivitySync(Intent(context,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));inst.waitForIdleSync()
        val dir=File(context.filesDir,"mixes").apply{mkdirs()};val files=(1..2).map{n->File.createTempFile("qa-tone-",".wav",dir).also{f->f.outputStream().buffered().use{out->StemCore.header(out,44100L*12);repeat(44100*12){i->val v=(sin(2*Math.PI*i*(220*n)/44100)*5000).toInt().toShort();StemCore.writeShort(out,v);StemCore.writeShort(out,v)}}}}
        val items=files.map{f->val uri=FileProvider.getUriForFile(context,"app.remix.player.files",f);MediaItem.Builder().setMediaId(uri.toString()).setUri(uri).setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(uri).build()).build()}
        var future:com.google.common.util.concurrent.ListenableFuture<MediaController>?=null;var controller:MediaController?=null
        try{main{future=MediaController.Builder(context,SessionToken(context,ComponentName(context,PlaybackService::class.java))).buildAsync()};val p=future!!.get(15,TimeUnit.SECONDS);controller=p
            main{PlaybackOptions.overlapMs=0;PlaybackOptions.fadeMs=0;p.setMediaItems(items,0,0);p.prepare();p.play()};await("Local WAV not playing"){p.isPlaying&&p.currentPosition>300&&p.duration in 11900L..12100L}
            main{p.pause();p.seekTo(6000)};await("Seek/pause failed"){!p.isPlaying&&p.currentPosition in 5900L..6100L}
            main{p.removeMediaItem(1);p.addMediaItem(1,items[1])};await("Queue append changed paused track or position"){p.mediaItemCount==2&&p.currentMediaItem?.mediaId==items[0].mediaId&&!p.isPlaying&&p.currentPosition in 5900L..6100L}
            main{RepeatRegion.active=LoopCore.create(items[0].mediaId,1000,3000,p.duration);p.seekTo(2850);p.play()};await("A/B did not loop"){p.isPlaying&&p.currentPosition in 1000L..2400L};main{p.pause();RepeatRegion.active=null}
            main{p.moveMediaItem(1,0)};await("Queue order failed"){p.mediaItemCount==2&&p.getMediaItemAt(0).mediaId==items[1].mediaId&&p.currentMediaItem?.mediaId==items[0].mediaId}
            main{p.seekToDefaultPosition(0);p.play()};await("Second track did not start"){p.isPlaying&&p.currentMediaItem?.mediaId==items[1].mediaId&&p.currentPosition>300}
            // Enable real two-source transition; primary queue should resume the incoming song beyond its intro.
            main{p.pause();p.shuffleModeEnabled=false;p.repeatMode=Player.REPEAT_MODE_OFF;PlaybackOptions.overlapMs=3000;p.setMediaItems(items,0,6500);p.prepare();p.play()}
            await("Live overlap did not hand off the incoming position",7000){p.isPlaying&&p.currentMediaItem?.mediaId==items[1].mediaId&&p.currentPosition in 2000L..4500L}
            main{PlaybackOptions.overlapMs=0}
            inst.uiAutomation.executeShellCommand("input keyevent 3").close();SystemClock.sleep(300);var pos=0L;main{pos=p.currentPosition};await("Background playback did not advance"){p.isPlaying&&p.currentPosition>pos+300}
        }finally{main{PlaybackOptions.overlapMs=0;RepeatRegion.active=null;controller?.let{it.pause();it.clearMediaItems()};future?.let{MediaController.releaseFuture(it)};activity.finish()};files.forEach{it.delete()}}
    }
}
