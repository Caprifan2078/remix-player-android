# v0.66 — PCM and queue boundary fixes

- Sanitize non-finite left/right input independently before entering resampler history, including the equal-rate bypass. Valid PCM samples remain unchanged. A damaged sample is replaced with zero; this prevents NaN/Inf from spreading across sinc taps or endpoint padding.
- Enforce the persisted queue's 8192-character ID limit and maximum queue capacity of 300 for single insert and play-next, matching the batch path.
- Add a standalone regression suite (`bash tests/run-boundary66.sh`) and integrate its two groups into the full JVM suite.
- Give the full kotlinc compilation a configurable 2 GiB heap by default (existing JAVA_OPTS overrides it).
- No Android APK or physical device validation claimed.
