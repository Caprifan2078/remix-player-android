#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
printf 'package app.remix.player\nfun main(){whisperBoundary63Tests();whisperWordTests()}\n' > "$tmp/Main.kt"
kotlinc app/src/main/java/app/remix/player/{AudioCore,WhisperSegments,SubtitleCore,StemCore,AnalysisMono,WordLyrics}.kt tests/{WhisperBoundary63Test,WhisperWordTest}.kt "$tmp/Main.kt" -include-runtime -d "$tmp/test.jar"
java -jar "$tmp/test.jar"
