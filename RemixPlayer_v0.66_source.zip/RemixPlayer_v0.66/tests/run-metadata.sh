#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp=$(mktemp -d);trap 'rm -rf "$tmp"' EXIT
printf 'package app.remix.player\nfun main(){trackMetadataTests();librarySearchTests()}\n' > "$tmp/Main.kt"
kotlinc app/src/main/java/app/remix/player/{TrackMetadata,LibrarySearch}.kt tests/{TrackMetadataTest,LibrarySearchTest}.kt "$tmp/Main.kt" -include-runtime -d "$tmp/test.jar"
java -jar "$tmp/test.jar"
