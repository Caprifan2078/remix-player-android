#!/usr/bin/env bash
set -euo pipefail
mkdir -p smoke-output
adb install -r "$1"
adb shell am instrument -w -r app.remix.player.test/androidx.test.runner.AndroidJUnitRunner | tee smoke-output/instrumentation.txt
# Match the number of tests in the actual source; three of five is not a pass.
root="$(cd "$(dirname "$0")/.." && pwd)"
expected=$(grep -RhE '^[[:space:]]*@Test([[:space:]]|$)' "$root/app/src/androidTest" | wc -l)
(( expected > 0 ))
python3 "$root/scripts/check-instrumentation.py" smoke-output/instrumentation.txt "$expected"
