package app.remix.player
import kotlin.math.*
import java.io.File
fun release41Tests(){
    val s=NeuralInstrumental.Settings(NeuralInstrumental.Style.DANCE,120,0,false,12,41)
    val windows=listOf(RhythmMap.Window(0.0,8.0,100.0,.9),RhythmMap.Window(8.0,16.0,150.0,.9),RhythmMap.Window(16.0,24.0,150.0,.9))
    val follow=NeuralInstrumental.Follow(emptyList(),120.0,250,windows)
    val points=NeuralInstrumental.boundaries(s,follow)
    check(points.size==193&&points[0]==0.0&&points.asList().zipWithNext().all{(a,b)->b>a})
    val start=11025L;val grid=AdaptiveGroove(120.0,.25,windows,120.0);val origin=grid.position(start)
    points.forEachIndexed{i,f->check(abs(grid.position(start+f.toLong())-origin-i)<.001)}
    val durations=points.asList().zipWithNext().map{(a,b)->b-a};check(durations.maxOrNull()!!/durations.minOrNull()!!>1.3)
    for(sec in listOf(1.0,9.0,15.0,23.7,900.0)){
        val bars=NeuralInstrumental.barsForDuration(sec,120.0,250,windows)
        check(NeuralInstrumental.boundaries(s.copy(bars=bars),follow).last()/44100+.25>=sec)
    }
    val fixed=NeuralInstrumental.boundaries(s);check(fixed.last()==s.bars*44100.0*240/120)
    val dir=kotlin.io.path.createTempDirectory("variable-neural").toFile();try{
        val a=File(dir,"a.wav");val b=File(dir,"b.wav");val short=s.copy(bars=2)
        val n=NeuralInstrumental.render(a,short,follow);check(n==NeuralInstrumental.boundaries(short,follow).last().toLong());check(a.length()==44+n*4)
        NeuralInstrumental.render(b,short,follow);check(a.readBytes().contentEquals(b.readBytes()))
        check(n!=NeuralInstrumental.boundaries(short).last().toLong())
    }finally{dir.deleteRecursively()}
    println("PASS: neural backing variable tempo grid, source phase, complete duration, deterministic PCM")
}
