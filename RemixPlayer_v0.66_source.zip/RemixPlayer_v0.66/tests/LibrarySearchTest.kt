package app.remix.player
fun librarySearchTests(){
    data class Song(val id:String,val group:String,val title:String,val artist:String,val album:String="")
    val songs=listOf(Song("a","a","Ёлка — Café","Artist","Album 1"),Song("b","a","Slowed + Reverb",""),Song("c","a","Hardstyle",""),Song("d","d","Another","Other"),Song("e","d","Nightcore",""))
    val search=LibrarySearch(songs,Song::id,Song::group){listOf(it.title,it.artist,it.album)}
    check(search.find("artist cafe елка").keys==setOf("a"))
    check(search.find("album 1").getValue("a").originalMatches)
    val remix=search.find("cafe reverb").getValue("a")
    check(!remix.originalMatches&&remix.versions.map{it.id}==listOf("b"))
    check(search.find("hardstyle reverb").isEmpty())
    check(search.find("nightcore").getValue("d").versions.single().id=="e")
    check(search.find("  ").size==2&&search.find("nonexistent").isEmpty())
    val large=(0 until 30000).flatMap{listOf(Song("$it","$it","Song $it","Artist"),Song("r$it","$it","Remix $it",""))}
    var calls=0
    val index=LibrarySearch(large,{calls++;it.id},Song::group){listOf(it.title,it.artist)}
    check(index.find("remix 29999").getValue("29999").versions.single().id=="r29999")
    val queries=listOf("remix 2","remix 29","remix 299","remix 2999","remix 29999","remix 2","artist","artist remix","artist remix 42","unknown","", "42", "24", "remix 29999")
    for(q in queries){
        val expected=LibrarySearch(large,Song::id,Song::group){listOf(it.title,it.artist)}.find(q)
        check(index.find(q)==expected)
    }
    index.find("remix 2999");calls=0;val narrowed=index.find("remix 29999");val visits=calls
    check(narrowed.size==1&&visits<100)
    calls=0;check(index.find("remix 29999")===narrowed&&calls==0)
    println("PASS: incremental search matches fresh index, query deletion and changes, narrowed visits=$visits, identical query cached")
    println("PASS: grouped version search, normalized Unicode, unordered terms, album, no sibling false matches, 60,000 records")
}
