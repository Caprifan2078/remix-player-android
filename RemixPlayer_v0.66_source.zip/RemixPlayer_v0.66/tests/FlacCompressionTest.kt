package app.remix.player
import java.io.*
import kotlin.math.*
import kotlin.random.Random
fun flacCompressionTests(){
    val dir=kotlin.io.path.createTempDirectory("flac-compress").toFile();try{
        val random=Random(18);val sizes=mutableListOf<String>()
        for(kind in 0..5){val n=if(kind==5)1 else 12345;val wav=File(dir,"$kind.wav");val flac=File(dir,"$kind.flac");val decoded=File(dir,"$kind.raw")
            wav.outputStream().buffered().use{w->StemCore.header(w,n.toLong());repeat(n){i->for(c in 0..1){val s=when(kind){0->0;1->(sin(2*PI*440*i/44100)*28000*(if(c==0)1 else -1)).roundToInt();2->if(i%2==0)32767 else -32768;3->random.nextInt(-32768,32768);4->(i*7+c*123)%60000-30000;else->-32768};StemCore.writeShort(w,s.toShort())}}}
            wav.inputStream().buffered().use{r->flac.outputStream().buffered().use{FlacExport.encode(r,it)}}
            if(kind==0)check(flac.length()<wav.length()/20){"Silence isn't compressed: ${flac.length()}/${wav.length()}"}
            if(kind==1)check(flac.length()<wav.length()/2){"Tone isn't compressed: ${flac.length()}/${wav.length()}"}
            if(kind==3)check(flac.length()<wav.length()+1000)
            val p=ProcessBuilder("ffmpeg","-v","error","-y","-i",flac.path,"-f","s16le",decoded.path).redirectErrorStream(true).start();val log=p.inputStream.readBytes();check(p.waitFor()==0){String(log)};check(decoded.readBytes().contentEquals(wav.readBytes().copyOfRange(44,wav.length().toInt()))){"Mismatch $kind"};sizes.add("$kind:${flac.length()}/${wav.length()}")
        };println("PASS: compressed FLAC 6 independent FFmpeg roundtrips (silence/tone/extremes/noise/ramp/1 sample); bytes ${sizes.joinToString()}")
    }finally{dir.deleteRecursively()}
}
