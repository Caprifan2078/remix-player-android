package app.remix.player
import java.io.*
import kotlin.math.*
fun release09Tests(){
    val dir=kotlin.io.path.createTempDirectory("remix09").toFile()
    try {
        val frames=44100L*2;val raw=File(dir,"source.pcm")
        raw.outputStream().buffered().use{w->for(i in 0 until frames){val x=sin(2*PI*440*i/44100)*.2;StemCore.writeShort(w,StemCore.pcm(x.toFloat()));StemCore.writeShort(w,StemCore.pcm((x*.5).toFloat()))}}
        val original=raw.readBytes();val fingerprints=mutableSetOf<Int>()
        GenreEngine.styles.forEach{style->val f=File(dir,"out.wav");GenreEngine.renderFromMix(raw,f,style,120.0,0.0,emptyList(),listOf(.1));check(f.length()==44+frames*4);val stats=Mastering.normalizeGenerated(f);check(stats.peak<=.892&&stats.rms>0&&stats.samples==frames*2);fingerprints.add(f.readBytes().contentHashCode());f.delete()}
        check(fingerprints.size>=25);check(raw.readBytes().contentEquals(original))
        val batch=EffectRender.batch(raw,dir,listOf(Presets.all[1],Presets.all[6],Presets.all[9])){_,_,_->}
        check(batch.size==3&&batch.all{(p,f)->f.length()==EffectRender.outputBytes(frames,p)})
        batch.forEach{it.second.delete()};check(raw.readBytes().contentEquals(original))
        val quiet=File(dir,"quiet.wav");fun wave(amplitude:Double){quiet.outputStream().buffered().use{w->StemCore.header(w,frames);for(i in 0 until frames){val x=StemCore.pcm((sin(2*PI*440*i/44100)*amplitude).toFloat());repeat(2){StemCore.writeShort(w,x)}}}}
        wave(.8);val before=Mastering.measure(quiet);val after=Mastering.normalizeGenerated(quiet);check(after.peak<before.peak&&abs(after.rms-10.0.pow(-15.0/20))<.001)
        wave(.03);val low=Mastering.measure(quiet);val boosted=Mastering.normalizeGenerated(quiet);check(abs(boosted.rms/low.rms-2.0)<.002)
        wave(0.0);val silence=quiet.readBytes();check(Mastering.normalizeGenerated(quiet).rms==0.0&&quiet.readBytes().contentEquals(silence))
        val bad=File(dir,"bad.wav");bad.writeBytes(ByteArray(48));check(runCatching{Mastering.measure(bad)}.isFailure)
        val cancelled=File(dir,"cancel.wav");Thread.currentThread().interrupt();try{check(runCatching{GenreEngine.renderFromMix(raw,cancelled,GenreEngine.styles.first(),120.0,0.0,emptyList(),emptyList())}.isFailure);check(!cancelled.exists())}finally{Thread.interrupted()}
        println("PASS: model-free rendering all 30 genres; ${fingerprints.size} distinct outputs; peak/RMS, silence, gain cap, source identity, three-effect batch, corrupt WAV and cancellation")
    }finally{dir.deleteRecursively()}
}
