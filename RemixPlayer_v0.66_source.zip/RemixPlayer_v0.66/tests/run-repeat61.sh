#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
jar=$(mktemp --suffix=.jar)
tmp=$(mktemp --suffix=.kt)
trap 'rm -f "$jar" "$tmp"' EXIT
printf 'package app.remix.player\nfun main(){sectionRepeatTests();repeat61Tests()}\n' > "$tmp"
kotlinc app/src/main/java/app/remix/player/SectionMap.kt tests/{SectionRepeatTest,Repeat61Test}.kt "$tmp" -include-runtime -d "$jar"
java -jar "$jar"
