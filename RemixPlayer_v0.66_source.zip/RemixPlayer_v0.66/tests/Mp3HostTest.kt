package app.remix.player
import java.io.*
import kotlin.math.*
fun main(args:Array<String>){val wav=ByteArrayOutputStream();StemCore.header(wav,44100);repeat(44100){i->val s=(sin(i*2*PI*440/44100)*12000).toInt().toShort();StemCore.writeShort(wav,s);StemCore.writeShort(wav,s)};for(b in listOf(128,192,256,320)){val f=File(args[0],"$b.mp3");f.outputStream().use{Mp3Export.encode(wav.toByteArray().inputStream(),it,b)};check(f.length()>1000)};println("PASS: LAME JNI generated 4 MP3 bitrates")}
