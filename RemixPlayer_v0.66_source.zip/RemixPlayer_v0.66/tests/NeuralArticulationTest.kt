package app.remix.player
import java.io.File
import java.io.RandomAccessFile
import kotlin.math.*
fun neuralArticulationTests(){
    val s=NeuralInstrumental.Settings(NeuralInstrumental.Style.DANCE,120,0,false,2,52,structured=false)
    val dir=kotlin.io.path.createTempDirectory("articulation").toFile()
    fun rms(file:File,center:Long,radius:Int=110):Double=RandomAccessFile(file,"r").use{r->r.seek(44+(center-radius)*4);var sum=0.0;repeat(radius*2){val x=java.lang.Short.reverseBytes(r.readShort()).toDouble()/32768; r.readShort();sum+=x*x};sqrt(sum/(radius*2))}
    try {
        val chords=File(dir,"chords.wav");val bass=File(dir,"bass.wav");val again=File(dir,"again.wav")
        val frames=NeuralInstrumental.render(chords,s.copy(mix=NeuralInstrumental.Mix(0,0,100,0)))
        val boundaries=NeuralInstrumental.boundaries(s)
        val held=(1..15).map{rms(chords,boundaries[it].roundToLong())}
        check(held.min()>.015){"chord retrigger gap: ${held.min()}"}
        check(rms(chords,boundaries[16].roundToLong())<.015){"chord change must fade"}
        check(NeuralInstrumental.render(bass,s.copy(mix=NeuralInstrumental.Mix(0,100,0,0)))==frames)
        check((1..3).all{rms(bass,boundaries[it].roundToLong())>.025}){"bass drops within beat"}
        check(rms(bass,boundaries[4].roundToLong())<.03){"bass beat should articulate"}
        NeuralInstrumental.render(again,s.copy(mix=NeuralInstrumental.Mix(0,0,100,0)))
        check(chords.readBytes().contentEquals(again.readBytes()))
        val follow=NeuralInstrumental.Follow(listOf(Harmony.Chord(0.0,0,false,.9)),120.0,0)
        NeuralInstrumental.render(again,s.copy(mix=NeuralInstrumental.Mix(0,0,100,0)),follow)
        check(rms(again,44100L)==0.0){"unknown harmony must remain silent"}
        check(chords.length()==44+frames*4)
        println("PASS: sustained chords across 15 sub-beat boundaries, articulated chord changes and bass beats, exact mute in unknown harmony, deterministic PCM; min chord boundary RMS=${held.min()}")
    }finally{dir.deleteRecursively()}
}
