package app.remix.player
import java.io.File
import kotlin.math.*
fun release40Tests(){
    val s=NeuralInstrumental.Settings(NeuralInstrumental.Style.DANCE,120,0,false,2,40)
    val follow=NeuralInstrumental.Follow(listOf(Harmony.Chord(.25,0,false,.9),Harmony.Chord(.75,0,false,.9),Harmony.Chord(1.25,9,true,.9),Harmony.Chord(2.5,4,false,.01),Harmony.Chord(3.0,7,false,.9)),123.7,250)
    val voices=NeuralInstrumental.voices(s,follow)
    check(voices.first()!!.chord==listOf(48,52,55));check(voices.any{it?.chord==listOf(57,60,64)});check(voices.any{it?.chord==listOf(55,59,62)});check(voices.none{it?.bass==40})
    for((i,v) in voices.withIndex()){val t=.25+i*15/123.7;if(t>2.05&&t<3.0)check(v==null);if(v!=null&&v.lead!=null)check(v.chord.any{it%12==v.lead%12})}
    val dir=kotlin.io.path.createTempDirectory("follow").toFile();try{val out=File(dir,"out.wav");val silent=follow.copy(chords=emptyList());val frames=NeuralInstrumental.render(out,s,silent);check(frames==(44100.0*240*2/123.7).roundToLong());check(out.length()==44+frames*4)
        java.io.RandomAccessFile(out,"r").use{r->val frame=(44100.0*15/123.7*1.5).toLong();r.seek(44+frame*4);repeat(200){check(r.readShort().toInt()==0)}}
        val a=File(dir,"a.wav");val b=File(dir,"b.wav");NeuralInstrumental.render(a,s,follow);NeuralInstrumental.render(b,s,follow);check(a.readBytes().contentEquals(b.readBytes()));check(!a.readBytes().contentEquals(out.readBytes()))
    }finally{dir.deleteRecursively()}
    println("PASS: neural backing follows source chord changes, exact fractional BPM, shifted timeline, unknown harmony mutes pitched parts, deterministic audio")
}
