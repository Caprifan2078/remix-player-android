package app.remix.player
fun groupingTests(){
    fun s(id:String,title:String,artist:String="Artist")=GroupingCore.Song(id,title,artist)
    val songs=listOf(s("a","Song"),s("b","Song (Slowed + Reverb)"),s("c","SONG — Nightcore"," artist "),s("d","Song [Remix]","Other"),s("e","Song (Live)"),s("f","Song (Instrumental)"),s("g","Song - Hardstyle Remix"),s("h","Another (Sped Up)","Unknown Artist"),s("i","Another","Unknown Artist"),s("j","Song (2012)"),s("k","Song - Remix Edit"))
    check(GroupingCore.suggest(songs).map{it.version}==listOf("b","c","f","g"))
    check(GroupingCore.suggest(songs+s("duplicate","Song")).isEmpty())
    val hyphenated=listOf(s("x","Love-Hate"),s("y","Love-Hate - Hardstyle Remix"),s("z","Love-Hate (Nightcore)"),s("q","Love-Hate [Slowed]"),s("w","Love-Hate (Live)"))
    check(GroupingCore.suggest(hyphenated).map{it.version}==listOf("y","z","q"))
    check(GroupingCore.suggest(hyphenated+s("duplicate","Love-Hate")).isEmpty())
    val big=(0 until 30000).flatMap{i->listOf(s("$i-o","Track $i"),s("$i-v","Track $i (Sped Up)"))};check(GroupingCore.suggest(big).size==30000)
    println("PASS: safe version suggestions, ambiguity/unknown artist rejection, 60,000 title entries")
}
