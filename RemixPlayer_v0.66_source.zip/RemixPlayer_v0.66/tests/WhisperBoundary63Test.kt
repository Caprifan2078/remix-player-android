package app.remix.player
fun whisperBoundary63Tests(){
    fun s(a:Long,b:Long,t:String,vararg words:Long)=WhisperSegments.Segment(a,b,t,words.toList())
    fun windows(left:List<WhisperSegments.Segment>,right:List<WhisperSegments.Segment>)=listOf(WhisperSegments.Window(0,25000,left),WhisperSegments.Window(23000,48000,right))
    // Both windows own a midpoint of the same line. Case and punctuation differ.
    val a=s(23100,24500,"Привет, мир!")
    val b=s(23500,24900,"привет мир",23600,24300)
    val later=s(32000,33500,"Привет мир")
    val result=WhisperSegments.merge(windows(listOf(a),listOf(b,later)))
    check(result==listOf(b,later)){"Boundary duplicate or lost word timing: $result"}
    // The preferred window's phrase is incomplete; a non-owned duplicate has valid word times.
    val c=s(23000,24300,"Hello world",23100,24000)
    val d=s(23100,24400,"Hello world!")
    check(WhisperSegments.merge(windows(listOf(d),listOf(c)))==listOf(c))
    // Two genuinely consecutive repetitions must remain.
    val r1=s(23100,23800,"go now",23100,23500);val r2=s(23900,24600,"go now",23900,24300)
    check(WhisperSegments.merge(windows(listOf(r1,r2),listOf(r2)))==listOf(r1,r2))
    // Distinct text at exactly the same start cannot yield ambiguous karaoke lines.
    val x=s(23400,24400,"first phrase");val y=s(23400,24800,"other phrase",23400,24200)
    check(WhisperSegments.merge(windows(listOf(x),listOf(y))).size==1)
    // A bad word timestamp never receives preference over a valid hypothesis.
    val bad=s(23500,24900,"привет мир",23600,24900)
    check(WhisperSegments.merge(windows(listOf(a),listOf(bad))).size==1)
    val overlap=WhisperSegments.lrc(listOf(s(1000,3000,"one two",1000,2500),s(2000,3500,"next line",2100,2800)))
    val lines=Lrc.parse(overlap);check(WordLyrics.parse(lines[0]).words.isEmpty());check(WordLyrics.parse(lines[1]).words.size==2)
    println("PASS: Whisper boundary duplicate suppression, preserved observed word timing, genuine repetitions, unique karaoke starts")
}
