package app.remix.player
import java.io.ByteArrayOutputStream
import kotlin.math.*
fun asrPreparationTests(){
    fun tone(hz:Double,anti:Boolean=false,adaptive:Boolean=false):Double{
        val pcm=ByteArrayOutputStream();repeat(44100){i->val x=(sin(2*PI*hz*i/44100)*16000).toInt().toShort();StemCore.writeShort(pcm,x);StemCore.writeShort(pcm,if(anti)(-x).toShort() else x)}
        var n=0;var power=0.0;SubtitleCore.mono16k(pcm.toByteArray().inputStream(),adaptive){if(n in 200..15799)power+=(it/32768.0).pow(2);n++};check(n==16000);return sqrt(power/15600)
    }
    val pass=tone(1000.0);val stop=tone(10000.0);val anti=tone(1000.0,true,true)
    check(abs(pass-16000/32768.0/sqrt(2.0))<.005);check(stop<.005);check(abs(anti-pass)<.005);check(tone(1000.0,true)<1e-8)
    for(n in listOf(0,1,2,3,31,1023,1024,1025,4097)) {var count=0;SubtitleCore.mono16k(ByteArray(n*4).inputStream(),true){check(it==0.toShort());count++};check(count==(n*16000L+44099).div(44100).toInt())}
    check(runCatching{SubtitleCore.mono16k(byteArrayOf(0,0,0).inputStream(),true){}}.isFailure)
    println("PASS: ASR bandlimited 16 kHz PCM, 10 kHz alias RMS $stop, passband $pass, antiphase $anti, exact lengths and truncated input rejection")
}
