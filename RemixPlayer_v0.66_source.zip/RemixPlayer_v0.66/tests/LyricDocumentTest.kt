package app.remix.player
fun lyricDocumentTests(){
    val raw="[ar:Artist]\n[offset:250]\n[00:01.000]<00:01.000>Привет <00:01.500>мир\n[00:04.000]Next"
    val shifted=LyricDocument.shift(raw,750)
    check(Lrc.offset(shifted)==1000L)
    check(Lrc.parse(shifted).map{it.ms}==listOf(2000L,5000L))
    check(WordLyrics.parse(Lrc.parse(shifted).first()).words.map{it.ms}==listOf(2000L,2500L))
    check(shifted.contains("[ar:Artist]")&&shifted.contains("[00:01.000]<00:01.000>"))
    val clipped=LyricDocument.shift(raw,-2000);check(Lrc.parse(clipped).first().ms==0L)
    check(Lrc.parse(LyricDocument.shift(clipped,2000))==Lrc.parse(raw))
    check(LyricDocument.shift(raw,0)==raw)
    check(runCatching{LyricDocument.shift("plain",100)}.isFailure)
    check(runCatching{LyricDocument.shift(raw,Long.MAX_VALUE)}.isFailure)
    val plain="Привет мир\n第二行\nhello"
    check(LyricDocument.plain(plain)==plain)
    check(LyricDocument.plain(raw)=="Привет мир\nNext")
    check(LyricDocument.decode(plain.toByteArray())==plain)
    check(LyricDocument.decode(byteArrayOf(-17,-69,-65)+plain.toByteArray())==plain)
    for((bom,charset) in listOf(byteArrayOf(-1,-2) to Charsets.UTF_16LE,byteArrayOf(-2,-1) to Charsets.UTF_16BE))check(LyricDocument.decode(bom+plain.toByteArray(charset))==plain)
    check(LyricDocument.decode("a\r\nb\rc".toByteArray())=="a\nb\nc")
    for(b in listOf(byteArrayOf(),byteArrayOf(-64,-81),byteArrayOf(0,5),ByteArray(1024*1024+1)," ".toByteArray(),"a".repeat(500001).toByteArray()))check(runCatching{LyricDocument.decode(b)}.isFailure)
    val rev=LyricDocument.revision("a",1.2,raw)
    check(rev.length==64&&rev==LyricDocument.revision("a",1.2,raw))
    check(rev!=LyricDocument.revision("b",1.2,raw)&&rev!=LyricDocument.revision("a",1.1,raw)&&rev!=LyricDocument.revision("a",1.2,shifted))
    check(LyricDocument.revision("ab",null,"c")!=LyricDocument.revision("a",null,"bc"))
    println("PASS: lyric document UTF-8/UTF-16 BOM, malformed and oversize rejection, plain text, reversible global line/word shift and stale revision detection")
}
