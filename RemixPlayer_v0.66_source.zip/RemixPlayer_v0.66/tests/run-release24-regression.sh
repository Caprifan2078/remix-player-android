#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp=$(mktemp -d);trap 'rm -rf "$tmp"' EXIT
printf 'package app.remix.player\nfun main(){release24Regression()}\n' > "$tmp/Runner.kt"
kotlinc app/src/main/java/app/remix/player/{PlayerExtras,LibraryCore,TimeStretch,AudioCore,WordLyrics}.kt tests/Release24Regression.kt "$tmp/Runner.kt" -include-runtime -d "$tmp/regression.jar"
java -jar "$tmp/regression.jar"
