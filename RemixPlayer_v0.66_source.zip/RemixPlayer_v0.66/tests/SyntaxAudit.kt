import com.intellij.openapi.util.Disposer
import com.intellij.psi.PsiErrorElement
import com.intellij.psi.util.PsiTreeUtil
import org.jetbrains.kotlin.cli.jvm.compiler.KotlinCoreEnvironment
import org.jetbrains.kotlin.cli.jvm.compiler.EnvironmentConfigFiles
import org.jetbrains.kotlin.config.CompilerConfiguration
import org.jetbrains.kotlin.psi.KtPsiFactory
import java.io.File
fun main(args:Array<String>){val parent=Disposer.newDisposable();try{val env=KotlinCoreEnvironment.createForProduction(parent,CompilerConfiguration(),EnvironmentConfigFiles.JVM_CONFIG_FILES);val factory=KtPsiFactory(env.project,false);val files=args.map(::File).flatMap{it.walkTopDown().filter{f->f.isFile&&f.extension=="kt"}.toList()};var failures=0;for(f in files){val parsed=factory.createFile(f.name,f.readText());for(error in PsiTreeUtil.collectElementsOfType(parsed,PsiErrorElement::class.java)){val line=parsed.text.take(error.textOffset).count{it=='\n'}+1;println("${f.path}:$line: ${error.errorDescription}");failures++}};check(failures==0){"$failures syntax errors"};println("PASS: parsed ${files.size} Kotlin source/test files without syntax errors (not Android typechecking)")}finally{Disposer.dispose(parent)}}
