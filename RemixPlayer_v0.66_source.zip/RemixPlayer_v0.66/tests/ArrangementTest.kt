package app.remix.player
import kotlin.math.*
fun arrangementTests(){
    val plan=Arrangement.plan(listOf(.04,.18,.04,.28,.12,.08,.16,.06),31.0)
    check(plan.first().part==Arrangement.Part.INTRO&&plan.last().part==Arrangement.Part.OUTRO)
    check(plan.any{it.part==Arrangement.Part.BUILD}&&plan.any{it.part==Arrangement.Part.DROP}){plan}
    check(plan.zipWithNext().all{(a,b)->a.end==b.start}&&plan.last().end==31.0)
    check(Arrangement.plan(emptyList(),5.0).all{it.part==Arrangement.Part.GROOVE})
    check(Arrangement.plan(listOf(Double.NaN,-1.0),7.0).all{it.part==Arrangement.Part.GROOVE})
    val e=Arrangement.Envelope(plan,8000);var maxDelta=0f;var prev=e.sample(0).drums;var maxRiser=0f
    for(f in 1 until 31*8000){val m=e.sample(f.toLong());check(listOf(m.drums,m.bass,m.sourceDrums,m.riser).all{it.isFinite()&&it in 0f..1f});maxDelta=max(maxDelta,abs(m.drums-prev));prev=m.drums;maxRiser=max(maxRiser,m.riser)}
    check(maxDelta<.01f&&maxRiser>.4f)
    val dir=kotlin.io.path.createTempDirectory().toFile();try{
        val files=Arrangement.batch(listOf(1,2,3),dir,48){n,f,_->f.writeBytes(ByteArray(48){n.toByte()})};check(files.size==3&&files.all{it.second.length()==48L});files.forEach{it.second.delete()}
        check(runCatching{Arrangement.batch(listOf(1,2,3),dir,48){n,f,_->f.writeBytes(ByteArray(if(n==2)12 else 48))}}.isFailure);check(dir.listFiles()!!.isEmpty())
        check(runCatching{Arrangement.batch(listOf(1,2),dir,48){_,f,_->f.writeBytes(ByteArray(48));Thread.currentThread().interrupt()}}.isFailure);Thread.interrupted();check(dir.listFiles()!!.isEmpty())
    }finally{dir.deleteRecursively()}
    println("PASS: dynamic structure, bounded smooth levels, unknown energy fallback, batch success/rollback/cancellation")
}
