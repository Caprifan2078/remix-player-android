package app.remix.player
fun customPresetTests(){
    val p=CustomPresetCore.create("Test",floatArrayOf(.8f,.9f,.4f,.5f,.6f,.7f,.8f));check(CustomPresetCore.exportable(p));check(CustomPresetCore.create(p.name,CustomPresetCore.values(p))==p)
    val extreme=CustomPresetCore.create("Extreme",floatArrayOf(1.8f,.5f,0f,0f,0f,0f,0f));check(CustomPresetCore.exportable(extreme)){"valid extreme preset cannot be saved"}
    for(i in 0..6){val v=CustomPresetCore.values(p);v[i]=Float.NaN;check(runCatching{CustomPresetCore.create("Test",v)}.isFailure)}
    println("PASS: custom preset validation, roundtrip, export limits, non-finite values rejected")
}
