package app.remix.player
fun playlistOrderTests(){
    val ids=listOf("c","a","b")
    check(PlaylistOrder.apply(listOf("a","b","c","d"),ids){it}==ids)
    check(PlaylistOrder.apply(listOf("a","b"),ids){it}==listOf("a","b"))
    check(PlaylistOrder.append(ids,listOf("b","d","c","e",""))==listOf("c","a","b","d","e"))
    check(PlaylistOrder.merge(ids,"a","z")==listOf("c","z","b"))
    check(PlaylistOrder.merge(ids,"c","b")==listOf("a","b"))
    check(PlaylistOrder.move(ids,"x",0)==null&&PlaylistOrder.move(ids,"a",3)==null)
    for(n in 1..25)for(i in 0 until n)for(j in 0 until n){
        val list=List(n){it.toString()};val moved=PlaylistOrder.move(list,list[i],j)!!
        check(moved[j]==list[i]&&moved.size==n&&moved.filter{it!=list[i]}==list.filter{it!=list[i]})
    }
    val large=List(60000){it.toString()};check(PlaylistOrder.apply(large,large.reversed()){it}==large.reversed())
    println("PASS: playlist order, filtered ordering, bulk append without duplicates, group merge, invalid and exhaustive move positions, 60000 entries")
}
