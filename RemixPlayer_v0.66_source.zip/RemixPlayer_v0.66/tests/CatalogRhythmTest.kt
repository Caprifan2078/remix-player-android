package app.remix.player
import java.net.URI
import kotlin.math.*
fun catalogRhythmTests(){
    val entries=ModelCatalog.entries;check(entries.size==8&&entries.map{it.id}.distinct().size==8);check(entries.all{ModelCatalog.allowed(it,URI(it.url))});val model=entries.first();check(model.sha256!!.matches(Regex("[a-f0-9]{64}")));check(ModelCatalog.redirect(model,URI(model.url),"https://cas-bridge.xethub.hf.co/test").host=="cas-bridge.xethub.hf.co")
    for(url in listOf("http://huggingface.co/x","https://huggingface.co.evil.test/x","https://huggingface.co@evil.test/x","https://huggingface.co:444/x","https://127.0.0.1/x","https://huggingface.co/x#fragment")){check(runCatching{ModelCatalog.redirect(model,URI(model.url),url)}.isFailure)}
    check(!ModelCatalog.allowed(entries.first{it.kind==ModelCatalog.Kind.SPEECH},URI("https://alphacephei.com/other.zip")));check(entries.filter{it.kind==ModelCatalog.Kind.SPEECH}.all{it.sha256==null}&&entries.last().sha256!=null);println("PASS: eight pinned catalog entries, SHA metadata, redirect allowlist and hostile URLs rejected")
    check(ModelCatalog.expectedStems(entries.first())==4&&ModelCatalog.expectedStems(entries[1])==6);check(entries[1].sha256=="7ce55792e2231c93fbf92de95f5fd5b3a5e6c89f7db690dfd693e8f1dce56869")
    val c=RhythmMap.Collector();repeat(1600){i->c.add(if(i%50<3).8 else .01)};repeat(1600){i->c.add(if(i%75<3).8 else .01)};repeat(1600){c.add(.01)};val w=c.finish();check(w.size==2);check(abs(w[0].bpm-120)<1);check(abs(w[1].bpm-80)<1);check(w[0].start==0.0&&w[1].start==16.0);check(RhythmMap.unstable(w,120.0));check(!RhythmMap.unstable(listOf(RhythmMap.Window(0.0,16.0,90.0,.8),RhythmMap.Window(16.0,32.0,180.0,.8)),90.0));println("PASS: local tempo map, 120/80 BPM changes, silence rejection, half/double tempo equivalence")
    val measure=VocalConditioning.Measure();repeat(16000){i->measure.add((1000*sin(i*2*PI*440/16000)).toInt().toShort())};check(measure.gain() in 3.0..4.0)
    val f=VocalConditioning.Filter();var last=0.toShort();repeat(16000){last=f.sample(5000)};check(abs(last.toInt())<=1)
    val loud=VocalConditioning.Filter(4.0);repeat(1000){i->loud.sample(if(i%2==0)32767 else -32768)}
    val silence=VocalConditioning.Measure();repeat(1000){silence.add(0)};check(silence.gain()==1.0)
    println("PASS: ASR high-pass DC rejection, bounded gain, silence preservation")
}
