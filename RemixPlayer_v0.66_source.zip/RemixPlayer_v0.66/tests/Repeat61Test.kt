package app.remix.player
fun repeat61Tests(){
    val frames=List(24){i->SectionMap.Frame(i*2.0,.12,.35,.45,.20,.4,List(12){if(it==0).6 else if(it==i%8+1).4 else 0.0})}
    val sections=SectionMap.build(frames,48.0)
    check(sections.size==3&&sections.map{it.start}==listOf(0.0,16.0,32.0)&&sections.map{it.repeatGroup}.distinct().size==1&&sections.first().repeatGroup!=null){"Three repeats lost: $sections"}
    println("PASS: all three non-overlapping repeats retained")
}

