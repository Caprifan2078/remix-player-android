package app.remix.player
import kotlin.math.*
fun playbackTimingTests(){
    check(PlaybackTiming.gain(0,60000,3000,true,true)==0f);check(PlaybackTiming.gain(3000,60000,3000,true,true)==1f);check(PlaybackTiming.gain(60000,60000,3000,true,true)==0f)
    for(i in 0L..3000){val a=PlaybackTiming.gain(i,60000,3000,true,true);val b=PlaybackTiming.gain(60000-i,60000,3000,true,true);check(abs(a-b)<1e-6);if(i>0)check(a>=PlaybackTiming.gain(i-1,60000,3000,true,true))}
    check(PlaybackTiming.gain(1000,2000,5000,true,true)==1f);check(PlaybackTiming.gain(1000,-1,3000,true,true)==1f);check(PlaybackTiming.gain(0,1000,0,true,true)==1f);check(PlaybackTiming.gain(0,1000,500,false,true)==1f)
    val end=PlaybackTiming.deadline(123,15);check(end==900123L&&PlaybackTiming.remaining(123,end)==900000L&&PlaybackTiming.remaining(end,end)==0L&&PlaybackTiming.remaining(end+5,end)==0L)
    println("PASS: bounded symmetric single-player fade, short tracks and unknown durations, monotonic sleep deadline")
}
