package app.remix.player
import java.nio.*
import java.io.File
fun main(args:Array<String>){
    val b=ByteBuffer.wrap(File(args[0]).readBytes()).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer();val x=FloatArray(b.remaining());b.get(x)
    val y=AstGenreCore.features(x);val out=ByteBuffer.allocate(y.size*4).order(ByteOrder.LITTLE_ENDIAN);out.asFloatBuffer().put(y);File(args[1]).writeBytes(out.array())
}
