package app.remix.player
import kotlin.math.*
import java.io.File
fun neuralToneTests(){
    val n=4410
    fun spectrum(style:NeuralInstrumental.Style,part:NeuralTone.Part,freq:Double):DoubleArray{
        val osc=NeuralTone.Oscillator(style,part);osc.tune(freq);val pcm=DoubleArray(n){osc.next()};check(pcm.all{it.isFinite()&&abs(it)<1.36})
        return DoubleArray(5){k->val h=k+1;val re=pcm.indices.sumOf{i->pcm[i]*cos(2*PI*freq*h*i/44100)};val im=pcm.indices.sumOf{i->pcm[i]*sin(2*PI*freq*h*i/44100)};2*hypot(re,im)/n}
    }
    val styles=NeuralInstrumental.Style.entries
    for(part in NeuralTone.Part.entries){val sig=styles.map{spectrum(it,part,440.0)};check(sig.all{it[0]>.65});for(i in sig.indices)for(j in i+1 until sig.size)check(sig[i].indices.sumOf{k->abs(sig[i][k]/sig[i][0]-sig[j][k]/sig[j][0])}>.05)}
    val high=NeuralTone.Oscillator(styles[1],NeuralTone.Part.LEAD);high.tune(9000.0);val pcm=DoubleArray(n){high.next()}
    fun amplitude(f:Double)=2*hypot(pcm.indices.sumOf{i->pcm[i]*cos(2*PI*f*i/44100)},pcm.indices.sumOf{i->pcm[i]*sin(2*PI*f*i/44100)})/n
    check(amplitude(9000.0)>.7&&amplitude(17100.0)<.0001);high.tune(0.0);repeat(100){check(high.next()==0.0)}
    val dir=kotlin.io.path.createTempDirectory("neural-tone").toFile();try{val s=NeuralInstrumental.Settings(styles[0],120,0,false,1,56,mix=NeuralInstrumental.Mix(0,0,100,0));val out=File(dir,"pad.wav");val frames=NeuralInstrumental.render(out,s);var side=0.0;var mid=0.0;out.inputStream().buffered().use{r->java.io.DataInputStream(r).readFully(ByteArray(44));repeat(frames.toInt()){val l=StemCore.readShort(r).toDouble();val rr=StemCore.readShort(r).toDouble();side+=(l-rr)*(l-rr);mid+=(l+rr)*(l+rr)}};check(side>0&&side/mid<.3);check(out.length()==44+frames*4)}finally{dir.deleteRecursively()}
    println("PASS: nine distinct style/part timbres, high-frequency harmonic cutoff, exact mute and bounded stereo pad")
}
