package app.remix.player
import kotlin.math.*
fun genreDynamicsTests(){
    val d=GenreDynamics(8000)
    d.frame(.4f,-.2f);check(d.left==.4f&&d.right==-.2f)
    fun old(x:Float)=if(abs(x)<=.85f)x else sign(x)*(.85f+.15f*tanh((abs(x)-.85f)/.15f))
    val oldRatio=old(1.6f)/old(.8f);check(abs(oldRatio-2f)>.5f)
    d.frame(1.6f,.8f);check(abs(d.left/d.right-2f)<1e-6&&d.left<=1f)
    val compressed=d.left/1.6f;d.frame(.4f,-.2f);check(d.left/.4f>compressed&&d.left<.4f)
    repeat(8000){d.frame(.4f,-.2f)};check(abs(d.left-.4f)<.0001f)
    val rng=kotlin.random.Random(9);repeat(50000){val l=rng.nextFloat()*8-4;val r=rng.nextFloat()*8-4;d.frame(l,r);check(abs(d.left)<=1f&&abs(d.right)<=1f&&abs(d.left*r-d.right*l)<1e-5)}
    val k=KickSpace(8000);repeat(800){check(k.sample(1f,0f)==1f)}
    var g=1f;repeat(160){g=k.sample(1f,1f)};check(g in .38f.. .40f);val low=g;g=k.sample(0f,1f);check(g>low&&g<.41f);repeat(8000){g=k.sample(0f,1f)};check(g>.999f)
    val beat=GenreEngine.Beat(GenreEngine.styles.first(),120.0,0.0,8000);beat.sample(0);check(beat.kickEnvelope==1f);for(i in 1L..3200L)beat.sample(i);check(beat.kickEnvelope==0f)
    val root=kotlin.io.path.createTempDirectory("genre-dynamics").toFile()
    try{
        val frames=22050L
        repeat(4){i->java.io.File(root,"$i.pcm").writeBytes(ByteArray((frames*4).toInt()))}
        val clean=java.io.File(root,"clean.wav");val loud=java.io.File(root,"loud.wav")
        val mix=GenreMix(source=0f,vocals=0f)
        GenreEngine.render(root,frames,4,clean,GenreEngine.styles.first(),120.0,0.0,controls=mix){}
        java.io.File(root,"3.pcm").outputStream().buffered().use{w->repeat((frames*2).toInt()){StemCore.writeShort(w,25000)}}
        GenreEngine.render(root,frames,4,loud,GenreEngine.styles.first(),120.0,0.0,controls=mix){}
        check(clean.readBytes().contentEquals(loud.readBytes())){"Muted vocal must not alter arrangement"}
        check(clean.readBytes().drop(44).any{it!=0.toByte()})
    }finally{root.deleteRecursively()}
    println("PASS: muted vocals do not affect generated accompaniment (two rendered WAVs match)")
    println("PASS: linked stereo peak control preserves channel ratio (old 2:1 became $oldRatio), no clipping, smooth release, kick-dependent bass ducking, muted drums neutral")
}
