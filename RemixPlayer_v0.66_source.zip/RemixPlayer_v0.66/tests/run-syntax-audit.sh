#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
kh=$(dirname "$(dirname "$(readlink -f "$(command -v kotlinc)")")")
tmp=$(mktemp -d);trap 'rm -rf "$tmp"' EXIT
kotlinc -cp "$kh/lib/kotlin-compiler.jar" tests/SyntaxAudit.kt -d "$tmp/audit.jar"
java -cp "$tmp/audit.jar:$kh/lib/*" SyntaxAuditKt app/src/main/java app/src/androidTest/java tests
