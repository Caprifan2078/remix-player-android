package app.remix.player
fun whisperWordTests(){
    val valid=WhisperSegments.parse("10\t200\tПривет мир!\t20,95",23000,25000).single()
    check(valid.wordStarts==listOf(23200L,23950L));val line=Lrc.parse(WhisperSegments.lrc(listOf(valid))).single();val words=WordLyrics.parse(line)
    check(words.text=="Привет мир!"&&words.words.map{it.ms}==valid.wordStarts)
    for(bad in listOf("20,20","9,95","20,200","20","20,95,100","x,95","20,9999999999999999999")){
        val segment=WhisperSegments.parse("10\t200\tHello world\t$bad",0,25000).single();check(segment.wordStarts.isEmpty());check(!WhisperSegments.lrc(listOf(segment)).contains('<'))
    }
    check(WhisperSegments.parse("0\t100\t音楽",0,1000).single().wordStarts.isEmpty())
    val window=WhisperSegments.Window(23000,48000,listOf(valid));check(WhisperSegments.merge(listOf(window)).single().wordStarts==valid.wordStarts)
    println("PASS: Whisper estimated word markers, UTF-8, strict bounds and monotonicity, malformed data phrase fallback, window merge")
}
