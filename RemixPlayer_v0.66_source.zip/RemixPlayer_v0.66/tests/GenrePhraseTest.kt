package app.remix.player
import java.io.File
import kotlin.math.abs
fun genrePhraseTests(){
    val sequences=GenreEngine.styles.indices.map{i->
        for(slot in 0..15){val p=GenrePhrase.probabilities(i,true,slot,1,.9);check(p.all{it.isFinite()&&it>0}&&abs(p.sum()-1)<1e-9)}
        val s=NeuralInstrumental.Settings(GenrePhrase.family(i),GenreEngine.styles[i].target.coerceIn(60,200),0,true,2,5703,genre=i)
        val a=NeuralInstrumental.notes(s);check(a.contentEquals(NeuralInstrumental.notes(s)));check(a.any{it>0});a.toList()
    }
    check(sequences.distinct().size==30){"Distinct sequences: ${sequences.distinct().size}"}
    val distributions=GenreEngine.styles.indices.map{i->(0..15).flatMap{GenrePhrase.probabilities(i,true,it,1,.9).toList()}};check(distributions.distinct().size==30)
    val style=GenreEngine.styles[6];val drum=NeuralDrums(GenrePhrase.family(6),1,style);val bounds=DoubleArray(17){it*5000.0};val plan=drum.plan(bounds);check((0..15).filter{plan.kicks[it]==bounds[it].toLong()}==style.kick.toList())
    val dir=kotlin.io.path.createTempDirectory("genre57").toFile();try{val s=NeuralInstrumental.Settings(GenrePhrase.family(6),135,0,true,1,5703,genre=6);val a=File(dir,"a.wav");val b=File(dir,"b.wav");val n=NeuralInstrumental.render(a,s);NeuralInstrumental.render(b,s);check(n>0&&a.length()==44+n*4&&a.readBytes().contentEquals(b.readBytes()))}finally{dir.deleteRecursively()}
    println("PASS: 30 genre-conditioned symbolic distributions, 30 distinct deterministic sequences, genre percussion plan and actual WAV render")
}
