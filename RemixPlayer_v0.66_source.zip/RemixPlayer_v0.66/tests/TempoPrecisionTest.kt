package app.remix.player
import kotlin.math.*
fun tempoPrecisionTests(){
    for(target in listOf(123.7,137.3,174.2)){
        val interval=6000/target
        val e=List(8000){i->val p=i%interval;val d=min(p,interval-p);.02+.6*exp(-d*d/8.0)}
        val t=Tempo.estimate(e)?:error("No tempo $target")
        val aligned=listOf(t.bpm/2,t.bpm,t.bpm*2).minByOrNull{abs(it-target)}!!;check(abs(aligned-target)<.8){"$target -> ${t.bpm}"}
    }
    check(Tempo.estimate(List(1000){if(it==5)Double.NaN else .01})==null)
    check(Tempo.estimate(List(1000){if(it==5)-1.0 else .01})==null)
    check(Tempo.estimate(List(1000){.01},0)==null)
    println("PASS: fractional-lag BPM precision (half/double equivalent) at 123.7/137.3/174.2, non-finite/negative inputs, invalid envelope rate")
}
