package app.remix.player
fun eqNonfinite65Tests(){
    for(level in listOf(0f,6f)){
        val eq=GraphicEq(44100,2,List(10){if(it==3)level else 0f})
        check(eq.sample(Float.NaN,0)==0f){"EQ failed to sanitize NaN, level=$level"}
        check(eq.sample(Float.POSITIVE_INFINITY,1)==0f){"EQ failed to sanitize infinity"}
        repeat(10000){check(eq.sample(.25f,0).isFinite());check(eq.sample(-.25f,1).isFinite())}
        check(eq.sample(.25f,0)>.1f&&eq.sample(-.25f,1)<-.1f){"EQ state poisoned"}
    }
    println("PASS: EQ bypass and active filters recover from malformed samples")
}
