package app.remix.player
import kotlin.math.*
import java.io.File
fun stretchTests(){
    val dir=kotlin.io.path.createTempDirectory().toFile();try{
        val src=File(dir,"in.wav");val frames=88200L
        src.outputStream().buffered().use{w->StemCore.header(w,frames);for(i in 0 until frames){val v=(sin(i*2*PI*440/44100)*12000).toInt().toShort();StemCore.writeShort(w,v);StemCore.writeShort(w,(-v).toShort())}}
        for(speed in listOf(.75,.85,1.0,1.2,1.33)){
            val dst=File(dir,"out.wav");TimeStretch.render(src,dst,frames,speed);val n=TimeStretch.outputFrames(frames,speed);check(dst.length()==44+n*4)
            if(speed==1.0)check(src.readBytes().contentEquals(dst.readBytes()))
            var crossings=0;var prev=0;dst.inputStream().buffered().use{r->check(r.skip(44)==44L);for(i in 0 until n){val l=StemCore.readShort(r).toInt();val right=StemCore.readShort(r).toInt();check(abs(l+right)<=1);if(i in 4410L until n-4410&&prev<=0&&l>0)crossings++;prev=l}}
            val hz=crossings*44100.0/(n-8820);check(abs(hz-440)<12){"$speed $hz"}
        }
        for(i in 0..1000){val ratio=.4/1.5+(1.8/.5-.4/1.5)*i/1000;val stages=TimeStretch.stages(ratio);check(stages.all{it in .75..1.33});check(abs(stages.fold(1.0){a,b->a*b}-ratio)<1e-6)}
        println("PASS: 1001 staged ratios, unit-speed PCM identity")
        val p=TimeStretch.plan(90.0,180);check(p.speed==1.0&&p.gridBpm==180.0);check(TimeStretch.plan(100.0,150).speed in .75..1.33)
        val l=Lrc.parse(TimeStretch.lyrics("[offset:100]\n[00:01.100]<00:01.100>One <00:02.300>two",1.2)).single();check(l.ms==1000L&&WordLyrics.parse(l).words.map{it.ms}==listOf(1000L,2000L))
        val flac=File(dir,"out.flac");src.inputStream().buffered().use{r->flac.outputStream().buffered().use{FlacExport.encode(r,it)}};check(flac.length()<src.length());check(flac.inputStream().use{String(it.readNBytes(4))}=="fLaC")
        val ff=runCatching{ProcessBuilder("ffmpeg","-version").redirectErrorStream(true).start().also{it.inputStream.readBytes()}.waitFor()==0}.getOrDefault(false)
        if(ff){val raw=File(dir,"decoded.raw");val proc=ProcessBuilder("ffmpeg","-v","error","-y","-i",flac.path,"-f","s16le",raw.path).redirectErrorStream(true).start();val log=proc.inputStream.readBytes();check(proc.waitFor()==0){String(log)};check(raw.readBytes().contentEquals(src.readBytes().copyOfRange(44,src.length().toInt())));println("PASS: FLAC independently decoded, PCM byte identical")}
        val short=File(dir,"short.wav");short.outputStream().use{w->StemCore.header(w,1);repeat(2){StemCore.writeShort(w,1)}};TimeStretch.render(short,File(dir,"short-out.wav"),1,.75)
        val out=File(dir,"cancel.wav");Thread.currentThread().interrupt();check(runCatching{TimeStretch.render(src,out,frames,1.2)}.isFailure);Thread.interrupted();check(!out.exists())
        val batch=Arrangement.batchSized(listOf(3,8),dir,{it.toLong()},0){n,f,_->f.writeBytes(ByteArray(n))};check(batch.map{it.second.length()}==listOf(3L,8L))
    }finally{dir.deleteRecursively()};println("PASS: five tempo ratios, stereo coherence, preserved sine pitch, retimed lyrics, short input, cancellation, variable-size batch")
}
