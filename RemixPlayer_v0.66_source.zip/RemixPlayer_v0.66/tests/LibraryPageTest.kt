package app.remix.player
fun libraryPageTests(){
    for(total in listOf(0,1,99,100,101,199,200,201,60000,60001)){
        var end=100;var visited=0
        do {
            val page=LibraryPage.window(total,end)
            check(page.start==visited&&page.end-page.start in 0..100)
            visited=page.end
            val next=page.nextEnd?:break
            val nextPage=LibraryPage.window(total,next)
            check(nextPage.previousEnd==page.end)
            end=next
        }while(true)
        check(visited==total)
        check(LibraryPage.window(total,Int.MAX_VALUE).end==total)
    }
    check(LibraryPage.window(101,200).start==100)
    println("PASS: bounded 100-row pages, forward/back navigation, empty and partial pages, 60,001 entries")
}
