package app.remix.player
fun trackMetadataTests(){
    data class Song(val id:String,val group:String,val fields:TrackMetadata.Fields,val lyrics:String,val favorite:Boolean,val ratio:Double?)
    val initial=TrackMetadata.Fields("Original","Artist","Album")
    val songs=mutableListOf(Song("a","a",initial,"LRC",false,null),Song("r","a",initial,"Remix LRC",true,1.25))
    val next=TrackMetadata.validated("  Новое название  "," "," Новая пластинка ")
    check(next==TrackMetadata.Fields("Новое название","Неизвестный исполнитель","Новая пластинка"))
    fun replace(id:String,expected:TrackMetadata.Fields)=TrackMetadata.replace(songs,id,expected,next,Song::id,Song::fields){s,f->s.copy(fields=f)}
    check(replace("r",initial));check(songs[1]==Song("r","a",next,"Remix LRC",true,1.25));check(songs[0].fields==initial)
    check(!replace("r",initial)&&!replace("deleted",initial))
    songs[0]=songs[0].copy(favorite=true,lyrics="updated")
    check(replace("a",initial)&&songs[0].favorite&&songs[0].lyrics=="updated")
    for(bad in listOf("", " ","a\nB","\u0000","x".repeat(4097)))check(runCatching{TrackMetadata.validated(bad,"a","")}.isFailure)
    check(runCatching{TrackMetadata.validated("a","b","x".repeat(4097))}.isFailure)
    val index=LibrarySearch(songs,Song::id,Song::group){listOf(it.fields.title,it.fields.artist,it.fields.album)}
    check(index.find("новая пластинка").keys==setOf("a")&&index.find("original").isEmpty())
    println("PASS: metadata validation, stale edit rejection, identity, lyrics and favorite preservation, updated search")
}
