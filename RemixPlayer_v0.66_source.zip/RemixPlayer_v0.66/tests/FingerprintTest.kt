package app.remix.player
import kotlin.math.*
fun fingerprintTests(){
    val notes= intArrayOf(55,64,58,69,53,60,66,57,62,71,54,63,67,59,65,56,70,61,68,52,64,59,72,54,61,67,56,63,69,57,65,60)
    fun wave(speed:Double=1.0,pitch:Double=1.0,volume:Double=1.0,reverse:Boolean=false,delay:Double=0.0):FloatArray=FloatArray((8000*(notes.size*.75/speed+delay)).toInt()){i->val time=i/8000.0-delay;if(time<0)0f else{val slot=(time*speed/.75).toInt().coerceIn(notes.indices);val note=notes[if(reverse)notes.lastIndex-slot else slot];val f=440*2.0.pow((note-69)/12.0)*pitch;((.4*sin(2*PI*f*time)+.16*sin(2*PI*f*2*time)+.08*sin(2*PI*f*3*time))*volume).toFloat()}}
    val a=AudioFingerprint.make(wave());val b=AudioFingerprint.make(wave(volume=.4));check(AudioFingerprint.compare(a,b)!!.score>.99)
    val fast=AudioFingerprint.compare(a,AudioFingerprint.make(wave(1.2,1.2,.8,delay=1.0)));println("fingerprint speed test: $fast");check(fast!=null&&abs(fast.speed-1.2)<.06)
    check(AudioFingerprint.compare(a,AudioFingerprint.make(wave(reverse=true)))==null)
    check(AudioFingerprint.compare(a,AudioFingerprint.make(FloatArray(8000*16)))==null)
    check(AudioFingerprint.compare(a,AudioFingerprint.make(FloatArray(8000*16){sin(2*PI*440*it/8000).toFloat()}))==null)
    println("PASS: audio fingerprint gain invariance, speed/pitch and intro shift, reordered notes, silence and static-tone rejection")
}
