package app.remix.player
fun dspNonfinite65Tests(){
    val original=Presets.all.first()
    val effect=Preset("bass",bass=.55f,room=.2f)
    val d=Dsp(44100,2);val o=FloatArray(2)
    d.frame(floatArrayOf(Float.NaN,Float.POSITIVE_INFINITY),o,original)
    check(o.all{it==0f}){"nonfinite input escaped original: ${o.toList()}"}
    d.frame(floatArrayOf(.25f,-.5f),o,original);check(o.contentEquals(floatArrayOf(.25f,-.5f)))
    d.frame(floatArrayOf(Float.NaN,Float.NEGATIVE_INFINITY),o,effect);check(o.all{it.isFinite()})
    repeat(10000){d.frame(floatArrayOf(.25f,-.25f),o,effect);check(o.all{it.isFinite()})}
    check(kotlin.math.abs(o[0])>.1f && kotlin.math.abs(o[1])>.1f){"DSP history poisoned: ${o.toList()}"}
    println("PASS: malformed PCM sanitized without permanently poisoning DSP state")
}
