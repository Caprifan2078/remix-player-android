package app.remix.player
import java.io.*
import java.nio.file.Files
import java.util.zip.ZipInputStream
fun stemZipTests(){val dir=Files.createTempDirectory("stem-zip").toFile();try{
    val frames=501L;val data=(0 until 6).map{i->ByteArray((frames*4).toInt()){j->(i+j*7).toByte()}.also{File(dir,"$i.pcm").writeBytes(it)}}
    for(count in listOf(4,6)){val out=ByteArrayOutputStream();val progress=mutableListOf<Int>();StemZip.export(dir,frames,count,out){progress.add(it)};check(progress==(1..count).toList());ZipInputStream(out.toByteArray().inputStream()).use{z->repeat(count){i->check(z.nextEntry.name==listOf("drums","bass","other","vocals","guitar","piano")[i]+".wav");val wav=z.readBytes();check(wav.size==44+data[i].size);check(String(wav.copyOfRange(0,4))=="RIFF");check(wav.copyOfRange(44,wav.size).contentEquals(data[i]));z.closeEntry()};check(z.nextEntry==null)}}
    File(dir,"3.pcm").writeBytes(byteArrayOf(0));check(runCatching{StemZip.export(dir,frames,4,ByteArrayOutputStream())}.isFailure)
    println("PASS: 4/6-stem WAV ZIP export, byte-identical PCM, progress, incomplete cache rejection")
}finally{dir.deleteRecursively()}}
