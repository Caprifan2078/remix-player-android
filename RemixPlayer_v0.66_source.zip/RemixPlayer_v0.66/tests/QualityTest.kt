package app.remix.player
import java.io.File
import kotlin.math.*
fun qualityTests(){
    val dir=kotlin.io.path.createTempDirectory("quality").toFile();try{
        fun wave(name:String,fn:(Int)->Pair<Short,Short>):File{val f=File(dir,name);val n=44100*10;f.outputStream().buffered().use{w->StemCore.header(w,n.toLong());repeat(n){i->val (l,r)=fn(i);StemCore.writeShort(w,l);StemCore.writeShort(w,r)}};return f}
        val clean=wave("clean.wav"){i->val v=StemCore.pcm((.25*sin(i*2*PI*440/44100)).toFloat());v to v};val q=RemixQuality.inspect(clean);check(q.score>=95&&q.warnings().isEmpty()&&q.clippedFraction==0.0&&q.internalSilenceSeconds==0.0)
        val clip=wave("clip.wav"){32767.toShort() to (-32768).toShort()};val c=RemixQuality.inspect(clip);check(c.clippedFraction==1.0&&c.dc>.9&&c.score<q.score&&c.warnings().size>=2)
        val silence=wave("silence.wav"){0.toShort() to 0.toShort()};check(RemixQuality.inspect(silence).score==0)
        val gaps=wave("gap.wav"){i->val v=if(i in 44100*3 until 44100*5)0.toShort() else StemCore.pcm((.25*sin(i*2*PI*440/44100)).toFloat());v to v};val g=RemixQuality.inspect(gaps);check(abs(g.internalSilenceSeconds-2)<.01&&g.score<q.score)
        val pulses=wave("pulse.wav"){i->val v=if(i%22050<1102)StemCore.pcm((.6*sin(i*2*PI*440/44100)).toFloat())else 0.toShort();v to v};val beat=RemixQuality.inspect(pulses,120);check(beat.measuredBpm!=null&&abs(beat.measuredBpm-120)<2)
        val bad=File(dir,"bad.wav");bad.writeBytes(ByteArray(48));check(runCatching{RemixQuality.inspect(bad)}.isFailure)
        Thread.currentThread().interrupt();try{check(runCatching{RemixQuality.inspect(clean)}.isFailure)}finally{Thread.interrupted()}
        println("PASS: measured signal quality, clipping, DC, internal gaps, silence, 120 BPM, invalid WAV and cancellation")
        val a=listOf(0,0,0,0,4,4,4,4,7,7,7,7,9,9,9,9);val b=listOf(9,4,0,7,9,4,0,7,9,4,0,7,9,4,0,7)
        val chords=(a+b+a).mapIndexed{i,x->Harmony.Chord(i*.5,x,false,.3)};val r=MusicAnalysis.Report(Tempo.Result(120.0,.8),0.0,"C major",.3,.2,24.0,List(6){.2},chords)
        val matches=StructureCore.repetitions(r);check(matches.any{it.first==0.0&&it.second==16.0});check(matches.none{it.first==0.0&&it.second==8.0});check(StructureCore.profile(r).size==3)
        println("PASS: ordered repeated harmony, reordered histogram rejection, measurable sound descriptors")
        val first=File(dir,"first.pcm");val second=File(dir,"second.pcm");fun raw(f:File,v:Short){f.outputStream().buffered().use{w->repeat(44100*4){StemCore.writeShort(w,v);StemCore.writeShort(w,v)}}};raw(first,8000);raw(second,-8000)
        val mix=File(dir,"transition.wav");val frames=TransitionMix.render(first,second,mix,2);check(frames==44100L*6&&mix.length()==44+frames*4);val input=java.io.RandomAccessFile(mix,"r");input.use{r->fun at(i:Long):Int{r.seek(44+i*4);return (r.readUnsignedByte() or (r.readUnsignedByte() shl 8)).toShort().toInt()};check(at(0)==8000&&at(frames-1)==-8000&&abs(at(44100L*3))<2)}
        Thread.currentThread().interrupt();val cancelled=File(dir,"cancelled.wav");try{check(runCatching{TransitionMix.render(first,second,cancelled,2)}.isFailure);check(!cancelled.exists())}finally{Thread.interrupted()}
        println("PASS: offline DJ transition, exact length, preserved endpoints, midpoint and cancellation")
    }finally{dir.deleteRecursively()}
}
