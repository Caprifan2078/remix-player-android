package app.remix.player
import java.io.File
import java.io.RandomAccessFile
import kotlin.math.*
fun genreCheckpointTests(){
    val root=kotlin.io.path.createTempDirectory("genre-checkpoint").toFile()
    try{
        val raw=File(root,"source.pcm");val frames=22050L
        raw.outputStream().buffered().use{w->repeat(frames.toInt()){i->val x=(sin(i*.08)*12000).toInt().toShort();StemCore.writeShort(w,x);StemCore.writeShort(w,(x/2).toShort())}}
        val styles=GenreEngine.styles.take(3);val p=GenreCheckpoint.Plan(styles,GenreMix(),BeatCorrection.Manual(120.0,0.0),false)
        val dir=EffectCheckpoint.directory(root,java.util.UUID.randomUUID().toString());val calls=mutableListOf<String>();val reuse=mutableListOf<String>()
        fun render(s:GenreEngine.Style,f:File){calls.add(s.name);val tmp=File.createTempFile("tempo-",".wav",f.parentFile);try{val plan=TimeStretch.plan(120.0,s.target);GenreEngine.renderFromMix(raw,tmp,s,plan.gridBpm,0.0,emptyList(),listOf(.1));TimeStretch.render(tmp,f,frames,plan.speed);val stats=Mastering.normalizeGenerated(f);check(stats==Mastering.measure(f))}finally{tmp.delete()}}
        fun run(d:File=dir,plan:GenreCheckpoint.Plan=p,inputs:List<File> = emptyList(), fail:Boolean=false)=GenreCheckpoint.render(raw,inputs,d,plan,120.0,{_,s->reuse.add(s.name)}){s,f,i->if(fail&&i==1)error("process interrupted");render(s,f)}
        check(runCatching{run(fail=true)}.isFailure);check(calls==listOf(styles[0].name))
        val first=File(dir,"version-0.wav").readBytes();val orphan=File(dir,"tempo-orphan.wav").apply{writeText("partial")};calls.clear();val result=run();check(calls==styles.drop(1).map{it.name}&&reuse==listOf(styles[0].name)&&!orphan.exists());check(result[0].second.readBytes().contentEquals(first))
        val baseline=run(EffectCheckpoint.directory(root,java.util.UUID.randomUUID().toString()));check(result.zip(baseline).all{(a,b)->a.second.readBytes().contentEquals(b.second.readBytes())})
        RandomAccessFile(result[1].second,"rw").use{it.seek(100);val b=it.readByte();it.seek(100);it.writeByte(b.toInt() xor 1)};calls.clear();run();check(calls==listOf(styles[1].name))
        calls.clear();check(runCatching{run(plan=p.copy(mix=GenreMix(bass=.2f)))}.isFailure);check(runCatching{run(plan=p.copy(manual=BeatCorrection.Manual(120.0,.2)))}.isFailure);check(calls.isEmpty())
        val stemFiles=List(4){i->File(root,"stem-$i.pcm").also{raw.copyTo(it)}};val advanced=p.copy(separated=true);val advancedDir=EffectCheckpoint.directory(root,java.util.UUID.randomUUID().toString());run(advancedDir,advanced,stemFiles);RandomAccessFile(stemFiles[0],"rw").use{val b=it.readByte();it.seek(0);it.writeByte(b.toInt() xor 1)};check(runCatching{run(advancedDir,advanced,stemFiles)}.isFailure)
        raw.appendBytes(ByteArray(4));check(runCatching{run()}.isFailure);EffectCheckpoint.finish(dir);check(!File(dir,"source.sha256").exists());check(result.all{it.second.isFile})
        println("PASS: genre batch resume, bit-identical output, damaged WAV repair, mix/grid/source/stem changes rejected, completion marker cleanup, mastering exact stats")
    }finally{root.deleteRecursively()}
}
