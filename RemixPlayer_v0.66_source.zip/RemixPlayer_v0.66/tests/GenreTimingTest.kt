package app.remix.player
import kotlin.math.*
fun genreTimingTests(){
    val rate=8000
    val windows=listOf(RhythmMap.Window(0.0,16.0,120.0,.9),RhythmMap.Window(16.0,32.0,90.0,.9))
    val report=MusicAnalysis.Report(Tempo.Result(120.0,.8),0.0,null,0.0,.1,32.0,emptyList(),tempoWindows=windows)
    val manual=BeatCorrection.resolve(report,BeatCorrection.Manual(120.0,22.25,true))!!
    val groove=AdaptiveGroove(manual.bpm,manual.phase,manual.windows,manual.reference,rate,manual.anchor)
    val at=groove.position((manual.anchor*rate).roundToLong());check(abs(at/4-round(at/4))<1e-9){"anchor: $at"}
    val old=AdaptiveGroove(manual.bpm,manual.phase,manual.windows,manual.reference,rate).position((manual.anchor*rate).roundToLong());check(abs(old/4-round(old/4))>.05){"old anchor error $old"}
    var last=groove.position(0);for(i in 1L..32L*rate){val now=groove.position(i);check(now>last);last=now}
    println("PASS: manual beat anchor follows integrated local tempo (old constant-phase position $old, new $at), continuous grid")
    val s=GenreEngine.styles.first{it.name=="Frenchcore"}.copy(snare=intArrayOf(),hat=intArrayOf());val r=44100;val b=GenreEngine.Beat(s,200.0,0.0,r)
    val retrigger=(.15*r).roundToInt();var prev=0f;var jump=0f
    for(i in 0..retrigger){val now=b.sample(i.toLong());if(i==retrigger)jump=abs(now-prev);prev=now}
    val p=DrumPalette.voice(s);val age=(retrigger-1).toDouble()/r;val oldJump=abs(tanh(sin(2*PI*(p.kickHz*age+p.sweepHz*.025*(1-exp(-age/.025))))*exp(-age/p.decay)*(1+s.drive*9))*.52)
    check(oldJump>.4&&jump<.04){"old $oldJump, new $jump"}
    val sparse=s.copy(kick=intArrayOf(0));val tail=GenreEngine.Beat(sparse,120.0,0.0,r);var before=0f;val end=(.36*r).roundToInt();for(i in 0..end){val now=tail.sample(i.toLong());if(i==end)check(abs(now-before)<.002);before=now}
    println("PASS: kick retrigger discontinuity $oldJump -> $jump; smoothed fixed-length tail")
}
