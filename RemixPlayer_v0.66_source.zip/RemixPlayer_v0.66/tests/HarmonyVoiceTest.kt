package app.remix.player
import kotlin.math.*
fun harmonyVoiceTests(){
    val invalid=listOf(Harmony.Chord(0.0,0,false,.01),Harmony.Chord(.2,10000,false,.9),Harmony.Chord(.4,4,false,Double.NaN),Harmony.Chord(Double.NaN,2,false,.9))
    val bass=Harmony.Bass(invalid,120.0,0.0,.5f,intArrayOf(0,4,8,12),emptyList(),8000)
    val lead=LeadSynth(invalid,120.0,0.0,GenreEngine.styles.first(),8000)
    repeat(8000){i->check(bass.sample(i.toLong())==0f);check(lead.sample(i.toLong(),1f)==0f)}
    val valid=Harmony.Chord(0.0,11,false,.9)
    val line=Harmony.Bass(listOf(valid),120.0,0.0,0f,intArrayOf(0),emptyList(),8000)
    check((0L until 1000L).any{abs(line.sample(it))>.01})
    for(root in 0..11)for(interval in listOf(0,3,4,7,12))for(last in 60..83){
        val note=Harmony.leadNote(root,interval,last)
        check(note in 60..83&&note%12==(root+interval)%12&&abs(note-last)<=11)
    }
    check(Harmony.leadNote(11,12,Int.MIN_VALUE)==83)
    check(Harmony.leadNote(0,0,83)==72)
    println("PASS: unreliable/out-of-range harmony muted, valid bass audible, octave-aware lead voice selection")
}
