package app.remix.player
import kotlin.math.*
fun astGenreTests(){
    val silence=AstGenreCore.features(FloatArray(16000));val floor=((ln(1.1920928955078125e-7)+4.2677393)/(2*4.5689974)).toFloat();val pad=(4.2677393/(2*4.5689974)).toFloat()
    check(silence.size==1024*128&&silence.take(98*128).all{abs(it-floor)<1e-6}&&silence.drop(98*128).all{abs(it-pad)<1e-6})
    val tone=FloatArray(16000){(.25*sin(2*PI*440*it/16000)).toFloat()};val features=AstGenreCore.features(tone);check(features.all{it.isFinite()});check(features.take(128).maxOrNull()!!>floor+.5)
    check(!AstGenreCore.audible(FloatArray(48000)));check(AstGenreCore.audible(FloatArray(48000){.1f}));check(AstGenreCore.windows(100,100)==listOf(0L));check(AstGenreCore.windows(300,100)==listOf(0L,100L,200L))
    val one=FloatArray(10){if(it==7)8f else -2f};val two=FloatArray(10){if(it==9)8f else -2f};val result=AstGenreCore.combine(listOf(one,one,one));check(result.accepted&&result.scores.first().label=="Поп"&&abs(result.scores.sumOf{it.probability}-1)<1e-9);check(!AstGenreCore.combine(listOf(one,two)).accepted);check(!AstGenreCore.combine(listOf(FloatArray(10))).accepted);check(runCatching{AstGenreCore.probabilities(FloatArray(10){Float.NaN})}.isFailure)
    println("PASS: AST log-mel shape, silence floor, padding, window selection, stable softmax, agreement and abstention")
}
