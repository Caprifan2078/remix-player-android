package app.remix.player

fun sectionRepeatTests(){
    fun f(i:Int,kind:Int,rms:Double=.12):SectionMap.Frame {
        val chroma=List(12){if(it==0) .6 else if(it==kind+1) .4 else 0.0}
        return SectionMap.Frame(i*2.0,rms,.35,.45,.20,.4,chroma)
    }
    val seq=listOf(0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7)
    val repeated=SectionMap.build(seq.mapIndexed{i,k->f(i,k)},32.0)
    check(repeated.size==2&&repeated[0].end==16.0&&repeated[0].repeatGroup!=null&&repeated[0].repeatGroup==repeated[1].repeatGroup){"Constant-energy repeated passage was lost: $repeated"}
    val constant=SectionMap.build(List(16){f(it,0)},32.0)
    check(constant.none{it.repeatGroup!=null}){"Stationary input should not imply a repeated section: $constant"}
    val sparse=SectionMap.build(List(20){i->f(i,i%8,if(i<12)0.0 else .12)},40.0)
    check(sparse.isNotEmpty()&&sparse.first().start==0.0&&sparse.last().end==40.0){"Quiet intro lost whole song"}
    check(sparse.first().type=="Тихий фрагмент")
    val reversed=SectionMap.build((seq.take(8)+seq.take(8).reversed()).mapIndexed{i,k->f(i,k)},32.0)
    check(reversed.none{it.repeatGroup!=null}){"Different sequence was marked repeated: $reversed"}
    println("PASS: constant-energy repeated phrases, static/reversed sequence rejection, long quiet intro")
}
