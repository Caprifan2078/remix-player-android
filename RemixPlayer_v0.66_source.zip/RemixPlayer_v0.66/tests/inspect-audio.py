import array, csv, hashlib, math, pathlib, subprocess, sys, wave
root=pathlib.Path(sys.argv[1]); rows=[]
with (root/'manifest.tsv').open() as f:
    for item in csv.DictReader(f,delimiter='\t'):
        p=root/item['file']
        with wave.open(str(p),'rb') as w:
            assert (w.getnchannels(),w.getframerate(),w.getsampwidth(),w.getnframes())==(2,44100,2,int(item['frames'])),p
            data=w.readframes(w.getnframes())
        x=array.array('h');x.frombytes(data)
        if sys.byteorder!='little': x.byteswap()
        peak=max(abs(a) for a in x); rms=math.sqrt(sum(a*a for a in x)/len(x))/32768
        clipped=sum(a in (-32768,32767) for a in x)
        assert rms>.0001,p
        decoded=subprocess.check_output(['ffmpeg','-v','error','-xerror','-i',str(p),'-f','s16le','-acodec','pcm_s16le','-'])
        assert decoded==data,p
        rows.append(dict(item,peak=peak,rms=round(rms,7),clipped=clipped,sha256=hashlib.sha256(data).hexdigest()))
assert len(rows)==101
assert len({r['sha256'] for r in rows if r['category']=='neural'})==30
with wave.open(str(root/'effect-00.wav'),'rb') as w:
    assert (root/'fixture.pcm').read_bytes()==w.readframes(int(rows[0]['frames']))
with (root/'metrics.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print(f'PASS: {len(rows)} WAV files independently decoded by FFmpeg; duration, PCM, non-silence, original identity, 30 distinct neural profiles')
print('Full-scale samples by category:',{k:sum(r['clipped'] for r in rows if r['category']==k) for k in ('effect','genre','neural')})
print('Files with full-scale samples:',[(r['name'],r['clipped']) for r in rows if r['clipped']])

if len(sys.argv)>2 and sys.argv[2]=="--require-no-fullscale":
    assert all(r["clipped"]==0 for r in rows), "Full-scale samples in acceptance fixture"
