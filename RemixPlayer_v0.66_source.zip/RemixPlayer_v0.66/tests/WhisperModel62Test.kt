package app.remix.player
fun whisperModel62Tests(){
    val models=WhisperModelSpec.models
    check(models.map{it.id}==listOf("tiny","base","small"))
    check(models.zipWithNext().all{(a,b)->a.size<b.size&&a.minFreeRam<b.minFreeRam})
    check(models.all{it.sha.matches(Regex("[a-f0-9]{64}"))&&WhisperModelSpec.matches(it.size,it.sha)&&!WhisperModelSpec.matches(it.size+1,it.sha)&&!WhisperModelSpec.matches(it.size,"0".repeat(64))})
    check(WhisperModelSpec.maxBytes==487601967L);check(WhisperModelSpec.bySize(0)==null)
    check(!WhisperModelSpec.matches(models.first().size,models.last().sha))
    println("PASS: Whisper multilingual model size/hash binding and memory guard configuration")
}
