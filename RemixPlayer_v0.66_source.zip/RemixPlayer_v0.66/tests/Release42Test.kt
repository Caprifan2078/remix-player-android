package app.remix.player
import kotlin.math.*
fun release42Tests(){
    val s=NeuralInstrumental.Settings(NeuralInstrumental.Style.DANCE,120,0,false,4,42)
    val points=NeuralInstrumental.boundaries(s);val d=NeuralDrums(s.style,s.seed);val p=d.plan(points);val sample=NeuralDrums.Sample()
    check(p.kicks[0]==0L&&p.kicks[4]==points[4].roundToLong());check(p.snares[4]==points[4].roundToLong()&&p.snares[12]==points[12].roundToLong());check(p.hats[2]==points[2].roundToLong()&&p.snares[63]==points[63].roundToLong())
    var peak=0.0;var side=0.0;for(i in 0 until 2000){d.sample(p,2,points[2].roundToLong()+i,sample);peak=maxOf(peak,abs(sample.center));side=maxOf(side,abs(sample.side))};check(peak>.005&&side>.001)
    d.sample(p,1,(points[1]+(points[2]-points[1])*.5).toLong(),sample);check(sample.center==0.0&&sample.side==0.0)
    val dark=NeuralDrums(NeuralInstrumental.Style.DARK,42).plan(points);check(dark.kicks[6]==points[6].roundToLong()&&dark.kicks[4]!=p.kicks[4]);val soft=NeuralDrums(NeuralInstrumental.Style.SOFT,42).plan(points);check(soft.kicks[4]==0L)
    val windows=listOf(RhythmMap.Window(0.0,8.0,100.0,.9),RhythmMap.Window(8.0,16.0,150.0,.9));val moving=NeuralInstrumental.boundaries(s.copy(bars=12),NeuralInstrumental.Follow(emptyList(),120.0,250,windows));val mp=d.plan(moving);check(mp.kicks[64]==moving[64].roundToLong());check(mp.kicks[64]!=64*points[1].roundToLong())
    println("PASS: neural drums distinct style patterns, variable grid, snare and hat energy, stereo, silent gap, four-bar fill")
}
