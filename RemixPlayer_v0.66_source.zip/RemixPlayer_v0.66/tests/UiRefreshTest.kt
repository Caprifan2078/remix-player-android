package app.remix.player
fun uiRefreshTests(){
    check(UiRefresh.delayMs(true,true,false)==100L)
    check(UiRefresh.delayMs(true,false,false)==250L)
    check(UiRefresh.delayMs(false,true,false)==500L)
    check(UiRefresh.delayMs(false,false,true)==250L)
    for(d in listOf(1L,1000L,Long.MAX_VALUE)){
        check(UiRefresh.progress(-1,d)==0)
        check(UiRefresh.progress(d,d)==1000)
        check(UiRefresh.progress(d/2,d) in 0..500)
    }
    check(UiRefresh.progress(100,-1)==0)
    val line=WordLyrics.Line("x",List(60000){WordLyrics.Word(it/2*10L,0,1)})
    for(ms in listOf(-1L,0L,1L,10L,55L,299990L,Long.MAX_VALUE))check(WordLyrics.current(line,ms)==line.words.indexOfLast{it.ms<=ms})
    check(WordLyrics.current(WordLyrics.Line("",emptyList()),0)==-1)
    println("PASS: adaptive UI cadence, bounded progress, duplicate word timestamps and 60000-word binary lookup")
}
