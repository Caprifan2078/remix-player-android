package app.remix.player
import java.io.*
import kotlin.math.*
fun eqRenderTests(){val dir=kotlin.io.path.createTempDirectory("eq-render").toFile();try{
    val raw=File(dir,"source.pcm");val frames=44100L;raw.outputStream().buffered().use{w->for(i in 0 until frames){StemCore.writeShort(w,(8000*sin(2*PI*1000*i/44100)).roundToInt().toShort());StemCore.writeShort(w,0)}};val bytes=raw.readBytes();val flat=File(dir,"flat.wav");EqRender.render(raw,flat,List(10){0f});check(flat.readBytes().copyOfRange(44,flat.length().toInt()).contentEquals(bytes));val cut=File(dir,"cut.wav");EqRender.render(raw,cut,List(10){if(it==5)-12f else 0f});check(cut.length()==flat.length());val levels=Mastering.measure(cut);check(levels.rms/Mastering.measure(flat).rms in .23.. .28);cut.inputStream().buffered().use{r->check(r.skip(44)==44L);repeat(frames.toInt()){StemCore.readShort(r);check(StemCore.readShort(r)==0.toShort())}};check(raw.readBytes().contentEquals(bytes))
    val canceled=File(dir,"cancel.wav");Thread.currentThread().interrupt();try{check(runCatching{EqRender.render(raw,canceled,List(10){0f})}.isFailure);check(!canceled.exists())}finally{Thread.interrupted()};println("PASS: EQ render flat PCM identity, -12 dB band response, stereo isolation, source preserved, cancellation")
}finally{dir.deleteRecursively()}}
