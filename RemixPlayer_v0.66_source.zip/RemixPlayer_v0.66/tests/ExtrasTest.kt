package app.remix.player
import kotlin.math.*
import kotlin.random.Random
fun extrasTests(){
    val rng=Random(17);val seen=List(200){VersionChoice.random("orig",listOf("orig","a","b"),rng)}.toSet();check(seen==setOf("orig","a","b"));check(VersionChoice.random("orig",emptyList<String>())=="orig")
    var hist=ListeningStats.add(emptyList(),"a",5000,10000);hist=ListeningStats.add(hist,"a",3000,13000);check(hist.single().playedMs==8000L);check(ListeningStats.add(hist,"a",16000,29000)==hist);hist=ListeningStats.add(hist,"b",1000,14000,1);check(hist.single().id=="b")
    val flat=GraphicEq(44100,2,List(10){0f});check(flat.sample(.37f,0)==.37f)
    val levels=List(10){if(it==5)12f else 0f};val eq=GraphicEq(44100,2,levels);var power=0.0;var side=0.0;for(i in 0 until 44100){val y=eq.sample((.1*sin(2*PI*1000*i/44100)).toFloat(),0);val r=eq.sample(0f,1);check(y.isFinite()&&y in -1f..1f);if(i>22050){power+=y*y;side+=r*r}};check(power>90&&side==0.0)
    val chords=List(64){i->Harmony.Chord(i*.5,if(i in 16..31)5 else if(i%2==0)0 else 7,false,.3)};val report=MusicAnalysis.Report(Tempo.Result(145.0,.8),0.0,"C major",.4,.15,32.0,List(8){.15},chords);check(RemixAdvisor.repetitions(report).any{it.first==0.0&&it.second==16.0});val picks=RemixAdvisor.recommend(report);check(picks.size==5&&picks.map{it.style.name}.distinct().size==5);check(RemixAdvisor.recommend(report.copy(tempo=null)).isEmpty());check(RemixAdvisor.repetitions(report.copy(chords=emptyList())).isEmpty())
    val f=java.io.File.createTempFile("digest-test", ".txt");try{f.writeText("abc");check(VerifiedDownload.matches(f,"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"));check(!VerifiedDownload.matches(f,"0".repeat(64)))}finally{f.delete()}
    val lead=LeadSynth(chords,145.0,0.0,GenreEngine.styles.first());var peak=0f;for(i in 0 until 44100){val v=lead.sample(i.toLong(),1f);check(v.isFinite()&&abs(v)<.1f);peak=max(peak,abs(v))};check(peak>.01f);val quiet=LeadSynth(emptyList(),145.0,0.0,GenreEngine.styles.first());check((0L..1000L).all{quiet.sample(it,1f)==0f})
    println("PASS: bounded chord-tone lead and silence without harmony")
    println("PASS: random versions, bounded listening history, 10-band EQ identity/frequency/channel isolation, remix suggestions and repeated harmony")
}
