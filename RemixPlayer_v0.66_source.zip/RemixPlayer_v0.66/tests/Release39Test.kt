package app.remix.player
import kotlin.math.abs
import java.io.File
fun release39Tests(){
    for(style in NeuralInstrumental.Style.entries)for(slot in 0..15)for(prev in 0..8){val p=NeuralInstrumental.probabilities(style,true,slot,prev);check(p.all{it.isFinite()&&it>0}&&abs(p.sum()-1)<1e-10)}
    val settings=NeuralInstrumental.Settings(NeuralInstrumental.Style.DARK,120,0,true,1,39)
    check(NeuralInstrumental.notes(settings).contentEquals(NeuralInstrumental.notes(settings)));check((40..50).any{!NeuralInstrumental.notes(settings).contentEquals(NeuralInstrumental.notes(settings.copy(seed=it)))})
    val dir=kotlin.io.path.createTempDirectory("neural-test").toFile();try{val a=File(dir,"a.wav");val b=File(dir,"b.wav");val n=NeuralInstrumental.render(a,settings);check(n==88200L&&a.length()==44+n*4);NeuralInstrumental.render(b,settings);check(a.readBytes().contentEquals(b.readBytes()));a.inputStream().buffered().use{r->java.io.DataInputStream(r).readFully(ByteArray(44));var peak=0;repeat((n*2).toInt()){peak=maxOf(peak,abs(StemCore.readShort(r).toInt()))};check(peak in 1000..32000)};check(runCatching{settings.copy(bpm=0)}.isFailure)}finally{dir.deleteRecursively()}
    println("PASS: trained symbolic note model probabilities, seed diversity, repeatable bounded PCM generation")
    val seg=WhisperSegments.parse("0\t100\tПривет мир\n100\t200\t[музыка]\n-1\t1\tbad\n300\t999999999\tbad\n",25000,25000)
    check(seg.size==2&&seg[0].startMs==25000L&&seg[1].endMs==27000L);val lrc=WhisperSegments.lrc(seg);check(Lrc.parse(lrc).map{it.ms}==listOf(25000L,26000L));check(!lrc.contains('<'));check(!lrc.contains("bad"));check(WhisperSegments.parse("0\t100\t音楽",0,1000).single().text=="音楽")
    println("PASS: Whisper segment timestamps, UTF-8 text, bounds, no fabricated word timing")
}
