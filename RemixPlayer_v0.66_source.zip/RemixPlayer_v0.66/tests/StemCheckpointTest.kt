package app.remix.player
import java.io.File
import java.io.RandomAccessFile
import kotlin.math.sin
fun stemCheckpointTests(){
    val root=kotlin.io.path.createTempDirectory("stem-checkpoint").toFile()
    try{
        val frames=77L;val block=16;val overlap=4;val count=4
        fun open(name:String,key:String="input:model")=StemCheckpoint.open(File(root,name),key,frames,count,block,overlap)
        fun fill(c:StemCheckpoint,i:Int){c.commit{j->sin((i*100+j)*.07).toFloat()*.8f}}
        val baseline=open("baseline");while(baseline.next<baseline.starts.size)fill(baseline,baseline.next)
        var interrupted=open("resume");fill(interrupted,0);fill(interrupted,1)
        File(interrupted.dir,"0.pcm").appendBytes(ByteArray(44){17});File(interrupted.dir,"state.part").writeText("partial")
        interrupted=open("resume");check(interrupted.next==2);check(File(interrupted.dir,"0.pcm").length()==interrupted.committedFrames*4)
        while(interrupted.next<interrupted.starts.size)fill(interrupted,interrupted.next)
        repeat(count){check(File(baseline.dir,"$it.pcm").readBytes().contentEquals(File(interrupted.dir,"$it.pcm").readBytes()))}
        // Independently reproduce the old overlap-add math; the new uninterrupted path must match too.
        repeat(count){st->val expected=java.io.ByteArrayOutputStream();for((i,start) in baseline.starts.withIndex()){
            val n=if(i==baseline.starts.lastIndex)(frames-start).toInt() else block-overlap
            for(k in 0 until n)for(ch in 0..1){val channel=st*2+ch;fun v(b:Int,pos:Int)=sin((b*100+channel*block+pos)*.07).toFloat()*.8f
                val x=if(i>0&&k<overlap)StemCore.blend(v(i-1,block-overlap+k),v(i,k),k,overlap)else v(i,k)
                StemCore.writeShort(expected,StemCore.pcm(x))}
        };check(expected.toByteArray().contentEquals(File(baseline.dir,"$st.pcm").readBytes()))}
        check(open("resume").next==baseline.starts.size)
        RandomAccessFile(File(interrupted.dir,"0.pcm"),"rw").use{val v=it.readByte();it.seek(0);it.writeByte(v.toInt() xor 255)};check(open("resume").next==0)
        val changed=open("change");fill(changed,0);check(open("change","new input:model").next==0)
        val corrupt=open("corrupt");fill(corrupt,0);File(corrupt.dir,"state.bin").appendBytes(byteArrayOf(1));check(open("corrupt").next==0)
        val cancelled=open("cancel");fill(cancelled,0);Thread.currentThread().interrupt();try{check(runCatching{fill(cancelled,1)}.isFailure)}finally{Thread.interrupted()};check(open("cancel").next==1)
        println("PASS: stem checkpoint resumes bit-identical PCM/overlap, truncates uncommitted append, rejects corrupted PCM/state and changed input, preserves cancelled block prefix")
    }finally{root.deleteRecursively()}
}
