package app.remix.player
fun libraryTests(){
    data class Song(val id:String,val group:String)
    val originals=(0 until 30000).map{Song("$it","$it")}
    val versions=originals.map{Song("r${it.id}",it.id)}
    val index=LibraryIndex(originals+versions,Song::id,Song::group)
    check(index.get("r42")==versions[42]);check(index.get(null)==null);check(index.versions("42")==listOf(originals[42],versions[42]))
    check(index.preferred(originals[42],"r43")==originals[42]);check(index.preferred(originals[42],"r42")==versions[42])
    for(n in listOf(0,1,100,299,15000,29999)){
        var calls=0;val queue=index.queue(originals,versions[n],"$n",{calls++;"r$it"})
        check(queue.size==300&&queue.contains(versions[n])&&queue.distinct().size==300&&calls==299)
    }
    check(index.queue(emptyList(),versions[0],"0",{null}).isEmpty())
    check(index.queue(originals.take(10),originals[9],"9",{null}).size==10)
    check(PlaybackBookmark.position(-4,100)==0L&&PlaybackBookmark.position(200,100)==99L)
    check(PlaybackBookmark.transfer(90000,1.0,1.25)==72000L&&PlaybackBookmark.transfer(1000,null,1.0)==0L)
    println("PASS: 60,000 indexed tracks, six bounded queue windows, invalid preferences, bookmark and tempo mapping")
}
