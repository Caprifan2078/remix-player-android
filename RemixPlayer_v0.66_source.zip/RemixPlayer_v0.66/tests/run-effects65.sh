#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
printf 'package app.remix.player\nfun main(){effectTests()}\n' > "$tmp/Main.kt"
kotlinc app/src/main/java/app/remix/player/{GenrePhrase,GenrePhraseWeights,NeuralTone,NeuralInstrumental,NeuralDrums,PhraseWeights,Harmony,AdaptiveGroove,RhythmMap,StemCore,GenreEngine,GenreMix,Arrangement,LeadSynth,VocalSpace,GenreDynamics,Tempo,MusicAnalysis,SoundProfile,SectionMap,StructureCore,RemixAdvisor,MusicalIntelligence,TimeStretch,AudioCore,EffectRender}.kt tests/EffectTest.kt "$tmp/Main.kt" -include-runtime -d "$tmp/test.jar"
java -jar "$tmp/test.jar"
