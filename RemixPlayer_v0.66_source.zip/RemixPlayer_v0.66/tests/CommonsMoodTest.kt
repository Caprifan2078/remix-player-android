package app.remix.player

fun commonsMoodTests(){
    val source="https://commons.wikimedia.org/wiki/File:Music.ogg"
    val url="https://upload.wikimedia.org/wikipedia/commons/a/aa/Music.ogg"
    fun recording(u:String=url,s:String=source,l:String="CC0 1.0",lu:String="https://creativecommons.org/publicdomain/zero/1.0/",mime:String="audio/ogg",media:String="AUDIO",bytes:Long=100,restrictions:String="")=CommonsAudioCore.recording("File:Music.ogg","Composer",s,u,mime,media,l,lu,restrictions,bytes)
    check(recording()?.title=="Music")
    check(recording(mime="application/ogg")!=null)
    check(recording(l="Public domain",lu="https://commons.wikimedia.org/wiki/Help:Public_domain")!=null)
    for(u in listOf("http://upload.wikimedia.org/wikipedia/commons/a.ogg","https://upload.wikimedia.org.evil.org/wikipedia/commons/a.ogg","https://upload.wikimedia.org@evil.org/wikipedia/commons/a.ogg","https://upload.wikimedia.org/wikipedia/commons/../a.ogg","https://upload.wikimedia.org/wikipedia/commons/a.ogg?q=1"))check(recording(u=u)==null)
    check(recording(s="https://evil.org/wiki/File:Music.ogg")==null);check(recording(l="CC BY-SA 4.0")==null);check(recording(lu="https://evil.org/")==null);check(recording(mime="video/mp4")==null);check(recording(media="VIDEO")==null);check(recording(bytes=0)==null);check(recording(bytes=CommonsAudioCore.MAX_BYTES+1)==null);check(recording(restrictions="other") == null)
    val q=CommonsAudioCore.query("Моцарт & piano");check("filetype%3Aaudio" in q&&"%26" in q&&"gsrnamespace=6" in q);check(runCatching{CommonsAudioCore.query(" ")}.isFailure)
    println("PASS: Commons strict audio/license/host/size filtering and encoded search")
    check(MoodCore.starts(44100L*3)==listOf(0L));check(MoodCore.starts(44100L*20)==listOf(44100L*5/2));check(MoodCore.starts(44100L*60)==listOf(0L,44100L*45/2,44100L*45))
    val happy=MoodCore.Result(.9f,.9f);val sad=MoodCore.Result(.1f,.1f)
    check(MoodCore.combine(listOf(happy,happy,happy)).label=="Бодрое");check(MoodCore.combine(listOf(happy,sad)).label==null);check(MoodCore.combine(listOf(happy,MoodCore.Result(.8f,.8f),sad)).label=="Бодрое");check(MoodCore.combine(listOf(happy,MoodCore.Result(.1f,.9f))).label==null)
    println("PASS: mood multi-window sampling, consensus and ambiguity rejection")
}
