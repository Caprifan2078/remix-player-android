package app.remix.player
import java.io.File
import kotlin.math.*
fun backingFitTests(){
    fun report(bpm:Double,key:String="C major",phase:Double=.1,confidence:Double=.8,windows:List<RhythmMap.Window> = emptyList())=MusicAnalysis.Report(Tempo.Result(bpm,confidence),phase,key,.12,.2,20.0,emptyList(),tempoWindows=windows)
    val base=report(120.0,"D major",.2);val back=report(100.0,"C major",.1)
    val p=BackingFit.plan(base,back,BackingFit.Options(true,true,true),10)
    check(abs(p.speed-1.2)<1e-9&&p.semitones==2&&p.offsetMs==127)
    val half=BackingFit.plan(base,report(60.0,"B minor"),BackingFit.Options(true,true,true))
    check(half.speed==1.0&&half.semitones==0&&half.offsetMs==0)
    val unknown=BackingFit.plan(base,report(100.0,confidence=.1),BackingFit.Options(),50);check(unknown.speed==1.0&&unknown.offsetMs==50)
    val changing=report(100.0,windows=listOf(RhythmMap.Window(0.0,16.0,100.0,.9),RhythmMap.Window(16.0,32.0,125.0,.9)))
    check(!BackingFit.plan(base,changing,BackingFit.Options()).changed)
    check(BackingFit.plan(base,report(85.0),BackingFit.Options()).speed==1.0)
    val dir=kotlin.io.path.createTempDirectory("fit38-").toFile()
    try{val raw=File(dir,"raw.pcm");raw.outputStream().buffered().use{w->repeat(44100){i->val v=(10000*sin(2*PI*440*i/44100)).roundToInt().toShort();StemCore.writeShort(w,v);StemCore.writeShort(w,(-v.toInt()).toShort())}}
        val prepared=File(dir,"fit.pcm");check(BackingFit.prepare(raw,prepared,BackingFit.Plan(1.0,0,0,emptyList()))==raw&&!prepared.exists())
        check(BackingFit.prepare(raw,prepared,p)==prepared);check(abs(prepared.length()/4-36750)<5);check(raw.length()==176400L)
        var crosses=0;var last=0;prepared.inputStream().buffered().use{r->repeat((prepared.length()/4).toInt()){val l=StemCore.readShort(r).toInt();val right=StemCore.readShort(r).toInt();check(abs(l+right)<=1);if(last<=0&&l>0)crosses++;last=l}}
        val hz=crosses*44100.0/(prepared.length()/4);check(hz in 475.0..515.0){"pitch $hz"}
        val out=File(dir,"mix.wav");check(AccompanimentMix.render(raw,prepared,out,AccompanimentMix.Settings(p.offsetMs))==44100L&&out.length()==176444L)
    }finally{dir.deleteRecursively()}
    println("PASS: backing fit tempo, relative keys, weak/variable tempo rejection, phase offset, stereo pitch and original timeline")
}
