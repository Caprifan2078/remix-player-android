#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp=$(mktemp -d);trap 'rm -rf "$tmp"' EXIT
jar="$tmp/test.jar"
cat > "$tmp/Main.kt" <<'KOTLIN'
package app.remix.player
fun main(){var failed=0;for(test in listOf(::boundary66Tests,::queueBoundary66Tests,::resamplerQualityTests,::queueEditTests)){try{test()}catch(e:Exception){failed++;println("FAIL: ${e.message}")}};check(failed==0){"$failed failing groups"}}
KOTLIN
kotlinc app/src/main/java/app/remix/player/{StemCore,QueueEdit,QueueSnapshot,LibraryCore,TimeStretch,AudioCore}.kt tests/Boundary66Test.kt tests/ResamplerQualityTest.kt tests/QueueEditTest.kt "$tmp/Main.kt" -include-runtime -d "$jar"
java -jar "$jar"
