package app.remix.player
import kotlin.math.*
fun release21Tests(){
    val report=MusicAnalysis.Report(null,null,null,0.0,.1,60.0,List(15){.1})
    check(BeatCorrection.resolve(report,null)==null);val grid=BeatCorrection.resolve(report,BeatCorrection.Manual(120.0,2.25))!!;check(grid.bpm==120.0&&abs(grid.phase-.25)<1e-9&&grid.windows.isEmpty());check(BeatCorrection.resolve(report,BeatCorrection.Manual(120.0,60.0))==null)
    val tap=BeatCorrection.Tap();val values=listOf(1000L,1500,2002,2500,3001).map{tap.add(it)};check(abs(values.last()!!-120)<.5);check(tap.add(6000)==null)
    println("PASS: manual BPM and anchor, missing automatic beat recovery, tap tempo, invalid duration")
    fun ex(i:Int,l:String,v:Double)=PersonalTags.Example("$l$i",l,List(PersonalTags.DIM){v})
    val examples=(0..3).map{ex(it,"Calm",.15+it*.01)}+(0..3).map{ex(it,"Club",.80+it*.01)}
    check(PersonalTags.predict(List(10){.17},examples)?.label=="Calm");check(PersonalTags.predict(List(10){.82},examples)?.label=="Club");check(PersonalTags.predict(List(10){.5},examples)==null);check(PersonalTags.predict(List(10){.17},examples.take(4))==null);check(PersonalTags.predict(List(10){.17},examples.take(3)+examples.takeLast(4),"Calm0")==null)
    check(PersonalTags.features(report)==null)
    println("PASS: personal classifier, two labels, uncertain and sparse abstention, self-exclusion")
    val timed="[offset:100]\n[00:01.000]<00:01.000>Hello <00:01.500>world\n[00:03.000]<00:03.000>Привет <00:03.700>мир"
    val aligned=LyricAlign.align(timed,"Hello, world!\nПривет, мир!");check(aligned.complete&&aligned.matched==4&&aligned.unmatchedLines.isEmpty());val parsed=Lrc.parse(aligned.lrc);check(parsed.map{it.ms}==listOf(1100L,3100L));check(WordLyrics.parse(parsed[0]).text=="Hello, world!");check(WordLyrics.parse(parsed[0]).words.map{it.ms}==listOf(1100L,1600L));val partial=LyricAlign.align(timed,"Hello brave world\nПривет мир");check(!partial.complete&&partial.unmatchedLines==listOf(1)&&partial.matched==4);check(runCatching{LyricAlign.align("[00:01]hello", "hello")}.isFailure);println("PASS: lyric alignment, exact word times and offset, multilingual punctuation, partial match rejection")
    val cache=ReportCache<Int,String>(3);cache[1]="a";cache[2]="b";cache[3]="c";check(cache[1]=="a");cache[4]="d";check(cache.keys.toList()==listOf(3,1,4));check(cache[2]==null)
    val stream=RenderAnalysis();val reference=MusicAnalysis.Analyzer(44100);val mono=AnalysisMono{reference.sample(it)}
    repeat(44100*10){i->val x=(sin(2*PI*440*i/44100)*(if(i%22050<1200)16000 else 1000)).toInt().toShort();val y=(-x).toShort();stream.frame(x,y);mono.frame(x/32768.0,y/32768.0)};mono.finish();val a=stream.finish();val b=reference.finish();check(a==b&&a.duration==10.0&&a.rms>.01);check(runCatching{stream.finish()}.isFailure)
    println("PASS: single-pass canonical PCM analysis, exact stereo report equivalence, bounded LRU")
    val repeated="[00:01.000]<00:01.000>hey <00:02.000>you\n[00:10.000]<00:10.000>hey <00:11.000>you";val amb=LyricAlign.align(repeated,"hey you");check(amb.ambiguous&&!amb.complete);check(LyricAlign.align(repeated,"hey you\nhey you").complete)
    val sync=LyricTapSync("First\n\nВторая\nThird");sync.mark(0);sync.mark(2200);check(runCatching{sync.mark(2000)}.isFailure);sync.undo();sync.mark(2400);check(runCatching{sync.lrc()}.isFailure);sync.mark(5500);check(Lrc.parse(sync.lrc()).map{it.ms}==listOf(0L,2400L,5500L));check(runCatching{sync.mark(6000)}.isFailure)
    println("PASS: ambiguous repeated-word alignment rejection, manual line timing, undo and incomplete-save prevention")
}
