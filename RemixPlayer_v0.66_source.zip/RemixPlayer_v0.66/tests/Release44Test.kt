package app.remix.player
import java.io.File
import kotlin.math.abs
fun release44Tests(){
    val s=NeuralInstrumental.Settings(NeuralInstrumental.Style.DANCE,120,0,false,8,44,variation=0)
    val n=NeuralInstrumental.notes(s);check(n.sliceArray(0..31).contentEquals(n.sliceArray(32..63)));check(n.sliceArray(64..95).contentEquals(n.sliceArray(96..127)))
    check(!n.contentEquals(NeuralInstrumental.notes(s.copy(variation=100))));check(n.contentEquals(NeuralInstrumental.notes(s)))
    check(runCatching{s.copy(variation=101)}.isFailure);check(runCatching{NeuralInstrumental.Mix(-1)}.isFailure)
    val longer=s.copy(bars=16);val levels=(0..256).map{NeuralInstrumental.sectionLevels(longer,it)};check(levels.all{a->a.all{it in 0.0..1.0}});check(levels[112][0]<levels[64][0]);check(levels.zipWithNext().all{(a,b)->a.indices.all{abs(a[it]-b[it])<.08}})
    val dir=kotlin.io.path.createTempDirectory("neural-mix").toFile();try{
        val short=s.copy(bars=1);val a=File(dir,"a.wav");val b=File(dir,"b.wav");val silent=File(dir,"silent.wav")
        val f=NeuralInstrumental.render(a,short);check(NeuralInstrumental.render(b,short.copy(mix=NeuralInstrumental.Mix(0,0,0,100)))==f)
        check(!a.readBytes().contentEquals(b.readBytes()));check(NeuralInstrumental.render(silent,short.copy(mix=NeuralInstrumental.Mix(0,0,0,0)))==f);check(silent.readBytes().drop(44).all{it==0.toByte()});check(silent.length()==a.length())
        // All four parts can be isolated; each actually produces sound, not just metadata.
        for(m in listOf(NeuralInstrumental.Mix(100,0,0,0),NeuralInstrumental.Mix(0,100,0,0),NeuralInstrumental.Mix(0,0,100,0),NeuralInstrumental.Mix(0,0,0,100))){NeuralInstrumental.render(b,short.copy(mix=m));check(b.readBytes().drop(44).any{it!=0.toByte()})}
    }finally{dir.deleteRecursively()}
    println("PASS: neural motif recurrence, variation, deterministic notes, smooth section levels, four independently audible parts, exact mute and duration")
}
