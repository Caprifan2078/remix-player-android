package app.remix.player
import kotlin.math.*
fun main(){
    boundary66Tests();queueBoundary66Tests();dspNonfinite65Tests();eqNonfinite65Tests();
    whisperBoundary63Tests();repeat61Tests();mixedLyrics62Tests();whisperModel62Tests();peakGuardTests();
    commonsMoodTests();portablePlaybackTests();lyricStructureTests();genrePhraseTests();fingerprintTests();whisperWordTests();neuralToneTests();
    playerUiSafetyTests();uiRefreshTests();lyricDocumentTests();neuralArticulationTests();groupEditTests();libraryPageTests();trackMetadataTests();batchHistoryTests();playlistOrderTests();queueEditTests();phraseAlignTests();release44Tests();release43Tests();release42Tests();release41Tests();release40Tests();release39Tests();backingFitTests();release37Tests();astGenreTests();barArrangementTests();musicalIntelligenceTests();librarySearchTests();timedLineEditTests();asrPreparationTests();sectionRepeatTests();harmonyVoiceTests();genreTimingTests();genreDynamicsTests();genreCheckpointTests();stemCheckpointTests();effectCheckpointTests();workGateTests();release24Regression();release23Regression();modelDiagnosticTests();storageTests();portableSettingsTests();audioFileTests();release21Tests();tempoPrecisionTests();genreMixTests();overlapTests();eqRenderTests();analysisLoopTests();flacCompressionTests();resamplerQualityTests();queueSnapshotTests();playbackTimingTests();sectionMapTests();adaptiveGrooveTests();catalogRhythmTests();mixerTests();qualityTests();extrasTests();stemZipTests();customPresetTests();groupingTests();backupTests();release09Tests();effectTests();libraryTests();subtitleTests();stretchTests()
    stemTests()
    genreTests()
    harmonyTests()
    arrangementTests()
    val wl=WordLyrics.parse(Lrc.parse("[offset:100]\n[00:01.00]<00:01.00>One <00:01.50>two").single());check(wl.text=="One two"&&wl.words.map{it.ms}==listOf(1100L,1600L)&&WordLyrics.current(wl,1600)==1);check(WordLyrics.parse(Lyric(0,"Plain")).words.isEmpty());println("PASS: enhanced LRC word markers and offset")
    check(Presets.all.size==41)
    check(Presets.all.map{it.name}.distinct().size==41)
    val lines=Lrc.parse("[offset:100]\n[00:01.2][00:02.34]Hello\n[00:03]World\n[00:99]invalid")
    check(lines.map{it.ms}==listOf(1300L,2440L,3100L));check(Lrc.current(lines,0)==-1);check(Lrc.current(lines,2440)==1);check(Lrc.current(lines,10000)==2)
    val input=floatArrayOf(.25f,-.5f); val output=FloatArray(2);val dsp=Dsp(48000,2);dsp.frame(input,output,Presets.all.first());check(input.contentEquals(output))
    for(p in Presets.all){val d=Dsp(44100,2); repeat(20000){i->input[0]=sin(i*.1).toFloat();input[1]=cos(i*.2).toFloat();d.frame(input,output,p);check(output.all{it.isFinite()&&it in -1f..1f})}}
    val d=Dsp(48000,1);val i=floatArrayOf(1f);val o=FloatArray(1);val p=Preset("room",room=.8f);d.frame(i,o,p);i[0]=0f;var tail=false;repeat(5000){d.frame(i,o,p);if(abs(o[0])>.01)tail=true};check(tail)
    val beat=List(3000){if(it%50<3) .8 else .01};val tempo=Tempo.estimate(beat);check(tempo!=null && abs(tempo.bpm-120)<1);check(Tempo.estimate(List(1000){.01})==null)
    println("PASS: tempo estimation (synthetic 120 BPM), silence/constant rejection; 41 presets, LRC parsing and lookup, original identity, bounded DSP output, reverb tail")
}
