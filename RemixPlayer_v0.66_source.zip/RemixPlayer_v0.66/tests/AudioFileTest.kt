package app.remix.player
import java.io.*
fun audioFileTests(){val raw=File.createTempFile("clip-test-",".pcm");try{
    raw.outputStream().use{w->repeat(44100){StemCore.writeShort(w,12000);StemCore.writeShort(w,-12000)}}
    val o=ByteArrayOutputStream();AudioFileCore.write(raw,o);check(o.size()==44+raw.length().toInt());check(o.toByteArray().copyOfRange(44,o.size()).contentEquals(raw.readBytes()))
    val copied=ByteArrayOutputStream();check(AudioFileCore.copyCanonical(o.toByteArray().inputStream(),copied)==44100L);check(copied.toByteArray().contentEquals(o.toByteArray()));check(runCatching{AudioFileCore.copyCanonical(o.toByteArray().copyOf(o.size()-1).inputStream(),ByteArrayOutputStream())}.isFailure);check(runCatching{AudioFileCore.copyCanonical((o.toByteArray()+byteArrayOf(0)).inputStream(),ByteArrayOutputStream())}.isFailure)
    val clip=AudioFileCore.clipFromMs(100,900,100,44100);val c=ByteArrayOutputStream();AudioFileCore.write(raw,c,clip);val b=c.toByteArray();check(b.size.toLong()==44+clip.frames*4);val pcm=DataInputStream(b.inputStream());pcm.skipBytes(44);check(StemCore.readShort(pcm)==0.toShort());check(StemCore.readShort(pcm)==0.toShort());pcm.skipBytes(clip.fadeIn.toInt()*4-4);check(StemCore.readShort(pcm)==12000.toShort());check(StemCore.readShort(pcm)==(-12000).toShort());check(b.takeLast(4).all{it==0.toByte()})
    check(runCatching{AudioFileCore.clipFromMs(900,100,0,44100)}.isFailure);check(runCatching{AudioFileCore.write(raw,ByteArrayOutputStream(),AudioFileCore.Clip(0,44101))}.isFailure)
    Thread.currentThread().interrupt();try{check(runCatching{AudioFileCore.write(raw,ByteArrayOutputStream())}.isFailure)}finally{Thread.interrupted()}
    println("PASS: canonical WAV PCM identity, sample-accurate clip, stereo fades, invalid bounds and cancellation")
}finally{raw.delete()}}
