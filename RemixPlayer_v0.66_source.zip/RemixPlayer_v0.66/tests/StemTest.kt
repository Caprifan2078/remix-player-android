package app.remix.player
import java.io.ByteArrayOutputStream
import java.io.ByteArrayInputStream
import kotlin.math.abs
fun stemTests(){
    for(n in 1L..500L){val starts=StemCore.starts(n,32,8).toList();check(starts.first()==0L);check(starts.last()+32>=n);check(starts.zipWithNext().all{it.second-it.first==24L});check(starts.dropLast(1).all{it+32<n});val total=starts.dropLast(1).size*24L+n-starts.last();check(total==n)}
    check(StemCore.mix(shortArrayOf(1000,-1000,3000,5000),floatArrayOf(0f,0f,0f,1f)).toInt()==5000)
    check(StemCore.mix(shortArrayOf(32767,32767),floatArrayOf(1f,1f)).toInt()==32767)
    check(StemCore.mix(shortArrayOf(1000,2000),floatArrayOf(0f,0f)).toInt()==0)
    check(StemCore.pcm(Float.NaN).toInt()==0)
    for(i in 0..7)check(abs(StemCore.blend(.25f,.25f,i,8)-.25f)<1e-6)
    val b=ByteArrayOutputStream();StemCore.header(b,2);repeat(4){StemCore.writeShort(b,(-it*1000).toShort())};val a=b.toByteArray();check(a.size==52&&String(a.copyOfRange(0,4))=="RIFF"&&String(a.copyOfRange(36,40))=="data"&&a[40]==8.toByte());val input=ByteArrayInputStream(a,44,8);repeat(4){check(StemCore.readShort(input).toInt()==-it*1000)}
    for(rate in listOf(22050,44100,48000,96000)){var count=0;val r=StemCore.Resampler(rate){l,right->check(abs(l-.5f)<1e-6&&abs(right+.5f)<1e-6);count++};repeat(rate){r.frame(.5f,-.5f)};r.finish();check(count==44100){"$rate -> $count"}}
    println("PASS: 500 chunk lengths, crossfade, PCM clipping, solo/mute, WAV headers and stereo resampling at 4 rates")
}
