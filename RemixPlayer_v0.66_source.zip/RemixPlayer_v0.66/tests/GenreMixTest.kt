package app.remix.player
import java.io.File
import kotlin.math.*
fun genreMixTests(){
    val style=GenreEngine.styles.first();val samples=shortArrayOf(0,0,1000,4000);val normal=GenreEngine.mix(samples,0f,style);val vocal=GenreEngine.mix(samples,0f,style,controls=GenreMix(vocals=0f));check(normal>vocal&&vocal>0)
    check(GenreEngine.mix(samples,0f,style,controls=GenreMix(source=0f,vocals=0f))==0f);check(GenreMix.from(GenreMix().values())==GenreMix());check(runCatching{GenreMix(drums=Float.NaN)}.isFailure)
    val dir=kotlin.io.path.createTempDirectory("genre-mix").toFile();try{val raw=File(dir,"raw.pcm");raw.outputStream().buffered().use{w->repeat(44100){i->val v=(sin(i*2*PI*440/44100)*4000).toInt().toShort();repeat(2){StemCore.writeShort(w,v)}}};val output=File(dir,"out.wav");GenreEngine.renderFromMix(raw,output,style,120.0,0.0,emptyList(),listOf(.1),controls=GenreMix(0f,0f,0f,0f,0f,0f));check(output.readBytes().drop(44).all{it==0.toByte()});GenreEngine.renderFromMix(raw,output,style,120.0,0.0,emptyList(),listOf(.1),controls=GenreMix(0f,0f,0f,1f));check(output.readBytes().drop(44).any{it!=0.toByte()});check(output.length()==raw.length()+44)}finally{dir.deleteRecursively()}
    println("PASS: six genre mix controls, vocal isolation, mute, fallback source isolation, output length and validation")
}
