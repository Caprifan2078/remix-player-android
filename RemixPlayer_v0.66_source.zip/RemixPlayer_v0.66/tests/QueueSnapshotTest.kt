package app.remix.player
fun queueSnapshotTests(){
    val s=QueueSnapshot.Saved(listOf("b-remix","a","c","d"),1,17000,20000,true,2)
    fun restore(missing:Set<String>)=QueueSnapshot.restore(s){it.takeUnless(missing::contains)}!!
    val normal=restore(emptySet());check(normal.items==s.ids&&normal.index==1&&normal.position==17000L&&normal.shuffle&&normal.repeat==2)
    val before=restore(setOf("b-remix"));check(before.index==0&&before.position==17000L)
    val removed=restore(setOf("a"));check(removed.items[removed.index]=="c"&&removed.position==0L)
    val last=restore(setOf("a","c","d"));check(last.index==0&&last.position==0L)
    check(QueueSnapshot.restore<String>(s){null}==null)
    check(QueueSnapshot.restore(s.copy(index=-1)){it}==null)
    check(QueueSnapshot.restore(s.copy(ids=List(301){"x"})){it}==null)
    check(QueueSnapshot.restore(s.copy(position=100000)){it}!!.position==19999L)
    val dup=QueueSnapshot.restore(s.copy(ids=listOf("x","x","y"),index=1)){it}!!;check(dup.index==1&&dup.items.size==3)
    println("PASS: exact queue order/versions, current occurrence, removed songs, bounds and resume position")
}
