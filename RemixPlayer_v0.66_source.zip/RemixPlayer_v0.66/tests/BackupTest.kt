package app.remix.player
import java.io.*
import java.nio.file.Files
import java.util.zip.*
fun backupTests(){
    val root=Files.createTempDirectory("remix-backup-test").toFile()
    try{
        val payloads=listOf(ByteArray(190003){(it*17).toByte()},byteArrayOf(0,1,2,3))
        val meta="{\"test\":true}".toByteArray();val out=ByteArrayOutputStream()
        BackupCore.write(out,meta,payloads.mapIndexed{i,b->BackupCore.Item(if(i==0)"mp3" else "../../evil"){ByteArrayInputStream(b)}})
        val archive=out.toByteArray();val restored=BackupCore.read(archive.inputStream(),File(root,"good"))
        check(restored.metadata.contentEquals(meta));check(restored.files.map{it.name}==listOf("0.mp3","1.audio"));check(restored.files.zip(payloads).all{(f,b)->f.readBytes().contentEquals(b)})
        fun reject(data:ByteArray,name:String){val target=File(root,name);check(runCatching{BackupCore.read(data.inputStream(),target)}.isFailure);check(!target.exists())}
        reject(archive.copyOf(archive.size/2),"truncated")
        val bad=ByteArrayOutputStream();ZipOutputStream(bad).use{z->fun entry(n:String,s:String){z.putNextEntry(ZipEntry(n));z.write(s.toByteArray());z.closeEntry()};entry("remix-backup-v1","1");entry("library.json","{}");entry("audio/../../escaped.mp3","bad")};reject(bad.toByteArray(),"traversal");check(!File(root,"escaped.mp3").exists())
        val corrupt=archive.copyOf();val needle=payloads[0].copyOf(20);val at=corrupt.indices.first{idx->idx+needle.size<=corrupt.size&&corrupt.copyOfRange(idx,idx+needle.size).contentEquals(needle)};corrupt[at+100]=(corrupt[at+100].toInt() xor 1).toByte();reject(corrupt,"crc")
        BackupCore.validate(listOf(0,0,2),mapOf(0 to 1),listOf(listOf(0,2)))
        check(runCatching{BackupCore.validate(listOf(1,0),emptyMap(),emptyList())}.isFailure)
        check(runCatching{BackupCore.validate(listOf(0,0,2),mapOf(2 to 1),emptyList())}.isFailure)
        check(runCatching{BackupCore.validate(listOf(0,0),emptyMap(),listOf(listOf(1)))}.isFailure)
        println("PASS: portable backup byte roundtrip, truncation/CRC/path traversal rejection, rollback, group and playlist invariants")
    }finally{root.deleteRecursively()}
}
