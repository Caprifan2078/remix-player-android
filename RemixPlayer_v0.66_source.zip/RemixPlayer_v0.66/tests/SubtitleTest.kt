package app.remix.player
import java.io.*
import java.util.zip.*
fun subtitleTests(){
    val words=listOf(SubtitleCore.Word("one",0.4,0.8,.9),SubtitleCore.Word("two",1.1,1.5,.8),SubtitleCore.Word("bad",1.6,1.7,.1),SubtitleCore.Word("three",3.0,3.4,.9),SubtitleCore.Word("late",2.0,2.2,.9))
    val lines=Lrc.parse(SubtitleCore.enhanced(words));check(lines.size==2);check(WordLyrics.parse(lines[0]).words.map{it.ms}==listOf(400L,1100L));check(WordLyrics.parse(lines[1]).text=="three")
    val pcm=ByteArrayOutputStream();repeat(44100){StemCore.writeShort(pcm,1000);StemCore.writeShort(pcm,-200)};var n=0;SubtitleCore.mono16k(pcm.toByteArray().inputStream()){check(it==400.toShort());n++};check(n==16000)
    fun zip(vararg names:String):ByteArray=ByteArrayOutputStream().also{b->ZipOutputStream(b).use{z->names.forEach{z.putNextEntry(ZipEntry(it));z.write(byteArrayOf(1,2,3));z.closeEntry()}}}.toByteArray()
    val tmp=kotlin.io.path.createTempDirectory().toFile();try{val ok=SubtitleCore.unpack(zip("model/am/final.mdl","model/conf/model.conf").inputStream(),File(tmp,"ok"));check(ok.name=="model");for((i,name) in listOf("../escape","/absolute","a\\b","x/../../escape").withIndex()){val bad=File(tmp,"bad$i");check(runCatching{SubtitleCore.unpack(zip(name).inputStream(),bad)}.isFailure);check(!bad.exists())};val large=File(tmp,"large");check(runCatching{SubtitleCore.unpack(zip("big").inputStream(),large,2)}.isFailure);check(!large.exists());check(!File(tmp,"escape").exists())}finally{tmp.deleteRecursively()}
    println("PASS: timed transcription grouping and low confidence rejection; 44.1 kHz stereo to 16 kHz mono; model ZIP limits, traversal rejection and rollback")
}
