package app.remix.player
import kotlin.math.*
fun peakGuardTests(){
    val guard=LinkedPeakGuard(44100)
    val f=floatArrayOf(.5f,-.25f);guard.apply(f);check(f.contentEquals(floatArrayOf(.5f,-.25f)))
    f[0]=2f;f[1]=-.5f;guard.apply(f);check(abs(f[0])<=.985001f&&abs(f[0]/f[1]+4f)<1e-5f)
    f[0]=.5f;f[1]=-.25f;guard.apply(f);check(f[0]<.5f&&abs(f[0]/f[1]+2f)<1e-5f)
    repeat(44100){f[0]=.5f;f[1]=-.25f;guard.apply(f)};check(abs(f[0]-.5f)<.0001f)
    guard.reset();f[0]=Float.NaN;f[1]=Float.POSITIVE_INFINITY;guard.apply(f);check(f.all{it==0f})
    val input=floatArrayOf(1f,-.5f);val output=FloatArray(2);val dsp=Dsp(44100,2);dsp.frame(input,output,Presets.all.first());check(input.contentEquals(output))
    for(p in Presets.all.filter{it.bass!=0f||it.drive!=0f||it.room!=0f||it.pan!=0f||it.muffled!=0f}){
        val d=Dsp(44100,2);repeat(44100){i->input[0]=sin(i*.02).toFloat();input[1]=.5f*input[0];d.frame(input,output,p);check(output.all{it.isFinite()&&abs(it)<=.985001f}){p.name}}
    }
    println("PASS: shared peak guard, stereo ratio, release, nonfinite safety, original identity and processed preset ceiling")
}
