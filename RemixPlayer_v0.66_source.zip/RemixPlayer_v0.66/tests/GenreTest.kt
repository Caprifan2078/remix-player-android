package app.remix.player
import kotlin.math.*
import java.io.File
fun genreTests(){
    check(GenreEngine.styles.size==30)
    val rate=16000;val a=MusicAnalysis.Analyzer(rate);repeat(rate*12){i->val t=i.toDouble()/rate;val beat=if((i+rate/4)%(rate/2)<rate/40) .45 else 0.0;a.sample((sin(2*PI*261.626*t)+sin(2*PI*329.628*t)+sin(2*PI*391.995*t))*.10+beat)};val report=a.finish();check(report.tempo!=null&&abs(report.tempo.bpm-120)<2){report};check(report.phaseSeconds!=null);check(report.key=="C major"){report};check(report.energy.size==3)
    val silent=MusicAnalysis.Analyzer(rate);repeat(rate*9){silent.sample(0.0)};check(silent.finish().let{it.tempo==null&&it.key==null&&it.phaseSeconds==null})
    val fingerprints=GenreEngine.styles.map{style->val beat=GenreEngine.Beat(style,120.0,0.0);var hash=0L;var nonzero=0;repeat(44100*4){i->val x=beat.sample(i.toLong());check(x.isFinite()&&abs(x)<1.2);if(abs(x)>.001)nonzero++;hash=hash*31+x.toBits()};check(nonzero>1000);hash};check(fingerprints.distinct().size==30)
    val dir=kotlin.io.path.createTempDirectory().toFile();try{repeat(4){i->File(dir,"$i.pcm").outputStream().use{w->repeat(8820){StemCore.writeShort(w,if(i==3)1000 else 0)}}};val out=File(dir,"render.wav");GenreEngine.render(dir,4410,4,out,GenreEngine.styles.first(),120.0,0.0){};check(out.length()==44L+4410*4);val broken=File(dir,"bad.wav");File(dir,"1.pcm").writeBytes(byteArrayOf());check(runCatching{GenreEngine.render(dir,4410,4,broken,GenreEngine.styles.first(),120.0,0.0){}}.isFailure&&!broken.exists())}finally{dir.deleteRecursively()}
    println("PASS: 30 distinct procedural beats, tempo/phase/C-major estimate, silence rejection, WAV render and failure cleanup")
}
