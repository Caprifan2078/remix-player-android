#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp=$(mktemp -d);trap 'rm -rf "$tmp"' EXIT
jdk=$(dirname "$(dirname "$(readlink -f "$(command -v javac)")")")
gcc -O2 -shared -fPIC -I"$jdk/include" -I"$jdk/include/linux" native/mp3.c -Wl,-l:libmp3lame.so.0 -o "$tmp/libremixmp3.so"
kotlinc app/src/main/java/app/remix/player/{StemCore,Mp3Export}.kt tests/Mp3HostTest.kt -include-runtime -d "$tmp/test.jar"
java -Djava.library.path="$tmp" -jar "$tmp/test.jar" "$tmp"
for b in 128 192 256 320;do
  codec=$(ffprobe -v error -select_streams a:0 -show_entries stream=codec_name -of csv=p=0 "$tmp/$b.mp3");test "$codec" = mp3
  ffmpeg -v error -i "$tmp/$b.mp3" -f null -
done
printf 'PASS: FFmpeg independently decoded all 4 files\n'
