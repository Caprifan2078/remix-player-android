package app.remix.player
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
fun workGateTests(){
    val gate=WorkGate();var persisted=""
    check(gate.begin("disk failed"){false}==null&&gate.current()==null)
    val a=gate.begin("render"){persisted=it.id;true}!!
    check(gate.begin("another"){error("must not persist") }==null)
    gate.cancel(a);check(!gate.enter(a));check(gate.finish(a){persisted=""});check(persisted.isEmpty())
    val b=gate.begin("backup"){persisted=it.id;true}!!
    check(!gate.finish(a){error("stale callback")});check(persisted==b.id)
    val started=CountDownLatch(1);val stopped=CountDownLatch(1);var interrupted=false
    val worker=Thread{check(gate.enter(b));started.countDown();try{Thread.sleep(30000)}catch(e:InterruptedException){interrupted=true}finally{gate.leave(b);stopped.countDown()}}
    worker.start();check(started.await(2,TimeUnit.SECONDS));check(!gate.finish(b){error("still running")});gate.cancel(b);check(stopped.await(2,TimeUnit.SECONDS));worker.join();check(interrupted&&b.cancelled)
    check(gate.begin("while committing"){true}==null);check(gate.finish(b){persisted=""});check(gate.current()==null)
    println("PASS: work gate blocks overlaps, cancels queued/running jobs, retains ownership through commit, rejects stale callbacks and failed journal writes")
}
