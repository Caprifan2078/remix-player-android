#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
printf 'package app.remix.player\nfun main(){batchHistoryTests();queueEditTests();playlistOrderTests()}\n' > "$tmp/Main.kt"
kotlinc app/src/main/java/app/remix/player/{QueueEdit,QueueSnapshot,PlayerExtras,PlaylistOrder,LibraryCore,TimeStretch,StemCore,AudioCore}.kt tests/{BatchHistoryTest,QueueEditTest,PlaylistOrderTest}.kt "$tmp/Main.kt" -include-runtime -d "$tmp/tests.jar"
java -jar "$tmp/tests.jar"
