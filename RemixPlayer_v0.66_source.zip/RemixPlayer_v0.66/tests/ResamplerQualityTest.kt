package app.remix.player
import kotlin.math.*
fun resamplerQualityTests(){
    fun tone(hz:Double,rate:Int):Double{var n=0;var power=0.0;val r=StemCore.Resampler(rate){l,right->check(abs(l+right)<1e-5);if(n in 2000..41999)power+=l*l;n++};repeat(rate){i->val s=(sin(2*PI*hz*i/rate)*.5).toFloat();r.frame(s,-s)};r.finish();check(n==44100);return sqrt(power/40000)}
    val pass=tone(1000.0,96000);val stop=tone(30000.0,96000)
    check(abs(pass-.5/sqrt(2.0))<.005){"passband $pass"};check(stop<.005){"Aliased ultrasonic signal RMS $stop"}
    for(rate in listOf(8000,22050,32000,44100,48000,96000,192000))for(n in listOf(1,3,31,97)){var count=0;val r=StemCore.Resampler(rate){l,right->check(abs(l-.25f)<1e-6&&abs(right+.25f)<1e-6);count++};repeat(n){r.frame(.25f,-.25f)};r.finish();check(count.toLong()==(n*44100L+rate-1)/rate){"$rate $n $count"}}
    println("PASS: bandlimited resampling, 30 kHz alias rejection, stereo alignment, short inputs and exact lengths")
}
