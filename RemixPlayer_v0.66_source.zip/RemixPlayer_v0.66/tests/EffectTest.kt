package app.remix.player
import java.io.File
import kotlin.math.*
fun effectTests(){
    val dir=kotlin.io.path.createTempDirectory("effects-test").toFile()
    try{val raw=File(dir,"raw.pcm");val n=22050;raw.outputStream().buffered().use{out->repeat(n){i->val s=(sin(2*PI*440*i/44100)*8000).roundToInt().toShort();StemCore.writeShort(out,s);StemCore.writeShort(out,s)}}
        for(p in Presets.all){val output=File(dir,"out.wav");EffectRender.render(raw,output,p);val count=(output.length()-44)/4;check(abs(count-n/p.speed)<3){"${p.name}: $count"};check(output.length()>44);output.delete()}
        val original=File(dir,"orig.wav");EffectRender.render(raw,original,Presets.all.first());check(original.readBytes().copyOfRange(44,original.length().toInt()).contentEquals(raw.readBytes()))
        val night=File(dir,"night.wav");EffectRender.render(raw,night,Preset("pitch",1.25f,1.25f));val pcm=night.readBytes();var crossings=0;var prev=0;for(i in 44 until pcm.size step 4){val sample=((pcm[i].toInt() and 255) or (pcm[i+1].toInt() shl 8)).toShort().toInt();if(prev<=0&&sample>0)crossings++;prev=sample};val hz=crossings*44100.0/((pcm.size-44)/4);check(abs(hz-550)<4){"pitch $hz"}
        val high=File(dir,"high.pcm");high.outputStream().buffered().use{w->repeat(n){i->val v=(sin(2*PI*18000*i/44100)*20000).roundToInt().toShort();repeat(2){StemCore.writeShort(w,v)}}};val shifted=File(dir,"shifted.wav");EffectRender.render(high,shifted,Preset("alias",1.5f,1.5f));var power=0.0;var samples=0;shifted.inputStream().buffered().use{r->check(r.skip(44)==44L);for(i in 0 until (shifted.length()-44)/4){val x=StemCore.readShort(r)/32768.0;StemCore.readShort(r);if(i in 500 until (shifted.length()-44)/4-500){power+=x*x;samples++}}};check(sqrt(power/samples)<.005){"Pitch alias: ${sqrt(power/samples)}"};println("PASS: pitch-up 18 kHz alias suppression RMS ${sqrt(power/samples)}")
        val custom=listOf(Preset("slow-high",.4f,1.5f),Preset("fast-low",1.8f,.5f),Preset("slow-low",.4f,.5f),Preset("fast-high",1.8f,1.5f))
        val batch=EffectRender.batch(raw,dir,custom){_,_,_->}
        for((p,f) in batch){val count=(f.length()-44)/4;check(f.length()==EffectRender.outputBytes(n.toLong(),p));check(abs(count-n/p.speed)<8){"${p.name} $count"};check(f.length()>44)}
        val cancel=File(dir,"cancel-effect.wav");check(runCatching{EffectRender.render(raw,cancel,custom[0]){if(it>=30)Thread.currentThread().interrupt()}}.isFailure);Thread.interrupted();check(!cancel.exists());check(dir.listFiles()!!.none{it.name.startsWith("stretch-")||it.name.startsWith("pitch-")})
        println("PASS: four extreme custom effects, batch size agreement, duration, cancellation cleanup")
        check(TimeStretch.lyrics("[00:10.00]hello",.5).contains("[00:20.000]"));check(dir.listFiles()!!.none{it.name.startsWith("pitch-")||it.name.startsWith("stretch-")})
        println("PASS: all 41 offline effects, duration, original PCM identity, pitch and lyric scaling, temporary cleanup")
    }finally{dir.deleteRecursively()}
}
