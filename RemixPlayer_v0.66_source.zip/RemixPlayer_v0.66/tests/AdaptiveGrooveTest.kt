package app.remix.player
import kotlin.math.*
fun adaptiveGrooveTests(){
    val rate=8000;val base=AdaptiveGroove(120.0,.25,rate=rate);for(f in listOf(0L,2000L,8000L,32000L))check(abs(base.position(f)-(f.toDouble()/rate-.25)*8)<1e-9)
    val windows=listOf(RhythmMap.Window(0.0,16.0,120.0,.9),RhythmMap.Window(16.0,32.0,90.0,.9),RhythmMap.Window(32.0,48.0,90.0,.9));val g=AdaptiveGroove(120.0,0.0,windows,120.0,rate)
    check(abs(g.position(8L*rate)-64)<1e-8);check(abs(g.position(40L*rate)-g.position(32L*rate)-48)<1e-8);var previous=g.position(0);for(f in 1L..48L*rate){val now=g.position(f);check(now>previous&&now-previous<.002);previous=now};check(g.position(0)==0.0)
    val half=AdaptiveGroove(180.0,0.0,listOf(RhythmMap.Window(0.0,16.0,90.0,.9)),180.0,rate);check(abs(half.position(8L*rate)-96)<1e-8)
    val weak=AdaptiveGroove(120.0,0.0,listOf(RhythmMap.Window(0.0,16.0,80.0,.1)),120.0,rate);check(weak.position(16L*rate)==128.0)
    for(s in GenreEngine.styles){val p=DrumPalette.voice(s);check(p.kickHz in 35.0..65.0&&p.swing in 0.0..0.2);var prev=DrumPalette.swing(0.0,p.swing);for(i in 1..6400){val x=DrumPalette.swing(i/100.0,p.swing);check(x>prev);prev=x};check(DrumPalette.swing(64.0,p.swing)==64.0)}
    check(GenreEngine.styles.map{DrumPalette.voice(it)}.distinct().size>=8);check(DrumPalette.fill(63,DrumPalette.voice(GenreEngine.styles.first())))
    println("PASS: continuous adaptive BPM grid, low-confidence rejection, half/double tempo, 30 swing patterns, eight percussion palettes")
    fun tone(hz:Double):SoundProfile.Features?{val a=MusicAnalysis.Analyzer(16000);repeat(32000){i->a.sample(.25*sin(2*PI*hz*i/16000))};return a.finish().spectrum}
    val low=tone(100.0)!!;val mid=tone(1000.0)!!;val high=tone(4000.0)!!;check(low.low>.98&&mid.mid>.98&&high.high>.98);check(abs(low.centroidHz-100)<5&&abs(high.centroidHz-4000)<5);check(MusicAnalysis.Analyzer(16000).finish().spectrum==null)
    val a=listOf(0,0,0,0,4,4,4,4,7,7,7,7,9,9,9,9);val b=listOf(9,4,0,7,9,4,0,7,9,4,0,7,9,4,0,7);val chords=(b+a+b+a+b).mapIndexed{i,x->Harmony.Chord(i*.5,x,false,.3)};val r=MusicAnalysis.Report(Tempo.Result(120.0,.8),0.0,"C major",.3,.2,40.0,listOf(.1,.1,.3,.3,.1,.1,.3,.3,.1,.1),chords)
    check(SoundProfile.chorusCandidates(r).any{it.first==8.0&&it.second==24.0});check(SoundProfile.chorusCandidates(r.copy(energy=List(10){.1})).isEmpty())
    println("PASS: measured three-band spectral profile, centroid, silence rejection, repeated loud-section candidates")
    val duck=VocalSpace(8000);check(duck.sample(0,0)==1f);var gain=1f;var prevGain=1f;repeat(8000){gain=duck.sample(20000,-20000);check(gain in .549f..1f&&abs(gain-prevGain)<.01f);prevGain=gain};check(gain<.56f);repeat(16000){gain=duck.sample(0,0)};check(gain>.99f)
    println("PASS: stereo vocal-triggered ducking, bounded attenuation, smooth attack/release and silence recovery")
}
