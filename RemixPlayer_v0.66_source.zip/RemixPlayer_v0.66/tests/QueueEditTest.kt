package app.remix.player
fun queueEditTests(){
    val ids=listOf("a","b","c","d")
    fun plan(id:String,next:Boolean=true,shuffle:Boolean=false,limit:Int=4)=QueueEdit.plan(ids,1,id,next,shuffle,limit)
    check(plan("a")==QueueEdit.Action.Move(0,1));check(plan("d")==QueueEdit.Action.Move(3,2));check(plan("c")==QueueEdit.Action.Refused.PRESENT);check(plan("b")==QueueEdit.Action.Refused.CURRENT)
    check(plan("e")==QueueEdit.Action.Refused.FULL);check(plan("e",limit=5)==QueueEdit.Action.Insert(2));check(plan("e",false,limit=5)==QueueEdit.Action.Insert(4));check(plan("a",false)==QueueEdit.Action.Refused.PRESENT)
    check(plan("e",shuffle=true,limit=5)==QueueEdit.Action.Refused.SHUFFLE);check(plan("e",false,true,5)==QueueEdit.Action.Insert(4));check(QueueEdit.plan(emptyList(),-1,"a",true,false)==QueueEdit.Action.Refused.EMPTY);check(QueueEdit.plan(ids,-1,"a",true,false)==QueueEdit.Action.Refused.INVALID)
    check(!QueueEdit.sameTimeline(ids,listOf("a","c","b","d")));check(QueueEdit.sameTimeline(ids,ids.toList()))
    for(n in 1..12)for(c in 0 until n)for(k in 0..n){
        val old=List(n){it.toString()};val id=k.toString();val result=QueueEdit.plan(old,c,id,true,false,20);val changed=old.toMutableList()
        when(result){is QueueEdit.Action.Move->changed.add(result.to,changed.removeAt(result.from));is QueueEdit.Action.Insert->changed.add(result.index,id);else->continue}
        check(changed[changed.indexOf(old[c])+1]==id);check(changed.toSet().size==changed.size)
    }
    println("PASS: play-next/append, current item, queue bounds, shuffle guard, stale timeline and exhaustive small queues")
}
