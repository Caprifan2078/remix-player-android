package app.remix.player
fun playerUiSafetyTests(){
    val old=PlayerUiSafety.Target(false,"song",1)
    val new=old.copy(generation=2)
    val mixer=old.copy(mixer=true)
    check(PlayerUiSafety.seekPosition(old,new,10000,500)==null)
    check(PlayerUiSafety.seekPosition(old,mixer,10000,500)==null)
    check(PlayerUiSafety.seekPosition(old,old.copy(id="other"),10000,500)==null)
    check(PlayerUiSafety.seekPosition(null,old,10000,500)==null)
    check(PlayerUiSafety.seekPosition(old,old,-1,500)==null)
    for(d in listOf(1L,999L,1000L,1234567L,Long.MAX_VALUE))for(p in 0..1000){
        val expected=java.math.BigInteger.valueOf(d).multiply(java.math.BigInteger.valueOf(p.toLong())).divide(java.math.BigInteger.valueOf(1000)).longValueExact()
        check(PlayerUiSafety.seekPosition(old,old,d,p)==expected)
    }
    check(PlayerUiSafety.seekPosition(old,old,1000,-5)==0L)
    check(PlayerUiSafety.seekPosition(old,old,1000,1005)==1000L)
    for(d in listOf(1,767,768,769,1536,1537,10000,Int.MAX_VALUE)){
        val sample=PlayerUiSafety.coverSample(d,1)!!
        check((d.toLong()+sample-1)/sample<=768)
        check(sample and (sample-1)==0)
        if(sample>1)check((d.toLong()+sample/2-1)/(sample/2)>768)
    }
    check(PlayerUiSafety.coverSample(0,100)==null)
    println("PASS: stale seek identity, 5005 exact seek positions, bounded cover sampling")
}
