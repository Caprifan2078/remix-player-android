package app.remix.player
import java.io.*
import kotlin.math.*
fun release37Tests(){
    val dir=kotlin.io.path.createTempDirectory("remix37-").toFile()
    try{
        fun raw(name:String,frames:Int,l:Short,r:Short)=File(dir,name).also{f->f.outputStream().buffered().use{w->repeat(frames){StemCore.writeShort(w,l);StemCore.writeShort(w,r)}}}
        val a=raw("base",4410,12000,-12000);val b=raw("back",2205,6000,6000);val out=File(dir,"out.wav")
        check(AccompanimentMix.render(a,b,out,AccompanimentMix.Settings(20,1f,1f,0))==4410L)
        val bytes=out.readBytes();check(bytes.size==44+4410*4);fun sample(i:Int,c:Int):Short{val k=44+i*4+c*2;return ((bytes[k].toInt() and 255) or (bytes[k+1].toInt() shl 8)).toShort()}
        check(sample(0,0)==6000.toShort()&&sample(881,1)==(-6000).toShort());check(sample(882,0)==9000.toShort()&&sample(882,1)==(-3000).toShort());check(sample(3087,0)==6000.toShort())
        AccompanimentMix.render(a,b,out,AccompanimentMix.Settings(-20,0f,1f,0));val p=out.readBytes();check((p[44].toInt() and 255)==(6000 and 255));check(p.copyOfRange(44+1323*4,p.size).all{it==0.toByte()});check(runCatching{AccompanimentMix.render(a,b,out,AccompanimentMix.Settings(200))}.isFailure)
        AccompanimentMix.render(a,b,out,AccompanimentMix.Settings(0,1f,0f,0));check(out.readBytes().copyOfRange(44,out.length().toInt()).contentEquals(a.readBytes()))
        println("PASS: external accompaniment mix, signed offset, source duration, stereo, mute and overlap validation")
        val tone=raw("tone",44100*3,4000,4000);val v=MoodCore.input(tone);check(v.size==360000&&abs(v[1000]-4000f/32768)<.0001&&v.last()==0f)
        check(MoodCore.Result(.8f,.8f).label=="Бодрое"&&MoodCore.Result(.2f,.8f).label=="Напряжённое"&&MoodCore.Result(.2f,.2f).label=="Меланхоличное"&&MoodCore.Result(.8f,.2f).label=="Спокойное"&&MoodCore.Result(.51f,.8f).label==null);check(runCatching{MoodCore.Result(Float.NaN,.5f)}.isFailure);check(runCatching{MoodCore.input(raw("quiet",44100*3,0,0))}.isFailure)
        println("PASS: mood model input shape, short-track padding, silence rejection and valence/arousal uncertainty")
        val s=SubtitleExport.srt("[offset:100]\n[00:01.000]<00:01.000>Hello\n[00:02.000]World\n[00:10.000]Again");check("00:00:01,100 --> 00:00:02,100\nHello" in s&&"00:00:02,100 --> 00:00:08,100" in s&&"00:00:10,100 --> 00:00:14,100" in s);check(runCatching{SubtitleExport.srt("plain text")}.isFailure)
        println("PASS: subtitle SRT export, offset, inferred end caps and missing-timing rejection")
    }finally{dir.deleteRecursively()}
}
