package app.remix.player
fun boundary66Tests() {
    var bad = 0
    for (rate in listOf(8000, 22050, 44100, 48000, 96000, 192000, 384000)) {
        for (corrupt in listOf(Float.NaN, Float.POSITIVE_INFINITY, Float.NEGATIVE_INFINITY)) {
            var frames = 0; var lastL = 0f; var lastR = 0f
            val rs = StemCore.Resampler(rate) { l, r ->
                if (!l.isFinite() || !r.isFinite()) bad++
                check(kotlin.math.abs(r - .25f) < .0001f) { "Unaffected right channel altered: $rate $r" }
                frames++; lastL=l; lastR=r
            }
            repeat(2048) { i -> rs.frame(if(i in listOf(0,512,1024)) corrupt else -.25f, .25f) }
            rs.finish();rs.finish()
            check(frames.toLong() == (2048L*44100+rate-1)/rate)
            check(kotlin.math.abs(lastL+.25f)<.0001f && kotlin.math.abs(lastR-.25f)<.0001f)
        }
    }
    check(bad == 0) { "Non-finite PCM propagated to $bad output samples" }
    println("PASS: 21 resampler corruption cases; both channels, recovery, exact count and idempotent finish")
}
fun queueBoundary66Tests() {
    val ids=listOf("a","b")
    for(next in listOf(true,false)) {
        check(QueueEdit.plan(ids,0,"x".repeat(8193),next,false)==QueueEdit.Action.Refused.INVALID) { "Oversize ID accepted next=$next" }
        check(QueueEdit.plan(ids,0,"x".repeat(8192),next,false) is QueueEdit.Action.Insert)
        check(QueueEdit.plan(ids,0,"c",next,false,301)==QueueEdit.Action.Refused.INVALID) { "Queue limit exceeds persisted limit" }
    }
    println("PASS: queue single insert and play-next respect persisted ID and capacity limits")
}
