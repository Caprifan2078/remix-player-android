package app.remix.player
fun portablePlaybackTests(){
    val c=PortablePlayback.Controls(List(10){0f},List(6){1f},3000,8000,true)
    check(c.randomVersions);check(runCatching{c.copy(eq=List(10){Float.NaN})}.isFailure);check(runCatching{c.copy(overlapMs=999)}.isFailure)
    check(PortablePlayback.validGains(List(6){.25f}));check(!PortablePlayback.validGains(List(5){1f}));check(!PortablePlayback.validGains(List(4){Float.POSITIVE_INFINITY}))
    val s=QueueSnapshot.Saved(listOf("a","missing","b","a"),1,3000,5000,true,2)
    val q=PortablePlayback.captureQueue(s,mapOf("a" to 1,"b" to 0))!!
    check(q.rows==listOf(1,0,1)&&q.index==1&&q.position==0L)
    check(q.remap(listOf("newB","newA")).ids==listOf("newA","newB","newA"))
    check(runCatching{q.remap(listOf("only"))}.isFailure)
    val h=ListeningStats.Entry("a",100,10);check(PortablePlayback.mergeHistory(listOf(h),listOf(h.copy(playedMs=90),h.copy(id="b"))).size==2)
    check(PortablePlayback.mergeHistory(listOf(h),listOf(h.copy(playedMs=200))).single().playedMs==200L)
    println("PASS: portable playback controls, exact queue remapping, missing current track, safe gains and history merge")
}
fun lyricStructureTests(){
    val raw="[00:01]A different intro\n[00:10]I see the moon\n[00:13]The stars are bright\n[00:16]We travel home\n[00:20]Different verse\n[00:30]I SEE the moon!\n[00:33]The stars are bright\n[00:36]We travel home\n[00:40]Ending"
    val r=LyricStructure.find(raw).single();check(r.firstMs==10000L&&r.secondMs==30000L&&r.lines==3)
    check(LyricStructure.find((1..20).joinToString("\n"){"[00:${(it*2).toString().padStart(2,'0')}]Same line"}).isEmpty())
    check(LyricStructure.find(raw.replace("[00:33]The stars are bright","[00:33]Another phrase")).isEmpty())
    println("PASS: repeated timed lyrics with punctuation/case variation; reject stationary text and interrupted sequences")
}
