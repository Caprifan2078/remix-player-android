#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
[[ $# == 1 ]] || { echo "Usage: $0 OUTPUT_DIRECTORY" >&2; exit 2; }
out=$(realpath -m "$1"); mkdir -p "$out"
jar=$(mktemp --suffix=.jar); trap 'rm -f "$jar"' EXIT
kotlinc app/src/main/java/app/remix/player/{GenrePhrase,GenrePhraseWeights,NeuralTone,NeuralInstrumental,NeuralDrums,PhraseWeights,Harmony,AdaptiveGroove,RhythmMap,StemCore,GenreEngine,GenreMix,Arrangement,LeadSynth,VocalSpace,GenreDynamics,Tempo,MusicAnalysis,SoundProfile,SectionMap,StructureCore,RemixAdvisor,MusicalIntelligence,TimeStretch,AudioCore,EffectRender}.kt tests/AudioAcceptance.kt -include-runtime -d "$jar"
java -jar "$jar" "$out"
python3 tests/inspect-audio.py "$out"
