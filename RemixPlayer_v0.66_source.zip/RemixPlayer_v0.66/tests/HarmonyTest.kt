package app.remix.player
import kotlin.math.*
fun harmonyTests(){
    for(root in 0..11)for(minor in listOf(false,true)){
        val v=DoubleArray(12);v[root]=1.0;v[(root+(if(minor)3 else 4))%12]=.8;v[(root+7)%12]=.7
        val c=Harmony.detect(v,0.0);check(c!=null&&c.root==root&&c.minor==minor)
    }
    check(Harmony.detect(DoubleArray(12){1.0},0.0)==null)
    check(Harmony.detect(DoubleArray(12),0.0)==null)
    val seq=listOf(Harmony.Chord(0.0,0,false,.5),Harmony.Chord(.5,7,false,.5))
    val bass=Harmony.Bass(seq,120.0,0.0,.5f,intArrayOf(0,4,8,12),listOf(.2))
    var peak=0f;repeat(88200){i->val x=bass.sample(i.toLong());check(x.isFinite()&&abs(x)<=.2f);peak=maxOf(peak,abs(x));if(i>80000)check(abs(x)<.0001f)};check(peak>.01)
    val empty=Harmony.Bass(emptyList(),120.0,0.0,0f,intArrayOf(0),emptyList());repeat(44100){check(empty.sample(it.toLong())==0f)}
    println("PASS: 24 synthetic major/minor triads, ambiguity rejection, bounded bass and silence outside known harmony")
}
