#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
printf 'package app.remix.player\nfun main(){dspNonfinite65Tests();eqNonfinite65Tests();peakGuardTests();eqRenderTests();flacCompressionTests();playbackTimingTests();analysisLoopTests();storageTests()}\n' > "$tmp/Main.kt"
kotlinc app/src/main/java/app/remix/player/{AudioCore,PlayerExtras,StemCore,EqRender,Mastering,FlacExport,PlaybackTiming,AnalysisMono,LoopCore,StorageCore}.kt tests/{DspNonfinite65Test,EqNonfinite65Test,PeakGuardTest,EqRenderTest,FlacCompressionTest,PlaybackTimingTest,AnalysisLoopTest,StorageTest}.kt "$tmp/Main.kt" -include-runtime -d "$tmp/test.jar"
java -jar "$tmp/test.jar"
