package app.remix.player
fun mixedLyrics62Tests(){
    val raw="[offset:100]\n[00:01]<00:01>Привет <00:01.50>мир\n[00:03]Это припев"
    val mixed=PhraseAlign.align(raw,"Привет, мир!\nЭто припев.")
    check(mixed.complete);val lines=Lrc.parse(mixed.lrc)
    check(WordLyrics.parse(lines[0]).words.map{it.ms}==listOf(1100L,1600L))
    check(WordLyrics.parse(lines[1]).words.isEmpty());check(lines.map{it.ms}==listOf(1100L,3100L))
    val both=PhraseAlign.align("[00:01]<00:01>Hello <00:01.50>world\n[00:03]<00:03>again <00:03.50>now","Hello world again now")
    check(both.complete&&WordLyrics.parse(Lrc.parse(both.lrc).single()).words.map{it.ms}==listOf(1000L,1500L,3000L,3500L))
    val partial=PhraseAlign.align("[00:01]<00:01>hello world\n[00:03]again now","Hello world again now")
    check(partial.complete&&!partial.lrc.contains('<'))
    val overlap=PhraseAlign.align("[00:01]<00:01>Hello <00:03.50>world\n[00:03]again now","Hello world\nagain now")
    check(overlap.complete&&!overlap.lrc.contains('<'))
    val corrected=PhraseAlign.align("[00:01]<00:01>I <00:01.20>can <00:01.40>see <00:01.60>a <00:01.80>light","I can see a night",true)
    check(corrected.complete&&corrected.corrected==1&&!corrected.lrc.contains('<'))
    check(runCatching{PhraseAlign.align("[00:01]<bad>hello","hello")}.isFailure)
    println("PASS: mixed lyrics, offset, multi-phrase timing, incomplete/overlapping/approximate fallback and malformed markers")
}
