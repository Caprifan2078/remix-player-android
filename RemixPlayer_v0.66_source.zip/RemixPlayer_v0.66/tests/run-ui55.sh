#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
printf 'package app.remix.player\nfun main(){playerUiSafetyTests()}\n' > "$tmp/Main.kt"
kotlinc app/src/main/java/app/remix/player/PlayerUiSafety.kt tests/PlayerUiSafetyTest.kt "$tmp/Main.kt" -include-runtime -d "$tmp/ui.jar"
java -jar "$tmp/ui.jar"
