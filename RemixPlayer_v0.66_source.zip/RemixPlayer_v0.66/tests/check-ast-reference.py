"""Optional host-only numerical comparison, requires numpy, torch, torchaudio and kotlinc."""
from pathlib import Path
import tempfile, subprocess
import numpy as np
import torch, torchaudio
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as tmp:
    t=Path(tmp); x=(np.random.default_rng(36).normal(0,.15,16000)+.1*np.sin(np.arange(16000)*.2)).astype('<f4').clip(-1,1)
    x.tofile(t/'in.f32')
    subprocess.run(['kotlinc',str(root/'app/src/main/java/app/remix/player/AstGenreCore.kt'),str(root/'tests/AstReference.kt'),'-include-runtime','-d',str(t/'ref.jar')],check=True)
    subprocess.run(['java','-jar',str(t/'ref.jar'),str(t/'in.f32'),str(t/'out.f32')],check=True)
    y=np.fromfile(t/'out.f32',dtype='<f4').reshape(1024,128)
    f=torchaudio.compliance.kaldi.fbank(torch.from_numpy(x).unsqueeze(0),htk_compat=True,sample_frequency=16000,use_energy=False,window_type='hanning',num_mel_bins=128,dither=0.0,frame_shift=10)
    f=torch.nn.functional.pad(f,(0,0,0,1024-f.shape[0])); f=(f+4.2677393)/(2*4.5689974)
    d=np.abs(y-f.numpy()); print('AST frontend vs torchaudio Kaldi: max abs',float(d.max()),'mean abs',float(d.mean())); assert d.max()<.003
