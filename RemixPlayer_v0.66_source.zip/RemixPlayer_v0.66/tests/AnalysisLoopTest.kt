package app.remix.player
import kotlin.math.*
fun analysisLoopTests(){
    for(mode in 0..3){var n=0;var power=0.0;val mono=AnalysisMono{v->n++;power+=v*v};repeat(5003){i->val x=.5*sin(2*PI*440*i/44100);when(mode){0->mono.frame(x,x);1->mono.frame(x,-x);2->mono.frame(x,0.0);3->mono.frame(0.0,x)}};mono.finish();check(n==5003&&sqrt(power/n) in .34.. .37){"Stereo mode $mode: $n $power"}}
    var count=0;val mono=AnalysisMono{check(it.isFinite());count++};mono.frame(Double.NaN,Double.POSITIVE_INFINITY);mono.finish();mono.finish();check(count==1)
    val region=LoopCore.create("song",1000,5000,10000)!!;check(LoopCore.seek(region,"song",5000,true)==1000L);check(LoopCore.seek(region,"other",5000,true)==null);check(LoopCore.seek(region,"song",5000,false)==null);check(LoopCore.seek(region,"song",4999,true)==null);check(LoopCore.create("song",1000,1200,10000)==null);check(LoopCore.create("song",0,11000,10000)==null)
    println("PASS: stereo analysis preserves in-phase, anti-phase and one-sided signals; exact counts, nonfinite input; scoped A/B loop")
}
