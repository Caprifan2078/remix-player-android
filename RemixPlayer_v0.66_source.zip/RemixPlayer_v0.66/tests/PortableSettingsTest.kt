package app.remix.player
fun portableSettingsTests(){
    val p=Preset("Custom",.8f,.9f);val q=Preset("CUSTOM",.9f,.9f);val merge=PortableSettings.mergePresets(listOf(p),listOf(p,q,Preset("Reserved")),listOf("reserved"));check(merge.imported==2&&merge.skipped==1);check(merge.items.map{it.name}==listOf("Custom","CUSTOM (2)","Reserved (2)"));check(PortableSettings.mergePresets(listOf(p),listOf(q),emptyList(),1).skipped==1)
    check(PortableSettings.remap(mapOf(1 to "data"),listOf("new1","new2"))==mapOf("new2" to "data"));check(runCatching{PortableSettings.remap(mapOf(2 to 1),listOf("x"))}.isFailure)
    val raw="[00:01.00]Hello\n[00:02.00]World";check(PortableSettings.validateTranslation(raw,listOf("Привет","Мир")));check(!PortableSettings.validateTranslation(raw,listOf("Привет")))
    val a=PersonalTags.Example("x","rock",List(10){.5});val b=a.copy(id="y");check(PortableSettings.mergeExamples(listOf(a),listOf(a.copy(label="pop"),b))==listOf(a,b));check(PortableSettings.mergeExamples(listOf(a),listOf(b),1)==listOf(a))
    println("PASS: portable settings URI remapping, translation validation, conflict-safe preset and training example merge")
}
