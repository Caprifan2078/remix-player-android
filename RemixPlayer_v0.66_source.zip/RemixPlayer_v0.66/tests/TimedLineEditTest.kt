package app.remix.player
fun timedLineEditTests(){
    val raw="[ar:Artist]\r\n[offset:100]\r\n[00:01.000]<00:01.000> Hello  <00:01.500>wrld!\r\n[00:03.000]Other\r\n"
    val line=Lrc.parse(raw).first();val edit=TimedLineEdit.open(raw,line);check(edit.fragments.map{it.ms}==listOf(1100L,1600L));check(edit.fragments.map{it.text}==listOf("Hello","wrld!"))
    val changed=edit.replace(listOf("Hello","world!"));check(changed==raw.replace("wrld!","world!"));check(Lrc.parse(changed).map{it.ms}==Lrc.parse(raw).map{it.ms});check(WordLyrics.parse(Lrc.parse(changed).first()).words.map{it.ms}==listOf(1100L,1600L))
    for(bad in listOf(listOf("one"),listOf("","world"),listOf("one","<00:02>bad"),listOf("one","bad\nline")))check(runCatching{edit.replace(bad)}.isFailure)
    val repeated="[00:01]<00:01>one\n[00:01]<00:01>one";check(runCatching{TimedLineEdit.open(repeated,Lrc.parse(repeated).first())}.isFailure)
    val multi="[00:01][00:02]<00:02>one";check(runCatching{TimedLineEdit.open(multi,Lrc.parse(multi).first())}.isFailure)
    val timed="[00:01]<00:01>Cafe\u0301 <00:02>мои\u0306";val aligned=LyricAlign.align(timed,"Café мой");check(aligned.complete&&aligned.matched==2)
    println("PASS: timed fragment editing, exact metadata/offset preservation, ambiguous and injected markers rejected, Unicode combining marks aligned")
}
