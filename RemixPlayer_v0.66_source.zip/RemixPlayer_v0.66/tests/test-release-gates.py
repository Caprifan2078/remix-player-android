"""Offline acceptance gate regressions: synthetic ELF and instrumentation output."""
import importlib.util, pathlib, struct, tempfile, zipfile, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('audit', ROOT/'scripts/check-native-apk.py'); audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
def elf(machine=183, align=16384):
    b=bytearray(120); b[:6]=b'\x7fELF\x02\x01'; struct.pack_into('<H',b,18,machine);struct.pack_into('<Q',b,32,64);struct.pack_into('<HH',b,54,56,1);struct.pack_into('<IIQQQQQQ',b,64,1,5,0,0,0,0,0,align);return b
with tempfile.TemporaryDirectory() as d:
    f=pathlib.Path(d)/'fixture.apk'
    for wrong in (True,False):
        with zipfile.ZipFile(f,'w',compression=zipfile.ZIP_DEFLATED) as z:
            for abi,machine in [('arm64-v8a',183),('x86_64',62)]:
                for name in ('libremixmp3.so','libremixwhisper.so','libonnxruntime.so'):
                    z.writestr(f'lib/{abi}/{name}',elf(62 if wrong else machine))
        assert audit.audit(f)==int(wrong), f'wrong ABI fixture={wrong}'
    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', UserWarning)
        with zipfile.ZipFile(f,'a',compression=zipfile.ZIP_DEFLATED) as z:
            z.writestr('lib/arm64-v8a/libremixmp3.so',elf())
    assert audit.audit(f)==1, 'duplicate library accepted'
print('PASS: ABI directory matches actual ELF machine; duplicates rejected')
spec=importlib.util.spec_from_file_location('instrument', ROOT/'scripts/check-instrumentation.py'); inst=importlib.util.module_from_spec(spec);spec.loader.exec_module(inst)
for output,expected in [('OK (5 tests)\nINSTRUMENTATION_CODE: -1\n',True),('OK (3 tests)\nINSTRUMENTATION_CODE: -1\n',False),('OK (5 tests)\nINSTRUMENTATION_CODE: 0\n',False),('OK (5 tests)\nINSTRUMENTATION_STATUS_CODE: -3\nINSTRUMENTATION_CODE: -1\n',False),('OK (5 tests)\n',False),('FAILURES!!!\nOK (5 tests)\nINSTRUMENTATION_CODE: -1\n',False)]:
    assert inst.verify(output,5)==expected,repr(output)
print('PASS: full instrumentation count, final result, ignored and failed runs')
