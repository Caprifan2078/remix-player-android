package app.remix.player
import java.io.ByteArrayOutputStream
fun release23Regression(){
    val absurd="[offset:9223372036854775807]\n[00:01.000]<00:01.000>one"
    val parsed=Lrc.parse(absurd).single()
    check(parsed.ms==1000L){"LRC overflow: ${parsed.ms}"}
    check(WordLyrics.parse(parsed).words.single().ms==1000L)
    check(Lrc.parse(TimeStretch.lyrics(absurd,.5)).single().ms==2000L)
    val negative="[offset:-9223372036854775808]\n[00:01.000]one"
    check(Lrc.parse(negative).single().ms==1000L)
    val out=ByteArrayOutputStream()
    check(runCatching{StemCore.header(out,Long.MAX_VALUE/2+1,2)}.isFailure){"WAV accepted overflowed length"}
    check(out.size()==0)
    check(runCatching{StemCore.header(out,1,0)}.isFailure)
    check(runCatching{StemCore.header(out,1,2,0)}.isFailure)
    val max=(0xffffffffL-36)/4;StemCore.header(out,max);check(out.size()==44)
    val invalid=ByteArrayOutputStream();check(runCatching{StemCore.header(invalid,max+1)}.isFailure&&invalid.size()==0)
    check(Lrc.parse("[offset:-500]\n[00:01.00]one").single().ms==500L)
    println("PASS: LRC offset overflow and WAV header dimension validation")
    data class Row(val id:String,val group:String)
    val rows=listOf(Row("a","a"),null,Row("b","a"),Row("a","b"),Row("c","missing"),Row("d","c"),Row("x","y"),Row("y","x"),Row("z","z"))
    val repaired=LibraryRecovery.recover(rows.size,{rows[it]?:error("corrupt row")},Row::id,Row::group,{it.copy(group=it.id)})
    check(repaired.skipped==2&&repaired.repaired==4)
    check(repaired.items.map{it.id}==listOf("a","b","c","d","x","y","z"))
    check(repaired.items.map{it.group}==listOf("a","a","c","d","x","y","z"))
    println("PASS: library recovery retains later rows, first duplicate and valid groups; repairs orphan and cyclic groups")
    val original="[00:04.000]one";check(Lrc.parse(GroupLyrics.preserve("",original,.5)).single().ms==8000L);check(GroupLyrics.preserve("own",original,.5)=="own");check(GroupLyrics.preserve("",original,null).isEmpty())
    println("PASS: regrouping retains explicit or inherited lyrics without assuming a new tempo ratio")
}
