#!/usr/bin/env bash
# Debug APK on disposable emulator only. Seeds original synthetic audio, not a neural model.
set -euo pipefail
pkg=app.remix.player
work=$(mktemp -d);trap 'rm -rf "$work"' EXIT
mkdir -p smoke-output
python3 - "$work" <<'PY'
import sys, wave, struct, math, json, xml.etree.ElementTree as ET
from pathlib import Path
p=Path(sys.argv[1]); frames=44100*60
uid='00000000-0000-0000-0000-000000000014'
uri='content://app.remix.player.files/mixes/mixer-test.wav'
# Each stem contains a distinct, low-volume original sinusoid.
for i,hz in enumerate([110,165,220,330]):
    block=b''.join(struct.pack('<hh',int(900*math.sin(2*math.pi*hz*j/44100)),int(900*math.sin(2*math.pi*hz*j/44100))) for j in range(44100))
    (p/f'{i}.pcm').write_bytes(block*60)
with wave.open(str(p/'mixer-test.wav'),'wb') as w:
    w.setparams((2,2,44100,frames,'NONE','not compressed'));w.writeframes((p/'0.pcm').read_bytes())
(p/'meta').write_text(f'{frames}\n4\n')
def prefs(name, vals):
    root=ET.Element('map')
    for k,v in vals.items(): ET.SubElement(root,'string',name=k).text=v
    ET.ElementTree(root).write(p/(name+'.xml'),encoding='utf-8',xml_declaration=True)
prefs('library',{'tracks':json.dumps([{'uri':uri,'title':'Mixer Test','artist':'Synthetic','group':uri,'lyrics':'[00:01]Test'}])})
prefs('stem_cache',{uri:uid});prefs('playback_bookmark',{'id':uri})
PY
adb shell am force-stop "$pkg"
uid=00000000-0000-0000-0000-000000000014
adb shell run-as "$pkg" mkdir -p files/mixes "files/stems/$uid" shared_prefs
put(){ adb shell -T run-as "$pkg" sh -c "'cat > $2'" < "$1"; }
put "$work/mixer-test.wav" files/mixes/mixer-test.wav
for i in 0 1 2 3; do put "$work/$i.pcm" "files/stems/$uid/$i.pcm"; done
put "$work/meta" "files/stems/$uid/meta"
for i in library stem_cache playback_bookmark; do put "$work/$i.xml" "shared_prefs/$i.xml"; done
# Notification permission is optional for actual playback; avoid an emulator permission dialog.
adb shell pm grant "$pkg" android.permission.POST_NOTIFICATIONS || true
adb shell am start -W -n "$pkg/.MainActivity" --ez open_mixer true
sleep 3
dump(){ adb shell uiautomator dump /sdcard/remix-mixer.xml >/dev/null; adb pull /sdcard/remix-mixer.xml "$1" >/dev/null; }
tap_label(){ dump "$work/ui.xml"; read -r x y < <(python3 - "$work/ui.xml" "$1" <<'PY'
import sys,re,xml.etree.ElementTree as ET
for n in ET.parse(sys.argv[1]).iter('node'):
    if n.get('text')==sys.argv[2]:
        x,y,X,Y=map(int,re.findall(r'\d+',n.get('bounds')));print((x+X)//2,(y+Y)//2);break
else: raise SystemExit('Button not found: '+sys.argv[2])
PY
); adb shell input tap "$x" "$y"; }
tap_label '▶ Слушать микс'
sleep 2
adb shell input keyevent KEYCODE_HOME
sleep 5
adb shell dumpsys activity services "$pkg/.MixerService" > smoke-output/mixer-background.txt
grep -q 'isForeground=true' smoke-output/mixer-background.txt
adb shell am start -W -n "$pkg/.MainActivity" --ez open_mixer true
sleep 2
dump smoke-output/mixer-ui.xml
python3 - <<'PY'
import re,xml.etree.ElementTree as ET
texts=[n.get('text','') for n in ET.parse('smoke-output/mixer-ui.xml').iter('node')]
positions=[int(m[1])*60+int(m[2]) for t in texts if (m:=re.fullmatch(r'Микшер · (\d+):(\d+)',t))]
assert positions and max(positions)>=5, texts
PY
tap_label 'Ⅱ Пауза микса'
sleep 2
adb shell dumpsys activity services "$pkg/.MixerService" > smoke-output/mixer-stopped.txt
if grep -q 'isForeground=true' smoke-output/mixer-stopped.txt; then exit 1; fi
adb logcat -d -s AndroidRuntime:E > smoke-output/mixer-crashes.txt
if grep -q 'FATAL EXCEPTION' smoke-output/mixer-crashes.txt; then exit 1; fi
