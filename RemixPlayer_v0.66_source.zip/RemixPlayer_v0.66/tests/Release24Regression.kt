package app.remix.player
fun release24Regression(){
    EqualizerSettings.restore{ i->when(i){1->Float.NaN;2->Float.POSITIVE_INFINITY;3->99f;4->-99f;5->error("wrong preference type");else->3f} }
    check(EqualizerSettings.get()==listOf(3f,0f,0f,12f,-12f,0f,3f,3f,3f,3f));EqualizerSettings.set(List(10){0f})
    println("PASS: EQ startup recovers NaN, infinity, wrong types and out-of-range values per band")
    val rows=listOf(ListeningStats.Entry("a",100,50),null,ListeningStats.Entry("b",10,60),ListeningStats.Entry("a",90,40),ListeningStats.Entry("a",120,70),ListeningStats.Entry("bad",-1,80),ListeningStats.Entry("",10,90))
    check(ListeningStats.recover(rows.size){rows[it]?:error("corrupt") }==listOf(rows[4],rows[2]))
    println("PASS: listening history isolates bad rows, deduplicates and retains newest valid totals")
    val ids=listOf("a",null,"a-remix","gone","b","a")
    val result=LibraryRecovery.playlist(ids.size,{ids[it]?:error("corrupt")},{when(it){"a","a-remix"->"a";"b"->"b";else->null}})
    check(result.toList()==listOf("a","b"))
    println("PASS: playlist recovery retains valid order, remaps versions, ignores bad/deleted members")
}
