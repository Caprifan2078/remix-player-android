package app.remix.player
import java.io.File
import kotlin.math.*
fun musicalIntelligenceTests(){
    fun f(i:Int,k:Int,rms:Double=.12)=SectionMap.Frame(i*2.0,rms,.35,.45,.20,.4,List(12){if(it==0).6 else if(it==k+1).4 else 0.0})
    val seq=listOf(0,1,2,3,4,5,6,7,0,1,2,3,4,5,6,7)
    val report=MusicAnalysis.Report(Tempo.Result(120.0,.8),0.0,"C major",.3,.12,32.0,List(8){.12},featureFrames=seq.mapIndexed{i,k->f(i,k)})
    val old=Arrangement.plan(report.energy,report.duration);check(old.none{it.part==Arrangement.Part.DROP})
    val new=SectionArrangement.plan(report);check(new.all{it.part==Arrangement.Part.DROP}&&new.size==2){new}
    check(new.zipWithNext().all{(a,b)->a.end==b.start}&&new.first().start==0.0&&new.last().end==32.0)
    val static=report.copy(featureFrames=List(16){f(it,0)});check(SectionArrangement.plan(static).none{it.part==Arrangement.Part.DROP})
    val intro=report.copy(duration=40.0,energy=List(10){if(it<6)0.0 else .12},featureFrames=List(20){i->f(i,i%8,if(i<12)0.0 else .12)})
    check(SectionArrangement.plan(intro).first().part==Arrangement.Part.BREAK)
    check(SectionArrangement.plan(report.copy(featureFrames=emptyList()))==old)
    check(SectionArrangement.plan(report.copy(featureFrames=report.featureFrames.drop(1)))==old)
    val profile=MusicalIntelligence.profile(report);check(profile.pulse!=null&&abs(profile.pulse-.4)<1e-9&&profile.tempo==120.0&&profile.brightness==null)
    check(MusicalIntelligence.profile(report.copy(rms=0.0)).labels.isEmpty())
    val soft=RemixAdvisor.recommend(report,goal=RemixAdvisor.Goal.SOFT);val strong=RemixAdvisor.recommend(report,goal=RemixAdvisor.Goal.ENERGETIC)
    check(soft.size==5&&strong.size==5&&soft.map{it.style.drive}.average()<strong.map{it.style.drive}.average());check((soft+strong).all{it.speed in .75..1.33})
    println("PASS: section-aware arrangement uses repeated phrases at constant energy, silence/static rejection, fallback, acoustic descriptors and goal-directed recommendations")
    val dir=kotlin.io.path.createTempDirectory("section-render").toFile();try {
        val raw=File(dir,"input.pcm");val frames=44100L*8;raw.outputStream().buffered().use{w->repeat(frames.toInt()){i->val v=(sin(2*PI*440*i/44100)*3000).toInt().toShort();StemCore.writeShort(w,v);StemCore.writeShort(w,v)}}
        val a=File(dir,"a.wav");val b=File(dir,"b.wav");val c=File(dir,"c.wav");val style=GenreEngine.styles.first();val sections=listOf(Arrangement.Section(0.0,4.0,Arrangement.Part.BREAK),Arrangement.Section(4.0,8.0,Arrangement.Part.DROP))
        GenreEngine.renderFromMix(raw,a,style,120.0,0.0,emptyList(),listOf(.1,.1))
        GenreEngine.renderFromMix(raw,b,style,120.0,0.0,emptyList(),listOf(.1,.1),sections=sections)
        GenreEngine.renderFromMix(raw,c,style,120.0,0.0,emptyList(),listOf(.1,.1),sections=sections)
        check(a.length()==44+frames*4&&b.length()==a.length()&&!a.readBytes().contentEquals(b.readBytes())&&b.readBytes().contentEquals(c.readBytes()))
    }finally{dir.deleteRecursively()}
    println("PASS: section plan changes rendered WAV, exact duration, deterministic rerender")
}
