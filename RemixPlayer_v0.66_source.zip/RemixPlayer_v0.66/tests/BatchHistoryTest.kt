package app.remix.player
fun batchHistoryTests(){
    val batch=QueueEdit.appendBatch(listOf("a","b"),listOf("b","c","c","d","e","e",""),4)
    check(batch.additions==listOf("c","d")&&batch.duplicates==3&&batch.overflow==1&&batch.invalid==1)
    check(QueueEdit.appendBatch(emptyList(),listOf("b","a","b")).additions==listOf("b","a"))
    val existing=List(300){"old$it"};check(QueueEdit.appendBatch(existing,listOf("new","old0")).let{it.additions.isEmpty()&&it.duplicates==1&&it.overflow==1})
    val large=QueueEdit.appendBatch(emptyList(),List(60000){"track$it"});check(large.additions.size==300&&large.overflow==59700)
    val entries=listOf(ListeningStats.Entry("a",1000,1),ListeningStats.Entry("remix",5000,8),ListeningStats.Entry("b",3000,4),ListeningStats.Entry("deleted",4000,10))
    val groups=ListeningStats.grouped(entries){when(it){"a","remix"->"a";"b"->"b";else->null}}
    check(groups==listOf(ListeningStats.Entry("a",6000,8),ListeningStats.Entry("b",3000,4)))
    check(ListeningStats.total(groups)==9000L)
    val max=listOf(ListeningStats.Entry("a",Long.MAX_VALUE,1),ListeningStats.Entry("b",100,2))
    check(ListeningStats.grouped(max){"same"}.single().playedMs==Long.MAX_VALUE&&ListeningStats.total(max)==Long.MAX_VALUE)
    println("PASS: bulk queue order, 300-item limit, exact version deduplication, 60000 candidates; grouped listening history, removed tracks, saturated totals")
}
