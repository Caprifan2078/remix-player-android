package app.remix.player
import kotlin.math.*
fun sectionMapTests(){
    fun f(i:Int,kind:Int)=SectionMap.Frame(i*2.0,if(kind==0).04 else .25,if(kind==0).85 else .05,if(kind==0).1 else .9,.05,if(kind==0).1 else .8,List(12){if(it==kind*5)1.0 else 0.0})
    val pattern=listOf(0,0,0,1,1,1,0,0,0,1,1,1)
    val frames=pattern.mapIndexed(::f);val sections=SectionMap.build(frames,24.0)
    check(sections.size==4){sections};check(sections.first().start==0.0&&sections.last().end==24.0);check(sections.zipWithNext().all{(a,b)->a.end==b.start});check(sections[1].repeatGroup!=null&&sections[1].repeatGroup==sections[3].repeatGroup);check(sections[0].repeatGroup!=sections[1].repeatGroup)
    check(SectionMap.build(frames.map{it.copy(rms=0.0)},24.0).isEmpty());check(SectionMap.build(frames.reversed(),24.0).isEmpty());check(SectionMap.build(frames.map{it.copy(mid=Double.NaN)},24.0).isEmpty())
    val a=MusicAnalysis.Analyzer(16000);repeat(16000*9){i->a.sample(.3*sin(2*PI*(if(i<64000)100 else 1000)*i/16000))};val r=a.finish();check(r.featureFrames.size==5);check(r.featureFrames.first().low>.95&&r.featureFrames[3].mid>.95);check(r.featureFrames.map{it.start}==listOf(0.0,2.0,4.0,6.0,8.0));check(r.featureFrames.all{it.chroma.all(Double::isFinite)})
    println("PASS: multi-feature section boundaries, repeated groups, invalid/silent input, streaming two-second spectral and tonal frames")
}
