package app.remix.player
import java.io.File
import kotlin.math.*
fun release43Tests(){
    val f=File.createTempFile("phase43-",".pcm")
    try{
        f.outputStream().buffered().use{w->repeat(44100*3){i->val x=(10000*sin(2*PI*440*i/44100)).toInt().toShort();StemCore.writeShort(w,x);StemCore.writeShort(w,(-x).toShort())}}
        val mood=MoodCore.input(f);check(mood.size==360000&&mood.take(72000).maxOrNull()!!>.2f&&mood.last()==0f)
        val pcm=AnalysisPcm.excerpt(f,0,44100*3,targetRate=16000);check(pcm.size==48000&&AstGenreCore.audible(pcm));check(AstGenreCore.features(pcm).all{it.isFinite()})
        check(AnalysisPcm.excerpt(f,123,4411,targetRate=16000).size==1601)
        check(runCatching{AnalysisPcm.excerpt(f,1,44100*3,targetRate=16000)}.isFailure)
    }finally{f.delete()}
    println("PASS: shared AST/MERT adaptive stereo input, exact sample counts, excerpt bounds and anti-phase preservation")
    fun seg(a:Long,b:Long,t:String)=WhisperSegments.Segment(a,b,t)
    val a=WhisperSegments.Window(0,25000,listOf(seg(20000,22000,"before"),seg(23000,24600,"cross"),seg(24600,24900,"tail")))
    val b=WhisperSegments.Window(23000,48000,listOf(seg(23000,24600,"cross"),seg(24600,24900,"tail"),seg(30000,31000,"cross")))
    val merged=WhisperSegments.merge(listOf(a,b));check(merged.map{it.text}==listOf("before","cross","tail","cross"));check(merged[1].startMs==23000L&&merged[1].endMs==24600L)
    check(WhisperSegments.merge(listOf(a))==a.segments);check(WhisperSegments.merge(emptyList()).isEmpty());check(runCatching{WhisperSegments.merge(listOf(b,a))}.isFailure)
    check(WhisperSegments.merge(listOf(a,b.copy(segments=emptyList())))==a.segments)
    check(WhisperSegments.parse("100\t101\tbad",0,1000).isEmpty())
    println("PASS: overlapping Whisper windows retain genuine repeats, original timestamps, edge segments and reject reversed input")
}
