package app.remix.player
import kotlin.math.abs
fun mixerTests(){
    for(count in listOf(4,6)){
        val ramp=GainRamp(FloatArray(count){1f},441);val target=FloatArray(count){if(it==3)0f else .25f};ramp.set(target)
        var old=1f;repeat(441){ramp.advance();check(ramp.current[3]<=old&&abs(ramp.current[3]-old)<.003f);old=ramp.current[3]};check(ramp.current.contentEquals(target))
        ramp.set(FloatArray(count){1f});repeat(100){ramp.advance()};val mid=ramp.current.copyOf();ramp.set(FloatArray(count));ramp.advance();check(ramp.current.indices.all{abs(ramp.current[it]-mid[it])<.003f});repeat(440){ramp.advance()};check(ramp.current.all{it==0f})
        check(runCatching{ramp.set(FloatArray(count){Float.NaN})}.isFailure)
        val samples=ShortArray(count){10000};check(StemCore.mix(samples,ramp.current)==0.toShort());ramp.set(FloatArray(count){if(it==3)1f else 0f});repeat(441){ramp.advance()};check(StemCore.mix(samples,ramp.current)==10000.toShort())
    }
    val g=MixerGeneration();val a=g.begin();val b=g.begin();check(!g.finish(a)&&g.active==b);check(g.finish(b)&&g.active==null);val c=g.begin();g.cancel();val d=g.begin();check(!g.finish(c)&&g.active==d);check(g.finish(d));println("PASS: stereo-frame gain ramps, retargeting, mute/solo, invalid gains, stale playback completion rejection")
}
