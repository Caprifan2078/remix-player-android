package app.remix.player
import kotlin.math.*
fun barArrangementTests(){
    val rate=8000;val duration=31.0;val frames=(duration*rate).toLong();val energy=listOf(.04,.18,.04,.28,.12,.08,.16,.06)
    val grid=AdaptiveGroove(137.0,.17,listOf(RhythmMap.Window(0.0,16.0,137.0,.9),RhythmMap.Window(16.0,31.0,112.0,.9)),137.0,rate)
    val old=Arrangement.plan(energy,duration);check(old.drop(1).any{abs(grid.position((it.start*rate).roundToLong())/16-round(grid.position((it.start*rate).roundToLong())/16))>.1})
    val aligned=Arrangement.aligned(energy,frames,grid,rate);check(aligned.size>=3);check(aligned.first().start==0.0&&aligned.last().end==duration);check(aligned.zipWithNext().all{(a,b)->a.end==b.start&&a.end>a.start})
    check(aligned.drop(1).all{val pos=grid.position((it.start*rate).roundToLong());abs(pos-round(pos/16)*16)<.002})
    check(Arrangement.aligned(emptyList(),7,grid,rate).single().end==7.0/rate)
    val e=Arrangement.Envelope(listOf(Arrangement.Section(0.0,1.0,Arrangement.Part.BUILD),Arrangement.Section(1.0,1.5,Arrangement.Part.OUTRO)),rate)
    var oldRiser=0f;var oldDrums=0f;var maxR=0f;var maxD=0f
    repeat(rate*3/2){i->val x=e.sample(i.toLong());if(i>0){maxR=max(maxR,abs(x.riser-oldRiser));maxD=max(maxD,abs(x.drums-oldDrums))};oldRiser=x.riser;oldDrums=x.drums};check(maxR<.002&&maxD<.002&&oldDrums<.001){"riser $maxR drums $maxD"}
    println("PASS: adaptive bar-aligned arrangement, variable tempo, short tracks, smooth riser and short outro (max step $maxR / $maxD)")
    val style=GenreEngine.styles.first().copy(kick=intArrayOf(),snare=intArrayOf(0),hat=intArrayOf())
    val snare=GenreEngine.Beat(style,120.0,0.0,44100);check(snare.sample(0)==0f)
    repeat(7055){i->snare.sample((i+1).toLong())};check(abs(snare.sample(7056))<.0001)
    val hat=GenreEngine.Beat(style.copy(snare=intArrayOf(),hat=intArrayOf(0)),120.0,0.0,44100);check(hat.sample(0)==0f);repeat(3086){i->hat.sample((i+1).toLong())};check(abs(hat.sample(3087))<.0001)
    println("PASS: precomputed percussion curves, zero-onset snare/hat and bounded smooth voice tails")
}
