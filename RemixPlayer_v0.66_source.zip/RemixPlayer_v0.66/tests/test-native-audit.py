import importlib.util, pathlib, struct, tempfile, zipfile
p=pathlib.Path(__file__).resolve().parents[1]/'scripts/check-native-apk.py'
spec=importlib.util.spec_from_file_location('audit',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def elf(align,off=0,va=0,machine=183):
    b=bytearray(120);b[:6]=b'\x7fELF\x02\x01';struct.pack_into('<H',b,18,machine);struct.pack_into('<Q',b,32,64);struct.pack_into('<HH',b,54,56,1);struct.pack_into('<IIQQQQQQ',b,64,1,5,off,va,0,0,0,align);return b
assert m.elf_errors(elf(16384))==[]
assert m.elf_errors(elf(4096))
assert m.elf_errors(elf(16384,4096,0))
assert m.elf_errors(b'broken')
with tempfile.TemporaryDirectory() as d:
    f=pathlib.Path(d)/'fixture.apk'
    for full in (False,True):
        with zipfile.ZipFile(f,'w',compression=zipfile.ZIP_DEFLATED) as z:
            for abi in ('arm64-v8a','x86_64'):
                for name in ('libremixmp3.so','libremixwhisper.so','libonnxruntime.so') if full else ('libremixmp3.so',):
                    z.writestr(f'lib/{abi}/{name}',elf(16384,machine=183 if abi=='arm64-v8a' else 62))
        assert m.audit(f)==(0 if full else 1)
print('PASS: synthetic ELF64 16 KiB alignment gate and mandatory native libraries for both ABIs')
