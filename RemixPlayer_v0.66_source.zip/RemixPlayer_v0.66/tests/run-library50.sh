#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp=$(mktemp -d);trap 'rm -rf "$tmp"' EXIT
printf 'package app.remix.player\nfun main(){libraryPageTests();librarySearchTests();groupingTests();trackMetadataTests()}\n' > "$tmp/Main.kt"
kotlinc app/src/main/java/app/remix/player/{LibraryPage,LibrarySearch,GroupingCore,TrackMetadata}.kt tests/{LibraryPageTest,LibrarySearchTest,GroupingTest,TrackMetadataTest}.kt "$tmp/Main.kt" -include-runtime -d "$tmp/test.jar"
java -Xmx1g -jar "$tmp/test.jar"
