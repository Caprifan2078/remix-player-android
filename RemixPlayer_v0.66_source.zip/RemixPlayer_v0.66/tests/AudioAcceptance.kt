package app.remix.player
import java.io.File
import kotlin.math.*
/** Host-side audio acceptance: actual WAV rendering from a deliberately loud, original stereo fixture. */
fun main(args:Array<String>){
    require(args.size==1);val dir=File(args[0]);dir.mkdirs();require(dir.isDirectory)
    val raw=File(dir,"fixture.pcm");val n=44100*4
    raw.outputStream().buffered().use{out->repeat(n){i->val t=i/44100.0;val beat=t%.5;val root=listOf(48,55,53,57)[(t/1).toInt().coerceAtMost(3)];val f=440*2.0.pow((root-69)/12.0);val bass=.49*sin(2*PI*f*t);val lead=.24*sin(2*PI*f*4*t);val kick=.22*sin(2*PI*58*beat)*exp(-beat*18);val side=.07*sin(2*PI*740*t);StemCore.writeShort(out,StemCore.pcm((bass+lead+kick+side).toFloat()));StemCore.writeShort(out,StemCore.pcm((bass+lead+kick-side).toFloat()))}}
    val chord=(0 until 8).map{Harmony.Chord(it*.5, listOf(0,7,5,9)[it/2], false,.95)}
    File(dir,"manifest.tsv").printWriter().use{m->m.println("file\tcategory\tname\tframes");for((i,p) in Presets.all.withIndex()){val f=File(dir,"effect-%02d.wav".format(i));EffectRender.render(raw,f,p);m.println("${f.name}\teffect\t${p.name}\t${(EffectRender.outputBytes(n.toLong(),p)-44)/4}")};for((i,s) in GenreEngine.styles.withIndex()){val f=File(dir,"genre-%02d.wav".format(i));GenreEngine.renderFromMix(raw,f,s,120.0,0.0,chord,List(400){.4});m.println("${f.name}\tgenre\t${s.name}\t$n");val g=File(dir,"neural-%02d.wav".format(i));val frames=NeuralInstrumental.render(g,NeuralInstrumental.Settings(NeuralInstrumental.Style.DANCE,s.target,0,true,2,61,genre=i));m.println("${g.name}\tneural\t${s.name}\t$frames")}}
    println("Rendered ${Presets.all.size+GenreEngine.styles.size*2} WAV files")
}
