package app.remix.player
import java.io.File
fun effectCheckpointTests(){
    val root=kotlin.io.path.createTempDirectory("checkpoint-test").toFile()
    try{
        val raw=File(root,"raw.pcm");raw.writeBytes(ByteArray(4*2048){(it%121).toByte()});val dir=EffectCheckpoint.directory(root,java.util.UUID.randomUUID().toString());val presets=listOf(Preset("One"),Preset("Two"),Preset("Three"));val calls=mutableListOf<String>()
        val progress:(Int,Preset,Int)->Unit={_,_,_->}
        fun render(a:File,b:File,p:Preset,cb:(Int)->Unit){calls.add(p.name);EffectRender.render(a,b,p,cb)}
        check(runCatching{EffectCheckpoint.render(raw,dir,presets,progress){a,b,p,cb->if(p.name=="Two")error("simulated termination");render(a,b,p,cb)}}.isFailure)
        check(calls==listOf("One"));check(File(dir,"version-0.wav").isFile);check(!File(dir,"version-1.wav").exists())
        val orphan=File(dir,"stretch-orphan.wav").apply{writeText("incomplete")};calls.clear();val results=EffectCheckpoint.render(raw,dir,presets,progress,::render);check(calls==listOf("Two","Three"));check(results.size==3);check(!orphan.exists())
        val f=results[1].second;java.io.RandomAccessFile(f,"rw").use{it.seek(100);it.writeByte(255)};calls.clear();EffectCheckpoint.render(raw,dir,presets,progress,::render);check(calls==listOf("Two"))
        calls.clear();check(runCatching{EffectCheckpoint.render(raw,dir,listOf(Preset("One",bass=.5f),presets[1],presets[2]),progress,::render)}.isFailure);check(calls.isEmpty());raw.appendBytes(ByteArray(4));calls.clear();check(runCatching{EffectCheckpoint.render(raw,dir,presets,progress,::render)}.isFailure);check(calls.isEmpty());check(runCatching{EffectCheckpoint.directory(root,"../bad")}.isFailure)
        println("PASS: resumable effect batch, retained completed work, same-size corruption repair, source/preset change rejection, path validation")
    }finally{root.deleteRecursively()}
}
