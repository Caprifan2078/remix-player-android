package app.remix.player
fun phraseAlignTests(){
    val raw="[offset:100]\n[00:01]Hello world\n[00:03]This is\n[00:04]a test\n[00:07]Noise\n[00:09]Привет мир"
    val r=PhraseAlign.align(raw,"Hello, world!\nThis is a test.\nПривет, мир!")
    check(r.complete&&r.skipped==1&&r.corrected==0);check(Lrc.parse(r.lrc).map{it.ms}==listOf(1100L,3100L,9100L));check(!r.lrc.contains('<'))
    val repeated="[00:01]Hello world\n[00:03]Hello world";check(PhraseAlign.align(repeated,"Hello world").ambiguous);check(PhraseAlign.align(repeated,"Hello world\nHello world").complete)
    val error="[00:01]I can see a light";check(!PhraseAlign.align(error,"I can see a night").complete);check(PhraseAlign.align(error,"I can see a night",true).let{it.complete&&it.corrected==1});check(!PhraseAlign.align(error,"I can hear a night",true).complete)
    check(!PhraseAlign.align("[00:01]one two three four","one two\nthree four").complete)
    check(!PhraseAlign.align("[00:01]one two\n[00:30]three four","one two three four").complete)
    check(PhraseAlign.align("[00:01]<00:01>hello","hello").complete)
    check(runCatching{PhraseAlign.align("[00:01]hello\n[00:01]hello","hello")}.isFailure)
    check(runCatching{PhraseAlign.align("[00:01]hello","[00:02]hello")}.isFailure)
    println("PASS: phrase-level reference alignment, original starts, split ASR phrases, optional single-word correction, ambiguity and invalid inputs")
}
