package app.remix.player
import kotlin.math.*
fun overlapTests(){
    check(OverlapCore.window(60000,120000,5000)==OverlapCore.Window(55000,5000));check(OverlapCore.window(3000,2100,8000)==OverlapCore.Window(2300,700));check(OverlapCore.window(1000,3000,3000)==null);check(OverlapCore.window(-1,4000,3000)==null)
    var old=1f;var next=0f
    for(i in -100L..5100L){val g=OverlapCore.gains(i,5000);check(g.outgoing in 0f..1f&&g.incoming in 0f..1f&&g.incoming+g.outgoing<=1.000001f);check(g.outgoing<=old+1e-6&&g.incoming>=next-1e-6);old=g.outgoing;next=g.incoming}
    check(OverlapCore.eligible(1f,1f,false,false,false,false));check(!OverlapCore.eligible(1f,1f,true,false,false,false));check(!OverlapCore.eligible(1f,1f,false,true,false,false));check(!OverlapCore.eligible(1f,1f,false,false,true,false));check(!OverlapCore.eligible(1f,1f,false,false,false,true));check(!OverlapCore.eligible(.8f,1f,false,false,false,false));check(OverlapCore.drift(1000,1500)&&!OverlapCore.drift(1000,1100));check(OverlapCore.handoffPosition(10000,5000)==4999L)
    println("PASS: live overlap planning, 5201 gain pairs, bounded correlated peak, short/unknown durations, exclusion conditions and handoff bounds")
}
