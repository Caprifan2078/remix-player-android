# Acceptance 0.66

Baseline v0.65: tests/qa66/boundary-before2.log reproduces 4,182 non-finite resampler outputs and acceptance of a too-long queue ID. The first baseline attempt had missing compile dependencies and is preserved separately; it was not a functional test result. After fixes, tests/qa66/boundary-after.log confirms four passing groups, including legacy quality and queue tests. PCM test spans seven rates and three non-finite values (21 cases), unaffected channel, recovery, length, and repeated finish.

Fresh checks: tests/qa66/syntax.log (syntax only); mp3.log (host JNI and FFmpeg); effects.log (offline effect rendering); native-audit.log and release-gates.log (synthetic gate tests, not APK verification). Android toolchain preflight blocked; see android-build.log.

The default kotlinc heap failed in core-before.log. A subsequent run compiled but was interrupted by an in-flight shell script edit (core-after.log), not a product test failure. Final run evidence: core-final.log and core-final.exit.

Run all with `bash tests/run-core.sh`, `bash tests/run-boundary66.sh`, `bash tests/run-effects65.sh`, `bash tests/run-mp3-host.sh`, `bash tests/run-syntax-audit.sh`, `python3 tests/test-native-audit.py`, `python3 tests/test-release-gates.py`.

Final clean JVM run: **115 PASS groups, exit 0**. Separate targeted, MP3, effects and syntax checks also exit 0.
