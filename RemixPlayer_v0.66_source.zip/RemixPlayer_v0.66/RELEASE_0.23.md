# Remix Player 0.23.0 — targeted reliability audit

Base: exact v0.22 source ZIP. No speculative new AI feature or model added.

## Repairs
- LRC offset overflow: malformed offsets outside the representable LRC range are ignored. Line and word timestamps share bounded arithmetic; retiming uses the same offset. Normal offsets remain supported. Extremely long timestamps are capped at 999:59.999 (the parser's range).
- RIFF/WAV header: validate channel count, sampling rate, byte rate and frame count before multiplying and before writing anything. Reject unsupported RIFF sizes instead of emitting wrapped lengths.
- Library loading: independently parse rows; keep the first duplicate URI; preserve readable rows after an invalid one; promote orphan/cyclic/indirect groups to standalone songs, rather than guessing a parent. Attempt to save the original JSON to an internal recovery file and display a warning. If internal storage is not writable, the UI warns that the snapshot could not be saved. Recovery snapshot is private; a user-facing export/recovery wizard is not implemented.
- Group merging: manual and suggested grouping use one helper; verify both roots are still present; preserve explicit/inherited lyrics before changing parent; clear old tempo ratios because the new relationship is unknown; carry favorites and playlist membership, remove obsolete preferred-version mapping. For unknown ratios, switching versions starts at the beginning rather than guessing a position.

## Evidence and boundaries
- tests/RELEASE23_BEFORE.txt records two independent failures on the old implementation (LRC overflow and WAV header overflow).
- tests/RELEASE23_AFTER.txt records three targeted PASS groups on changed JVM code (including library recovery and lyric preservation). The runnable script is tests/run-release23-regression.sh. They are not device tests.
- tests/SYNTAX_AUDIT.txt: 102 Kotlin files parsed. Syntax parsing is not Android typechecking.
- tests/MP3_RESULT.txt: 4 bitrates generated via host JNI and independently decoded via FFmpeg.
- tests/NATIVE_AUDIT_RESULT.txt: synthetic ELF alignment test passed; no Android .so or APK was audited.
- tests/RESULT.txt: full v0.23 suite did not complete before container time limit. The original v0.22 result is separately preserved as tests/RESULT_v0.22.txt; do not count it as a v0.23 result.
- No Gradle, SDK or adb in environment. No Android compilation, CI execution, emulator/device run or real neural model inference. No repo creation or code publication. Crossfade and neural quality are unverified. The full release is not ready.

## Acceptance gates
1. Android compile, lint, APK and native checks; then instrumented tests on API 29 and 35 and smoke on physical phone.
2. Recover malformed library fixture; verify later tracks remain visible and original data remains in the recovery directory.
3. Group two songs with an inherited lyric version, check that lyrics remain synchronized to that file and version switching no longer assumes the old tempo relation.
4. Test background playback, real overlap, mixer and network model installation on device. Measure memory/CPU/battery before deciding whether to port hot paths to Rust.
5. Listen to representative music; evaluate separation, karaoke and remix quality against source audio. Professional singing ASR and fully generative arrangements remain unfinished.
